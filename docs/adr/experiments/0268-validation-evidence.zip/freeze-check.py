from pathlib import Path
import subprocess,hashlib,json,sys,datetime
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0268')
def capture():
 names=sorted(set(subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=r).split(b'\0'))-{b''})
 return {'base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=r,text=True),'files':{n.decode():hashlib.sha256((r/n.decode()).read_bytes()).hexdigest()for n in names}}
state=capture()
if sys.argv[1]=='before':
 state['started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (p/'frozen-before.json').open('x') as f:json.dump(state,f,indent=2);f.write('\n')
 print({'frozen_files':len(state['files']),'base_revision':state['base_revision']})
else:
 before=json.loads((p/'frozen-before.json').read_text());assert all(state[k]==before[k]for k in ['base_revision','status','files'])
 with (p/'frozen-after.json').open('x') as f:json.dump({'status':'passed','files_unchanged':len(state['files']),'base_revision':state['base_revision'],'git_status_unchanged':True,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_sha256':hashlib.sha256((p/'frozen-before.json').read_bytes()).hexdigest()},f,indent=2);f.write('\n')
 print({'status':'passed','frozen_files_unchanged':len(state['files'])})
