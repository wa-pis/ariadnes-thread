from pathlib import Path
import sys,json,time,hashlib
sys.path.insert(0,'/Users/agrudin/dev/my/ariadna/tests')
from space_nav._owner_endpoint_fixture import produce,Budget
from test_owner_endpoint_fixture import _factory,Clock
from space_nav import _owner_endpoint_run as run
root=Path('/private/tmp/ariadna-f18-0268')
packet=produce(factory=_factory,budget=Budget(0.0,Clock()));assert packet['status']=='passed',packet['failure']
encoded=json.dumps(packet,allow_nan=False,sort_keys=True)
original=run._worker_command
# The real cold parent runs fake producer bytes and its actual independent auditor.
def parent(source,directory,started):
 code=("import sys\nfrom space_nav import _owner_endpoint_run as r\n"
       "original=r._worker_command\n"
       f"raw={encoded!r}\n"
       "r._worker_command=lambda kind,*args:([sys.executable,'-c','import sys;sys.stdout.write('+repr(raw)+')'] if kind=='produce' else original(kind,*args))\n"
       f"sys.exit(r.main(['--parent',{str(source)!r},{str(directory)!r},{repr(started)!r}]))\n")
 return [sys.executable,'-c',code]
run._parent_command=parent
began=time.monotonic();report=run.run_isolated(json.dumps(run._INPUT).encode(),root/'artificial-cold-packet')
assert report['status']=='passed',report
assert report['parent']['producer_mode']=='injected'
assert not any(x=='tudatpy' or x.startswith('tudatpy.') or x=='spiceypy' for x in sys.modules)
result={'schema':'ariadna.f18.artificial-cold-qualification.v1','status':'passed','mode':'injected','actual_private_native_factories':0,'actual_private_native_integrations':0,'actual_private_owner_visitor_calls':0,'logical_simulated_counts':packet['counts'],'calls_checked':8,'saved_analytic_arcs_checked':2,'observed_after_supervisor_fsync_s':time.monotonic()-began,'report':report,'raw_files':{str(p.relative_to(root)): {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (root/'artificial-cold-packet').rglob('*') if p.is_file()}}
with (root/'artificial-cold-qualification.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print({k:result[k]for k in ['status','mode','actual_private_native_integrations','calls_checked','observed_after_supervisor_fsync_s']})
