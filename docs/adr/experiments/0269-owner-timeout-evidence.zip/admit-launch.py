from pathlib import Path
import json,hashlib,time,subprocess,sys,os,datetime
p=Path('/private/tmp/ariadna-f18-0269');r=Path('/Users/agrudin/dev/my/ariadna');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
profile=json.loads((p/'profile.json').read_text());before=json.loads((p/'root-preflight.json').read_text());start=json.loads((p/'preflight-start.json').read_text())
assert sys.executable==start['interpreter'];elapsed=time.monotonic()-start['started_s'];assert 0<=elapsed<600
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==profile['base_revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
for name,m in profile['source_pins'].items():assert (r/name).stat().st_size==m['bytes']and sha(r/name)==m['sha256']
for name,key in [('native-entry.py','entry_sha256'),('launch-once.py','launch_sha256'),('call-once.py','caller_sha256')]:assert sha(p/name)==profile[key]
assert sha(profile['sandbox_profile'])==profile['sandbox_sha256']
for m in before['native_pins']+before['resources']:assert Path(m['path']).stat().st_size==m['bytes']and sha(m['path'])==m['sha256']
for name,h in before['old_timers_ledgers'].items():assert sha(name)==h
assert os.statvfs('/private/tmp/ariadna-f17-0263/volume').f_flag&os.ST_RDONLY
assert json.loads((p/'operational-before.json').read_text())['manifest_equal']
reviews={n:json.loads((p/n).read_text())for n in ('independent-admission.json','independent-controls.json')}
assert reviews['independent-admission.json']['status']=='PASS'
assert reviews['independent-controls.json']['status']=='PASS'
assert json.loads((p/'fake-cleanup-check.json').read_text())['status']=='PASS'
assert json.loads((p/'caller-fake-qualification.json').read_text())['status']=='passed'
assert not(p/'episode-start.json').exists()and not Path(profile['work_directory']).exists()
x={'schema':'ariadna.f18.native-launch-admission.v1','status':'PASS','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'interpreter':sys.executable,'elapsed_s':time.monotonic()-start['started_s'],'ceiling_s':600,'profile_sha256':sha(p/'profile.json'),'independent_reviews':{n:{'sha256':sha(p/n),'status':v['status']}for n,v in reviews.items()},'entry_launcher_caller_pins':{k:profile[k]for k in ('entry_sha256','launch_sha256','caller_sha256')},'root_independent_script_review':'Root read native-entry/launch-once authored by controls reviewer; controls reviewer separately read rootcaller. Pinned qualified runtime untouched.','new_native_entries':0,'old_clocks_reset':False,'preflight_resources_kernels_sources_unchanged':True,'read_only_image':True,'operational_before_paths':71459,'bounded_scope':'One fixed analytic packet; all failure consumes; no retry,newdata,build,SPICE,physicalmission.'}
assert 0<=x['elapsed_s']<600
with(p/'launch-admission.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print({'status':x['status'],'elapsed_s':x['elapsed_s'],'profile_sha256':x['profile_sha256']})
