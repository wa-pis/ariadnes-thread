from pathlib import Path
import json,hashlib,os,time,subprocess,datetime,stat
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0269');v=Path('/private/tmp/ariadna-f17-0263/volume')
start=json.loads((p/'preflight-start.json').read_text());now=time.monotonic();assert 0<=now-start['started_s']<600
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
q=json.loads((r/'docs/adr/experiments/0268-qualification.json').read_text());prov=json.loads(Path('/private/tmp/ariadna-f17-0266/provisioning-receipt.json').read_text())
for name,meta in q['source_pins'].items():assert (r/name).stat().st_size==meta['bytes'] and sha(r/name)==meta['sha256'],name
for item in prov['old_pins_unchanged']+prov['complete_required_files']:
 path=Path(item['path']);assert path.is_file() and not path.is_symlink();assert path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],str(path)
for name,h in prov['old_timers_ledgers_unchanged'].items():assert sha(name)==h,name
extraold=[Path('/private/tmp/ariadna-f17-0266')/n for n in ('preflight-start.json','acquisition-precharge.json','packet/episode-start.json','packet-stage.json','packet-finalization.json','offline-audit.json')]
statv=os.statvfs(v);assert statv.f_flag&os.ST_RDONLY
assert statv.f_blocks*statv.f_frsize<=8*1024**3
assert len([x for x in (v/'home/.tudat/resource').rglob('*')if x.is_file()])==5
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert base=='a6e89e3da46c4a05525f3cd72ef21347f0d0e5bf'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
assert not(p/'episode-start.json').exists() and not(p/'native-packet').exists()
x={'schema':'ariadna.f18.native-preflight-files.v1','status':'passed_static_files_pending_control_admission','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-start['started_s'],'base_revision':base,'source_pins':q['source_pins'],'native_pins':prov['old_pins_unchanged'],'resources':prov['complete_required_files'],'resource_bytes':131662,'old_timers_ledgers':prov['old_timers_ledgers_unchanged']|{str(x):sha(x)for x in extraold},'read_only_mount':True,'scratch_capacity_bytes':statv.f_blocks*statv.f_frsize,'scratch_ceiling_bytes':8*1024**3,'new_acquisition_bytes':0,'aggregate_acquisition_bytes':497045495,'aggregate_ceiling_bytes':2*1024**3,'resource_identity':'Exact retained local payloads only; upstream2.4content authenticity remains unverified.','work':'No native/scientific imports,SPICE,build,integration,formula evaluation or payload copies during this file preflight.','operational_prefix':'/opt/homebrew/Caskroom/miniforge/base/envs/space-nav','prefix_enforcement':'Future sandbox denies all operationalprefixreads and all network; readonlyimage;writes onlyexclusiveoutputnamespace.'}
with (p/'root-preflight.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print({'status':x['status'],'elapsed_s':x['elapsed_s'],'capacity_bytes':x['scratch_capacity_bytes']})
