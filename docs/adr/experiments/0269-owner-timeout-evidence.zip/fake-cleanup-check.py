"""Artificial PID-group cleanup qualification; no project/native imports."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


def main() -> None:
    root = Path(__file__).parent
    spec = importlib.util.spec_from_file_location("launch_once", root / "launch-once.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    observations: list[dict[str, object]] = []
    for dead_leader in (False, True):
        code = ("import os,subprocess,sys,time; "
                "p=subprocess.Popen([sys.executable,'-I','-S','-c','import time; time.sleep(30)']); "
                "print(p.pid,flush=True); " + ("" if dead_leader else "time.sleep(30)"))
        process = subprocess.Popen([sys.executable, "-I", "-S", "-c", code],
                                   stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                   start_new_session=True, text=True)
        assert process.stdout is not None
        child = int(process.stdout.readline())
        os.kill(child, 0)
        if dead_leader:
            assert process.wait(timeout=2) == 0
        with tempfile.TemporaryDirectory(prefix="f18-fake-group-") as directory:
            record = Path(directory) / "parent.pgid"
            with record.open("xb") as stream:
                stream.write((str(process.pid) + "\n").encode())
            assert module.kill_parent_group(record) == process.pid
            if not dead_leader:
                process.wait(timeout=2)
            deadline = time.monotonic() + 2
            live = True
            while time.monotonic() < deadline:
                try:
                    os.kill(child, 0)
                except ProcessLookupError:
                    live = False
                if not live:
                    break
                time.sleep(0.01)
            assert not live, "fake descendant survived recorded-group cleanup"
            observations.append({"leader_exited_before_cleanup": dead_leader,
                                 "recorded_pgid": process.pid, "child_pid": child,
                                 "no_live_descendant_after_cleanup": True})
        process.stdout.close()
    receipt = {"schema": "ariadna.f18.artificial-launch-cleanup.v1", "status": "PASS",
               "native_imports": 0, "native_factories": 0, "native_integrations": 0,
               "inputs": "two Python sleep descendants; alive leader and dead leader",
               "checks": observations}
    with (root / "fake-cleanup-check.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
