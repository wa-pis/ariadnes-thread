"""One native packet, guarded by immutable preflight and qualified watcher."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
import time
from typing import Any


def kill_parent_group(path: Path) -> int | None:
    """Kill the recorded group even after its original leader has exited."""
    if not path.exists():
        return None
    raw = path.read_bytes()
    if len(raw) > 32 or not raw.strip().isdigit():
        raise RuntimeError("invalid bounded parent PGID record")
    pgid = int(raw)
    if pgid <= 1 or pgid in {os.getpid(), os.getpgrp()}:
        raise RuntimeError("unsafe parent PGID record")
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return pgid


def main() -> int:
    profile_path = Path(sys.argv[1]).resolve()
    profile = json.loads(profile_path.read_bytes())
    started = float(sys.argv[2])
    if not math.isfinite(started) or not 0 <= time.monotonic() - started < 60.0:
        raise RuntimeError("inherited caller60s clock required")
    repo = Path(profile["repo"])
    work = Path(profile["work_directory"])
    preflight_started = float(profile["preflight_started_s"])
    now = time.monotonic()
    if not math.isfinite(preflight_started) or not 0 <= now - preflight_started < 600:
        raise RuntimeError("preflight600s exhausted or incomparable")
    for name, expected in profile["source_pins"].items():
        raw = (repo / name).read_bytes()
        if len(raw) != expected["bytes"] or hashlib.sha256(raw).hexdigest() != expected["sha256"]:
            raise RuntimeError("frozen source mismatch: " + name)
    entry = Path(__file__).with_name("native-entry.py")
    if hashlib.sha256(entry.read_bytes()).hexdigest() != profile["entry_sha256"]:
        raise RuntimeError("native entry pin mismatch")
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != profile["launch_sha256"]:
        raise RuntimeError("launch pin mismatch")
    if hashlib.sha256(Path(profile["sandbox_profile"]).read_bytes()).hexdigest() != profile["sandbox_sha256"]:
        raise RuntimeError("sandbox pin mismatch")
    admission = json.loads(Path(profile["prelaunch_admission"]).read_bytes())
    if admission.get("status") != "PASS":
        raise RuntimeError("prelaunch admission unavailable")
    environment = profile["environment"]
    if environment.get("PYTHONPATH") != str(repo / "src") or environment.get("PYTHONDONTWRITEBYTECODE") != "1":
        raise RuntimeError("fixed source bootstrap environment required")
    sys.path.insert(0, str(repo / "src"))
    from space_nav import _owner_endpoint_run as controller
    work.mkdir(parents=False, exist_ok=False)
    marker = {"schema": "ariadna.f18.native-consumed.v1", "profile_sha256": hashlib.sha256(profile_path.read_bytes()).hexdigest(),
              "preflight_elapsed_s": time.monotonic() - preflight_started,
              "status": "consumed-before-native-entry", "retry_authorized": False}
    if not 0 <= marker["preflight_elapsed_s"] < 600:
        raise RuntimeError("preflight600s exhausted before consumption")
    with (work / "consumed.json").open("xb") as stream:
        stream.write(controller._json_bytes(marker))
        stream.flush()
        os.fsync(stream.fileno())
    evidence = controller._Evidence(work, 0)
    evidence.caps["producer.json"] = controller.REPORT_BYTES
    evidence.caps["producer.stderr.log"] = 0
    output, errors = work / "producer.json", work / "producer.stderr.log"
    evidence.write(output, b"")
    evidence.write(errors, b"")
    report: dict[str, Any] = {"schema": "ariadna.f18.native-launch.v1", "status": "failed",
                              "started_s": started, "deadline_s": started + 60.0,
                              "failure": None, "parent_pgid": None,
                              "physical_admission": "unavailable"}
    command = ["/usr/bin/sandbox-exec", "-f", profile["sandbox_profile"],
               profile["private_python"], "-B", str(entry), str(profile_path), repr(started)]
    old_environment = os.environ.copy()
    old_directory = Path.cwd()
    try:
        os.environ.clear()
        os.environ.update(environment)
        os.chdir(work)
        report["worker"] = controller._watch_worker(command, output, errors, started + 60.0, evidence)
        report["supervisor"] = controller._read(output, controller.REPORT_BYTES)
        supervisor = report["supervisor"]
        if (report["worker"]["exit_code"] != 0 or supervisor.get("status") != "passed"
                or supervisor.get("finalization") != "checked-after-fsync"):
            raise RuntimeError("native supervisor failed or unfinalized")
        report["status"] = "passed"
    except (OSError, RuntimeError, ValueError, TypeError) as exc:
        report["failure"] = f"{type(exc).__name__}: {exc}"[:2048]
    finally:
        try:
            report["parent_pgid"] = kill_parent_group(work / "parent.pgid")
        finally:
            os.chdir(old_directory)
            os.environ.clear()
            os.environ.update(old_environment)
    report["elapsed_after_group_cleanup_s"] = time.monotonic() - started
    report["group_cleanup_completed"] = True
    if report["elapsed_after_group_cleanup_s"] >= 60.0:
        report["status"], report["failure"] = "failed", report["failure"] or "inclusive60s cleanup exhausted"
    structured = sum(path.stat().st_size for path in work.rglob("*") if path.is_file() and not path.name.endswith(".log"))
    logs = sum(path.stat().st_size for path in work.rglob("*.log"))
    report["structured_bytes_before_receipt"] = structured
    report["log_bytes"] = logs
    if structured + controller.REPORT_BYTES > controller.EVIDENCE_BYTES or logs > controller.LOG_BYTES:
        report["status"], report["failure"] = "failed", report["failure"] or "aggregate packet byte cap"
    report["elapsed_before_receipt_s"] = time.monotonic() - started
    evidence.write(work / "receipt.json", controller._json_bytes(report))
    controller._sync(work / "receipt.json")
    report["elapsed_after_receipt_fsync_s"] = time.monotonic() - started
    report["finalization"] = "checked-after-fsync"
    if report["elapsed_after_receipt_fsync_s"] >= 60.0:
        report["status"], report["failure"] = "failed", report["failure"] or "inclusive60s finalization exhausted"
        report["finalization"] = "failed-after-fsync"
    sys.stdout.buffer.write(controller._json_bytes(report))
    return 0 if report["status"] == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
