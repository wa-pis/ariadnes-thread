"""Fixed F18.3 entry; no native execution occurs when imported."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys


def main() -> int:
    profile_path = Path(sys.argv[1]).resolve()
    profile = json.loads(profile_path.read_bytes())
    started = float(sys.argv[2])
    args = sys.argv[3:]
    work = Path(profile["work_directory"])
    if args:
        if len(args) != 4 or args[0] != "--parent":
            raise RuntimeError("fixed parent arguments required")
        if os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0):
            raise RuntimeError("cold parent requires isolated session")
    if os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0):
        raise RuntimeError("native entry requires isolated session")
    raw = (str(os.getpgrp()) + "\n").encode("ascii")
    if len(raw) > 32:
        raise RuntimeError("entry PGID exceeds fixed cap")
    with (work / ("parent.pgid" if args else "supervisor.pgid")).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if Path(sys.executable).resolve() != Path(profile["private_python"]).resolve():
        raise RuntimeError("private interpreter identity mismatch")
    sys.path.insert(0, str(Path(profile["repo"]) / "src"))
    from space_nav import _owner_endpoint_run as controller
    if args:
        return controller.main(args)

    def parent_command(source: Path, directory: Path, parent_started: float) -> list[str]:
        return [sys.executable, "-B", str(Path(__file__).resolve()),
                str(profile_path), repr(parent_started), "--parent", str(source),
                str(directory), repr(parent_started)]

    # Only command construction changes; the qualified controller remains intact.
    controller._parent_command = parent_command
    raw = controller._json_bytes(controller._INPUT)
    result = controller.run_isolated(raw, work / "native-packet", started_s=started)
    sys.stdout.buffer.write(controller._json_bytes(result))
    sys.stdout.buffer.flush()
    return 0 if result.get("status") == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
