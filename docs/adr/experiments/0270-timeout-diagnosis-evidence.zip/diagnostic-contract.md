# F18.4 source diagnosis and next-step contract

Current authority: saved/source diagnosis and design only. Base203a4f90726d139d970d85cca7be3bdc41770173. No native/import probe or F18.3 retry is authorized by this document.

## Question and evidence boundary

The consumed0269packet has no producer JSON, no durable phase/counter telemetry and no numerical audit. Its64-byte warning is also present in0266success. Sources give call order, not the program counter at kill. Static review does not prove import, constructor, visitor or integration causation.

Next proposed question: does the exact cold producer-prefix `from tudatpy.interface import spice` return under the unchanged0269private Python/environment/read-only mount/sandbox? Stop after installing the SPICE guard and recording loaded-kernel file identity; never call produce(), _native_context(), _native_factory(), create_dynamics_simulator or owner/helper visitors. A successful probe cannot retrospectively locate0269's stall or qualify endpoints.

## Separate preparation and future execution

F18.5 proposed: minimal private import-only probe plus independent stdlib saved-trace auditor; reuse qualified0269outer controls/PGID bootstrap without modifying old source/evidence. Qualify injected imports/guards, exact event order/unknown or duplicate events, missing prefix, truncated/failed trace, zero configured owner work, kernel-origin/hash mismatch and time/log/byte/cold-stall cleanup on artificial processes; run focused checks, frozen portable/live make test,Ruff,independent review,strictOpenSpec before completion. No native/scientific imports or native probe in this preparation; existing required live regression stays separately authorized only for its old scope.

F18.6 proposed, not authorized: one cold import-only attempt after F18.5 qualification and separately explicit authority. Pin exact source/kernel/resources/import-prefix/versions/flags/env/sandbox/working directories/probe/auditor/outercontrols and absence of loaded native modules. Reuse read-only retained image and all5resource files; no acquisition/build/install/thread-env tweak/tmp redirection or writable-image experiment. Same<=600s comparable-clock preflight including independent admission; one<=60s inclusive45producer/<=10audit/finalize5 clock;64KiB input,64KiB combined logs,2MiB aggregate structured evidence including outer records. Max1explicit import attempt;0explicit factories/integrations/owner/helper visitor calls,0optimizer/ephemeris studies. Stop on first failure, no retries/data/gate/limit changes, preserve old clocks/ledgers.

## Observable trace and independent audit

At most6 ordered completed marker writes, each<=512bytes, separate dedicated JSONL trace<=4KiB, inside existing2MiB aggregate. Fixed sequence:
1 bootstrap-ready: input validated before project/native imports;
2 guards-ready: same project fixture/guard imports and source audit-hook prefix complete;
3 native-import-enter: emitted immediately before `from tudatpy.interface import spice`;
4 native-import-return: emitted immediately after that statement returns;
5 spice-guard-ready: _guard_spice installed without querying SPICE;
6 complete: loaded kernel path/hash match the preflight private binary; no context/owner/helper call.
Each marker has schema, fixed phase index/name, monotonic elapsed time and fixed scope, bounded finite JSON only. Flush/retain each marker before crossing to its next operation; external watchdog includes all writes/fsync/streaming/cold imports and partial failures. Do not mix trace lines into scientific producer JSON or reinterpret OpenMP stderr as a marker. No native phase counters or scientific values fabricated.

Marker writes are observations: a saved enter without return brackets the unobserved region including import and adjacent marker I/O; it does not prove a native instruction, deadlock, root cause or exact consumed0269phase. Missing marks and observer I/O failure stay unavailable. Trace auditing must preserve this uncertainty. A trace does not measure every native RHS/callback.

Independent auditor imports only stdlib, never producer/TudatPy/numpy/scipy/spiceypy; checks fixed input/source/kernel pins, exact prefix/order/length/time bounds, child status, retained stdout/stderr/partial caps, clock/finalization/cleanup and zero explicit owner-work scope by frozen entry path. Missing complete means diagnostic UNAVAILABLE/FAILED, never scientific PASS; saved failure accounting is separate from import completion. A complete probe only qualifies that import profile, not a causal or physical conclusion.

## Gates and next decisions

F18.3 remains consumed/unqualified; no8-call/2-arc result or zero historical native counts is invented. F17/F17.1, native owner/carry/prior arithmetic/concurrency/ABI-FP and all physicalF0/M3 gates stay open. Automation remains PAUSED. After an import result, separately choose an appropriately bounded next observation; do not automatically repeat F18.3, change TMP permissions/OMP settings, extend45s or start a full mission.
