from pathlib import Path
import json,hashlib,time,sys,datetime,os,subprocess
p=Path('/private/tmp/ariadna-f18-0270');r=Path('/Users/agrudin/dev/my/ariadna');v=Path('/private/tmp/ariadna-f17-0263/volume');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();start=json.loads((p/'source-profile.json').read_text());assert sys.executable==start['interpreter']
source=json.loads((p/'native-source-diagnosis.json').read_text());env=json.loads((p/'environment-comparison.json').read_text());checked={}
for m in source['source_pins']+list(env['files'].values()):
 f=Path(m['path']);assert sha(f)==m['sha256'],str(f)
 if 'bytes'in m:assert f.stat().st_size==m['bytes'],str(f)
 for ex in m.get('excerpts',[]):
  actual='\n'.join(f.read_text().splitlines()[ex['start_line']-1:ex['end_line']]);assert actual.rstrip('\n')==ex['text'].rstrip('\n'),(str(f),ex['start_line'])
 checked[str(f)]={'bytes':f.stat().st_size,'sha256':m['sha256']}
reviews={n:json.loads((p/n).read_text())for n in ('source-design-review.json','environment-design-review.json')}
verdicts={n:z['review_result']if n=='source-design-review.json'else z['status']for n,z in reviews.items()}
for n,status in verdicts.items():assert status=='PASS',(n,status)
old=json.loads(Path('/private/tmp/ariadna-f18-0269/root-preflight.json').read_text())
for m in old['native_pins']+old['resources']:assert Path(m['path']).stat().st_size==m['bytes']and sha(m['path'])==m['sha256'],m['path']
for f,h in old['old_timers_ledgers'].items():assert sha(f)==h,f
assert os.statvfs(v).f_flag&os.ST_RDONLY
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==start['base_revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
elapsed=time.monotonic()-start['started_s'];assert 0<=elapsed<=start['ceiling_s']
x={'schema':'ariadna.f18.saved-source-diagnosis-completion.v1','status':'PASS_SOURCE_DIAGNOSIS_AND_DESIGN_ONLY','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_revision':start['base_revision'],'elapsed_s':elapsed,'ceiling_s':600,'clock_interpreter':sys.executable,'checked_named_sources':checked,'independent_reviews':{n:{'sha256':sha(p/n),'status':verdicts[n]}for n,z in reviews.items()},'native_kernel_source_pins_and5resources_unchanged':True,'old10timers_ledgers_unchanged':True,'image_readonly':True,'native_imports_probes_factories_integrations_spice_builds_payload_copies':0,'root_checks':'Exact sourcehashes/excerpt lines, read-only mount/native/resource/oldclock pins; no full operationalprefix rescan claimed.','checker_setup_correction':'Initial generic status-key lookup failed for native-source review schema; explicit review_result/status fields validated without changing either receipt.','hypothesis_status':'No location/cause proved from saved packet; selected next question is separatelyqualified cold import-only trace.','selected_contract_sha256':sha(p/'diagnostic-contract.md'),'clarifications_from_independent_reviews':['Obtain loaded kernel only via sys.modules registry, no additional explicit import/context/owner/helper call.','Flush+fsync each emitted marker inside fixed clock, but a visible lastline alone does not prove fsync/operation completed; require child exit0/finalization for completion.','Preserve process-role flags: nativeentry/coldparent -B, producer -m without-I/-B; bytecode/sourcebootstrap inherited from exact0269environment.']}
with(p/'source-completion.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print({'status':x['status'],'elapsed_s':elapsed,'named_files_checked':len(checked),'review_status':list(verdicts.values())})
