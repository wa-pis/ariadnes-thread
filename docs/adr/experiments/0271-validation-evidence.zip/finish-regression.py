from pathlib import Path
import datetime, hashlib, json, xml.etree.ElementTree as ET
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0271');old=Path('/private/tmp/ariadna-f18-0268')
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
def junit(path):
 cases=ET.parse(path).findall('.//testcase');ids={c.get('classname','')+'::'+c.get('name','')for c in cases}
 assert len(ids)==len(cases),path
 failed=[c.attrib for c in cases if c.find('failure')is not None or c.find('error')is not None]
 skipped={c.get('classname','')+'::'+c.get('name',''):c.find('skipped').get('message')for c in cases if c.find('skipped')is not None}
 new={c.get('classname','')+'::'+c.get('name','')for c in cases if c.get('classname','')in ('tests.test_import_probe','tests.test_import_probe_audit')}
 return {'cases':len(cases),'passed':len(cases)-len(failed)-len(skipped),'failed':len(failed),'skipped':skipped,'new_import_probe_cases':len(new),'sha256':sha(path),'bytes':path.stat().st_size},ids,new
profile=json.loads((p/'profile.json').read_text());freeze=json.loads((p/'frozen-after.json').read_text());exit=json.loads((p/'regression-exit.json').read_text());review=json.loads((p/'code-review-v2.json').read_text())
assert exit['exit_code']==0 and exit['elapsed_s']<profile['regression_ceiling_s']
assert freeze['status']=='passed' and review['status']=='PASS' and not review['findings']
a,ai,an=junit(p/'portable.xml');b,bi,bn=junit(p/'live.xml');f,fi,fn=junit(p/'focused.xml');oa,oai,_=junit(old/'portable.xml');ob,obi,_=junit(old/'live.xml')
assert not a['failed'] and not b['failed'] and not f['failed']
assert f['passed']==124 and a['new_import_probe_cases']==124 and b['new_import_probe_cases']==0
assert fi==fn==an and not ai&bi
assert ai==oai|an and bi==obi
assert a['skipped']==oa['skipped'] and b['skipped']==ob['skipped']
assert a['passed']==oa['passed']+124==7848 and b['passed']==ob['passed']==413
for name,pin in profile['new_sources'].items():
 assert sha(r/name)==pin['sha256'] and (r/name).stat().st_size==pin['bytes']
 assert review['reviewed_files'][name]==pin
assert sha(p/'profile.json')==review['profile_sha256']
y={'schema':'ariadna.f18.import-probe-qualification.v1','status':'passed_artificial_preparation_only','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_revision':profile['base_revision'],'scope':profile['scope'],'focused':f,'portable':a,'live':b,'combined_passed':a['passed']+b['passed'],'focused_not_double_counted':True,'case_ids_disjoint':True,'all_old_cases_and_skip_reasons_unchanged':True,'frozen_files_unchanged':freeze['files_unchanged'],'git_status_unchanged':True,'regression_exit':exit,'new_sources':profile['new_sources'],'independent_code_review':{'status':'PASS','sha256':sha(p/'code-review-v2.json'),'original_review_retained':'code-review.json; wording correction only, pure control imports eager, native/scientific imports lazy'},'ruff':{'exit_code':0,'log_sha256':sha(p/'ruff.log'),'output':(p/'ruff.log').read_text().strip()},'strict_before_freeze':{'exit_code':0,'log_sha256':sha(p/'strict-before.log')},'command':'make test RUN=/private/tmp/ariadna-f18-0271/test-runner; wrapper adds only per-lane external JUnit, both Makefile commands and Conda environment unchanged','work_performed':'Injected kernel files/hooks, fake probe children and real independent stdlib saved-trace CLI. Existing required live regressions only in prior scope; new native probe/import/owner/physical branches not executed.','limits_and_inference':'Qualified45/10/5 clocks, marker/trace/input/log/partition controls and external watcher artificial observer stalls; complete marker alone is insufficient. Source/kernel/resource flags/environment/preflight/outeraggregatecleanupfsync remain separate F18.6 admission.','gates':'F18.5 only complete; F18.6 not executed or admitted, F18.3 consumed/unqualified with historical counts unknown, physicalF0/M3 and99percent/safety gates open','scheduler':'ariadna-m3 PAUSED'}
with(p/'regression-qualification.json').open('x')as handle:json.dump(y,handle,indent=2);handle.write('\n')
print({k:y[k]for k in ('status','combined_passed','frozen_files_unchanged')})
