from pathlib import Path
import datetime, hashlib, json, os, subprocess
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0271')
files=['src/space_nav/_import_probe.py','src/space_nav/_import_probe_audit.py','tests/test_import_probe.py','tests/test_import_probe_audit.py']
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert base=='6195fe41cd1806eed484503e8ecbc6a78fbd30a6'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).strip()
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines())==set(files)
with(p/'profile.json').open('x')as f:json.dump({'schema':'ariadna.f18.import-probe-artificial-qualification.v1','base_revision':base,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'F18.5 injected probe/independent saved-trace auditor qualification only; no F18.6/native-probe/owner packet or new physical experiment. Existing live regression retains old authorized scope.','new_sources':{n:{'bytes':(r/n).stat().st_size,'sha256':hashlib.sha256((r/n).read_bytes()).hexdigest()}for n in files},'regression_ceiling_s':1800,'commands':{'focused':'Conda Python -I -B -m pytest -q --offline tests/test_import_probe.py tests/test_import_probe_audit.py with external log/JUnit','full':'make test RUN=/private/tmp/ariadna-f18-0271/test-runner (adds external per-lane JUnit only)','ruff':'Conda Ruff check --no-cache src tests','strict':'openspec validate refine-physical-trajectory --strict'},'science_limits':'Unchanged; artificial checks do not admit a native or physical profile.','automation':'PAUSED'},f,indent=2);f.write('\n')
commands=[('focused',[ '/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python','-I','-B','-m','pytest','-q','--offline','tests/test_import_probe.py','tests/test_import_probe_audit.py','--junitxml='+str(p/'focused.xml')]),('ruff',['/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/ruff','check','--no-cache','src','tests']),('strict-before',['openspec','validate','refine-physical-trajectory','--strict'])]
for name,cmd in commands:
 with(p/(name+'.log')).open('x')as log:
  check=subprocess.run(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',DO_NOT_TRACK='1',OPENSPEC_TELEMETRY='0'),timeout=180)
 assert check.returncode==0,(name,(p/(name+'.log')).read_text()[-4000:])
 print(name+': '+(p/(name+'.log')).read_text().strip().splitlines()[-1])
