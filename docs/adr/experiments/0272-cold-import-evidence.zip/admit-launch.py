from pathlib import Path
import hashlib,json,os,subprocess,time,datetime
p=Path('/private/tmp/ariadna-f18-0272');r=Path('/Users/agrudin/dev/my/ariadna');sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_bytes())
s=read('preflight-start.json');v=read('profile.json');assert 0<=time.monotonic()-s['started_s']<600
assert not(p/'execution').exists()and not(p/'episode-start.json').exists()
for name in ('independent-file-admission.json','final-profile-admission.json','controls-source-review.json','artificial-wiring-qualification.json'):
 x=read(name);assert x['status']==('PASS_STATIC_PENDING_ARTIFICIAL_WIRING_AND_FINAL_PROFILE' if name=='controls-source-review.json' else 'PASS'),(name,x['status'])
assert read('operational-before.json')['status']=='passed'
for name,z in v['source_pins'].items():assert(r/name).stat().st_size==z['bytes']and sha(r/name)==z['sha256']
for key,name in [('entry_sha256','native-entry.py'),('adapter_sha256','supervisor-adapter.py'),('launch_sha256','launch-once.py'),('caller_sha256','call-once.py'),('sandbox_sha256','native.sandbox')]:assert sha(p/name)==v[key],key
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==s['base_revision']
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='dev'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
pre=read('root-preflight.json')
for z in pre['native_pins']+pre['resources']:assert Path(z['path']).stat().st_size==z['bytes']and sha(z['path'])==z['sha256']
for path,digest in pre['old_timers_ledgers'].items():assert sha(path)==digest
sv=os.statvfs('/private/tmp/ariadna-f17-0263/volume');assert sv.f_flag&os.ST_RDONLY and sv.f_blocks*sv.f_frsize<=8*1024**3
receipt={'schema':'ariadna.f18.import-launch-admission.v1','status':'PASS','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight_elapsed_s':time.monotonic()-s['started_s'],'profile_sha256':sha(p/'profile.json'),'review_sha256':{name:sha(p/name)for name in('independent-file-admission.json','final-profile-admission.json','controls-source-review.json','artificial-wiring-qualification.json','operational-before.json')},'root_control_review':'Reviewed real adapter and entry connected to qualified probe.run/main: copied run_isolated control body with only fixed input/schema/callback edits, no old globals changed. Caller byteidentical0269; launcher adds adapterpin only; sandbox freshnamespace only. Artificial fakepackage checks qualify outer dispatch/cleanup, not real import or sixmarker correctness; those are0271tests.','authority':s['authority'],'remaining_import_attempts_before_consumption':1,'pending_native_or_trajectory_work':'none before consumption','scope':'one cold import-only, zero explicit owner/factories/integration/SPICEquery; no native retry or physical admission'}
assert receipt['preflight_elapsed_s']<600
with(p/'launch-admission.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print({'status':receipt['status'],'preflight_elapsed_s':receipt['preflight_elapsed_s'],'profile_sha256':receipt['profile_sha256']})
