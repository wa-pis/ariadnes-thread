from pathlib import Path
import hashlib,json,math,os,sys,time
W=Path('/private/tmp/ariadna-f18-0272');R=Path('/Users/agrudin/dev/my/ariadna');E=W/'execution';P=E/'native-packet/packet';findings=[]
def require(ok,label):
 if not ok:findings.append(label)
def load(path):return json.loads(Path(path).read_bytes())
def pin(path):
 b=Path(path).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
profile=load(W/'profile.json');start=load(W/'episode-start.json');consumed=load(E/'consumed.json');tool=load(W/'caller-tool-output.json');caller=load(W/'caller-finalization.json');launch=load(W/'caller-output.json');supervisor=load(E/'producer.json');parent=load(E/'native-packet/producer.json');observe=load(P/'observation.json');audit=load(P/'audit.json');trace=(P/'trace.jsonl').read_bytes();inputraw=(P/'input.json').read_bytes();phases=['bootstrap-ready','guards-ready','native-import-enter','native-import-return','spice-guard-ready','complete'];lines=trace.splitlines(keepends=True);markers=[json.loads(x) for x in lines]
require(len(lines)==6 and len(trace)<=4096,'six bounded trace records')
for index,(line,marker) in enumerate(zip(lines,markers)):
 require(len(line)<=512 and line.endswith(b'\n'),'marker byte/newline cap')
 expected_keys={'schema','scope','index','phase','elapsed_s'}|({'kernel_path','kernel_sha256'} if index==5 else set())
 require(set(marker)==expected_keys,'marker exact keys:'+str(index))
 require(marker['schema']=='ariadna-import-marker-v1' and marker['scope']=='import-only' and type(marker['index'])is int and marker['index']==index and marker['phase']==phases[index],'marker identity/order:'+str(index))
 value=marker['elapsed_s'];require(type(value)in(int,float) and math.isfinite(value) and 0<=value<45,'marker clock:'+str(index))
 if index:require(markers[index-1]['elapsed_s']<=value,'marker clock monotonic:'+str(index))
fixed=profile['probe_input'];require(json.loads(inputraw)==fixed,'packet fixed input')
require((E/'native-packet/input.json').read_bytes()==inputraw,'supervisor input parity')
require(markers[-1]['kernel_path']==fixed['kernel_path'] and markers[-1]['kernel_sha256']==fixed['kernel_sha256']==profile['kernel_sha256'],'loaded kernel recorded identity')
require(pin(R/'src/space_nav/_import_probe.py')['sha256']==fixed['probe_sha256'],'qualified producer source unchanged')
require(observe['schema']=='ariadna-import-observation-v1' and observe['exit_code']==0 and observe['finalization']=='checked-after-fsync','child observation return/fsync')
require(observe['probe_sha256']==fixed['probe_sha256'] and observe['trace_sha256']==hashlib.sha256(trace).hexdigest(),'observation digests')
require(markers[-1]['elapsed_s']<=observe['producer_elapsed_s']<=observe['finalized_elapsed_s']<45,'producer phase elapsed')
require(audit=={'schema':'ariadna-import-audit-v1','status':'passed','scope':'import-only','mode':'native','markers_checked':6,'kernel_sha256':fixed['kernel_sha256'],'completion_requires_outer_finalization':True,'physical_admission':'unavailable'},'included audit exact outcome')
require((P/'producer.json').stat().st_size==0,'probe stdout must be empty')
require(parent['schema']=='ariadna-import-run-v1' and parent['scope']=='import-only' and parent['mode']=='native' and parent['physical_admission']=='unavailable','parent scope')
require([(x['kind'],x['exit_code']) for x in parent['workers']]==[('probe',0),('audit',0)],'exact child/auditor sequence')
require(parent['limits']=={'total_s':60,'producer_finish_s':45,'audit_s':10,'audit_finish_s':55,'finalization_reserve_s':5,'input_bytes':65536,'logs_bytes':65536,'structured_evidence_bytes':2097152,'trace_bytes':4096,'marker_bytes':512,'explicit_import_attempts':1,'explicit_owner_work':0},'parent fixed limits')
require(supervisor['schema']=='ariadna-import-supervisor-v1' and supervisor['worker']['exit_code']==0 and supervisor['parent']==parent,'supervisor checked parent parity')
require(launch['schema']=='ariadna.f18.native-launch.v1' and launch['supervisor']==supervisor and launch['worker']['exit_code']==0 and launch['group_cleanup_completed']is True,'launcher nested parity')
for name,record in [('parent',parent),('supervisor',supervisor),('launch',launch)]:
 require(record['status']=='passed' and record['failure']is None and record['finalization']=='checked-after-fsync','successful observed finalization:'+name)
require(0<=parent['elapsed_at_last_valid_check_s']<=supervisor['elapsed_at_last_valid_check_s']<=launch['elapsed_after_group_cleanup_s']<=launch['elapsed_before_receipt_s']<=launch['elapsed_after_receipt_fsync_s']<60,'nested postfsync clock order')
require(parent['workers'][1]['elapsed_s']<10 and parent['elapsed_at_last_valid_check_s']<55,'included audit phase')
require(caller==tool['summary'],'caller fsynced receipt/tool parity')
require(tool['status']=='passed' and tool['within60s']is True and caller['status']=='passed' and caller['failure']is None and caller['returncode']==0,'caller success')
require(launch['elapsed_after_receipt_fsync_s']<=caller['elapsed_after_cleanup_s']<=caller['elapsed_after_output_fsync_s']<=tool['observed_after_caller_finalization_fsync_s']<60,'outer postfsync elapsed bound')
require(start['started_s']==launch['started_s']==parent['parent_started_s'] and start['deadline_s']==launch['deadline_s']==start['started_s']+60,'one inherited episode clock')
require(start['profile_sha256']==consumed['profile_sha256']==pin(W/'profile.json')['sha256'],'profile episode/consumed hash')
require(start['retry_authorized']is False and consumed['retry_authorized']is False and consumed['status']=='consumed-before-native-entry','exclusive consumed once status')
require(0<=start['preflight_elapsed_s']<=consumed['preflight_elapsed_s']<600,'preflight inclusive consume clock')
require(abs(start['started_s']-profile['preflight_started_s']-start['preflight_elapsed_s'])<1e-9,'preflight same clock identity')
# Durable pending receipts predate each successful observed post-fsync return; neither alone proves finalization.
pending={}
for filename,observed in [('native-packet/packet/receipt.json',parent),('native-packet/receipt.json',supervisor)]:
 d=load(E/filename);pending[filename]=d['finalization'];require(d['finalization']=='pending-after-fsync-observation' and d['status']=='passed' and d['failure']is None,'durable pending receipt:'+filename)
 for key,value in d.items():
  if key!='finalization':require(observed.get(key)==value,'pending/observed parity:'+filename+':'+key)
ld=load(E/'receipt.json')
for key,value in ld.items():require(launch.get(key)==value,'launch durable/observed parity:'+key)
# Exact disjoint stored native episode volume, including outside returned receipts but excluding later reviews/admission files.
files=sorted(p for p in E.rglob('*') if p.is_file());native_struct=sum(p.stat().st_size for p in files if not p.name.endswith('.log'));native_logs=sum(p.stat().st_size for p in files if p.name.endswith('.log'))
outer_names=['episode-start.json','caller-output.json','caller-finalization.json','caller-tool-output.json'];structured=native_struct+sum((W/n).stat().st_size for n in outer_names);logs=native_logs+(W/'caller-tool-stderr.log').stat().st_size
require(native_struct+(W/'episode-start.json').stat().st_size+(W/'caller-output.json').stat().st_size==caller['total_structured_bytes_before_caller_receipt'],'caller aggregate recomputation')
require(structured<=2097152 and logs<=65536 and len(inputraw)<=65536 and (W/'profile.json').stat().st_size<=65536,'all aggregate/input caps')
require(native_logs==launch['log_bytes']==parent['log_bytes']==64,'log accounting')
warning=(P/'producer.stderr.log').read_bytes();oldwarning=(Path('/private/tmp/ariadna-f18-0269/execution/native-packet/packet/producer.stderr.log')).read_bytes();require(warning==oldwarning,'same historical warning bytes')
# Read-only process existence queries use signal0 only; do not terminate or start native work.
groups={}
for name in ['parent.pgid','supervisor.pgid']:
 group=int((E/name).read_text());require(group==caller['groups'][name],'group recorded identity:'+name)
 try:os.killpg(group,0)
 except ProcessLookupError:groups[name]={'pgid':group,'status':'absent_ESRCH'}
 except PermissionError:groups[name]={'pgid':group,'status':'permission_denied'};findings.append('groupabsenceunproved:'+name)
 else:groups[name]={'pgid':group,'status':'still_exists'};findings.append('groupstillpresent:'+name)
rawpins={str(p.relative_to(W)):pin(p) for p in files+[W/n for n in outer_names]+[W/'caller-tool-stderr.log',W/'profile.json']}
result={'schema':'ariadna.f18.independent-saved-result-audit.v1','status':'PASS' if not findings else 'FAIL','findings':findings,'scope':'Separate postpacket stdlib/read-only saved-record/control audit, distinct from the already included0.033978791907429695s independent auditor within the60s native episode. No probe/owner/native/scientific imports or replay.','clock_interpreter':sys.executable,'review_checked_s':time.monotonic(),'base_revision':profile['base_revision'],'admitted_profile':pin(W/'profile.json'),'pins':rawpins,'verified':{'exact_six_marker_sequence':phases,'probe_exit':0,'included_independent_audit':'passed','all_observed_nested_finalization':'checked-after-fsync','durable_preobservation_receipts':pending,'profile_source_kernel_recorded_identity':True,'same_inherited_clock_and_preflight_consumption':True,'groups':groups},'measured':{'preflight_episode_s':start['preflight_elapsed_s'],'preflight_consumed_s':consumed['preflight_elapsed_s'],'trace_bytes':len(trace),'maximum_marker_bytes':max(map(len,lines)),'input_bytes':len(inputraw),'producer_observed_finalization_s':observe['finalized_elapsed_s'],'included_audit_child_elapsed_s':parent['workers'][1]['elapsed_s'],'outer_postcaller_fsync_s':tool['observed_after_caller_finalization_fsync_s'],'native_execution_structured_bytes':native_struct,'episode_aggregate_structured_bytes':structured,'episode_aggregate_log_bytes':logs},'source_scoped_work':{'explicit_spice_wrapper_import_attempts':1,'explicit_owner_factory_integration_context_visitor_calls':0,'explicit_spice_queries':0,'meaning':'Source-bound explicit call scope only. Native import-internal work is not instrumented; this is not a retrospective counter observation for0269.'},'factual_conclusion':'This one admitted unchanged0269-profile cold SPICE-wrapper/kernel import returned; the source guard, subsequent SPICE guard, recorded loaded-kernel identity, childexit0, independent trace audit and supervised outer cleanup/finalization completed inside60s.','inference_limits':['Six durable visible markers alone are insufficient; completion here additionally relies on successful child and nestedpostfsync/caller observations.','Marker enter/return elapsed difference includes adjacent observer I/O and is not a pure native-import benchmark.','This successful attempt does not locate or explain0269stall, recover its unknown native counters or authorize its retry.','No owner/carry/ABI-FP/concurrency/physicalF0/M3/99percent/mission-safety gate is closed; no command feasibility is established.','Preflight source/kernel/resource identity is separately evidenced; read-only saved-record review does not establish upstream authenticity or full linked-binary closure.']}
out=W/'independent-result-audit.json';payload=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
with out.open('xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())
fd=os.open(W,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'status':result['status'],'findings':findings,'path':str(out),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'structured_bytes':structured,'logs_bytes':logs,'groups':groups}))
