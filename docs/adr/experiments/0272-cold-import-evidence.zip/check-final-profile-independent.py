from pathlib import Path
import ast,hashlib,json,os,sys,time,zipfile
R=Path('/Users/agrudin/dev/my/ariadna');W=Path('/private/tmp/ariadna-f18-0272');O=Path('/private/tmp/ariadna-f18-0269');findings=[]
P=json.loads((W/'profile.json').read_bytes());old=json.loads((O/'profile.json').read_bytes());A=json.loads((W/'independent-file-admission.json').read_bytes());start=json.loads((W/'preflight-start.json').read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def require(ok,label):
 if not ok:findings.append(label)
def check(p,e):
 a=pin(p)
 for k in ('bytes','sha256'):
  if k in e:require(a[k]==e[k],str(p)+':'+k)
 return a
require(P['schema']=='ariadna.f18.import-profile.v1','profile schema')
require(P['base_revision']==start['base_revision']==A['base_revision'],'base revision')
require(P['repo']==str(R),'repo')
require(P['private_python']==old['private_python'],'private python')
require(P['work_directory']==str(W/'execution'),'exclusive workdir')
require(not (W/'execution').exists() and not (W/'episode-start.json').exists(),'native namespace already consumed')
require(P['preflight_started_s']==start['started_s']==A['started_s'],'same preflight clock')
require(P['environment']==old['environment']==A['exact0269environment'],'exact0269environment')
require(P['limits']==start['limits'],'fixed limits')
require(P['sandbox_profile']==str(W/'native.sandbox'),'sandbox path')
require(P['prelaunch_admission']==str(W/'launch-admission.json'),'admission path')
sp={rel:check(R/rel,e) for rel,e in P['source_pins'].items()}
z=zipfile.ZipFile(R/'docs/adr/experiments/0271-validation-evidence.zip');frozen=json.loads(z.read('frozen-before.json'))['files']
for rel,e in sp.items():require(e['sha256']==frozen.get(rel),'source not0271frozen:'+rel)
require(set(A['import_prefix_source_pins'])<=set(sp),'incomplete independently-derived prefix coverage')
for rel,e in old['source_pins'].items():require(P['source_pins'].get(rel)==e,'old0269source pin drift:'+rel)
for rel,e in A['qualified_new_sources'].items():require(P['source_pins'].get(rel)=={k:e[k] for k in ('bytes','sha256')},'new0271source pin drift:'+rel)
kp=next(p for p in A['native_pins'] if p.get('role')=='kernel')
expected_input={'schema':'ariadna-import-input-v1','scope':'import-only','mode':'native','kernel_path':kp['path'],'kernel_sha256':kp['sha256'],'probe_sha256':sp['src/space_nav/_import_probe.py']['sha256']}
require(P['probe_input']==expected_input,'fixed probe input')
require(P['kernel_sha256']==kp['sha256'],'kernel digest')
controls={}
for field,name in [('entry_sha256','native-entry.py'),('adapter_sha256','supervisor-adapter.py'),('launch_sha256','launch-once.py'),('caller_sha256','call-once.py'),('sandbox_sha256','native.sandbox')]:controls[name]=check(W/name,{'sha256':P[field]})
require((W/'call-once.py').read_bytes()==(O/'call-once.py').read_bytes(),'caller not byte-exact0269')
sandbox=(O/'native.sandbox').read_text().replace(str(O/'execution'),str(W/'execution'))
require((W/'native.sandbox').read_text()==sandbox,'sandbox changes beyond output path')
oldlaunch=(O/'launch-once.py').read_text();newlaunch=(W/'launch-once.py').read_text()
added='    adapter = Path(__file__).with_name("supervisor-adapter.py")\n    if hashlib.sha256(adapter.read_bytes()).hexdigest() != profile["adapter_sha256"]:\n        raise RuntimeError("supervisor adapter pin mismatch")\n'
require(newlaunch.replace(added,'',1)==oldlaunch and newlaunch.count(added)==1,'launcher changes beyond adapter hash')
def fn(path,name):return next(n for n in ast.parse(Path(path).read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name)
# Independent normalization of precisely the four permitted run_isolated differences.
n=fn(W/'supervisor-adapter.py','run_isolated');base=fn(R/'src/space_nav/_owner_endpoint_run.py','run_isolated')
require([a.arg for a in n.args.kwonlyargs]==['parent_command','started_s'],'adapter keyword-only contract')
n.args.kwonlyargs=n.args.kwonlyargs[1:];n.args.kw_defaults=n.args.kw_defaults[1:]
n.body[2]=base.body[2]
class Normalize(ast.NodeTransformer):
 def visit_Constant(self,node):
  if node.value=='ariadna-import-supervisor-v1':node.value='ariadna-owner-supervisor-v1'
  elif node.value=='ariadna-import-run-v1':node.value='ariadna-owner-run-v1'
  return node
 def visit_Name(self,node):
  if node.id=='parent_command':node.id='_parent_command'
  return node
n=Normalize().visit(n)
require(ast.dump(n,include_attributes=False)==ast.dump(base,include_attributes=False),'adapter nonallowed code drift')
# Independent entry and worker source inspection; do not execute any callable.
entry=(W/'native-entry.py').read_text();et=ast.parse(entry)
require('raw = controller._json_bytes(profile["probe_input"])' in entry,'entry fixedinput wiring')
require('from space_nav import _import_probe as controller' in entry,'entry importonly controller')
require('return controller.main(args)' in entry and '"--parent"' in entry,'entry cold parent route')
require('return [sys.executable, "-B",' in entry,'cold parent exact-B')
require('adapter.run_isolated(raw, work / "native-packet",' in entry,'fixed adapter route')
for forbidden in ['produce','_native_context','create_dynamics_simulator','integrate_equations_of_motion']:
 require(not any(isinstance(x,ast.Call) and ((isinstance(x.func,ast.Name) and x.func.id==forbidden) or (isinstance(x.func,ast.Attribute) and x.func.attr==forbidden)) for x in ast.walk(et)),'entry forbidden call:'+forbidden)
worker=ast.unparse(fn(R/'src/space_nav/_import_probe.py','_worker_command'))
require("[sys.executable, '-m', 'space_nav._import_probe', '--probe'" in worker,'producer exact-m-no-I-B')
require("'-I'" not in worker and "'-B'" not in worker,'worker extra flags')
require('["/usr/bin/sandbox-exec", "-f", profile["sandbox_profile"],\n               profile["private_python"], "-B",' in newlaunch,'native-entry exact-B')
# Fresh readback of physical pins/timers at final review, without native imports.
for group in ['native_pins','resources']:
 for e in A[group]:check(e['path'],e)
for e in A['old_timers_ledgers'].values():check(e['path'],e)
for name,e in A['old0269_all_archive_members_unchanged'].items():check(O/name,e)
stat=os.statvfs('/private/tmp/ariadna-f17-0263/volume');require(bool(stat.f_flag&os.ST_RDONLY),'image no longer readonly');require(stat.f_frsize*stat.f_blocks<=8*1024**3,'capacity ceiling')
now=time.monotonic();elapsed=now-start['started_s'];require(0<=elapsed<600,'preflight deadline')
result={'schema':'ariadna.f18.independent-final-profile-admission.v1','status':'PASS' if not findings else 'FAIL','scope':'Independent source/profile/static-controls review only; root must additionally bind separately passing artificial adapter qualification and final launch admission before any native attempt.','findings':findings,'base_revision':P['base_revision'],'started_s':start['started_s'],'checked_s':now,'elapsed_s':elapsed,'ceiling_s':600,'clock_interpreter':sys.executable,'profile':pin(W/'profile.json'),'previous_independent_file_admission':pin(W/'independent-file-admission.json'),'source_pin_count':len(sp),'source_pins':sp,'independent_prefix_files_covered':list(A['import_prefix_source_pins']),'fixed_probe_input':expected_input,'exact0269environment':True,'exact0269role_flags':{'native_entry':'-B','cold_parent':'-B','producer':'-m space_nav._import_probe --probe; no-I/-B','launcher':'unchanged0269caller -I -B'},'control_pins':controls,'independent_control_review':{'caller':'byte-exact0269','sandbox':'byte-exact0269 except exclusive fresh execution path','launcher':'byte-exact0269 plus adapter hash check only','adapter':'AST normalized exactly to pinned owner run_isolated after only keyword-only parent callback, fixed native input validation, two schema names and callback dispatch','entry':'only fixed import-probe/parent/supervisor routes, exclusive PGID identities and private interpreter/sourcebootstrap; no owner or scientific calls','outer_limits':'same absolute60s inclusive bound/groupcleanup/fsync and partition controls preserved'},'readback':'all10native/5resource/10clock and44old0269archive members rehashed unchanged; imageRO/capacity pass','work':'No native/project imports, probe/SPICE/integration/build/tests/payload copies performed in this review. Reads/AST/hashes only.','pending':'Artificial adapter-wiring qualification receipt and complete root launch admission must PASS within original600s; not established by this static receipt.'}
raw=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();out=W/'final-profile-admission.json'
with out.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
fd=os.open(W,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'path':str(out),'status':result['status'],'findings':findings,'elapsed_s':elapsed,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}))
