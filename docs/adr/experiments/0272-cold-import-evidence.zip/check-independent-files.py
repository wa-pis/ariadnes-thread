from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time,zipfile
R=Path('/Users/agrudin/dev/my/ariadna');W=Path('/private/tmp/ariadna-f18-0272');V=Path('/private/tmp/ariadna-f17-0263/volume')
started=json.loads((W/'preflight-start.json').read_text())['started_s'];findings=[]
def ident(p):
 p=Path(p);data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def check(p,expected):
 actual=ident(p)
 for k in ('bytes','sha256'):
  if k in expected and actual[k]!=expected[k]:findings.append({'path':str(p),'field':k,'expected':expected[k],'actual':actual[k]})
 return actual
old=json.loads(Path('/private/tmp/ariadna-f18-0269/profile.json').read_text());prior=json.loads(Path('/private/tmp/ariadna-f18-0269/root-preflight.json').read_text());receipt=json.loads(Path('/private/tmp/ariadna-f17-0266/provisioning-receipt.json').read_text());q=json.loads((R/'docs/adr/experiments/0271-qualification.json').read_text())
new_sources={rel:check(R/rel,pin) for rel,pin in q['new_sources'].items()};old_sources={rel:check(R/rel,pin) for rel,pin in old['source_pins'].items()}
native=[check(pin['path'],pin)|{'role':pin.get('role')} for pin in receipt['old_pins_unchanged']];resources=[check(pin['path'],pin) for pin in receipt['complete_required_files']]
if len(native)!=10 or len(resources)!=5:findings.append({'counts':[len(native),len(resources)]})
resource_root=V/'home/.tudat/resource';actual_resource_files={str(p) for p in resource_root.rglob('*') if p.is_file()}
if actual_resource_files!={p['path'] for p in resources}:findings.append({'resource_file_set_drift':sorted(actual_resource_files)})
if sum(p['bytes'] for p in resources)!=131662:findings.append({'resource_bytes':sum(p['bytes'] for p in resources)})
old_timers={p:check(p,{'sha256':sha}) for p,sha in prior['old_timers_ledgers'].items()}
for p,sha in receipt['old_timers_ledgers_unchanged'].items():check(p,{'sha256':sha})
# Read every retained prior episode member, without executing any old controller.
z=zipfile.ZipFile(R/'docs/adr/experiments/0269-owner-timeout-evidence.zip');episode={}
for name in z.namelist():
 if name.endswith('/'):continue
 expected=z.read(name);episode[name]=check(Path('/private/tmp/ariadna-f18-0269')/name,{'bytes':len(expected),'sha256':hashlib.sha256(expected).hexdigest()})
# Check retained named native wrappers against the prior source review.
z270=zipfile.ZipFile(R/'docs/adr/experiments/0270-timeout-diagnosis-evidence.zip');source270=json.loads(z270.read('source-completion.json'))['checked_named_sources']
wrappers={p:check(p,pin) for p,pin in source270.items() if '/site-packages/tudatpy/' in p and p.endswith('.py')}
# Conservatively include top-level/conditional local imports and explicit prepare-stage modules.
seeds=['__init__','_import_probe','_import_probe_audit','_owner_endpoint_run','_owner_endpoint_fixture','_native_arc_conformance','trajectory'];queue=list(seeds);seen=set();edges=[]
while queue:
 module=queue.pop(0)
 if module in seen:continue
 seen.add(module);path=R/'src/space_nav'/f'{module}.py';tree=ast.parse(path.read_text())
 def visit(nodes,conditional=False):
  for n in nodes:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):continue
   if isinstance(n,ast.ImportFrom) and n.level:
    targets=[n.module] if n.module else [a.name for a in n.names]
    edges.append({'module':module,'line':n.lineno,'statement':ast.unparse(n),'conditional':conditional})
    for target in targets:
     if (R/'src/space_nav'/f'{target}.py').is_file():queue.append(target)
   elif isinstance(n,(ast.If,ast.Try,ast.With)):
    visit(n.body,True);visit(getattr(n,'orelse',[]),True)
    for h in getattr(n,'handlers',[]):visit(h.body,True)
 visit(tree.body)
z271=zipfile.ZipFile(R/'docs/adr/experiments/0271-validation-evidence.zip');frozen=json.loads(z271.read('frozen-before.json'))['files']
prefix={str(Path('src/space_nav')/f'{m}.py'):check(R/'src/space_nav'/f'{m}.py',{'sha256':frozen[str(Path('src/space_nav')/f'{m}.py')]}) for m in sorted(seen)}
# Preserve exact private Conda metadata identities from prior source review.
env270=json.loads(z270.read('environment-comparison.json'));metadata={}
for name,expected in env270['metadata'].items():
 p=V/'env/conda-meta'/name;actual=json.loads(p.read_text());metadata[name]=ident(p)
 for key,value in expected.items():
  if actual.get(key)!=value:findings.append({'metadata':name,'field':key,'expected':value,'actual':actual.get(key)})
stat=os.statvfs(V);readonly=bool(stat.f_flag&os.ST_RDONLY);capacity=stat.f_frsize*stat.f_blocks
if not readonly or capacity>8*1024**3:findings.append({'readonly':readonly,'capacity':capacity})
branch=subprocess.check_output(['/usr/bin/git','branch','--show-current'],cwd=R,text=True).strip();head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=R,text=True).strip();status=subprocess.check_output(['/usr/bin/git','status','--porcelain'],cwd=R,text=True)
if branch!='dev' or head!='2566fb4c72a3c316f8f5ac11a2a18cdd88196027' or status:findings.append({'git':{'branch':branch,'head':head,'status':status}})
role_flags={'native_entry':['-B'],'cold_parent':['-B'],'producer':['-m','space_nav._import_probe','--probe'],'producer_extra_I_B':False,'bytecode_source_bootstrap':'exact0269environment'}
now=time.monotonic();elapsed=now-started
if elapsed<0 or elapsed>=600:findings.append({'preflight_elapsed_s':elapsed})
result={'schema':'ariadna.f18.independent-file-admission.v1','status':'PASS' if not findings else 'FAIL','scope':'Independent read-only file/resource/environment/static-prefix admission only; new launcher/control/profile admission pending and not implied.','base_revision':head,'branch':branch,'git_status':status,'started_s':started,'checked_s':now,'elapsed_s':elapsed,'ceiling_s':600,'clock_interpreter':sys.executable,'qualified_new_sources':new_sources,'old_0269_sources':old_sources,'native_pins':native,'resources':resources,'resource_bytes':sum(p['bytes'] for p in resources),'exact_resource_file_set':sorted(actual_resource_files),'old_timers_ledgers':old_timers,'old0269_all_archive_members_unchanged':episode,'import_prefix_source_pins':prefix,'import_prefix_static_edges':edges,'import_prefix_method':'AST top-level/conditional project imports, explicit probe._prepare fixture+guard imports, retained trajectory baseline; all hash-equal to0271 frozen checkout. No project imports executed. Includes package init path and independent-audit startup.','tudatpy_wrapper_pins':wrappers,'private_conda_metadata':metadata,'exact0269environment':old['environment'],'required_role_flags':role_flags,'readonly_image':readonly,'capacity_bytes':capacity,'ceiling_capacity_bytes':8*1024**3,'new_acquisition_bytes':0,'aggregate_acquisition_bytes':497045495,'work_counters':{'native_scientific_imports':0,'spice':0,'tests':0,'probes':0,'builds':0,'payload_copies':0,'integrations':0},'limits':'Private retained local file identities only; upstream resource release authenticity, full linked-binary/source/ABI-FP closure, runtime import completion, cause of0269stall and physical/M3 claims remain unqualified. No full operational-prefix rescan is claimed.','findings':findings}
payload=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();out=W/'independent-file-admission.json'
with out.open('xb') as f:f.write(payload);f.flush();os.fsync(f.fileno())
fd=os.open(W,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'status':result['status'],'findings':findings,'elapsed_s':elapsed,'prefix_files':len(prefix),'native_pins':len(native),'resources':len(resources),'old0269_members':len(episode),'path':str(out),'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}))
