from pathlib import Path
import ast

repo = Path('/Users/agrudin/dev/my/ariadna')
root = Path('/private/tmp/ariadna-f18-0272')
original = (repo / 'src/space_nav/_owner_endpoint_run.py').read_text()
tree = ast.parse(original)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'run_isolated')
body = ast.get_source_segment(original, node)
assert body is not None
body = body.replace(
    'def run_isolated(raw: bytes, directory: Path, *, started_s: float | None = None) -> dict[str, object]:',
    'def run_isolated(raw: bytes, directory: Path, *,\n                 parent_command: Callable[[Path, Path, float], list[str]],\n                 started_s: float | None = None) -> dict[str, object]:', 1)
body = body.replace(
    '    if _decode(raw, INPUT_BYTES) != _INPUT:\n        raise RunError("fixed owner-fixture input mismatch")',
    '    if _profile(raw)["mode"] != "native":\n        raise RunError("fixed native import input required")', 1)
body = body.replace('"ariadna-owner-supervisor-v1"', '"ariadna-import-supervisor-v1"')
body = body.replace('"ariadna-owner-run-v1"', '"ariadna-import-run-v1"')
body = body.replace('_watch_worker(_parent_command(', '_watch_worker(parent_command(', 1)
header = '''"""Fixed F18.6 schema/dispatch adapter; copied qualified outer controls.

No native execution occurs on import. Only profile/schema and parent dispatch
adaptations differ from the pinned owner's run_isolated implementation.
"""
from __future__ import annotations

from collections.abc import Callable
import math
from pathlib import Path
from typing import Any

from space_nav._import_probe import _profile
from space_nav._owner_endpoint_run import (
    REPORT_BYTES, RunError, _Evidence, _check, _json_bytes, _now, _read,
    _sync, _watch_worker,
)


'''
with (root / 'supervisor-adapter.py').open('x') as stream:
    stream.write(header + body + '\n')
entry = '''"""Fixed F18.6 entry; no native execution occurs when imported."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import sys


def main() -> int:
    profile_path = Path(sys.argv[1]).resolve()
    profile = json.loads(profile_path.read_bytes())
    started = float(sys.argv[2])
    args = sys.argv[3:]
    work = Path(profile["work_directory"])
    if args:
        if len(args) != 4 or args[0] != "--parent":
            raise RuntimeError("fixed parent arguments required")
        if os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0):
            raise RuntimeError("cold parent requires isolated session")
    if os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0):
        raise RuntimeError("native entry requires isolated session")
    raw = (str(os.getpgrp()) + "\\n").encode("ascii")
    if len(raw) > 32:
        raise RuntimeError("entry PGID exceeds fixed cap")
    with (work / ("parent.pgid" if args else "supervisor.pgid")).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    if Path(sys.executable).resolve() != Path(profile["private_python"]).resolve():
        raise RuntimeError("private interpreter identity mismatch")
    sys.path.insert(0, str(Path(profile["repo"]) / "src"))
    from space_nav import _import_probe as controller
    if args:
        return controller.main(args)

    def parent_command(source: Path, directory: Path, parent_started: float) -> list[str]:
        return [sys.executable, "-B", str(Path(__file__).resolve()),
                str(profile_path), repr(parent_started), "--parent", str(source),
                str(directory), repr(parent_started)]

    adapter_path = Path(__file__).with_name("supervisor-adapter.py")
    spec = importlib.util.spec_from_file_location("f186_supervisor_adapter", adapter_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("fixed supervisor adapter unavailable")
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    raw = controller._json_bytes(profile["probe_input"])
    result = adapter.run_isolated(raw, work / "native-packet",
                                  parent_command=parent_command, started_s=started)
    sys.stdout.buffer.write(controller._json_bytes(result))
    sys.stdout.buffer.flush()
    return 0 if result.get("status") == "passed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
'''
with (root / 'native-entry.py').open('x') as stream:
    stream.write(entry)
print('created exclusive entry and adapter')
