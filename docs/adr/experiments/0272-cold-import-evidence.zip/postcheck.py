from pathlib import Path
import hashlib,json,os,signal,time,datetime,subprocess
p=Path('/private/tmp/ariadna-f18-0272');r=Path('/Users/agrudin/dev/my/ariadna');sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest();pre=json.loads((p/'root-preflight.json').read_bytes());v=json.loads((p/'profile.json').read_bytes())
for name,z in v['source_pins'].items():assert(r/name).stat().st_size==z['bytes']and sha(r/name)==z['sha256']
for z in pre['native_pins']+pre['resources']:assert Path(z['path']).stat().st_size==z['bytes']and sha(z['path'])==z['sha256']
for path,digest in pre['old_timers_ledgers'].items():assert sha(path)==digest
sv=os.statvfs('/private/tmp/ariadna-f17-0263/volume');assert sv.f_flag&os.ST_RDONLY
result=json.loads((p/'caller-tool-output.json').read_bytes());groups=result['summary']['groups'];gone={}
for name,pid in groups.items():
 assert pid>1 and pid not in{os.getpid(),os.getpgrp()}
 try:os.killpg(pid,0)
 except ProcessLookupError:gone[name]=True
 else:gone[name]=False
assert all(gone.values()),gone
assert not(p/'caller-tool-stderr.log').read_bytes()
x={'schema':'ariadna.f18.import-postcheck.v1','status':'PASS','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pins_unchanged':len(v['source_pins']),'native_pins_unchanged':len(pre['native_pins']),'resources_unchanged':len(pre['resources']),'old_timers_ledgers_unchanged':len(pre['old_timers_ledgers']),'groups_absent':gone,'image_read_only':True,'new_acquisition_bytes':0,'explicit_import_attempts':1,'explicit_owner_factories_integrations_and_spice_queries':0,'historical0269actual_counts':'unknown','runtime_implementation_unchanged':True}
with(p/'postcheck.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print(x)
