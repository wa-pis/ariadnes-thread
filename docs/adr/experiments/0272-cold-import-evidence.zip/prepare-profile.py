from pathlib import Path
import hashlib,json,os,subprocess,time,datetime
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0272');v=Path('/private/tmp/ariadna-f17-0263/volume');old=Path('/private/tmp/ariadna-f18-0269');sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
start=json.loads((p/'preflight-start.json').read_text());assert 0<=time.monotonic()-start['started_s']<600
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==start['base_revision']
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='dev'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
q=json.loads((r/'docs/adr/experiments/0271-qualification.json').read_text());prev=json.loads((old/'profile.json').read_text());prov=json.loads(Path('/private/tmp/ariadna-f17-0266/provisioning-receipt.json').read_text())
for name,pin in q['new_sources'].items():assert(r/name).stat().st_size==pin['bytes']and sha(r/name)==pin['sha256'],name
for name,pin in prev['source_pins'].items():assert(r/name).stat().st_size==pin['bytes']and sha(r/name)==pin['sha256'],name
for pin in prov['old_pins_unchanged']+prov['complete_required_files']:
 path=Path(pin['path']);assert path.is_file()and not path.is_symlink()and path.stat().st_size==pin['bytes']and sha(path)==pin['sha256'],str(path)
ledgers=dict(prov['old_timers_ledgers_unchanged'])
for directory,names in [(Path('/private/tmp/ariadna-f17-0266'),('preflight-start.json','acquisition-precharge.json','packet/episode-start.json','packet-stage.json','packet-finalization.json','offline-audit.json')),(old,('preflight-start.json','episode-start.json','execution/consumed.json','caller-finalization.json','caller-tool-output.json'))]:
 for name in names:ledgers[str(directory/name)]=sha(directory/name)
for path,digest in prov['old_timers_ledgers_unchanged'].items():assert sha(path)==digest,path
statv=os.statvfs(v);assert statv.f_flag&os.ST_RDONLY and statv.f_blocks*statv.f_frsize<=8*1024**3
resources=[x for x in(v/'home/.tudat/resource').rglob('*')if x.is_file()];assert len(resources)==5
sources=prev['source_pins']|q['new_sources']
for path in sorted((r/'src/space_nav').rglob('*.py')):sources[str(path.relative_to(r))]={'bytes':path.stat().st_size,'sha256':sha(path)}
work=p/'execution';rules=(old/'native.sandbox').read_text().replace(str(old/'execution'),str(work));assert rules!=(old/'native.sandbox').read_text()
with(p/'native.sandbox').open('x')as f:f.write(rules)
launcher=(old/'launch-once.py').read_text();needle='    admission = json.loads(Path(profile["prelaunch_admission"]).read_bytes())\n';assert launcher.count(needle)==1
launcher=launcher.replace(needle,'    adapter = Path(__file__).with_name("supervisor-adapter.py")\n    if hashlib.sha256(adapter.read_bytes()).hexdigest() != profile["adapter_sha256"]:\n        raise RuntimeError("supervisor adapter pin mismatch")\n'+needle)
with(p/'launch-once.py').open('x')as f:f.write(launcher)
with(p/'call-once.py').open('xb')as f:f.write((old/'call-once.py').read_bytes())
pre={'schema':'ariadna.f18.import-preflight-files.v1','status':'PASS_FILES_PENDING_CONTROLS_ADMISSION','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-start['started_s'],'base_revision':start['base_revision'],'source_pins':sources,'native_pins':prov['old_pins_unchanged'],'resources':prov['complete_required_files'],'resource_bytes':sum(x.stat().st_size for x in resources),'old_timers_ledgers':ledgers,'read_only_mount':True,'scratch_capacity_bytes':statv.f_blocks*statv.f_frsize,'aggregate_acquisition_bytes':497045495,'new_acquisition_bytes':0,'acquisition_ceiling_bytes':2*1024**3,'native_imports_or_probes':0,'work':'Static read/hash only; no native/scientific imports,SPICE,integration,build,copies. Fullsrc pins include eager package prefix; package resources are retained local identity only, no upstream authentication.'}
with(p/'root-preflight.json').open('x')as f:json.dump(pre,f,indent=2);f.write('\n')
x={'schema':'ariadna.f18.import-profile.v1','base_revision':start['base_revision'],'repo':str(r),'private_python':prev['private_python'],'work_directory':str(work),'preflight_started_s':start['started_s'],'environment':prev['environment'],'source_pins':sources,'sandbox_profile':str(p/'native.sandbox'),'sandbox_sha256':sha(p/'native.sandbox'),'prelaunch_admission':str(p/'launch-admission.json'),'entry_sha256':'PENDING','adapter_sha256':'PENDING','launch_sha256':sha(p/'launch-once.py'),'caller_sha256':sha(p/'call-once.py'),'kernel_sha256':prev['kernel_sha256'],'limits':start['limits'],'authority':start['authority'],'inference':'Import-only attempt; no retrospective0269counts/cause/native-owner or physicalF0/M3admission; no retry.'}
kernels=[pin['path']for pin in prov['old_pins_unchanged']if pin['sha256']==prev['kernel_sha256']];assert len(kernels)==1,kernels
x['input_profile']={'schema':'ariadna-import-input-v1','scope':'import-only','mode':'native','kernel_path':kernels[0],'kernel_sha256':prev['kernel_sha256'],'probe_sha256':q['new_sources']['src/space_nav/_import_probe.py']['sha256']}
with(p/'profile-draft.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
assert len((p/'profile-draft.json').read_bytes())<65536
preserve=(old/'check-preservation.py').read_text().replace('/private/tmp/ariadna-f18-0269','/private/tmp/ariadna-f18-0272')
with(p/'check-preservation.py').open('x')as f:f.write(preserve)
print({'file_admission':pre['status'],'source_pins':len(sources),'native_pins':len(pre['native_pins']),'resources':len(resources),'resource_bytes':pre['resource_bytes'],'old_ledgers':len(ledgers),'elapsed_s':pre['elapsed_s'],'profile_bytes':(p/'profile-draft.json').stat().st_size})
