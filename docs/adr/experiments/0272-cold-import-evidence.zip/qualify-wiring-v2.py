from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time

root=Path('/private/tmp/ariadna-f18-0272')
repo=Path('/Users/agrudin/dev/my/ariadna')
qualification=root/'artificial-wiring-v2'
qualification.mkdir(exist_ok=False)
fake=qualification/'fake-repo'/'src'/'space_nav'
fake.mkdir(parents=True)
(fake/'__init__.py').write_text('__path__.append('+repr(str(repo/'src/space_nav'))+')\n')
(fake/'_import_probe.py').write_text('''from pathlib import Path
import json, os, subprocess, sys, time
from ._owner_endpoint_run import _json_bytes

def _profile(raw):
    assert not any(k.split('.')[0] in {'tudatpy','numpy','scipy','spiceypy','cspyce'} for k in sys.modules)
    value=json.loads(raw)
    assert value['schema']=='ariadna-import-input-v1' and value['mode']=='native'
    return value

def main(args):
    assert len(args)==4 and args[0]=='--parent'
    assert os.getpid()==os.getpgrp()==os.getsid(0)
    profile=_profile(Path(args[1]).read_bytes())
    directory=Path(args[2]);directory.mkdir(exist_ok=False)
    (directory/'dispatch.json').write_bytes(_json_bytes({'args':args,'pid':os.getpid(),'pgid':os.getpgrp(),'scientific_imports':0,'artificial':True}))
    mode=profile['kernel_path']
    if mode=='stall':time.sleep(10)
    if mode=='pass':
        child=subprocess.Popen([sys.executable,'-I','-B','-c','import time;time.sleep(60)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        (directory/'descendant.pid').write_text(str(child.pid))
    report={'schema':'ariadna-import-run-v1','status':'passed','physical_admission':'unavailable','finalization':'checked-after-fsync' if mode=='pass' else 'pending-after-fsync-observation'}
    sys.stdout.buffer.write(_json_bytes(report));sys.stdout.buffer.flush()
    return 0
''')
results=[]
for mode in ('pass','unfinalized','stall'):
    case=qualification/mode;case.mkdir()
    work=case/'work';work.mkdir()
    profile={'work_directory':str(work),'private_python':sys.executable,'repo':str(qualification/'fake-repo'),'probe_input':{'schema':'ariadna-import-input-v1','scope':'import-only','mode':'native','kernel_path':mode,'kernel_sha256':'0'*64,'probe_sha256':'0'*64}}
    source=case/'profile.json';source.write_text(json.dumps(profile))
    started=time.monotonic()-(58.5 if mode=='stall' else 0)
    command=[sys.executable,'-I','-B',str(root/'native-entry.py'),str(source),repr(started)]
    process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:output,errors=process.communicate(timeout=8)
    finally:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        for name in ('parent.pgid','supervisor.pgid'):
            path=work/name
            if path.exists():
                group=int(path.read_text());assert group>1 and group not in {os.getpid(),os.getpgrp()}
                try:os.killpg(group,signal.SIGKILL)
                except ProcessLookupError:pass
    report=json.loads(output)
    assert not errors,errors
    assert report['schema']=='ariadna-import-supervisor-v1'
    assert report['physical_admission']=='unavailable'
    assert (report['status']=='passed')==(mode=='pass'),report
    assert process.returncode==(0 if mode=='pass' else 2)
    childfacts=json.loads((work/'native-packet/packet/dispatch.json').read_bytes())
    assert childfacts['scientific_imports']==0 and childfacts['artificial'] is True
    assert int((work/'parent.pgid').read_text())==childfacts['pgid']
    descendant=work/'native-packet/packet/descendant.pid'
    if descendant.exists():
        pid=int(descendant.read_text())
        for check in range(20):
            try:os.kill(pid,0)
            except ProcessLookupError:break
            time.sleep(0.01)
        else:raise AssertionError('artificial descendant still visible after group cleanup')
    result={'mode':mode,'returncode':process.returncode,'status':report['status'],'failure':report['failure'],'finalization':report['finalization'],'elapsed_wall_s':time.monotonic()-(started+(58.5 if mode=='stall' else 0)),'inherited_elapsed_s':time.monotonic()-started,'scientific_imports':0,'parent_dispatch_isolated':True,'descendant_not_running':True}
    (case/'stdout.json').write_bytes(output)
    (case/'stderr.log').write_bytes(errors)
    results.append(result)
receipt={'schema':'ariadna.f18.import-artificial-entry-wiring.v1','status':'PASS','interpreter':sys.executable,'scope':'actual fresh native-entry and supervisor-adapter with fake probe package; only unchanged pure control helpers imported; no private interpreter/native/scientific imports,SPICE,integration or actual probe','production_source_unchanged':True,'production_limits_unchanged':True,'stall_clock':'Inherited58.5s elapsed of unchanged60s total, leaves1.5s for cold stalled artificial parent','pins':{name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in('native-entry.py','supervisor-adapter.py')},'results':results,'clock_s':time.monotonic(),'preflight_elapsed_s':time.monotonic()-json.loads((root/'preflight-start.json').read_bytes())['started_s']}
with(root/'artificial-wiring-qualification.json').open('x')as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps(receipt))
