from pathlib import Path
import hashlib,json,tomllib,datetime
p=Path('/private/tmp/ariadna-f18-0272');path=Path('/Users/agrudin/.codex/automations/ariadna-m3/automation.toml');x=tomllib.loads(path.read_text());assert x['id']=='ariadna-m3'and x['status']=='PAUSED'and'ADR0272'in x['prompt'];y={'schema':'ariadna.f18.import-scheduler-readback.v1','status':'PASS','automation_id':x['id'],'scheduler_status':x['status'],'rrule':x['rrule'],'target_thread_id':x['target_thread_id'],'updated_via':'official automation_update, successful result then configuration readback','prompt_sha256':hashlib.sha256(x['prompt'].encode()).hexdigest(),'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Authorized once-only observation complete; any next native owner diagnostic needs separate explicit bounded decision.'}
with(p/'scheduler-readback.json').open('x')as f:json.dump(y,f,indent=2);f.write('\n')
print(y)
