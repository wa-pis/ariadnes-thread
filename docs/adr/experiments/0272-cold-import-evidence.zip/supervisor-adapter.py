"""Fixed F18.6 schema/dispatch adapter; copied qualified outer controls.

No native execution occurs on import. Only profile/schema and parent dispatch
adaptations differ from the pinned owner's run_isolated implementation.
"""
from __future__ import annotations

from collections.abc import Callable
import math
from pathlib import Path
from typing import Any

from space_nav._import_probe import _profile
from space_nav._owner_endpoint_run import (
    REPORT_BYTES, RunError, _Evidence, _check, _json_bytes, _now, _read,
    _sync, _watch_worker,
)


def run_isolated(raw: bytes, directory: Path, *,
                 parent_command: Callable[[Path, Path, float], list[str]],
                 started_s: float | None = None) -> dict[str, object]:
    """Supervise the cold parent and all inherited worker descendants once.

    Opaque supervisor I/O still requires caller supervision. Native work is
    stopped before the supervisor records its own final receipt, even on failure.
    """
    entered = _now()
    if _profile(raw)["mode"] != "native":
        raise RunError("fixed native import input required")
    if started_s is None:
        started_s = entered
    if (type(started_s) not in (int, float) or not math.isfinite(started_s)
            or started_s > entered):
        raise RunError("parent start must be finite past monotonic time")
    started_s = float(started_s)
    last = _check(started_s + 60.0, entered)
    directory.mkdir(parents=False, exist_ok=False)
    evidence = _Evidence(directory, 2048)
    evidence.caps["producer.json"] = REPORT_BYTES
    source, output, errors = (directory / n for n in
                              ("input.json", "producer.json", "producer.stderr.log"))
    report: dict[str, Any] = {"schema": "ariadna-import-supervisor-v1", "status": "failed",
                              "failure": None, "parent": None,
                              "physical_admission": "unavailable",
                              "finalization": "pending-after-fsync-observation"}
    try:
        evidence.write(source, raw)
        _sync(source)
        last = _check(started_s + 60.0, last)
        evidence.write(output, b"")
        evidence.write(errors, b"")
        worker = _watch_worker(parent_command(source, directory / "packet", started_s),
                               output, errors, started_s + 60.0, evidence)
        # The entire parent/worker group is gone before any supervisor recording.
        report["worker"] = worker
        last = _check(started_s + 60.0, last)
        parent = _read(output, REPORT_BYTES)
        report["parent"] = parent
        if (worker["exit_code"] != 0 or parent.get("schema") != "ariadna-import-run-v1"
                or parent.get("status") != "passed"
                or parent.get("finalization") != "checked-after-fsync"
                or parent.get("physical_admission") != "unavailable"):
            raise RunError("cold parent failed/unfinalized")
        report["status"] = "passed"
    except (RunError, OSError, ValueError, TypeError) as exc:
        report["failure"] = f"{type(exc).__name__}: {exc}"[:2048]
    evidence.write(directory / "receipt.json", _json_bytes(report))
    try:
        for path in directory.iterdir():
            if path.is_file():
                _sync(path)
                last = _check(started_s + 60.0, last)
    except (RunError, OSError, ValueError) as exc:
        report["status"] = "failed"
        report["failure"] = report["failure"] or f"{type(exc).__name__}: {exc}"[:2048]
        report["finalization"] = "failed-after-fsync"
    else:
        report["finalization"] = "checked-after-fsync"
    report["elapsed_at_last_valid_check_s"] = last - started_s
    return report
