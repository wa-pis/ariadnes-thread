from pathlib import Path
import datetime, json, os, subprocess, time
p=Path('/private/tmp/ariadna-f18-0274');r=Path('/Users/agrudin/dev/my/ariadna')
started=time.monotonic()
with(p/'required-regression.log').open('x')as log:
 proc=subprocess.Popen(['make','test','RUN='+str(p/'test-runner')],cwd=r,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),start_new_session=True)
 with(p/'regression-process.json').open('x')as f:json.dump({'pid':proc.pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ceiling_s':1800,'command':'make test RUN='+str(p/'test-runner')},f,indent=2);f.write('\n')
 try:
  code=proc.wait(timeout=1800)
 except subprocess.TimeoutExpired:
  import signal
  os.killpg(proc.pid,signal.SIGKILL);proc.wait();code=124
result={'exit_code':code,'elapsed_s':time.monotonic()-started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with(p/'regression-exit.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(result,flush=True)
raise SystemExit(code)
