from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path('/private/tmp/ariadna-f18-0275');r=Path('/Users/agrudin/dev/my/ariadna');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();read=lambda n:json.loads((p/n).read_bytes())
a=read('preflight-start.json');v=read('profile.json');review=read('prelaunch-independent-review.json');assert review['status']=='PASS',review
assert 0<=time.monotonic()-a['started_s']<600 and not(p/'execution').exists()and not(p/'episode-start.json').exists()
assert read('artificial-wiring-qualification.json')['status']=='PASS' and read('operational-before.json')['status']=='passed'
assert review['profile_sha256']==sha(p/'profile.json')
collector=read('prelaunch-collector-review.json');assert collector['status']=='PASS'
for name,pin in (review['control_pins']|collector['control_pins']).items():assert(p/name).stat().st_size==pin['bytes']and sha(p/name)==pin['sha256'],name
for name,z in v['source_pins'].items():assert(r/name).stat().st_size==z['bytes']and sha(r/name)==z['sha256'],name
for key,name in(('entry_sha256','native-entry.py'),('adapter_sha256','supervisor-adapter.py'),('launch_sha256','launch-once.py'),('caller_sha256','call-once.py'),('sandbox_sha256','native.sandbox')):assert sha(p/name)==v[key],key
assert read('profile-ready.json')['profile_sha256']==sha(p/'profile.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==a['base_revision']and subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='dev'and not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
receipt={'schema':'ariadna.f18.setup-launch-admission.v1','status':'PASS','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight_elapsed_s':time.monotonic()-a['started_s'],'profile_sha256':sha(p/'profile.json'),'review_sha256':{n:sha(p/n)for n in('prelaunch-independent-review.json','prelaunch-collector-review.json','artificial-wiring-qualification.json','operational-before.json','root-preflight.json')},'authority':a['authority'],'remaining_setup_attempts_before_consumption':1,'scope':'One cold never-run setup;1context/1factoryFalse/0integration/1visitorTrue exact refusal; no SPICEquery/trajectory/old retry or physical admission.'}
assert receipt['preflight_elapsed_s']<600
with(p/'launch-admission.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print({'status':'PASS','preflight_elapsed_s':receipt['preflight_elapsed_s'],'profile_sha256':receipt['profile_sha256']})
