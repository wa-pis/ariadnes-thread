from pathlib import Path
import json,sys,time
p=Path(__file__).parent
mode='late'
assert not any(k.split('.')[0]in{'tudatpy','numpy','scipy','spiceypy','cspyce','space_nav'}for k in sys.modules)
if mode=='no-episode':
 print('EARLY_PARTIAL',flush=True);print('EARLY_ERROR',file=sys.stderr,flush=True);raise SystemExit(3)
(p/'episode-start.json').write_text(json.dumps({'started_s':time.monotonic()-(61 if mode=='late'else 0)}))
(p/'execution').mkdir();(p/'execution/consumed.json').write_text('{"artificial":true}')
if mode=='timeout':
 print('TIMEOUT_PARTIAL',flush=True);print('TIMEOUT_ERROR',file=sys.stderr,flush=True);time.sleep(5)
print(json.dumps({'status':'passed','within60s':True}),flush=True)
