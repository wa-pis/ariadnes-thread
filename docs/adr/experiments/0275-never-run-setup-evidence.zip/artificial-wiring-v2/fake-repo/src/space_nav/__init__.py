__path__.append('/Users/agrudin/dev/my/ariadna/src/space_nav')
