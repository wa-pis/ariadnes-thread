from pathlib import Path
import json, os, subprocess, sys, time
from ._owner_endpoint_run import _json_bytes, _check
_SCOPE="never-run-owner-setup-only"

def _profile(raw):
    assert not any(k.split('.')[0] in {'tudatpy','numpy','scipy','spiceypy','cspyce'} for k in sys.modules)
    value=json.loads(raw)
    assert value['schema']=='ariadna-owner-setup-input-v1' and value['mode']=='native'
    return value

def main(args):
    assert len(args)==4 and args[0]=='--parent'
    assert os.getpid()==os.getpgrp()==os.getsid(0)
    profile=_profile(Path(args[1]).read_bytes())
    directory=Path(args[2]);directory.mkdir(exist_ok=False)
    (directory/'dispatch.json').write_bytes(_json_bytes({'args':args,'pid':os.getpid(),'pgid':os.getpgrp(),'scientific_imports':0,'artificial':True}))
    mode=profile['kernel_path']
    if mode=='stall':time.sleep(10)
    if mode=='pass':
        child=subprocess.Popen([sys.executable,'-I','-B','-c','import time;time.sleep(60)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        (directory/'descendant.pid').write_text(str(child.pid))
    report={'schema':'ariadna-owner-setup-run-v1','scope':'never-run-owner-setup-only','mode':'native','status':'passed','physical_admission':'unavailable','finalization':'checked-after-fsync' if mode=='pass' else 'pending-after-fsync-observation'}
    sys.stdout.buffer.write(_json_bytes(report));sys.stdout.buffer.flush()
    return 0
