from pathlib import Path
import datetime,hashlib,json,math,zipfile
p=Path('/private/tmp/ariadna-f18-0275');r=Path('/Users/agrudin/dev/my/ariadna')
def read(n):return json.loads((p/n).read_bytes())
def pin(f):
 b=Path(f).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
profile=read('profile.json');admission=read('launch-admission.json');start=read('preflight-start.json');episode=read('episode-start.json');consumed=read('execution/consumed.json');post=read('postcheck.json')
assert admission['status']=='PASS'and admission['profile_sha256']==episode['profile_sha256']==consumed['profile_sha256']==pin(p/'profile.json')['sha256']
for n,h in admission['review_sha256'].items():assert pin(p/n)['sha256']==h,n
assert episode['retry_authorized']is False and consumed['retry_authorized']is False
assert math.isclose(episode['started_s']-start['started_s'],episode['preflight_elapsed_s'],rel_tol=0,abs_tol=1e-9)
assert 0<=admission['preflight_elapsed_s']<=episode['preflight_elapsed_s']<=consumed['preflight_elapsed_s']<600
assert episode['deadline_s']==episode['started_s']+60 and consumed['status']=='consumed-before-native-entry'
for n,expected in post['episode_files'].items():assert pin(p/n)==expected,n
files={str(f.relative_to(p)):pin(f)for f in(p/'execution').rglob('*')if f.is_file()}
for n in ['episode-start.json','caller-output.json','caller-finalization.json','caller-tool-output.json','caller-tool-observation.json','collector-tool-return.json','caller-tool-stderr.log']:files[n]=pin(p/n)
assert files==post['episode_files']
structured=sum(v['bytes']for n,v in files.items()if not n.endswith('.log'));logs=sum(v['bytes']for n,v in files.items()if n.endswith('.log'));assert structured==post['episode_structured_bytes']==12079 and logs==post['episode_log_bytes']==213
assert structured<2097152 and logs<65536
for n in ['execution/native-packet/input.json','execution/native-packet/packet/input.json']:assert read(n)==profile['probe_input']and files[n]['bytes']<=65536
packet='execution/native-packet/packet/';trace=(p/packet/'trace.jsonl').read_bytes();assert len(trace)==617<4096 and trace.endswith(b'\n');lines=trace.splitlines(keepends=True);markers=[json.loads(x)for x in lines]
phases=['bootstrap-ready','import-ready','context-ready','factory-enter'];assert len(markers)==4
for i,(line,m)in enumerate(zip(lines,markers,strict=True)):
 assert len(line)<=512 and set(m)=={'elapsed_s','index','phase','schema','scope'}
 assert type(m['index'])is int and m['index']==i and m['phase']==phases[i]and m['schema']=='ariadna-owner-setup-marker-v1'and m['scope']=='never-run-owner-setup-only'
 assert type(m['elapsed_s'])in(int,float)and math.isfinite(m['elapsed_s'])and 0<=m['elapsed_s']<45
assert [m['elapsed_s']for m in markers]==sorted(m['elapsed_s']for m in markers)
assert not(p/packet/'producer.json').read_bytes()
for n in ['observation.json','audit.json','audit.stderr.log']:assert not(p/packet/n).exists()
error=(p/packet/'producer.stderr.log').read_bytes();reported=post['reported_resource'];assert len(error)==213 and b'RuntimeError: Data file could not be opened.'in error and reported.encode()in error
with zipfile.ZipFile(r/'docs/adr/experiments/0269-owner-timeout-evidence.zip')as z:oldwarning=z.read('execution/native-packet/packet/producer.stderr.log')
assert len(oldwarning)==64 and error.startswith(oldwarning)
assert post['reported_resource_exists']is False and reported not in{x['path']for x in read('root-preflight.json')['resources']}
parent_receipt=read(packet+'receipt.json');parent=read('execution/native-packet/producer.json');super_receipt=read('execution/native-packet/receipt.json');supervisor=read('execution/producer.json');launch_receipt=read('execution/receipt.json');launcher=read('caller-output.json');caller_receipt=read('caller-finalization.json');caller=read('caller-tool-output.json');outer_receipt=read('caller-tool-observation.json');outer=read('collector-tool-return.json')
assert parent_receipt['finalization']==super_receipt['finalization']==outer_receipt['finalization']=='pending-after-fsync-observation'
assert parent['finalization']==supervisor['finalization']==launcher['finalization']=='checked-after-fsync'
for item in [parent_receipt,parent,super_receipt,supervisor,launch_receipt,launcher,caller_receipt,caller,outer_receipt,outer]:assert item['status']=='failed'
assert len(parent['workers'])==1 and parent['workers'][0]['kind']=='probe'and parent['workers'][0]['exit_code']==2
assert parent['failure']=='RunError: probe child failed; trace does not establish setup completion'
assert parent['limits']['factory_attempts']==parent['limits']['visitor_calls']==parent['limits']['context_checks']==1 and parent['limits']['integration_attempts']==0
assert {k:v for k,v in parent.items()if k not in ['finalization','structured_bytes','log_bytes','elapsed_at_last_valid_check_s']}=={k:v for k,v in parent_receipt.items()if k!='finalization'}
assert super_receipt['parent']==supervisor['parent']==parent
assert {k:v for k,v in supervisor.items()if k not in ['finalization','elapsed_at_last_valid_check_s']}=={k:v for k,v in super_receipt.items()if k!='finalization'}
assert launch_receipt['supervisor']==launcher['supervisor']==supervisor
assert {k:v for k,v in launcher.items()if k not in ['finalization','elapsed_after_receipt_fsync_s']}==launch_receipt
assert caller['summary']==caller_receipt and caller['within60s']is True and caller_receipt['returncode']==2
assert caller_receipt['total_structured_bytes_before_caller_receipt']==sum(v['bytes']for n,v in files.items()if n.startswith('execution/')and not n.endswith('.log'))+files['caller-output.json']['bytes']+files['episode-start.json']['bytes']
assert outer['observation']==outer_receipt and outer_receipt['returncode']==2 and outer_receipt['native_attempt_consumed']is True and outer['finalization']=='failed-or-unavailable-after-fsync'
times=[parent['elapsed_at_last_valid_check_s'],supervisor['elapsed_at_last_valid_check_s'],launcher['elapsed_after_group_cleanup_s'],launcher['elapsed_after_receipt_fsync_s'],caller_receipt['elapsed_after_cleanup_s'],caller_receipt['elapsed_after_output_fsync_s'],caller['observed_after_caller_finalization_fsync_s'],outer_receipt['observed_after_output_fsync_s'],outer['observed_after_observation_fsync_s']]
assert times==sorted(times)and all(0<=t<60 for t in times)
assert all(x['physical_admission']=='unavailable'for x in[parent,supervisor,launcher])
assert post['status']=='PASS_PRESERVATION_FAILURE_RETAINED'and post['source_pins_unchanged']==49 and post['native_pins_unchanged']==10 and post['resources_unchanged']==5 and post['old_timers_ledgers_unchanged']==25
assert post['groups_absent']=={'parent.pgid':True,'supervisor.pgid':True}
for name in ['parent.pgid','supervisor.pgid']:
 group=int((p/'execution'/name).read_bytes());assert group>1 and caller_receipt['groups'][name]==outer_receipt['groups'][name]==group
assert post['image_read_only']and post['new_acquisition_bytes']==0 and post['runtime_implementation_unchanged']
for n,expected in profile['source_pins'].items():assert pin(r/n)==expected,n
for n in ['preflight-start.json','profile.json','profile-ready.json','root-preflight.json','prelaunch-independent-review.json','prelaunch-collector-review-initial.json','prelaunch-collector-review.json','launch-admission.json','postcheck.json']:files[n]=pin(p/n)
if(p/'operational-after.json').exists():
 ops=read('operational-after.json');assert ops['status']=='passed'and ops['manifest_equal']and not ops['differences']and ops['paths_compared']==71459 and ops['regular_bytes']==1646916124;files['operational-after.json']=pin(p/'operational-after.json')
result={'schema':'ariadna.f18.setup-independent-failure-accounting.v1','status':'PASS_ACCOUNTED_FAILURE','findings':[],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent stdlib saved-record/hash/source review only. No project/native imports, SPICE, integration, mounted-image access, process signals, runtime tests, new resources or retries.','auditor_script':pin(Path(__file__)),'full_setup_success':'REJECT','full_success_rejection_reasons':['Native producer exited2 and emitted no producer report.','Only first4of8 markers are present; factory-return, visitor-enter, visitor-refused and complete are absent.','No successful producer observation or independent full success audit was launched.'],'profile_sha256':pin(p/'profile.json')['sha256'],'observed':{'admission_preflight_s':admission['preflight_elapsed_s'],'episode_preflight_s':episode['preflight_elapsed_s'],'consumed_preflight_s':consumed['preflight_elapsed_s'],'outer_post_observation_fsync_s':outer['observed_after_observation_fsync_s'],'partial_trace_bytes':len(trace),'partial_trace_sha256':pin(p/packet/'trace.jsonl')['sha256'],'markers':markers,'producer_exit_code':2,'producer_report_bytes':0,'stderr_bytes':len(error),'common_OMP_warning_bytes':64,'reported_resource':reported,'reported_resource_exists_saved_postcheck':False,'episode_structured_bytes':structured,'episode_log_bytes':logs,'nested_failed_statuses_and_distinct_prefinal_returned_postfsync':True,'recorded_groups':caller_receipt['groups'],'recorded_groups_absent_saved_postcheck':post['groups_absent'],'source_native_resource_old_ledger_preservation_saved_counts':[49,10,5,25]},'operation_accounting':{'cold_prefix_attempts_observed':1,'context_ready_markers':1,'factory_enter_markers':1,'factory_return_markers':0,'visitor_enter_markers':0,'explicit_integration_requests_reached':0,'explicit_visitor_requests_reached':0,'actual_native_internal_counts':'UNKNOWN; no completed report/count snapshot. A precharged factory-enter marker is not proof of successful native factory completion.','native_RHS_or_callback_counts':'UNKNOWN; do not infer zero internal initialization/callback work.'},'authority':{'attempt_consumed':True,'remaining_authorized_attempts':0,'retry_authorized':False},'scientific_caveats':['This is a correctly retained failed setup observation, not a successful never-run rejection test or completed-owner qualification.','Exact error text and saved absence support a missing-resource failure on this attempt; markers bracket whole factory plus adjacent observer I/O and do not identify a native instruction.','Shared64BOMPwarning does not establish0269cause, import completion or retrospective operation counts.','No new SPICE query or integration was explicitly requested; native internal initialization/resource actions were not instrumented.','F18.3,F17/F17.1,completed-owner/carry/concurrency/ABI-FP/prior arithmetic and physicalF0/M3/99percent/safety gates remain open.'],'reviewed_files':files,'not_independently_executed':'Root postcheck supplies actual group absence, native/resource/ledger preservation and resource absence observations; reviewer verifies saved identities/counts and raw failure chain without rerunning those system/native operations.'}
with(p/'audit-failure-accounting.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'full_setup_success':'REJECT','native_attempt_consumed':True,'structured_bytes':structured,'logs':logs,'output':str(p/'audit-failure-accounting.json'),**pin(p/'audit-failure-accounting.json')},indent=2))
