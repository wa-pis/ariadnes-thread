from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,time
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0275');old=Path('/private/tmp/ariadna-f18-0272');v=Path('/private/tmp/ariadna-f17-0263/volume');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();a=json.loads((p/'preflight-start.json').read_bytes());prev=json.loads((old/'profile.json').read_bytes());prov=json.loads(Path('/private/tmp/ariadna-f17-0266/provisioning-receipt.json').read_bytes());q=json.loads((r/'docs/adr/experiments/0274-owner-setup-qualification.json').read_bytes());assert 0<=time.monotonic()-a['started_s']<600
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==a['base_revision'] and not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True).strip()
for name,pin in (prev['source_pins']|q['new_sources']).items():assert (r/name).stat().st_size==pin['bytes'] and sha(r/name)==pin['sha256'],name
for pin in prov['old_pins_unchanged']+prov['complete_required_files']:
 f=Path(pin['path']);assert f.is_file()and not f.is_symlink()and f.stat().st_size==pin['bytes']and sha(f)==pin['sha256'],str(f)
sv=os.statvfs(v);assert sv.f_flag&os.ST_RDONLY and sv.f_blocks*sv.f_frsize<=8*1024**3
resources=[f for f in(v/'home/.tudat/resource').rglob('*')if f.is_file()];assert len(resources)==5
sources={str(f.relative_to(r)):{'bytes':f.stat().st_size,'sha256':sha(f)}for f in sorted((r/'src/space_nav').rglob('*.py'))}
for name,pin in q['new_sources'].items():sources[name]=pin
ledgers=dict(json.loads((old/'root-preflight.json').read_bytes())['old_timers_ledgers'])
for folder,names in [(old,('preflight-start.json','episode-start.json','execution/consumed.json','caller-finalization.json','caller-tool-output.json')),(Path('/private/tmp/ariadna-f18-0274'),('profile.json','regression-qualification.json','frozen-before.json','frozen-after.json','regression-exit.json'))]:
 for name in names:ledgers[str(folder/name)]=sha(folder/name)
for f,digest in json.loads((old/'root-preflight.json').read_bytes())['old_timers_ledgers'].items():assert sha(f)==digest,f
for name in ('call-once.py','launch-once.py'):
 with(p/name).open('xb')as f:f.write((old/name).read_bytes())
with(p/'native.sandbox').open('x')as f:f.write((old/'native.sandbox').read_text().replace(str(old/'execution'),str(p/'execution')))
entry=(old/'native-entry.py').read_text().replace('F18.6','F18.9').replace('from space_nav import _import_probe as controller','from space_nav import _owner_setup_probe as controller').replace('f186_supervisor_adapter','f189_supervisor_adapter')
with(p/'native-entry.py').open('x')as f:f.write(entry)
source=(r/'src/space_nav/_owner_setup_probe.py').read_text();node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name=='run_isolated');body=ast.get_source_segment(source,node);original=body
sig='def run_isolated(raw: bytes, directory: Path, *, started_s: float | None = None) -> dict[str, object]:';assert body.count(sig)==1
body=body.replace(sig,'def run_isolated(raw: bytes, directory: Path, *,\n                 parent_command: Callable[[Path, Path, float], list[str]],\n                 started_s: float | None = None) -> dict[str, object]:',1);assert body.count('_watch_worker(_parent_command(')==1;body=body.replace('_watch_worker(_parent_command(','_watch_worker(parent_command(',1)
header='''"""Fixed F18.9 dispatch adapter; no native execution on import."""
from __future__ import annotations
from collections.abc import Callable
import math
from pathlib import Path
from typing import Any
from space_nav._owner_setup_probe import _profile, _check, _SCOPE
from space_nav._owner_endpoint_run import REPORT_BYTES, RunError, _Evidence, _json_bytes, _now, _read, _sync, _watch_worker

'''
with(p/'supervisor-adapter.py').open('x')as f:f.write(header+body+'\n')
assert body.replace('def run_isolated(raw: bytes, directory: Path, *,\n                 parent_command: Callable[[Path, Path, float], list[str]],\n                 started_s: float | None = None) -> dict[str, object]:',sig,1).replace('_watch_worker(parent_command(','_watch_worker(_parent_command(',1)==original
pre={'schema':'ariadna.f18.setup-preflight-files.v1','status':'PASS_FILES_PENDING_CONTROLS_ADMISSION','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-a['started_s'],'base_revision':a['base_revision'],'source_pins':sources,'native_pins':prov['old_pins_unchanged'],'resources':prov['complete_required_files'],'resource_bytes':sum(f.stat().st_size for f in resources),'old_timers_ledgers':ledgers,'read_only_mount':True,'scratch_capacity_bytes':sv.f_blocks*sv.f_frsize,'aggregate_acquisition_bytes':497045495,'new_acquisition_bytes':0,'acquisition_ceiling_bytes':2*1024**3,'native_imports_or_probes':0}
with(p/'root-preflight.json').open('x')as f:json.dump(pre,f,indent=2);f.write('\n')
kernel=next(pin for pin in prov['old_pins_unchanged']if pin['role']=='kernel');assert kernel['sha256']==prev['kernel_sha256']
x={'schema':'ariadna.f18.setup-profile.v1','base_revision':a['base_revision'],'repo':str(r),'private_python':prev['private_python'],'work_directory':str(p/'execution'),'preflight_started_s':a['started_s'],'environment':prev['environment'],'source_pins':sources,'sandbox_profile':str(p/'native.sandbox'),'sandbox_sha256':sha(p/'native.sandbox'),'prelaunch_admission':str(p/'launch-admission.json'),'entry_sha256':sha(p/'native-entry.py'),'adapter_sha256':sha(p/'supervisor-adapter.py'),'launch_sha256':sha(p/'launch-once.py'),'caller_sha256':sha(p/'call-once.py'),'kernel_sha256':prev['kernel_sha256'],'limits':a['limits'],'authority':a['authority'],'inference':'One new never-run setup only; no0269counts/cause, no completed-owner/physical admission, no retry.'}
x['probe_input']={'schema':'ariadna-owner-setup-input-v1','scope':'never-run-owner-setup-only','mode':'native','kernel_path':kernel['path'],'kernel_sha256':kernel['sha256'],'probe_sha256':sources['src/space_nav/_owner_setup_probe.py']['sha256'],'owner_fixture_sha256':sources['src/space_nav/_owner_endpoint_fixture.py']['sha256'],'owner_auditor_sha256':sources['src/space_nav/_owner_endpoint_audit.py']['sha256'],'trajectory_sha256':sources['src/space_nav/trajectory.py']['sha256'],'setup_auditor_sha256':sources['src/space_nav/_owner_setup_audit.py']['sha256']}
with(p/'profile.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
assert(p/'profile.json').stat().st_size<65536
with(p/'check-preservation.py').open('x')as f:f.write((old/'check-preservation.py').read_text().replace(str(old),str(p)))
wire=(old/'qualify-wiring-v2.py').read_text().replace(str(old),str(p)).replace('_import_probe.py','_owner_setup_probe.py').replace('ariadna-import-input-v1','ariadna-owner-setup-input-v1').replace('ariadna-import-run-v1','ariadna-owner-setup-run-v1').replace('ariadna-import-supervisor-v1','ariadna-owner-setup-supervisor-v1').replace("'scope':'import-only'","'scope':'never-run-owner-setup-only'")
wire=wire.replace('from ._owner_endpoint_run import _json_bytes','from ._owner_endpoint_run import _json_bytes, _check\n_SCOPE="never-run-owner-setup-only"')
wire=wire.replace("report={'schema':'ariadna-owner-setup-run-v1','status'", "report={'schema':'ariadna-owner-setup-run-v1','scope':'never-run-owner-setup-only','mode':'native','status'")
with(p/'qualify-wiring.py').open('x')as f:f.write(wire)
print({'sources':len(sources),'native_pins':len(pre['native_pins']),'resources':len(resources),'old_ledgers':len(ledgers),'profile_bytes':(p/'profile.json').stat().st_size,'elapsed_s':pre['elapsed_s'],'adapter_body_exact_except_callback':True})
