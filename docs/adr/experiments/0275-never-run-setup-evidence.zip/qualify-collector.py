from pathlib import Path
import hashlib,json,subprocess,sys,time
p=Path('/private/tmp/ariadna-f18-0275');q=p/'artificial-collector';q.mkdir(exist_ok=False);source=(p/'run-once.py').read_text();results=[]
for mode in('pass','no-episode','timeout','late'):
 root=q/mode;root.mkdir();(root/'launch-admission.json').write_text('{"status":"PASS"}\n');(root/'profile.json').write_text('{}\n')
 fake='''from pathlib import Path
import json,sys,time
p=Path(__file__).parent
mode=MODE
assert not any(k.split('.')[0]in{'tudatpy','numpy','scipy','spiceypy','cspyce','space_nav'}for k in sys.modules)
if mode=='no-episode':
 print('EARLY_PARTIAL',flush=True);print('EARLY_ERROR',file=sys.stderr,flush=True);raise SystemExit(3)
(p/'episode-start.json').write_text(json.dumps({'started_s':time.monotonic()-(61 if mode=='late'else 0)}))
(p/'execution').mkdir();(p/'execution/consumed.json').write_text('{"artificial":true}')
if mode=='timeout':
 print('TIMEOUT_PARTIAL',flush=True);print('TIMEOUT_ERROR',file=sys.stderr,flush=True);time.sleep(5)
print(json.dumps({'status':'passed','within60s':True}),flush=True)
'''.replace('MODE',repr(mode))
 (root/'call-once.py').write_text(fake)
 script=source.replace(str(p),str(root));assert script!=source
 if mode=='timeout':script=script.replace('communicate(timeout=65)','communicate(timeout=0.25)')
 (root/'collector.py').write_text(script)
 out=subprocess.run([sys.executable,'-I','-B',str(root/'collector.py')],capture_output=True,timeout=5)
 report=json.loads(out.stdout);saved=json.loads((root/'caller-tool-observation.json').read_bytes());assert (out.returncode==0)==(mode=='pass') and (report['status']=='passed')==(mode=='pass')
 assert not out.stderr and saved['finalization']=='pending-after-fsync-observation'
 if mode=='no-episode':assert not saved['native_attempt_consumed']and saved['observed_after_output_fsync_s']is None and'EARLY_PARTIAL'in(root/'caller-tool-output.json').read_text()
 if mode=='timeout':assert 'TIMEOUT_PARTIAL'in(root/'caller-tool-output.json').read_text()and'TIMEOUT_ERROR'in(root/'caller-tool-stderr.log').read_text()and'external65s'in saved['failure']
 if mode=='late':assert report['observed_after_observation_fsync_s']>=60 and report['finalization']=='failed-or-unavailable-after-fsync'
 (root/'observed.json').write_bytes(out.stdout);results.append({'mode':mode,'returncode':out.returncode,'status':report['status'],'retained_observation':True,'scientific_imports':0})
x={'schema':'ariadna.f18.setup-artificial-collector-qualification.v1','status':'PASS','collector_sha256':hashlib.sha256(source.encode()).hexdigest(),'results':results,'scope':'Actual collector source with only fresh artificial root substitution; timeout case only shortens external65s failsafe to0.25s for artificial clock injection. No production cap changes or native/project/scientific imports.','preflight_elapsed_s':time.monotonic()-json.loads((p/'preflight-start.json').read_bytes())['started_s']}
with(p/'artificial-collector-qualification.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print(json.dumps(x))
