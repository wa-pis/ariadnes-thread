from pathlib import Path
import datetime,json,os,signal,subprocess,sys,time
p=Path('/private/tmp/ariadna-f18-0275');assert not(p/'episode-start.json').exists() and not(p/'execution').exists()
a=json.loads((p/'launch-admission.json').read_bytes());assert a['status']=='PASS'
entered=time.monotonic();process=subprocess.Popen([sys.executable,'-I','-B',str(p/'call-once.py'),str(p/'profile.json')],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
try:
 output,errors=process.communicate(timeout=65)
finally:
 try:os.killpg(process.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 for name in ('parent.pgid','supervisor.pgid'):
  record=p/'execution'/name
  if not record.exists():continue
  with record.open('rb')as f:raw=f.read(33)
  if len(raw)>32 or not raw.strip().isdigit():raise RuntimeError('invalid outer PGID')
  group=int(raw);assert group>1 and group not in{os.getpid(),os.getpgrp()}
  try:os.killpg(group,signal.SIGKILL)
  except ProcessLookupError:pass
 process.wait(timeout=1)

for name,data in(('caller-tool-output.json',output),('caller-tool-stderr.log',errors)):
 assert len(data)<=65536
 with(p/name).open('xb')as f:f.write(data);f.flush();os.fsync(f.fileno())
start=json.loads((p/'episode-start.json').read_bytes())['started_s'];post=time.monotonic()-start
x={'schema':'ariadna.f18.setup-caller-tool-observation.v1','returncode':process.returncode,'observed_after_output_fsync_s':post,'within60s':post<60,'elapsed_wrapper_s':time.monotonic()-entered,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_bytes':len(output),'stderr_bytes':len(errors),'native_attempt_consumed':(p/'execution/consumed.json').exists()}
with(p/'caller-tool-observation.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'returncode':process.returncode,'observed_after_observation_fsync_s':time.monotonic()-start,'observation':x}));print(output.decode())
