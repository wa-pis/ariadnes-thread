"""Read-only source receipts; deliberately imports no project/native code."""
from pathlib import Path
from hashlib import sha256
import json
import time
from datetime import datetime, timezone

repo = Path('/Users/agrudin/dev/my/ariadna')
volume = Path('/private/tmp/ariadna-f17-0263/volume')
core = volume / 'source'
site = volume / 'env/lib/python3.12/site-packages/tudatpy'
started = json.loads(Path('/private/tmp/ariadna-f18-0276/inventory-start.json').read_text())
anchors = []

def anchor(label, path, first, last, reason):
    data = path.read_bytes()
    lines = data.decode().splitlines()
    assert 1 <= first <= last <= len(lines), (label, len(lines))
    item = {'id': label, 'path': str(path), 'first_line': first, 'last_line': last,
            'sha256': sha256(data).hexdigest(), 'size_bytes': len(data),
            'excerpt': '\n'.join(lines[first-1:last]), 'reason': reason}
    anchors.append(item)
    return label

anchor('factory', repo/'src/space_nav/_owner_endpoint_fixture.py', 121, 173,
       'Fixed never-run/False branch imports dynamics before empty-body setup; later simulator argument is supplied simulate=False.')
anchor('dynamics_import', site/'dynamics/__init__.py', 1, 9, 'Eager package imports include environment_setup.')
anchor('environment_setup_import', site/'dynamics/environment_setup/__init__.py', 36, 49, 'Eager imports include gravity_field.')
anchor('gravity_import', site/'dynamics/environment_setup/gravity_field/__init__.py', 1, 2, 'Imports sbdb_wrapper at package import.')
anchor('sbdb_import', site/'dynamics/environment_setup/gravity_field/sbdb_wrapper.py', 1, 3, 'Importing tudatpy.data.sbdb first initializes tudatpy.data package.')
anchor('data_import', site/'data/__init__.py', 1, 4, 'Eager data package initialization includes processTrk234.')
anchor('trk_import', site/'data/processTrk234/__init__.py', 1, 1, 'Imports processor.')
anchor('processor_import', site/'data/processTrk234/processor.py', 1, 9, 'Imports converters at module top level.')
anchor('converters_import', site/'data/processTrk234/converters/__init__.py', 1, 5, 'Imports RadioBase eagerly.')
anchor('radio_class', site/'data/processTrk234/converters/radioBase.py', 5, 34, 'Class definition evaluates default_time_scale_converter at line25; stationDict at34 occurs after converter returns.')
anchor('time_python_import', site/'astro/time_representation/__init__.py', 1, 1, 'Exports corresponding kernel binding.')
anchor('converter_pybind', core/'src/tudatpy/astro/time_representation/expose_time_representation.cpp', 1589, 1601, 'Binding default_time_scale_converter names createDefaultTimeConverterPy; documentation is supporting context, not runtime evidence.')
anchor('converter_wrapper', core/'src/tudatpy/astro/time_representation/expose_time_representation.cpp', 90, 95, 'Wrapper calls createDefaultTimeConverter without arguments.')
anchor('converter_default_eop', core/'include/tudat/astro/earth_orientation/terrestrialTimeScaleConverter.h', 538, 548, 'Default argument creates EOPReader. Commented static converter is not executed.')
anchor('eop_filename', core/'include/tudat/astro/earth_orientation/eopReader.h', 40, 50, 'Default EOP file is eopc04_14_IAU2000.62-now.txt.')
anchor('eop_reader', core/'src/tudat/astro/earth_orientation/eopReader.cpp', 20, 60, 'EOPReader constructor calls readEopFile, which opens named file and throws on failure.')
anchor('converter_core', core/'src/tudat/astro/earth_orientation/terrestrialTimeScaleConverter.cpp', 64, 78, 'After EOPReader completes, constructor calls default UT1 correction factory and TerrestrialTimeScaleConverter.')
anchor('ut1_files', core/'src/tudat/astro/earth_orientation/shortPeriodEarthOrientationCorrectionCalculator.cpp', 76, 89, 'Four named UT1 tidal/libration files passed to eager short-period constructor.')
anchor('tidal_reader', core/'include/tudat/astro/earth_orientation/shortPeriodEarthOrientationCorrectionCalculator.h', 58, 81, 'Constructor immediately reads all amplitude/multiplier pairs.')
anchor('pair_reader', core/'src/tudat/astro/earth_orientation/readAmplitudeAndArgumentMultipliers.cpp', 23, 34, 'Each pair is read through readMatrixFromFile.')
anchor('matrix_reader', core/'src/tudat/io/matrixTextFileReader.cpp', 34, 43, 'readMatrixFromFile opens path and rejects missing file.')
anchor('historical_reader', core/'include/tudat/astro/earth_orientation/terrestrialTimeScaleConverter.h', 95, 127, 'Time-scale converter constructor unconditionally reads historicalDeltaT.txt before interpolation.')
anchor('delta_map_reader', core/'include/tudat/io/mapTextFileReader.h', 187, 205, 'Floating point map reader delegates to file-backed STL vector reader.')
anchor('earth_orientation_path', core/'include/tudat/io/basicInputOutput.h', 83, 86, 'Core accessor delegates to resource package get_earth_orientation_path.')
anchor('resource_home_path', volume/'env/include/tudat/resource/resource.h', 31, 60, 'Retained header resolves resource path via HOME/.tudat/resource/earth_orientation; compiled macro/linkage equivalence not proved.')
anchor('dsn_builtin', core/'src/tudat/simulation/environment_setup/defaultBodies.cpp', 508, 544, 'DSN station lookup returns source literal map; no resource-reader call in this function.')
anchor('body_settings', core/'include/tudat/simulation/environment_setup/createBodies.h', 39, 67, 'Empty settings hold null model pointers until supplied; fixed path only changes constant mass.')
anchor('body_list', core/'include/tudat/simulation/environment_setup/createBodies.h', 117, 158, 'BodyListSettings constructor and addSettings allocate plain settings.')
anchor('body_binding', core/'src/tudatpy/dynamics/environment_setup/expose_environment_setup.cpp', 255, 291, 'BodyListSettings binding targets core constructor.')
anchor('empty_binding', core/'src/tudatpy/dynamics/environment_setup/expose_environment_setup.cpp', 334, 340, 'add_empty_settings maps to BodyListSettings.addSettings.')
anchor('create_body_binding', core/'src/tudatpy/dynamics/environment_setup/expose_environment_setup.cpp', 651, 654, 'create_system_of_bodies maps to core createSystemOfBodies template.')
anchor('empty_body_core', core/'include/tudat/simulation/environment_setup/createBodies.h', 215, 246, 'createSystemOfBodies creates empty bodies, sets constant mass, only builds ephemeris when settings nonnull.')
anchor('empty_body_constructor', core/'include/tudat/simulation/environment_setup/body.h', 529, 544, 'Default Body constructs zero/identity state objects, not an Earth/time converter.')
anchor('system_body_core', core/'include/tudat/simulation/environment_setup/body.h', 2137, 2142, 'SystemOfBodies stores frame/map; constructor body empty.')
anchor('create_empty_core', core/'include/tudat/simulation/environment_setup/body.h', 2178, 2186, 'createEmptyBody constructs Body; frame processing deferred when false.')
anchor('integrator_builder', repo/'src/space_nav/trajectory.py', 1655, 1686, 'Fixed integrator builder constructs profile settings using lazy propagation_setup import.')
anchor('coupled_builder', repo/'src/space_nav/trajectory.py', 1689, 1756, 'Coast custom mass-rate and translation/mass/multitype settings; no thrust engine request.')
anchor('simulator_binding', core/'src/tudatpy/dynamics/simulator/expose_simulator.cpp', 472, 476, 'Public simulator maps bool argument to createDynamicsSimulator.')
anchor('simulator_dispatch', core/'include/tudat/simulation/estimation_setup/createNumericalSimulator.h', 53, 70, 'Single-arc constructor receives integration bool unchanged.')
anchor('simulator_setup', core/'include/tudat/simulation/propagation_setup/dynamicsSimulator.h', 659, 717, 'Simulator constructor eagerly builds feasibility/updater/derivative-model setup before integration guard.')
anchor('simulator_guard', core/'include/tudat/simulation/propagation_setup/dynamicsSimulator.h', 793, 798, 'Integration only when areEquationsOfMotionToBeIntegrated true at this guard; False does not skip preceding setup.')
anchor('sofa_leapsecond', core/'src/tudat/interface/sofa/sofaTimeConversions.cpp', 23, 44, 'Conversion function calls SOFA iauDat; no external leap-second filename here, and conversion method not called by fixed factory source.')
anchor('polar_motion_files', core/'src/tudat/astro/earth_orientation/shortPeriodEarthOrientationCorrectionCalculator.cpp', 91, 107, 'Other four files belong to separate polar-motion factory, not default UT1 factory.')
anchor('earth_orientation_other', core/'src/tudat/astro/earth_orientation/earthOrientationCalculator.cpp', 60, 94, 'Standard Earth-orientation calculator uses polar-motion and time conversion; no fixed factory call to this entry point established.')

edges = [
('factory','dynamics_import','eager-import'),('dynamics_import','environment_setup_import','eager-import'),
('environment_setup_import','gravity_import','eager-import'),('gravity_import','sbdb_import','eager-import'),
('sbdb_import','data_import','package-initialization'),('data_import','trk_import','eager-import'),
('trk_import','processor_import','eager-import'),('processor_import','converters_import','eager-import'),
('converters_import','radio_class','eager-class-definition'),('radio_class','time_python_import','namespace-import'),
('radio_class','converter_pybind','class-attribute-call'),('converter_pybind','converter_wrapper','binding'),
('converter_wrapper','converter_default_eop','no-argument-call/default-argument'),('converter_default_eop','eop_filename','default-constructor'),
('eop_filename','eop_reader','constructor-eager-open'),('converter_default_eop','converter_core','after-default-argument-success'),
('converter_core','ut1_files','eager-call'),('ut1_files','tidal_reader','constructor-eager-open'),
('tidal_reader','pair_reader','reader-call'),('pair_reader','matrix_reader','reader-call'),
('converter_core','historical_reader','constructor-eager-open'),('historical_reader','delta_map_reader','reader-call'),
('eop_filename','earth_orientation_path','path-accessor'),('earth_orientation_path','resource_home_path','header-call'),
('radio_class','dsn_builtin','later-class-attribute-call'),('factory','body_binding','after-import-success'),
('body_binding','body_list','binding'),('factory','empty_binding','after-import-success'),
('empty_binding','body_list','binding'),('factory','create_body_binding','after-import-success'),
('create_body_binding','empty_body_core','binding'),('empty_body_core','create_empty_core','call'),
('create_empty_core','empty_body_constructor','constructor'),('empty_body_core','system_body_core','constructor'),
('factory','integrator_builder','later-setup'),('factory','coupled_builder','later-setup'),
('factory','simulator_binding','later-setup-false'),('simulator_binding','simulator_dispatch','binding'),
('simulator_dispatch','simulator_setup','single-arc-dispatch'),('simulator_setup','simulator_guard','after-eager-setup')]

resources = [
('eopc04_14_IAU2000.62-now.txt','eager','eop_reader','Default EOPReader is evaluated before createDefaultTimeConverter function body; failure prevents later readers.'),
('utcLibrationAmplitudes.txt','eager','ut1_files','Read after EOPReader succeeds through default UT1 short-period factory.'),
('utcOceanTidesAmplitudes.txt','eager','ut1_files','Read after EOPReader succeeds through default UT1 short-period factory.'),
('utcLibrationFundamentalArgumentMultipliers.txt','eager','ut1_files','Read after EOPReader succeeds through default UT1 short-period factory.'),
('utcOceanTidesFundamentalArgumentMultipliers.txt','eager','ut1_files','Read after EOPReader succeeds through default UT1 short-period factory.'),
('historicalDeltaT.txt','eager','historical_reader','Read when converter constructor is reached, even though fixed coast needs no epoch conversion.'),
('polarMotionLibrationAmplitudesQuasiDiurnalOnly.txt','unused','polar_motion_files','Separate polar-motion correction factory not requested by fixed empty body/time-converter chain.'),
('polarMotionOceanTidesAmplitudes.txt','unused','polar_motion_files','Separate polar-motion correction factory not requested by fixed empty body/time-converter chain.'),
('polarMotionLibrationFundamentalArgumentMultipliersQuasiDiurnalOnly.txt','unused','polar_motion_files','Separate polar-motion correction factory not requested by fixed empty body/time-converter chain.'),
('polarMotionOceanTidesFundamentalArgumentMultipliers.txt','unused','polar_motion_files','Separate polar-motion correction factory not requested by fixed empty body/time-converter chain.')]
receipt = {
 'schema':'ariadna.f18.fixed-setup-source-callgraph.v1',
 'stage':'F18.10/ADR0276', 'base_revision':started['base_revision'],
 'scope':"Read/hash only. Source-visible fixed _native_factory('never-run', False) import/setup path; no execution or full linked-binary closure claim.",
 'created_utc':datetime.now(timezone.utc).isoformat(), 'elapsed_s_from_root_clock':time.monotonic()-started['started_s'],
 'native_imports':0,'project_imports':0,'tests':0,'spice_queries':0,'integrations':0,'factory_calls':0,'downloads':0,'resource_copies':0,'provisioning':0,'builds':0,
 'anchors':anchors,
 'edges':[{'from':a,'to':b,'classification':c} for a,b,c in edges],
 'resources':[{'relative_path':'earth_orientation/'+p,'classification':c,'anchor_id':a,'condition':why} for p,c,a,why in resources],
 'categories':{
  'eager':'Six source-visible resource readers occur as a side effect of importing dynamics through a radiometric data converter class attribute, before fixed factory empty-body statements.',
  'lazy':'SPICE loaders, supplied custom acceleration, zero coast mass-rate and epoch conversion methods are function bodies/callbacks; this inventory executes none. Constructor preparation may evaluate callbacks; actual partial native counts remain UNKNOWN.',
  'unused':'Polar-motion correction factory, standard Earth rotation setup, physical ephemeris/gravity/atmosphere/thrust models are not requested by the fixed empty Spacecraft settings. This is scoped source reasoning, not a global import-closure guarantee.',
  'unresolved':'Retained source and headers identify a consistent eager-import route, but compiled binary linkage, runtime module cache/order, all transitive import side effects, and full native resource closure have not been executed or proved.'},
 'leap_seconds':{
  'anchor_id':'sofa_leapsecond', 'classification':'lazy/unresolved-linked-implementation',
  'finding':'Source wrapper calls SOFA iauDat for leap seconds; no .tls/leap-second external resource reader found in the inspected converter/EOP path. The iauDat implementation and linked-binary resource closure are not established by this receipt. No SPICE leap-second kernel load is requested by the fixed factory source.'},
 'failure_interpretation':{
  'supported':'ADR0275 missing EOP failure is consistent with eager import-side default_time_scale_converter; it must not be attributed specifically to create_system_of_bodies.',
  'not_supported':'No claim which exact native instruction ran, all setup completed, six files were read in failed attempt, partial callback/native counts, physical trajectory accuracy, or safe/mission-ready behavior.'},
 'provenance_limit':'Source/header SHA pins prove bytes inspected only. Parent separately inventories local retained payload bytes and availability; this receipt does not grant provisioning or retry permission.'
}
out=Path('/private/tmp/ariadna-f18-0276/source-callgraph.json')
out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'path':str(out),'sha256':sha256(out.read_bytes()).hexdigest(),'size_bytes':out.stat().st_size,'anchors':len(anchors),'edges':len(edges),'eager_resources':sum(r['classification']=='eager' for r in receipt['resources']),'elapsed_s':receipt['elapsed_s_from_root_clock']}))
