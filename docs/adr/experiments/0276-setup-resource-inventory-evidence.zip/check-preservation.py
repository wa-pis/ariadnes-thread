from pathlib import Path
import json,hashlib,os,time,sys,datetime
p=Path('/private/tmp/ariadna-f18-0276');bpath=Path('/private/tmp/ariadna-f17-0263/operational-before.json');assert hashlib.sha256(bpath.read_bytes()).hexdigest()=='4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56'
b=json.loads(bpath.read_text());root=Path(b['prefix']);started=time.monotonic();current={}
for path in root.rglob('*'):
 name=str(path.relative_to(root))
 if path.is_symlink():current[name]={'symlink':os.readlink(path)}
 elif path.is_file():current[name]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
diffs=[n for n in sorted(set(b['files'])|set(current))if b['files'].get(n)!=current.get(n)]
x={'schema':'ariadna.f18.operational-preservation.v1','status':'passed' if not diffs else 'failed','phase':sys.argv[1],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prefix':str(root),'paths_compared':len(current),'regular_bytes':sum(x.get('bytes',0)for x in current.values()),'differences':diffs,'baseline_file_sha256':hashlib.sha256(bpath.read_bytes()).hexdigest(),'manifest_equal':not diffs,'elapsed_s':time.monotonic()-started}
with(p/('operational-'+sys.argv[1]+'.json')).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print({k:x[k]for k in ('status','paths_compared','regular_bytes','elapsed_s','differences')});assert not diffs
