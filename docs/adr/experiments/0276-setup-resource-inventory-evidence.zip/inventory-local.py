from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path('/private/tmp/ariadna-f18-0276');v=Path('/private/tmp/ariadna-f17-0263/volume');r=Path('/Users/agrudin/dev/my/ariadna');start=json.loads((p/'inventory-start.json').read_bytes());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();old=json.loads(Path('/private/tmp/ariadna-f18-0275/root-preflight.json').read_bytes());source=json.loads(Path('/private/tmp/ariadna-f18-0275/profile.json').read_bytes())['source_pins']
assert 0<=time.monotonic()-start['started_s']<900
for name,pin in source.items():assert(r/name).stat().st_size==pin['bytes']and sha(r/name)==pin['sha256'],name
for pin in old['native_pins']+old['resources']:assert Path(pin['path']).stat().st_size==pin['bytes']and sha(pin['path'])==pin['sha256'],pin['path']
for name,digest in old['old_timers_ledgers'].items():assert sha(name)==digest,name
sv=os.statvfs(v);assert sv.f_flag&os.ST_RDONLY
files=sorted(Path('/Users/agrudin/.tudat/resource/earth_orientation').glob('*'));files=[f for f in files if f.is_file()];assert len(files)<=32 and sum(f.stat().st_size for f in files)<=16*1024**2
payloads=[]
for f in files:
 assert not f.is_symlink();target=v/'home/.tudat/resource/earth_orientation'/f.name
 payloads.append({'name':f.name,'local_path':str(f),'bytes':f.stat().st_size,'sha256':sha(f),'image_path':str(target),'image_exists':target.exists(),'classification':'candidate only until fixed-path source review; hash is local identity, not upstream authentication or native parser qualification'})
processes=subprocess.check_output(['ps','-axo','pid,ppid,pgid,etime,args'],text=True);relevant=[s for s in processes.splitlines()if any(key in s for key in('pytest','space_nav._owner','ariadna-f18-0275/','ariadna-f18-0269/','ariadna-f18-0272/'))and not 'inventory-local.py'in s]
x={'schema':'ariadna.f18.setup-resource-local-inventory.v1','status':'PASS_LOCAL_CANDIDATES_SOURCE_CLASSIFICATION_PENDING','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-start['started_s'],'source_pins':source,'native_pins':old['native_pins'],'existing_resources':old['resources'],'old_ledgers':old['old_timers_ledgers'],'read_only_mount':True,'scratch_capacity_bytes':sv.f_blocks*sv.f_frsize,'aggregate_acquisition_bytes':497045495,'new_acquisition_bytes':0,'local_candidate_count':len(payloads),'local_candidate_bytes':sum(z['bytes']for z in payloads),'local_candidates':payloads,'relevant_processes':relevant,'no_native_imports_spice_integrations_or_resource_copies':True}
with(p/'local-inventory.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n')
print({'elapsed_s':x['elapsed_s'],'candidate_files':len(payloads),'candidate_bytes':x['local_candidate_bytes'],'all_missing_in_image':all(not z['image_exists']for z in payloads),'relevant_processes':relevant})
oldscript=Path('/private/tmp/ariadna-f18-0275/check-preservation.py').read_text()
with(p/'check-preservation.py').open('x')as f:f.write(oldscript.replace('/private/tmp/ariadna-f18-0275',str(p)))
