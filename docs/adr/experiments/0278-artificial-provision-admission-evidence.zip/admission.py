"""Fixed supplemented-setup admission checks; importing this file executes no run."""
from __future__ import annotations

from collections.abc import Callable
import hashlib
import io
import json
import math
import os
from pathlib import Path
import plistlib
import stat
import subprocess
import time
import zipfile

CONTRACT_SHA256 = '6c2c80e441c9b08fc8de48b21bfed2c506e11d3a32b106277ead897bca3c7714'
BASELINE_ZIP_SHA256 = 'd317c2a69d1e5d176478a3f1731c22eae8614c8598296653081e7706fa24e009'
REPO = Path('/Users/agrudin/dev/my/ariadna')
LIVE_ROOT = Path('/private/tmp/ariadna-f18-supplemented-setup-v1')
LIVE_MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
LIVE_IMAGE = Path('/private/tmp/ariadna-f17-0263/scratch.sparseimage')
PROBE_KEYS = {'schema', 'scope', 'mode', 'kernel_path', 'kernel_sha256', 'probe_sha256',
              'owner_fixture_sha256', 'owner_auditor_sha256', 'trajectory_sha256', 'setup_auditor_sha256'}


class AdmissionError(RuntimeError):
    """The fixed resource/setup proof cannot authorize a launch."""


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise AdmissionError(message)


def _number(value: object) -> bool:
    return type(value) in (int, float) and math.isfinite(value)


def _directory(path: Path) -> None:
    _need(path.is_absolute(), 'absolute directory required')
    for parent in [*reversed(path.parents), path]:
        _need(stat.S_ISDIR(parent.lstat().st_mode), 'non-directory or symlink ancestor')


def _read(path: Path, cap: int = 65536) -> bytes:
    _directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        _need(stat.S_ISREG(info.st_mode) and info.st_size <= cap, 'nonregular or oversized proof')
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            raw = stream.read(cap + 1)
        _need(len(raw) == info.st_size and len(raw) <= cap, 'proof changed or oversized')
        return raw
    finally:
        os.close(descriptor)


def _object(raw: bytes) -> dict[str, object]:
    def pairs(rows: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in rows:
            _need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result

    def invalid(value: str) -> None:
        raise AdmissionError('nonfinite JSON number: ' + value)

    result = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    _need(type(result) is dict, 'JSON object required')
    return result


def _proof(reference: object) -> tuple[dict[str, object], str]:
    _need(type(reference) is dict and set(reference) == {'path', 'sha256'}, 'proof reference')
    raw = _read(Path(reference['path']))
    digest = hashlib.sha256(raw).hexdigest()
    _need(digest == reference['sha256'], 'proof identity')
    return _object(raw), digest


def _pin(path: Path, expected: dict[str, object], tick: Callable[[], float]) -> None:
    _directory(path.parent)
    _need(type(expected['bytes']) is int and expected['bytes'] > 0, 'positive pinned length')
    _need(type(expected['sha256']) is str and len(expected['sha256']) == 64, 'pinned digest')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        _need(stat.S_ISREG(before.st_mode) and before.st_size == expected['bytes'], 'pinned file size/type')
        digest = hashlib.sha256()
        remaining = expected['bytes']
        while remaining:
            tick()
            data = os.read(fd, min(remaining, 1024 * 1024))
            _need(bool(data), 'pinned short read')
            digest.update(data)
            remaining -= len(data)
        after = os.fstat(fd)
        _need(not os.read(fd, 1) and before.st_size == after.st_size
              and before.st_mtime_ns == after.st_mtime_ns
              and digest.hexdigest() == expected['sha256'], 'pinned bytes drift')
    finally:
        os.close(fd)


def _live_observation(mount: Path, image: Path) -> dict[str, object]:
    _need(os.path.ismount(mount), 'live mount absent')
    fs = os.statvfs(mount)
    raw = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=5)
    _need(len(raw) <= 65536, 'mount metadata capacity')
    info = plistlib.loads(raw)
    matches = [item for item in info['images'] if item.get('image-path') == str(image)
               and any(row.get('mount-point') == str(mount) for row in item.get('system-entities', []))]
    _need(len(matches) == 1, 'retained image/mount identity')
    return {'read_only': bool(fs.f_flag & os.ST_RDONLY), 'mount': str(mount),
            'image': str(image), 'capacity_bytes': fs.f_blocks * fs.f_frsize}


def _native_baseline() -> dict[str, object]:
    archive = REPO / 'docs/adr/experiments/0276-setup-resource-inventory-evidence.zip'
    raw = _read(archive, 2 * 1024**2)
    _need(hashlib.sha256(raw).hexdigest() == BASELINE_ZIP_SHA256, 'original baseline archive')
    with zipfile.ZipFile(io.BytesIO(raw)) as packet:
        _need(packet.getinfo('local-inventory.json').file_size <= 65536, 'baseline metadata capacity')
        return _object(packet.read('local-inventory.json'))


def _native_reference() -> tuple[dict[str, object], dict[str, bytes]]:
    archive = REPO / 'docs/adr/experiments/0275-never-run-setup-evidence.zip'
    raw = _read(archive, 2 * 1024**2)
    _need(hashlib.sha256(raw).hexdigest()
          == 'fc7cb349728ae6304eb3619b291d84fda9da13d69e03e5a519caed9383b8db70',
          'qualified original setup archive')
    with zipfile.ZipFile(io.BytesIO(raw)) as packet:
        names = ('call-once.py', 'launch-once.py', 'native-entry.py', 'supervisor-adapter.py',
                 'run-once.py', 'native.sandbox', 'check-preservation.py', 'profile.json')
        _need(all(packet.getinfo(name).file_size <= 65536 for name in names), 'reference capacity')
        contents = {name: packet.read(name) for name in names}
    return _object(contents.pop('profile.json')), contents


def admit(profile_path: Path, contract_path: Path, output_path: Path, *, mode: str,
          started_s: float, now: Callable[[], float] = time.monotonic,
          observe: Callable[[Path, Path], dict[str, object]] | None = None) -> dict[str, object]:
    """Validate fresh actual bytes; artificial success can never be native PASS."""
    try:
        return _admit(profile_path, contract_path, output_path, mode=mode, started_s=started_s,
                      now=now, observe=observe)
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as exc:
        raise AdmissionError('supplemented admission: ' + str(exc)) from exc


def _admit(profile_path: Path, contract_path: Path, output_path: Path, *, mode: str,
           started_s: float, now: Callable[[], float],
           observe: Callable[[Path, Path], dict[str, object]] | None) -> dict[str, object]:
    _need(mode in {'artificial', 'native'}, 'explicit mode')
    _need(_number(started_s), 'finite original clock')
    last = started_s

    def tick() -> float:
        nonlocal last
        value = now()
        _need(_number(value) and last <= value and 0 <= value - started_s < 600, 'original600s clock')
        last = value
        return value - started_s

    tick()
    if mode == 'artificial':
        _need(observe is not None, 'explicit artificial filesystem observer required')
    if mode == 'native':
        _need(now is time.monotonic and observe is None, 'native replacement observer/clock forbidden')
        _need(profile_path == LIVE_ROOT / 'profile.json'
              and contract_path == REPO / 'docs/adr/experiments/0277-supplemented-setup-contract.json'
              and output_path == LIVE_ROOT / 'admission-check.json', 'fixed native paths')
    profile_raw, contract_raw = _read(profile_path), _read(contract_path)
    profile, contract = _object(profile_raw), _object(contract_raw)
    contract_digest = hashlib.sha256(contract_raw).hexdigest()
    _need(profile['schema'] == 'ariadna.f18.supplemented-admission-profile.v1'
          and profile['mode'] == mode and profile['contract_sha256'] == contract_digest
          and _number(profile['preflight_started_s'])
          and profile['preflight_started_s'] == started_s, 'profile scope/clock/contract')
    mount, image, resources = (Path(profile[name]) for name in ('mount', 'image', 'resources'))
    _directory(resources)
    expected_groups: dict[str, object]
    if mode == 'native':
        _need(contract_digest == CONTRACT_SHA256 and mount == LIVE_MOUNT and image == LIVE_IMAGE
              and resources == LIVE_MOUNT / 'home/.tudat/resource', 'official native contract/mount')
        _need(profile['work_directory'] == str(LIVE_ROOT / 'execution')
              and not os.path.lexists(LIVE_ROOT / 'execution')
              and not os.path.lexists(LIVE_ROOT / 'episode-start.json'), 'fresh native namespace')
        decision, _ = _proof(profile['execution_decision'])
        _need(decision['stage'] == 'F18.13' and decision['status'] == 'ADMITTED_ONCE'
              and decision['contract_sha256'] == contract_digest
              and decision['base_revision'] == profile['base_revision'], 'separate execution decision')
        _need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
              == profile['base_revision']
              and subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'dev'
              and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'clean native dev/base')
        baseline = _native_baseline()
        reference, old_controls = _native_reference()
        _need(profile['repo'] == str(REPO)
              and profile['private_python'] == reference['private_python']
              and profile['kernel_sha256'] == reference['kernel_sha256']
              and json.dumps(profile['limits'], sort_keys=True, allow_nan=False)
              == json.dumps(reference['limits'], sort_keys=True, allow_nan=False)
              and profile['probe_input'] == reference['probe_input']
              and profile['sandbox_profile'] == str(LIVE_ROOT / 'native.sandbox')
              and profile['prelaunch_admission'] == str(LIVE_ROOT / 'launch-admission.json'),
              'qualified native paths/limits/kernel/probe input')
        expected_groups = decision['expected_pins']
        required_controls = {str(LIVE_ROOT / name) for name in old_controls} | {
            str(LIVE_ROOT / 'provision.py'), str(LIVE_ROOT / 'admission.py')}
        _need(set(expected_groups['control_pins']) == required_controls
              and Path(__file__).resolve() == LIVE_ROOT / 'admission.py', 'complete fixed control set')
        for name, content in old_controls.items():
            if name in {'run-once.py', 'native.sandbox', 'check-preservation.py'}:
                content = content.replace(b'/private/tmp/ariadna-f18-0275', str(LIVE_ROOT).encode())
            pin = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
            _need(expected_groups['control_pins'][str(LIVE_ROOT / name)] == pin,
                  'qualified bytewise/namespace-only control')
        for field, name in (('entry_sha256', 'native-entry.py'), ('adapter_sha256', 'supervisor-adapter.py'),
                            ('launch_sha256', 'launch-once.py'), ('caller_sha256', 'call-once.py'),
                            ('sandbox_sha256', 'native.sandbox')):
            _need(profile[field] == expected_groups['control_pins'][str(LIVE_ROOT / name)]['sha256'],
                  'profile control hash binding')
        expected_source = {str(REPO / name): pin for name, pin in baseline['source_pins'].items()}
        expected_native = {pin['path']: {'bytes': pin['bytes'], 'sha256': pin['sha256']}
                           for pin in baseline['native_pins']}
        _need(expected_groups['source_pins'] == expected_source
              and expected_groups['native_pins'] == expected_native, 'preserved49source/10native pins')
        _need({name: row['sha256'] for name, row in expected_groups['ledger_pins'].items()}
              .items() >= baseline['old_ledgers'].items(), 'preserved old ledgers')
        old_resources = [{'name': str(Path(pin['path']).relative_to(resources)),
                          'bytes': pin['bytes'], 'sha256': pin['sha256']}
                         for pin in baseline['existing_resources']]
        for name in ('call-once.py', 'launch-once.py', 'native-entry.py', 'supervisor-adapter.py'):
            _need(expected_groups['control_pins'][str(LIVE_ROOT / name)]
                  == {k: contract['controls'][name][k] for k in ('bytes', 'sha256')}, 'byte-identical native control')
    else:
        _need(contract['qualification'] == 'ARTIFICIAL', 'fabricated contract label')
        expected_groups = {key: contract[field] for key, field in (
            ('source_pins', 'source_expected'), ('native_pins', 'native_expected'),
            ('control_pins', 'controls_expected'), ('ledger_pins', 'ledger_expected'))}
        old_resources = contract['old_resources']
    _need(profile['environment'] == contract['environment_unchanged'], 'unchanged environment')
    probe = profile['probe_input']
    _need(type(probe) is dict and set(probe) == PROBE_KEYS
          and probe['schema'] == 'ariadna-owner-setup-input-v1'
          and probe['scope'] == 'never-run-owner-setup-only' and probe['mode'] == mode, 'exact ten-key probe input')
    if mode == 'artificial':
        _need(probe == contract['probe_expected'], 'exact artificial reference probe input')
    for group, pins in expected_groups.items():
        _need(group in {'source_pins', 'native_pins', 'control_pins', 'ledger_pins'}
              and type(pins) is dict and bool(pins) and profile[group] == pins, 'pinned group identity')
        for name, pin in pins.items():
            _pin(Path(name), pin, tick)
    _need(set(expected_groups) == {'source_pins', 'native_pins', 'control_pins', 'ledger_pins'}, 'all pinned groups')
    rows = list(old_resources) + [{'name': 'earth_orientation/' + row['name'],
                                 'bytes': row['bytes'], 'sha256': row['sha256']}
                                for row in contract['supplement']]
    _need(len(old_resources) == 5 and len(contract['supplement']) == 6
          and len({row['name'] for row in rows}) == 11, 'exact11 resources')
    for row in rows:
        name = Path(row['name'])
        _need(not name.is_absolute() and '..' not in name.parts, 'relative resource name')
        _pin(resources / name, row, tick)
    actual: set[str] = set()
    for directory, dirs, files in os.walk(resources, followlinks=False):
        for name in dirs:
            _need(not (Path(directory) / name).is_symlink(), 'resource symlink directory')
        for name in files:
            actual.add(str((Path(directory) / name).relative_to(resources)))
    _need(actual == {row['name'] for row in rows}, 'exact resource inventory')
    precharge, precharge_hash = _proof(profile['proofs']['precharge'])
    provision, provision_hash = _proof(profile['proofs']['provision'])
    outcome, outcome_hash = _proof(profile['proofs']['outcome'])
    readback, _ = _proof(profile['proofs']['readback'])
    supplement = [{'name': row['name'], 'bytes': row['bytes'], 'sha256': row['sha256']}
                  for row in contract['supplement']]
    _need(precharge['schema'] == 'ariadna.f18.six-resource-precharge.v1'
          and precharge['status'] == 'reserved_before_copy'
          and _number(precharge['started_s']) and precharge['started_s'] == started_s
          and precharge['payloads'] == supplement
          and type(precharge['carried_bytes']) is int and precharge['carried_bytes'] == 497045495
          and type(precharge['additional_bytes']) is int and precharge['additional_bytes'] == 3578887
          and type(precharge['aggregate_bytes']) is int and precharge['aggregate_bytes'] == 500624382
          and precharge['ceiling_bytes'] == 2147483648, 'exact immutable precharge')
    _need(provision['schema'] == 'ariadna.f18.six-resource-provision.v1'
          and provision['status'] == 'completed-pending-outer-readback'
          and _number(provision['started_s']) and provision['started_s'] == started_s
          and provision['precharge_sha256'] == precharge_hash
          and provision['payloads'] == supplement
          and provision['resource_directory'] == str(resources)
          and provision['target_directory'] == str(resources / 'earth_orientation'), 'provision binding')
    _need(provision['completion_requires_outer_readback'] is True
          and outcome['status'] == 'passed' and outcome['receipt_sha256'] == provision_hash
          and _number(outcome['started_s']) and outcome['started_s'] == started_s
          and outcome['finalization'] == 'checked-after-fsync'
          and all(outcome.get(key) == value for key, value in provision.items()
                  if key not in {'status', 'elapsed_s'}), 'durable provision outer outcome')
    _need(readback['schema'] == 'ariadna.f18.supplemented-ro-readback.v1'
          and readback['mode'] == mode and _number(readback['started_s'])
          and readback['started_s'] == started_s
          and readback['read_only'] is True and readback['mount'] == str(mount)
          and readback['image'] == str(image) and readback['resources'] == rows
          and readback['provision_sha256'] == provision_hash
          and readback['outcome_sha256'] == outcome_hash
          and readback['precharge_sha256'] == precharge_hash, 'fresh RO proof binding')
    current = tick()
    times = [provision['elapsed_s'], outcome['elapsed_s'], readback['elapsed_s']]
    _need(all(_number(value) for value in times) and 0 <= times[0] <= times[1] <= times[2] <= current,
          'fresh ordered provision/readback times')
    observation = (observe or _live_observation)(mount, image)
    _need(observation['read_only'] is True and observation['mount'] == str(mount)
          and observation['image'] == str(image)
          and type(observation['capacity_bytes']) is int
          and 0 < observation['capacity_bytes'] <= 8589934592, 'actual retained RO image observation')
    result = {'schema': 'ariadna.f18.supplemented-admission.v1', 'mode': mode,
              'status': 'PENDING_DURABLE_ADMISSION',
              'native_launch_authorized': False, 'started_s': started_s,
              'elapsed_s': tick(), 'profile_sha256': hashlib.sha256(profile_raw).hexdigest(),
              'contract_sha256': contract_digest, 'resource_count': 11,
              'precharge_sha256': precharge_hash, 'provision_sha256': provision_hash,
              'outcome_sha256': outcome_hash, 'finalization': 'pending-outer-readback'}
    _directory(output_path.parent)
    with output_path.open('xb') as stream:
        stream.write((json.dumps(result, sort_keys=True, allow_nan=False) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(output_path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    result = dict(result, finalization='checked-after-fsync', elapsed_s=tick(),
                  status='PASS' if mode == 'native' else 'PASS_ARTIFICIAL_ADMISSION_ONLY',
                  native_launch_authorized=mode == 'native',
                  receipt_sha256=hashlib.sha256(_read(output_path)).hexdigest())
    tick()
    return result
