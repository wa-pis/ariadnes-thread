from pathlib import Path
import datetime,json,os,signal,subprocess,sys,time
p=Path('/private/tmp/ariadna-f18-supplemented-setup-v1');assert not(p/'episode-start.json').exists()and not(p/'execution').exists()
a=json.loads((p/'launch-admission.json').read_bytes());assert a['status']=='PASS'
entered=time.monotonic();process=subprocess.Popen([sys.executable,'-I','-B',str(p/'call-once.py'),str(p/'profile.json')],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
output=errors=b'';failure=None;groups={}
try:
 output,errors=process.communicate(timeout=65)
except subprocess.TimeoutExpired as exc:
 output=exc.output or b'';errors=exc.stderr or b'';failure='external65s failsafe exhausted; no timely success or retry'
finally:
 try:os.killpg(process.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 for name in('parent.pgid','supervisor.pgid'):
  record=p/'execution'/name
  if not record.exists():groups[name]=None;continue
  with record.open('rb')as f:raw=f.read(33)
  if len(raw)>32 or not raw.strip().isdigit():raise RuntimeError('invalid outer PGID')
  group=int(raw);assert group>1 and group not in{os.getpid(),os.getpgrp()};groups[name]=group
  try:os.killpg(group,signal.SIGKILL)
  except ProcessLookupError:pass
 process.wait(timeout=1)
 process.stdout.close();process.stderr.close()
raw_sizes={'stdout':len(output),'stderr':len(errors)}
if len(output)>65536 or len(errors)>65536:failure=failure or 'collector output cap; bounded partial retained'
output=output[:65536];errors=errors[:65536]
for name,data in(('caller-tool-output.json',output),('caller-tool-stderr.log',errors)):
 with(p/name).open('xb')as f:f.write(data);f.flush();os.fsync(f.fileno())
episode=p/'episode-start.json';start=json.loads(episode.read_bytes())['started_s']if episode.exists()else None
post=time.monotonic()-start if start is not None else None
try:caller=json.loads(output)
except(json.JSONDecodeError,UnicodeDecodeError):caller={};failure=failure or 'caller output unavailable or malformed'
if start is None:failure=failure or 'caller failed before durable episode start'
passed=(failure is None and process.returncode==0 and not errors and post is not None and 0<=post<60 and caller.get('status')=='passed'and caller.get('within60s')is True)
x={'schema':'ariadna.f18.setup-caller-tool-observation.v1','status':'passed'if passed else'failed','failure':failure,'returncode':process.returncode,'observed_after_output_fsync_s':post,'within60s':post is not None and 0<=post<60,'elapsed_wrapper_s':time.monotonic()-entered,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'retained_stdout_bytes':len(output),'retained_stderr_bytes':len(errors),'raw_sizes':raw_sizes,'groups':groups,'native_attempt_consumed':(p/'execution/consumed.json').exists(),'finalization':'pending-after-fsync-observation'}
with(p/'caller-tool-observation.json').open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
observed=time.monotonic()-start if start is not None else None
ok=passed and observed is not None and 0<=observed<60
print(json.dumps({'status':'passed'if ok else'failed','observed_after_observation_fsync_s':observed,'finalization':'checked-after-fsync'if ok else'failed-or-unavailable-after-fsync','observation':x}),flush=True)
raise SystemExit(0 if ok else 2)
