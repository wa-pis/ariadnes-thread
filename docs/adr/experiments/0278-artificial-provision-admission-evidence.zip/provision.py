"""Fixed six-file transaction; importing this module performs no provisioning."""
from __future__ import annotations

from collections.abc import Callable
import ctypes
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time

SIX_NAMES = (
    "eopc04_14_IAU2000.62-now.txt",
    "historicalDeltaT.txt",
    "utcLibrationAmplitudes.txt",
    "utcLibrationFundamentalArgumentMultipliers.txt",
    "utcOceanTidesAmplitudes.txt",
    "utcOceanTidesFundamentalArgumentMultipliers.txt",
)
_MAX_BYTES = 3_578_887
_CHUNK = 65_536


class ProvisionError(RuntimeError):
    """The fixed transaction was refused or did not finish durably in time."""


@dataclass(frozen=True, slots=True)
class Payload:
    name: str
    byte_count: int
    sha256: str

    def __post_init__(self) -> None:
        if type(self.name) is not str or self.name not in SIX_NAMES:
            raise ProvisionError("payload name is outside the fixed six names")
        if type(self.byte_count) is not int or not 0 < self.byte_count <= _MAX_BYTES:
            raise ProvisionError("payload byte_count must be a bounded positive integer")
        if type(self.sha256) is not str or re.fullmatch(r"[0-9a-f]{64}", self.sha256) is None:
            raise ProvisionError("payload sha256 must be lowercase SHA256")


def _sync(fd: int) -> None:
    os.fsync(fd)


def _publish(stage: Path, target: Path) -> None:
    """Publish on macOS without replacing an existing file, symlink or directory."""
    if sys.platform != "darwin" or stage.parent != target.parent:
        raise ProvisionError("exclusive same-directory macOS publication unavailable")
    try:
        library = ctypes.CDLL(None, use_errno=True)
        rename = library.renameatx_np
    except (OSError, AttributeError) as exc:
        raise ProvisionError("renameatx_np unavailable; no overwrite fallback") from exc
    rename.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    rename.restype = ctypes.c_int
    parent = os.open(stage.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        if rename(parent, os.fsencode(stage.name), parent, os.fsencode(target.name), 0x4) != 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), str(target))
    finally:
        os.close(parent)


def _directory(path: Path) -> None:
    if not isinstance(path, Path) or not path.is_absolute() or ".." in path.parts:
        raise ProvisionError("absolute normalized directory required")
    for candidate in reversed((path, *path.parents)):
        if not stat.S_ISDIR(candidate.lstat().st_mode):
            raise ProvisionError("directory or ancestor is symlink/non-directory: " + str(candidate))


def _absent(path: Path) -> None:
    try:
        path.lstat()
    except FileNotFoundError:
        return
    raise ProvisionError("occupied path: " + str(path))


def _write(fd: int, raw: bytes, check: Callable[[], float]) -> None:
    offset = 0
    while offset < len(raw):
        check()
        count = os.write(fd, raw[offset:])
        if count <= 0:
            raise ProvisionError("short write made no progress")
        offset += count
    check()


def _read_payload(path: Path, pin: Payload, check: Callable[[], float], destination: int | None = None) -> None:
    check()
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ProvisionError("payload is symlink/nonregular: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size != pin.byte_count:
            raise ProvisionError("payload size/type differs: " + pin.name)
        digest = hashlib.sha256()
        remaining = pin.byte_count
        while remaining:
            check()
            wanted = min(_CHUNK, remaining)
            raw = os.read(fd, wanted)
            if not raw or len(raw) > wanted:
                raise ProvisionError("payload short/oversized read: " + pin.name)
            digest.update(raw)
            remaining -= len(raw)
            if destination is not None:
                _write(destination, raw, check)
        if os.read(fd, 1) or digest.hexdigest() != pin.sha256:
            raise ProvisionError("payload hash/length differs: " + pin.name)
        check()
    finally:
        os.close(fd)


def _record(path: Path, value: dict[str, object], check: Callable[[], float]) -> bytes:
    raw = (json.dumps(value, allow_nan=False, sort_keys=True) + "\n").encode()
    if len(raw) > _CHUNK:
        raise ProvisionError("receipt exceeds64KiB")
    check()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        _write(fd, raw, check)
        _sync(fd)
        check()
    finally:
        os.close(fd)
    return raw


def _sync_directory(path: Path, check: Callable[[], float]) -> None:
    check()
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        _sync(fd)
        check()
    finally:
        os.close(fd)


def provision(
    sources: Path,
    resources: Path,
    receipts: Path,
    pins: tuple[Payload, ...],
    *,
    started_s: float,
    now: Callable[[], float] = time.monotonic,
    carried_bytes: int = 497045495,
    ceiling_bytes: int = 2147483648,
) -> dict[str, object]:
    """Add exactly six files once; failures retain charge/partial evidence.

    Success is conditional on separately saved outer return and fresh RO readback.
    This helper neither mounts an image nor admits any native operation.
    """
    if type(started_s) not in (int, float) or not math.isfinite(started_s):
        raise ProvisionError("finite inherited preflight start required")
    last = float(started_s)

    def check() -> float:
        nonlocal last
        current = now()
        if type(current) not in (int, float) or not math.isfinite(current):
            raise ProvisionError("finite monotonic clock required")
        if current < last or current >= started_s + 600.0:
            raise ProvisionError("inherited600s preflight exhausted or clock reversed")
        last = float(current)
        return last

    try:
        check()
        if type(pins) is not tuple or len(pins) != 6 or any(type(p) is not Payload for p in pins):
            raise ProvisionError("exact six Payload tuple required")
        for pin in pins:
            pin.__post_init__()
        by_name = {p.name: p for p in pins}
        if set(by_name) != set(SIX_NAMES):
            raise ProvisionError("unique fixed six-name manifest required")
        ordered = tuple(by_name[name] for name in SIX_NAMES)
        additional = sum(p.byte_count for p in ordered)
        if additional > _MAX_BYTES:
            raise ProvisionError("six-file byte ceiling exceeded")
        if (type(carried_bytes) is not int or type(ceiling_bytes) is not int
                or carried_bytes < 0 or not 0 < ceiling_bytes <= 2147483648
                or carried_bytes + additional > ceiling_bytes):
            raise ProvisionError("carried acquisition ceiling exceeded")
        for directory in (sources, resources, receipts):
            _directory(directory)
        if any(a.is_relative_to(b) or b.is_relative_to(a)
               for a, b in ((sources, resources), (sources, receipts), (resources, receipts))):
            raise ProvisionError("source/resource/receipt directories must be separate")
        target = resources / "earth_orientation"
        stage = resources / ".earth_orientation-stage"
        precharge = receipts / "acquisition-precharge.json"
        outcome = receipts / "provisioning-receipt.json"
        for path in (target, stage, precharge, outcome):
            _absent(path)
        for pin in ordered:
            _read_payload(sources / pin.name, pin, check)
        payloads = [{"name": p.name, "bytes": p.byte_count, "sha256": p.sha256} for p in ordered]
        charge: dict[str, object] = {
            "schema": "ariadna.f18.six-resource-precharge.v1", "status": "reserved_before_copy",
            "started_s": started_s, "carried_bytes": carried_bytes, "additional_bytes": additional,
            "aggregate_bytes": carried_bytes + additional, "ceiling_bytes": ceiling_bytes,
            "payloads": payloads,
        }
        charged = _record(precharge, charge, check)
        _sync_directory(receipts, check)
        check()
        stage.mkdir(mode=0o700)
        if stage.stat().st_dev != resources.stat().st_dev:
            raise ProvisionError("staging directory is not on resource filesystem")
        for pin in ordered:
            check()
            fd = os.open(stage / pin.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            try:
                _read_payload(sources / pin.name, pin, check, fd)
                _sync(fd)
                check()
            finally:
                os.close(fd)
        if {p.name for p in stage.iterdir()} != set(SIX_NAMES):
            raise ProvisionError("staged inventory differs from fixed six names")
        for pin in ordered:
            _read_payload(stage / pin.name, pin, check)
        _sync_directory(stage, check)
        _absent(target)
        check()
        _publish(stage, target)
        check()
        _sync_directory(resources, check)
        _directory(target)
        if {p.name for p in target.iterdir()} != set(SIX_NAMES):
            raise ProvisionError("published inventory differs from fixed six names")
        for pin in ordered:
            _read_payload(target / pin.name, pin, check)
        receipt: dict[str, object] = {
            "schema": "ariadna.f18.six-resource-provision.v1",
            "status": "completed-pending-outer-readback", "completion_requires_outer_readback": True,
            "started_s": started_s, "elapsed_s": check() - started_s,
            "source_directory": str(sources), "resource_directory": str(resources),
            "target_directory": str(target), "stage_directory": str(stage),
            "precharge_sha256": hashlib.sha256(charged).hexdigest(),
            "carried_bytes": carried_bytes, "additional_bytes": additional,
            "aggregate_bytes": carried_bytes + additional, "ceiling_bytes": ceiling_bytes,
            "payloads": payloads,
        }
        recorded = _record(outcome, receipt, check)
        _sync_directory(receipts, check)
        return {**receipt, "status": "passed", "receipt_sha256": hashlib.sha256(recorded).hexdigest(),
                "elapsed_s": check() - started_s, "finalization": "checked-after-fsync"}
    except (OSError, ValueError, TypeError, OverflowError) as exc:
        raise ProvisionError(str(exc)) from exc
