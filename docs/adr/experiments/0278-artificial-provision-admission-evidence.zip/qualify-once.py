"""Contain one fabricated qualification invocation, including startup and fsync."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
parent = root / sys.argv[1]
parent.mkdir(exist_ok=False)
started = time.monotonic()
pins = {name: {'bytes': (root / name).stat().st_size,
               'sha256': hashlib.sha256((root / name).read_bytes()).hexdigest()}
        for name in ('provision.py', 'admission.py', 'qualify.py')}
process = subprocess.Popen([sys.executable, '-I', '-B', str(root / 'qualify.py'), str(parent)],
                           stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
failure = None
output = errors = b''
try:
    output, errors = process.communicate(timeout=max(0.001, started + 120 - time.monotonic()))
except subprocess.TimeoutExpired as exc:
    output, errors = exc.output or b'', exc.stderr or b''
    failure = 'external120s timeout; bounded partial evidence retained'
finally:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=2)
for name, data in (('stdout.log', output), ('stderr.log', errors)):
    if len(data) > 65536:
        failure = failure or 'outer log partition exhausted'
    with (parent / name).open('xb') as stream:
        stream.write(data[:65536])
        stream.flush()
        os.fsync(stream.fileno())
for name, pin in pins.items():
    current = (root / name).read_bytes()
    if len(current) != pin['bytes'] or hashlib.sha256(current).hexdigest() != pin['sha256']:
        failure = failure or 'source changed during qualification'
packets = list(parent.glob('artificial-*/qualification.json'))
records = [json.loads(path.read_bytes()) for path in packets]
evidence_bytes = sum(path.stat().st_size for path in parent.rglob('*') if path.is_file())
passed = (failure is None and process.returncode == 0 and not errors
          and len(records) == 1 and records[0]['failures'] == records[0]['errors'] == 0
          and records[0]['sources'] == pins and evidence_bytes < 2097152 - 16384
          and 0 <= time.monotonic() - started < 120)
receipt = {'schema': 'ariadna.f18.supplemented-artificial-outer.v1',
           'status': 'passed-prefinal' if passed else 'failed', 'failure': failure,
           'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'started_s': started, 'elapsed_before_receipt_s': time.monotonic() - started,
           'limit_s': 120, 'returncode': process.returncode, 'source_pins': pins,
           'qualification_count': len(packets), 'evidence_bytes_before_receipt': evidence_bytes,
           'test_count': records[0]['test_count'] if records else None,
           'finalization': 'pending-observation-after-fsync',
           'native_admission': 'NATIVE_NOT_ADMITTED'}
with (parent / 'external-receipt.json').open('xb') as stream:
    stream.write((json.dumps(receipt, sort_keys=True) + '\n').encode())
    stream.flush()
    os.fsync(stream.fileno())
fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
try:
    os.fsync(fd)
finally:
    os.close(fd)
elapsed = time.monotonic() - started
observation = {'status': 'PASS_ARTIFICIAL_ONLY' if passed and elapsed < 120 else 'FAILED',
               'observed_after_fsync_s': elapsed, 'limit_s': 120, 'returncode': process.returncode,
               'test_count': receipt['test_count'], 'directory': str(parent),
               'native_positive_admission_tested': False}
print(json.dumps(observation), flush=True)
raise SystemExit(0 if observation['status'] == 'PASS_ARTIFICIAL_ONLY' else 2)
