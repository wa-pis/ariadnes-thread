"""F18.12 fabricated filesystem/admission qualification; never native admission."""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
import unittest
from unittest import mock
import uuid

STARTED = time.monotonic()
HERE = Path(__file__).resolve().parent
NAMES = (
    "eopc04_14_IAU2000.62-now.txt",
    "historicalDeltaT.txt",
    "utcLibrationAmplitudes.txt",
    "utcLibrationFundamentalArgumentMultipliers.txt",
    "utcOceanTidesAmplitudes.txt",
    "utcOceanTidesFundamentalArgumentMultipliers.txt",
)
SIZES = (3572052, 3627, 120, 319, 1136, 1633)
CARRIED = 497045495
ADDED = 3578887
TOTAL = 500624382
CEILING = 2147483648


def load(name: str) -> object:
    spec = importlib.util.spec_from_file_location(name, HERE / f"{name}.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


provision_module = load("provision")
admission_module = load("admission")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin_file(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": sha(data)}


def write_json(path: Path, value: object) -> str:
    data = (json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode()
    path.write_bytes(data)
    return sha(data)


class FixedClock:
    def __init__(self, value: float = 100.0) -> None:
        self.value = value

    def __call__(self) -> float:
        return self.value


class Fixture:
    def __init__(self, root: Path, *, full: bool = False) -> None:
        self.root = root
        self.sources = root / "sources"
        self.resources = root / "resources"
        self.receipts = root / "receipts"
        for directory in (self.sources, self.resources, self.receipts):
            directory.mkdir()
        self.payloads: dict[str, bytes] = {}
        for index, name in enumerate(NAMES):
            count = SIZES[index] if full else index + 11
            data = bytes([65 + index]) * count
            self.payloads[name] = data
            (self.sources / name).write_bytes(data)
        self.pins = tuple(
            provision_module.Payload(name, len(data), sha(data))
            for name, data in self.payloads.items()
        )
        self.old: dict[str, bytes] = {}
        for index in range(5):
            name = f"old-kernel/fake-{index}.txt"
            data = f"FABRICATED OLD RESOURCE {index}\n".encode()
            path = self.resources / name
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(data)
            self.old[name] = data
        self.clock = FixedClock()

    @property
    def target(self) -> Path:
        return self.resources / "earth_orientation"

    @property
    def precharge(self) -> Path:
        return self.receipts / "acquisition-precharge.json"

    @property
    def receipt(self) -> Path:
        return self.receipts / "provisioning-receipt.json"

    def run(self, **changes: object) -> dict[str, object]:
        arguments: dict[str, object] = {
            "started_s": 100.0,
            "now": self.clock,
            "carried_bytes": CARRIED,
            "ceiling_bytes": CEILING,
        }
        arguments.update(changes)
        return provision_module.provision(
            self.sources, self.resources, self.receipts, self.pins, **arguments
        )


class ProvisionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=RUN_DIRECTORY)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.fixture = Fixture(self.root)

    def fails(self, **changes: object) -> None:
        with self.assertRaises(provision_module.ProvisionError):
            self.fixture.run(**changes)
        if self.fixture.receipt.exists():
            record = json.loads(self.fixture.receipt.read_bytes())
            self.assertNotEqual(record.get("status"), "passed")
            self.assertNotEqual(record.get("status"), "COMPLETE")

    def assert_charge_retained(self) -> None:
        self.assertTrue(self.fixture.precharge.is_file())
        data = json.loads(self.fixture.precharge.read_bytes())
        self.assertIn(str(CARRIED), json.dumps(data))
        added = sum(len(value) for value in self.fixture.payloads.values())
        self.assertIn(str(CARRIED + added), json.dumps(data))
        self.assertNotIn("NATIVE_ADMITTED", json.dumps(data))

    def test_literal_names_and_frozen_payload(self) -> None:
        self.assertEqual(tuple(provision_module.SIX_NAMES), NAMES)
        with self.assertRaises((AttributeError, TypeError)):
            self.fixture.pins[0].name = "changed"

    def test_full_volume_six_new_and_five_old_independent_readback(self) -> None:
        with tempfile.TemporaryDirectory(dir=RUN_DIRECTORY) as directory:
            fixture = Fixture(Path(directory).resolve(), full=True)
            result = fixture.run()
            self.assertEqual(result["status"], "passed")
            self.assertEqual(sum(map(len, fixture.payloads.values())), ADDED)
            self.assertEqual(CARRIED + ADDED, TOTAL)
            expected = {**fixture.old, **{
                f"earth_orientation/{name}": data
                for name, data in fixture.payloads.items()
            }}
            paths = sorted(path for path in fixture.resources.rglob("*") if path.is_file())
            self.assertEqual(len(paths), 11)
            self.assertEqual({str(path.relative_to(fixture.resources)) for path in paths}, set(expected))
            for path in paths:
                relative = str(path.relative_to(fixture.resources))
                self.assertFalse(path.is_symlink())
                self.assertEqual(path.read_bytes(), expected[relative])
                self.assertEqual(sha(path.read_bytes()), sha(expected[relative]))
            charge = json.loads(fixture.precharge.read_bytes())
            self.assertIn(str(TOTAL), json.dumps(charge))
            receipt = json.loads(fixture.receipt.read_bytes())
            self.assertEqual(receipt["status"], "completed-pending-outer-readback")
            self.assertEqual(result["receipt_sha256"], sha(fixture.receipt.read_bytes()))
            self.assertNotIn("NATIVE_ADMITTED", json.dumps(result))

    def test_bad_size(self) -> None:
        (self.fixture.sources / NAMES[0]).write_bytes(b"short")
        self.fails()
        self.assertFalse(self.fixture.target.exists())

    def test_bad_hash(self) -> None:
        path = self.fixture.sources / NAMES[0]
        path.write_bytes(b"z" * len(self.fixture.payloads[NAMES[0]]))
        self.fails()
        self.assertFalse(self.fixture.target.exists())

    def test_missing_source(self) -> None:
        (self.fixture.sources / NAMES[0]).unlink()
        self.fails()

    def test_missing_pin(self) -> None:
        self.fixture.pins = self.fixture.pins[:-1]
        self.fails()

    def test_duplicate_pin(self) -> None:
        self.fixture.pins = self.fixture.pins[:-1] + (self.fixture.pins[0],)
        self.fails()

    def test_unknown_pin_name(self) -> None:
        old = self.fixture.pins[-1]
        with self.assertRaises(provision_module.ProvisionError):
            provision_module.Payload("unexpected.txt", old.byte_count, old.sha256)

    def test_symlink_source(self) -> None:
        path = self.fixture.sources / NAMES[0]
        path.unlink()
        path.symlink_to(self.fixture.sources / NAMES[1])
        self.fails()

    def test_nonregular_source_directory(self) -> None:
        path = self.fixture.sources / NAMES[0]
        path.unlink()
        path.mkdir()
        self.fails()

    def test_nonregular_source_fifo(self) -> None:
        path = self.fixture.sources / NAMES[0]
        path.unlink()
        os.mkfifo(path)
        self.fails()

    def test_symlink_source_ancestor(self) -> None:
        alias = self.root / "source-alias"
        alias.symlink_to(self.fixture.sources, target_is_directory=True)
        self.fixture.sources = alias
        self.fails()

    def test_symlink_destination_ancestor(self) -> None:
        alias = self.root / "resource-alias"
        alias.symlink_to(self.fixture.resources, target_is_directory=True)
        self.fixture.resources = alias
        self.fails()

    def test_symlink_receipt_ancestor(self) -> None:
        alias = self.root / "receipt-alias"
        alias.symlink_to(self.fixture.receipts, target_is_directory=True)
        self.fixture.receipts = alias
        self.fails()

    def test_occupied_empty_target(self) -> None:
        self.fixture.target.mkdir()
        self.fails()
        self.assertTrue(self.fixture.target.is_dir())

    def test_occupied_nonempty_target_preserved(self) -> None:
        self.fixture.target.mkdir()
        sentinel = self.fixture.target / "sentinel"
        sentinel.write_bytes(b"preserve")
        self.fails()
        self.assertEqual(sentinel.read_bytes(), b"preserve")

    def test_dangling_target_is_occupied(self) -> None:
        self.fixture.target.symlink_to(self.root / "absent")
        self.fails()
        self.assertTrue(self.fixture.target.is_symlink())

    def test_actual_no_replace_race_empty_target(self) -> None:
        original = provision_module._publish
        def race(stage: Path, target: Path) -> None:
            target.mkdir()
            original(stage, target)
        with mock.patch.object(provision_module, "_publish", side_effect=race):
            self.fails()
        self.assertTrue(self.fixture.target.is_dir())
        self.assertEqual(list(self.fixture.target.iterdir()), [])
        self.assert_charge_retained()

    def test_overflow(self) -> None:
        self.fails(carried_bytes=CEILING)
        self.assertFalse(self.fixture.precharge.exists())

    def test_expired(self) -> None:
        self.fixture.clock.value = 700.0
        self.fails()
        self.assertFalse(self.fixture.target.exists())

    def test_backwards_clock(self) -> None:
        self.fixture.clock.value = 99.0
        self.fails()

    def test_nan_clock(self) -> None:
        self.fixture.clock.value = math.nan
        self.fails()

    def test_infinite_clock(self) -> None:
        self.fixture.clock.value = math.inf
        self.fails()

    def test_incomparable_clock(self) -> None:
        self.fails(now=lambda: "not-a-clock")

    def test_copy_write_failure_retains_charge(self) -> None:
        original = os.write
        def fail_payload(fd: int, data: bytes) -> int:
            if stat.S_ISREG(os.fstat(fd).st_mode) and data.startswith(b"AAAA"):
                raise OSError("injected copy failure")
            return original(fd, data)
        with mock.patch.object(provision_module.os, "write", side_effect=fail_payload):
            self.fails()
        self.assertFalse(self.fixture.target.exists())
        self.assert_charge_retained()

    def test_short_read_retains_charge(self) -> None:
        original = os.read
        calls = 0
        def short(fd: int, count: int) -> bytes:
            nonlocal calls
            result = original(fd, count)
            if self.fixture.precharge.exists() and result.startswith(b"AAAA"):
                calls += 1
                return result[:-1]
            return result
        with mock.patch.object(provision_module.os, "read", side_effect=short):
            self.fails()
        self.assertGreater(calls, 0)
        self.assertFalse(self.fixture.target.exists())
        self.assert_charge_retained()

    def test_over_read_retains_charge(self) -> None:
        original = os.read
        def over(fd: int, count: int) -> bytes:
            result = original(fd, count)
            return result + b"X" if self.fixture.precharge.exists() and result.startswith(b"AAAA") else result
        with mock.patch.object(provision_module.os, "read", side_effect=over):
            self.fails()
        self.assertFalse(self.fixture.target.exists())
        self.assert_charge_retained()

    def test_fsync_failure_retains_precharge(self) -> None:
        original = provision_module._sync
        count = 0
        def fail_later(fd: int) -> None:
            nonlocal count
            count += 1
            if count == 3:
                raise OSError("injected fsync failure")
            original(fd)
        with mock.patch.object(provision_module, "_sync", side_effect=fail_later):
            self.fails()
        self.assert_charge_retained()
        self.assertFalse(self.fixture.target.exists())

    def test_publication_failure_retains_charge(self) -> None:
        with mock.patch.object(provision_module, "_publish", side_effect=OSError("unsupported")):
            self.fails()
        self.assert_charge_retained()
        self.assertFalse(self.fixture.target.exists())

    def test_parent_fsync_failure_is_published_but_not_admitted(self) -> None:
        original_publish = provision_module._publish
        original_sync = provision_module._sync
        published = False
        def publish(stage: Path, target: Path) -> None:
            nonlocal published
            original_publish(stage, target)
            published = True
        def sync(fd: int) -> None:
            if published:
                raise OSError("injected parent fsync failure")
            original_sync(fd)
        with mock.patch.object(provision_module, "_publish", side_effect=publish), mock.patch.object(provision_module, "_sync", side_effect=sync):
            self.fails()
        self.assertTrue(published)
        self.assertTrue(self.fixture.target.is_dir())
        self.assert_charge_retained()

    def test_final_clock_expiry_is_not_success(self) -> None:
        original = provision_module._publish
        def publish(stage: Path, target: Path) -> None:
            original(stage, target)
            self.fixture.clock.value = 700.0
        with mock.patch.object(provision_module, "_publish", side_effect=publish):
            self.fails()
        self.assert_charge_retained()

    def test_existing_precharge_never_overwritten(self) -> None:
        self.fixture.precharge.write_bytes(b"immutable first attempt")
        self.fails()
        self.assertEqual(self.fixture.precharge.read_bytes(), b"immutable first attempt")

    def test_payload_invalid_types_sizes_and_hashes(self) -> None:
        for count in (True, 0, -1, 3578888, 1.0, "1"):
            with self.subTest(count=count), self.assertRaises(provision_module.ProvisionError):
                provision_module.Payload(NAMES[0], count, "a" * 64)
        for digest in (None, "A" * 64, "g" * 64, "a" * 63):
            with self.subTest(digest=digest), self.assertRaises(provision_module.ProvisionError):
                provision_module.Payload(NAMES[0], 1, digest)

    def test_six_file_byte_overflow(self) -> None:
        self.fixture.pins = tuple(provision_module.Payload(name, 3578887, "a" * 64) for name in NAMES)
        self.fails()
        self.assertFalse(self.fixture.precharge.exists())

    def test_invalid_start_and_acquisition_types(self) -> None:
        for value in (True, math.nan, math.inf, "100"):
            with self.subTest(started=value):
                self.fails(started_s=value)
        for arguments in ({"carried_bytes": True}, {"carried_bytes": -1}, {"ceiling_bytes": True}, {"ceiling_bytes": 2147483649}):
            with self.subTest(arguments=arguments):
                self.fails(**arguments)

    def test_zero_progress_write_retains_charge(self) -> None:
        original = os.write
        def zero(fd: int, data: bytes) -> int:
            return 0 if data.startswith(b"AAAA") else original(fd, data)
        with mock.patch.object(provision_module.os, "write", side_effect=zero):
            self.fails()
        self.assert_charge_retained()
        self.assertFalse(self.fixture.target.exists())

    def test_precharge_sync_failure_does_not_start_copy(self) -> None:
        with mock.patch.object(provision_module, "_sync", side_effect=OSError("precharge not durable")):
            self.fails()
        self.assert_charge_retained()
        self.assertFalse(self.fixture.target.exists())
        self.assertFalse((self.fixture.resources / ".earth_orientation-stage").exists())

    def test_completion_receipt_sync_failure_cannot_admit(self) -> None:
        original_publish = provision_module._publish
        original_sync = provision_module._sync
        published = False
        def publish(stage: Path, target: Path) -> None:
            nonlocal published
            original_publish(stage, target)
            published = True
        def sync(fd: int) -> None:
            if published and stat.S_ISREG(os.fstat(fd).st_mode):
                raise OSError("completion receipt not durable")
            original_sync(fd)
        with mock.patch.object(provision_module, "_publish", side_effect=publish), mock.patch.object(provision_module, "_sync", side_effect=sync):
            self.fails()
        self.assertTrue(self.fixture.target.is_dir())
        self.assert_charge_retained()
        self.assertEqual(json.loads(self.fixture.receipt.read_bytes())["status"], "completed-pending-outer-readback")


class AdmissionFixture:
    def __init__(self, root: Path) -> None:
        self.fixture = Fixture(root, full=True)
        self.outcome = self.fixture.run()
        self.clock = FixedClock(102.0)
        self.profile_path = root / "profile.json"
        self.contract_path = root / "contract.json"
        self.output = root / "admission.json"
        self.mount = root / "fabricated-mount"
        self.image = root / "fabricated-image-label"
        self.mount.mkdir()
        self.image.write_bytes(b"NOT AN IMAGE; FABRICATED LABEL ONLY\n")
        groups: dict[str, dict[str, object]] = {}
        for name in ("source", "native", "control", "ledger"):
            path = root / f"fabricated-{name}-identity.txt"
            path.write_bytes(f"ARTIFICIAL {name} IDENTITY\n".encode())
            groups[name] = {str(path): pin_file(path)}
        self.contract: dict[str, object] = {
            "schema": "ariadna.f18.supplemented-setup-contract.v1",
            "qualification": "ARTIFICIAL",
            "old_resources": [
                {"name": name, "bytes": len(data), "sha256": sha(data)}
                for name, data in self.fixture.old.items()
            ],
            "supplement": [
                {"name": name, "bytes": len(data), "sha256": sha(data)}
                for name, data in self.fixture.payloads.items()
            ],
            "source_expected": groups["source"],
            "native_expected": groups["native"],
            "controls_expected": groups["control"],
            "ledger_expected": groups["ledger"],
            "environment_unchanged": {"HOME": str(root / "fabricated-home"), "LANG": "C"},
        }
        self.profile: dict[str, object] = {
            "schema": "ariadna.f18.supplemented-admission-profile.v1",
            "mode": "artificial",
            "contract_sha256": write_json(self.contract_path, self.contract),
            "preflight_started_s": 100.0,
            "mount": str(self.mount),
            "image": str(self.image),
            "resources": str(self.fixture.resources),
            "work_directory": str(root / "unused-work-directory"),
            "environment": copy.deepcopy(self.contract["environment_unchanged"]),
            "source_pins": copy.deepcopy(groups["source"]),
            "native_pins": copy.deepcopy(groups["native"]),
            "control_pins": copy.deepcopy(groups["control"]),
            "ledger_pins": copy.deepcopy(groups["ledger"]),
            "probe_input": {
                "schema": "ariadna-owner-setup-input-v1",
                "scope": "never-run-owner-setup-only",
                "mode": "artificial",
                "kernel_path": "FABRICATED-NOT-READ",
                "kernel_sha256": "a" * 64,
                "probe_sha256": "b" * 64,
                "owner_fixture_sha256": "c" * 64,
                "owner_auditor_sha256": "d" * 64,
                "trajectory_sha256": "e" * 64,
                "setup_auditor_sha256": "f" * 64,
            },
            "proofs": {},
        }
        self.contract["probe_expected"] = copy.deepcopy(self.profile["probe_input"])
        self.profile["contract_sha256"] = write_json(self.contract_path, self.contract)
        self.proof_paths = {
            "precharge": self.fixture.precharge,
            "provision": self.fixture.receipt,
            "outcome": root / "provision-outer-outcome.json",
            "readback": root / "fabricated-readback.json",
        }
        write_json(self.proof_paths["outcome"], self.outcome)
        rows = list(self.contract["old_resources"]) + [
            {"name": "earth_orientation/" + row["name"], "bytes": row["bytes"], "sha256": row["sha256"]}
            for row in self.contract["supplement"]
        ]
        readback = {
            "schema": "ariadna.f18.supplemented-ro-readback.v1",
            "mode": "artificial", "started_s": 100.0, "elapsed_s": 1.0,
            "read_only": True, "mount": str(self.mount), "image": str(self.image),
            "resources": rows,
            "provision_sha256": sha(self.fixture.receipt.read_bytes()),
            "outcome_sha256": sha(self.proof_paths["outcome"].read_bytes()),
            "precharge_sha256": sha(self.fixture.precharge.read_bytes()),
        }
        write_json(self.proof_paths["readback"], readback)
        for name, path in self.proof_paths.items():
            self.profile["proofs"][name] = {"path": str(path), "sha256": sha(path.read_bytes())}
        self.save()

    def save(self) -> None:
        write_json(self.profile_path, self.profile)

    def change_proof(self, name: str, **fields: object) -> None:
        path = self.proof_paths[name]
        document = json.loads(path.read_bytes())
        document.update(fields)
        self.profile["proofs"][name]["sha256"] = write_json(path, document)
        self.save()

    def observe(self, mount: Path, image: Path) -> dict[str, object]:
        return {"read_only": True, "mount": str(mount), "image": str(image), "capacity_bytes": 1024**3}

    def run(self, **changes: object) -> dict[str, object]:
        arguments: dict[str, object] = {"mode": "artificial", "started_s": 100.0, "now": self.clock, "observe": self.observe}
        arguments.update(changes)
        return admission_module.admit(self.profile_path, self.contract_path, self.output, **arguments)


class AdmissionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=RUN_DIRECTORY)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.fixture = AdmissionFixture(self.root)

    def fails(self, **changes: object) -> None:
        with self.assertRaises(admission_module.AdmissionError):
            self.fixture.run(**changes)
        if self.fixture.output.exists():
            saved = json.loads(self.fixture.output.read_bytes())
            self.assertFalse(saved["native_launch_authorized"])
            self.assertNotEqual(saved["status"], "PASS")

    def test_success_is_artificial_only_with_independent_eleven(self) -> None:
        result = self.fixture.run()
        saved = json.loads(self.fixture.output.read_bytes())
        self.assertEqual(result["status"], "PASS_ARTIFICIAL_ADMISSION_ONLY")
        self.assertEqual(saved["status"], "PENDING_DURABLE_ADMISSION")
        for record in (saved, result):
            self.assertFalse(record["native_launch_authorized"])
            self.assertEqual(record["resource_count"], 11)
        self.assertEqual(result["finalization"], "checked-after-fsync")
        self.assertEqual(saved["finalization"], "pending-outer-readback")
        self.assertEqual(result["receipt_sha256"], sha(self.fixture.output.read_bytes()))
        self.assertEqual(result["profile_sha256"], sha(self.fixture.profile_path.read_bytes()))
        self.assertEqual(result["contract_sha256"], sha(self.fixture.contract_path.read_bytes()))

    def test_missing_each_proof(self) -> None:
        for name in ("precharge", "provision", "outcome", "readback"):
            with self.subTest(name=name):
                reference = self.fixture.profile["proofs"].pop(name)
                self.fixture.save()
                self.fails()
                self.fixture.profile["proofs"][name] = reference

    def test_missing_proof_file(self) -> None:
        self.fixture.proof_paths["readback"].unlink()
        self.fails()

    def test_tampered_proof_without_rehash(self) -> None:
        self.fixture.proof_paths["readback"].write_bytes(b"{}\n")
        self.fails()

    def test_stale_precharge_clock(self) -> None:
        self.fixture.change_proof("precharge", started_s=99.0)
        self.fails()

    def test_tampered_carried_precharge(self) -> None:
        self.fixture.change_proof("precharge", carried_bytes=CARRIED - 1)
        self.fails()

    def test_tampered_aggregate_precharge(self) -> None:
        self.fixture.change_proof("precharge", aggregate_bytes=TOTAL - 1)
        self.fails()

    def test_tampered_boolean_precharge(self) -> None:
        self.fixture.change_proof("precharge", additional_bytes=True)
        self.fails()

    def test_pending_provision_cannot_replace_outer_outcome(self) -> None:
        self.fixture.change_proof("outcome", status="completed-pending-outer-readback")
        self.fails()

    def change_outcome_with_consistent_bindings(self, finalization: str | None) -> None:
        document = json.loads(self.fixture.proof_paths["outcome"].read_bytes())
        if finalization is None:
            del document["finalization"]
        else:
            document["finalization"] = finalization
        digest = write_json(self.fixture.proof_paths["outcome"], document)
        self.fixture.profile["proofs"]["outcome"]["sha256"] = digest
        self.fixture.change_proof("readback", outcome_sha256=digest)

    def test_outer_outcome_missing_finalization_rejected_after_rebinding(self) -> None:
        self.change_outcome_with_consistent_bindings(None)
        self.fails()

    def test_outer_outcome_pending_finalization_rejected_after_rebinding(self) -> None:
        self.change_outcome_with_consistent_bindings("pending-outer-readback")
        self.fails()

    def test_outer_outcome_failed_finalization_rejected_after_rebinding(self) -> None:
        self.change_outcome_with_consistent_bindings("failed")
        self.fails()

    def test_tampered_outer_receipt_binding(self) -> None:
        self.fixture.change_proof("outcome", receipt_sha256="0" * 64)
        self.fails()

    def test_tampered_provision_target_binding(self) -> None:
        self.fixture.change_proof("provision", target_directory=str(self.root / "wrong"))
        self.fails()

    def test_ro_false(self) -> None:
        self.fixture.change_proof("readback", read_only=False)
        self.fails()

    def test_stale_readback_clock(self) -> None:
        self.fixture.change_proof("readback", started_s=99.0)
        self.fails()

    def test_future_readback_time(self) -> None:
        self.fixture.change_proof("readback", elapsed_s=3.0)
        self.fails()

    def test_out_of_order_readback_time(self) -> None:
        self.fixture.change_proof("readback", elapsed_s=-1.0)
        self.fails()

    def test_readback_missing_resource(self) -> None:
        document = json.loads(self.fixture.proof_paths["readback"].read_bytes())
        self.fixture.change_proof("readback", resources=document["resources"][:-1])
        self.fails()

    def test_tampered_readback_resource_hash(self) -> None:
        document = json.loads(self.fixture.proof_paths["readback"].read_bytes())
        document["resources"][0]["sha256"] = "0" * 64
        self.fixture.change_proof("readback", resources=document["resources"])
        self.fails()

    def test_tampered_readback_mount(self) -> None:
        self.fixture.change_proof("readback", mount=str(self.root / "wrong"))
        self.fails()

    def test_tampered_readback_image(self) -> None:
        self.fixture.change_proof("readback", image=str(self.root / "wrong"))
        self.fails()

    def test_tampered_readback_binding(self) -> None:
        self.fixture.change_proof("readback", provision_sha256="0" * 64)
        self.fails()

    def test_extra_resource(self) -> None:
        (self.fixture.fixture.resources / "unlisted-extra").write_bytes(b"extra")
        self.fails()

    def test_resource_payload_mutation(self) -> None:
        path = self.fixture.fixture.target / NAMES[0]
        data = path.read_bytes()
        path.write_bytes(b"X" + data[1:])
        self.fails()

    def test_resource_symlink(self) -> None:
        path = self.fixture.fixture.resources / next(iter(self.fixture.fixture.old))
        path.unlink()
        path.symlink_to(self.fixture.fixture.sources / NAMES[0])
        self.fails()

    def test_resource_directory_symlink(self) -> None:
        (self.fixture.fixture.resources / "unlisted-link").symlink_to(self.root, target_is_directory=True)
        self.fails()

    def test_identity_groups_missing_stale_or_tampered(self) -> None:
        for group in ("source_pins", "native_pins", "control_pins", "ledger_pins"):
            with self.subTest(group=group):
                original = self.fixture.profile[group]
                self.fixture.profile[group] = {}
                self.fixture.save()
                self.fails()
                self.fixture.profile[group] = original
        self.fixture.save()

    def test_actual_control_bytes_changed(self) -> None:
        path = Path(next(iter(self.fixture.profile["control_pins"])))
        original = path.read_bytes()
        path.write_bytes(b"x" * len(original))
        self.fails()

    def test_contract_hash_mutation(self) -> None:
        self.fixture.contract_path.write_bytes(b"{}\n")
        self.fails()

    def test_nonartificial_contract(self) -> None:
        self.fixture.contract["qualification"] = "NATIVE"
        self.fixture.profile["contract_sha256"] = write_json(self.fixture.contract_path, self.fixture.contract)
        self.fixture.save()
        self.fails()

    def test_environment_mutation(self) -> None:
        self.fixture.profile["environment"]["LANG"] = "unexpected"
        self.fixture.save()
        self.fails()

    def test_probe_exact_key_set(self) -> None:
        self.fixture.profile["probe_input"]["extra"] = "not allowed"
        self.fixture.save()
        self.fails()

    def test_probe_hash_swap_under_unchanged_expected(self) -> None:
        self.fixture.profile["probe_input"]["probe_sha256"] = "0" * 64
        self.fixture.save()
        self.fails()

    def test_probe_kernel_path_swap_under_unchanged_expected(self) -> None:
        self.fixture.profile["probe_input"]["kernel_path"] = "different-fabricated-path"
        self.fixture.save()
        self.fails()

    def test_probe_mode_mutation(self) -> None:
        self.fixture.profile["probe_input"]["mode"] = "native"
        self.fixture.save()
        self.fails()

    def test_profile_mode_mutation(self) -> None:
        self.fixture.profile["mode"] = "native"
        self.fixture.save()
        self.fails()

    def test_stale_profile_clock(self) -> None:
        self.fixture.profile["preflight_started_s"] = 99.0
        self.fixture.save()
        self.fails()

    def test_expired_clock(self) -> None:
        self.fixture.clock.value = 700.0
        self.fails()

    def test_backwards_clock(self) -> None:
        self.fixture.clock.value = 99.0
        self.fails()

    def test_nonfinite_and_incomparable_clock(self) -> None:
        for value in (math.inf, math.nan, True, "not-a-clock"):
            with self.subTest(value=value):
                self.fails(now=lambda: value)

    def test_observed_writable(self) -> None:
        self.fails(observe=lambda mount, image: dict(self.fixture.observe(mount, image), read_only=False))

    def test_observed_wrong_identity(self) -> None:
        self.fails(observe=lambda mount, image: dict(self.fixture.observe(mount, image), image="wrong"))

    def test_observed_capacity_overflow_or_invalid(self) -> None:
        for value in (0, 8589934593, True, 1.0):
            with self.subTest(value=value):
                self.fails(observe=lambda mount, image: dict(self.fixture.observe(mount, image), capacity_bytes=value))

    def test_native_mode_injection_rejected_before_filesystem_observation(self) -> None:
        with mock.patch.object(admission_module, "_live_observation", side_effect=AssertionError("must not observe live image")):
            self.fails(mode="native")
        self.assertFalse(self.fixture.output.exists())

    def test_native_mode_fixed_paths_reject_fabricated_profile(self) -> None:
        with mock.patch.object(admission_module, "_live_observation", side_effect=AssertionError("must not observe live image")):
            self.fails(mode="native", started_s=time.monotonic(), now=time.monotonic, observe=None)
        self.assertFalse(self.fixture.output.exists())

    def test_existing_output_preserved(self) -> None:
        self.fixture.output.write_bytes(b"immutable first output")
        with self.assertRaises(admission_module.AdmissionError):
            self.fixture.run()
        self.assertEqual(self.fixture.output.read_bytes(), b"immutable first output")

    def test_dangling_output_preserved(self) -> None:
        self.fixture.output.symlink_to(self.root / "absent")
        with self.assertRaises(admission_module.AdmissionError):
            self.fixture.run()
        self.assertTrue(self.fixture.output.is_symlink())

    def test_receipt_fsync_failure_cannot_return_native_success(self) -> None:
        with mock.patch.object(admission_module.os, "fsync", side_effect=OSError("injected admission sync")):
            self.fails()

    def test_directory_fsync_failure_cannot_leave_disk_pass(self) -> None:
        original = os.fsync
        def fail_directory(fd: int) -> None:
            if stat.S_ISDIR(os.fstat(fd).st_mode):
                raise OSError("injected admission directory sync")
            original(fd)
        with mock.patch.object(admission_module.os, "fsync", side_effect=fail_directory):
            self.fails()
        self.assertEqual(json.loads(self.fixture.output.read_bytes())["status"], "PENDING_DURABLE_ADMISSION")

    def test_late_directory_fsync_cannot_leave_disk_pass(self) -> None:
        original = os.fsync
        def late_directory(fd: int) -> None:
            original(fd)
            if stat.S_ISDIR(os.fstat(fd).st_mode):
                self.fixture.clock.value = 700.0
        with mock.patch.object(admission_module.os, "fsync", side_effect=late_directory):
            self.fails()
        self.assertEqual(json.loads(self.fixture.output.read_bytes())["status"], "PENDING_DURABLE_ADMISSION")

    def test_late_fsync_cannot_return_success(self) -> None:
        original = os.fsync
        def late(fd: int) -> None:
            original(fd)
            self.fixture.clock.value = 700.0
        with mock.patch.object(admission_module.os, "fsync", side_effect=late):
            self.fails()

    def test_oversize_proof(self) -> None:
        path = self.fixture.proof_paths["readback"]
        raw = b" " * 65537
        path.write_bytes(raw)
        self.fixture.profile["proofs"]["readback"]["sha256"] = sha(raw)
        self.fixture.save()
        self.fails()

    def test_duplicate_json_key(self) -> None:
        raw = b'{"mode":"artificial","mode":"native"}\n'
        self.fixture.profile_path.write_bytes(raw)
        self.fails()

    def test_nonregular_proof(self) -> None:
        path = self.fixture.proof_paths["readback"]
        path.unlink()
        os.mkfifo(path)
        self.fails()

    def test_symlink_proof(self) -> None:
        path = self.fixture.proof_paths["readback"]
        path.unlink()
        path.symlink_to(self.fixture.proof_paths["outcome"])
        self.fails()


RUN_DIRECTORY: Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=os.environ.get("ARTIFICIAL_RUN_ROOT"))
    arguments = parser.parse_args()
    if not arguments.root:
        parser.error("a fresh evidence parent directory is required")
    parent = Path(arguments.root).resolve(strict=True)
    global RUN_DIRECTORY
    RUN_DIRECTORY = parent / ("artificial-" + uuid.uuid4().hex)
    RUN_DIRECTORY.mkdir(mode=0o700)
    output = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    log = output.getvalue().encode()
    log_path = RUN_DIRECTORY / "unittest.log"
    with log_path.open("xb") as stream:
        stream.write(log)
        stream.flush()
        os.fsync(stream.fileno())
    print(log.decode(), end="")
    elapsed = time.monotonic() - STARTED
    record = {
        "schema": "ariadna.f18.supplemented-artificial-qualification.v1",
        "qualification": "ARTIFICIAL_ONLY",
        "status": "test-pass-pending-external-clock-and-durable-receipt-check" if result.wasSuccessful() else "failed",
        "native_admission": "NATIVE_NOT_ADMITTED",
        "test_count": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "elapsed_s_before_receipt": elapsed,
        "limit_s": 120,
        "evidence_limit_bytes": 2097152,
        "full_new_payload_bytes": ADDED,
        "fake_resource_count": 11,
        "carried_bytes": CARRIED,
        "aggregate_bytes": TOTAL,
        "sources": {name: pin_file(HERE / name) for name in ("qualify.py", "provision.py", "admission.py")},
        "scientific_imports_or_executions": 0,
        "real_payload_reads_or_mounts": 0,
        "native_positive_admission_tested": False,
        "log_sha256": sha(log),
    }
    passed = result.wasSuccessful() and elapsed < 120 and len(log) < 2097152 - 65536
    name = "qualification.json" if passed else "qualification-failure.json"
    data = (json.dumps(record, sort_keys=True, allow_nan=False) + "\n").encode()
    with (RUN_DIRECTORY / name).open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(RUN_DIRECTORY, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    final_elapsed = time.monotonic() - STARTED
    evidence_bytes = sum(path.stat().st_size for path in RUN_DIRECTORY.iterdir() if path.is_file())
    if final_elapsed >= 120 or evidence_bytes > 2097152:
        print("FAIL: final durable evidence exceeded clock/byte limit", flush=True)
        return 2
    print(json.dumps({"evidence_directory": str(RUN_DIRECTORY), "passed": passed, "elapsed_s_after_fsync": final_elapsed, "evidence_bytes": evidence_bytes}, sort_keys=True), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
