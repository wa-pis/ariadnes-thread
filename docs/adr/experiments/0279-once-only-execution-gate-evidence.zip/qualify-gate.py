"""F18.13 artificial once-only gate checks; no native launch authority."""
from __future__ import annotations

import argparse
from collections.abc import Callable, Iterator
from contextlib import contextmanager
import copy
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
from types import ModuleType
import unittest
from unittest import mock
import uuid

STARTED = time.monotonic()
HERE = Path(__file__).resolve().parent
SOURCE_NAMES = (
    "dispatch-once.py", "qualify-gate.py", "admission.py", "provision.py", "fixture-reuse.py",
)


def load(name: str, filename: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


fixture_module = load("fixture_reuse", "fixture-reuse.py")
gate_module = load("dispatch_once", "dispatch-once.py")


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def pin(path: Path) -> dict[str, object]:
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def write_json(path: Path, value: object) -> str:
    raw = (json.dumps(value, sort_keys=True, allow_nan=False) + "\n").encode()
    path.write_bytes(raw)
    return sha(raw)


class GateFixture:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.connected = fixture_module.AdmissionFixture(root)
        (root / "admission.py").write_bytes((HERE / "admission.py").read_bytes())
        self.profile = self.connected.profile
        self.contract = self.connected.contract
        self.clock = self.connected.clock
        self.profile_path = self.connected.profile_path
        self.contract_path = self.connected.contract_path
        self.start = root / "gate-start.json"
        self.candidate = root / "admission-check.json"
        self.launch = root / "launch-admission.json"
        self.episode = root / "episode-start.json"
        self.execution = root / "execution"
        self.collector = root / "run-once.py"
        self.collector.write_bytes(b"# ARTIFICIAL COLLECTOR; NEVER EXECUTE\n")
        self.python = root / "fabricated-outer-python-label"
        self.python.write_bytes(b"ARTIFICIAL OUTER PYTHON IDENTITY; NEVER EXECUTE\n")
        collector_pin = pin(self.collector)
        self.contract["controls_expected"][str(self.collector)] = {
            "bytes": collector_pin["bytes"], "sha256": collector_pin["sha256"],
        }
        self.profile["control_pins"] = copy.deepcopy(self.contract["controls_expected"])
        self.profile["base_revision"] = "ARTIFICIAL-NOT-A-CHECKOUT"
        self.profile["work_directory"] = str(self.execution)
        self.profile["outer_gate"] = pin(HERE / "dispatch-once.py")
        self.profile["outer_python"] = pin(self.python)
        self.profile["contract_sha256"] = write_json(self.contract_path, self.contract)
        self.decision_path = root / "fabricated-execution-decision.json"
        self.decision: dict[str, object] = {
            "schema": "ariadna.f18.supplemented-execution-decision.v1",
            "stage": "F18.13", "mode": "artificial",
            "status": "ARTIFICIAL_EXECUTION_DECISION",
            "base_revision": self.profile["base_revision"],
            "contract_sha256": self.profile["contract_sha256"],
            "outer_gate_pin": copy.deepcopy(self.profile["outer_gate"]),
            "outer_python_pin": copy.deepcopy(self.profile["outer_python"]),
        }
        self.save_decision()
        self.dispatched: list[object] = []

    def save(self) -> None:
        write_json(self.profile_path, self.profile)

    def save_decision(self) -> None:
        self.profile["execution_decision"] = {
            "path": str(self.decision_path), "sha256": write_json(self.decision_path, self.decision),
        }
        self.save()

    def dispatch(self, *arguments: object) -> None:
        self.dispatched.append(arguments)

    def run(self, **changes: object) -> object:
        arguments: dict[str, object] = {
            "mode": "artificial", "started_s": 100.0, "now": self.clock,
            "observe": self.connected.observe, "dispatch": self.dispatch,
        }
        arguments.update(changes)
        return gate_module.gate(self.profile_path, self.contract_path, **arguments)


class GateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=RUN_DIRECTORY)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.fixture = GateFixture(self.root)

    def rejected(self, **changes: object) -> None:
        with self.assertRaises(gate_module.GateError):
            self.fixture.run(**changes)
        self.assertEqual(self.fixture.dispatched, [])
        if self.fixture.launch.is_file():
            record = json.loads(self.fixture.launch.read_bytes())
            self.assertNotEqual(record.get("status"), "PASS")
            self.assertIs(record["native_launch_authorized"], False)

    @contextmanager
    def mutate_admission(self, mutation: Callable[[dict[str, object]], None]) -> Iterator[None]:
        original = gate_module._load_admission
        called: list[bool] = []
        mutated: list[bool] = []
        def loader(path: Path) -> ModuleType:
            module = original(path)
            original_admit = module.admit
            def wrapped(*args: object, **kwargs: object) -> dict[str, object]:
                called.append(True)
                result = original_admit(*args, **kwargs)
                mutation(result)
                mutated.append(True)
                return result
            module.admit = wrapped
            return module
        with mock.patch.object(gate_module, "_load_admission", side_effect=loader):
            try:
                yield
            finally:
                self.assertEqual(called, [True], "actual admission must be called exactly once")
                self.assertEqual(mutated, [True], "semantic mutation must complete after actual admission")

    def test_connected_full_volume_durable_artificial_ready_dispatches_once(self) -> None:
        observed: list[object] = []
        with self.mutate_admission(lambda result: observed.append(result["status"])), mock.patch.object(gate_module.os, "execv", side_effect=AssertionError("artificial must never exec")):
            result = self.fixture.run()
        self.assertEqual(observed, ["PASS_ARTIFICIAL_ADMISSION_ONLY"])
        self.assertEqual(len(self.fixture.dispatched), 1)
        self.assertTrue(self.fixture.start.is_file())
        self.assertTrue(self.fixture.candidate.is_file())
        self.assertTrue(self.fixture.launch.is_file())
        pending = json.loads(self.fixture.candidate.read_bytes())
        ready = json.loads(self.fixture.launch.read_bytes())
        self.assertEqual(pending["status"], "PENDING_DURABLE_ADMISSION")
        self.assertIs(pending["native_launch_authorized"], False)
        self.assertEqual(ready["status"], "ARTIFICIAL_READY")
        self.assertIs(ready["native_launch_authorized"], False)
        files = [path for path in self.fixture.connected.fixture.resources.rglob("*") if path.is_file()]
        self.assertEqual(len(files), 11)
        self.assertEqual(sum(len(value) for value in self.fixture.connected.fixture.payloads.values()), 3578887)
        self.assertNotIn('"status": "PASS"', json.dumps(result, sort_keys=True))

    def test_each_occupied_path_refuses(self) -> None:
        for name in ("gate-start.json", "admission-check.json", "launch-admission.json", "episode-start.json", "execution"):
            with self.subTest(name=name), tempfile.TemporaryDirectory(dir=RUN_DIRECTORY) as directory:
                fixture = GateFixture(Path(directory).resolve())
                occupied = fixture.root / name
                occupied.write_bytes(b"IMMUTABLE FIRST ATTEMPT")
                with self.assertRaises(gate_module.GateError):
                    fixture.run()
                self.assertEqual(fixture.dispatched, [])
                self.assertEqual(occupied.read_bytes(), b"IMMUTABLE FIRST ATTEMPT")

    def test_each_dangling_path_refuses(self) -> None:
        for name in ("gate-start.json", "admission-check.json", "launch-admission.json", "episode-start.json", "execution"):
            with self.subTest(name=name), tempfile.TemporaryDirectory(dir=RUN_DIRECTORY) as directory:
                fixture = GateFixture(Path(directory).resolve())
                occupied = fixture.root / name
                occupied.symlink_to(fixture.root / "absent")
                with self.assertRaises(gate_module.GateError):
                    fixture.run()
                self.assertEqual(fixture.dispatched, [])
                self.assertTrue(occupied.is_symlink())

    def test_success_cannot_be_resumed(self) -> None:
        self.fixture.run()
        first = self.fixture.launch.read_bytes()
        with self.assertRaises(gate_module.GateError):
            self.fixture.run()
        self.assertEqual(len(self.fixture.dispatched), 1)
        self.assertEqual(self.fixture.launch.read_bytes(), first)

    def test_native_injections_refuse_before_live_observation(self) -> None:
        replacements = (
            {"now": self.fixture.clock},
            {"observe": self.fixture.connected.observe},
            {"dispatch": self.fixture.dispatch},
        )
        for replacement in replacements:
            arguments: dict[str, object] = {
                "mode": "native", "started_s": time.monotonic(),
                "now": time.monotonic, "observe": None, "dispatch": None,
            }
            arguments.update(replacement)
            with self.subTest(replacement=list(replacement)), mock.patch.object(gate_module, "_load_admission", side_effect=AssertionError("must not load admission")), mock.patch.object(gate_module, "_read", side_effect=AssertionError("must not read native paths")), mock.patch.object(gate_module.os, "execv", side_effect=AssertionError("must not exec")):
                with self.assertRaisesRegex(gate_module.GateError, "native replacement clock/observer/dispatch forbidden"):
                    gate_module.gate(gate_module.LIVE_ROOT / "profile.json", gate_module.CONTRACT_PATH, **arguments)
        self.assertEqual(self.fixture.dispatched, [])
        self.assertFalse(self.fixture.candidate.exists())

    def test_artificial_requires_explicit_observer_and_dispatch(self) -> None:
        for changes in ({"observe": None}, {"dispatch": None}):
            with self.subTest(changes=list(changes)):
                self.rejected(**changes)

    def test_missing_execution_decision_refuses(self) -> None:
        del self.fixture.profile["execution_decision"]
        self.fixture.save()
        self.rejected()

    def test_wrong_execution_decision_status_after_hash_rebinding(self) -> None:
        self.fixture.decision["status"] = "ADMITTED_ONCE"
        self.fixture.save_decision()
        self.rejected()

    def test_wrong_execution_decision_stage_after_hash_rebinding(self) -> None:
        self.fixture.decision["stage"] = "F18.9"
        self.fixture.save_decision()
        self.rejected()

    def test_missing_gate_pin_refuses(self) -> None:
        del self.fixture.profile["outer_gate"]
        self.fixture.save()
        self.rejected()

    def test_wrong_gate_hash_consistently_rebound_refuses(self) -> None:
        self.fixture.profile["outer_gate"]["sha256"] = "0" * 64
        self.fixture.decision["outer_gate_pin"] = copy.deepcopy(self.fixture.profile["outer_gate"])
        self.fixture.save_decision()
        self.rejected()

    def test_wrong_python_hash_consistently_rebound_refuses(self) -> None:
        self.fixture.profile["outer_python"]["sha256"] = "0" * 64
        self.fixture.decision["outer_python_pin"] = copy.deepcopy(self.fixture.profile["outer_python"])
        self.fixture.save_decision()
        self.rejected()

    def test_pending_returned_admission_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(status="PENDING_DURABLE_ADMISSION")):
            self.rejected()
        self.assertTrue(self.fixture.start.exists())
        self.assertFalse(self.fixture.launch.exists())

    def test_unfinalized_returned_admission_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(finalization="pending-outer-readback")):
            self.rejected()
        self.assertFalse(self.fixture.launch.exists())

    def test_missing_returned_finalization_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.pop("finalization")):
            self.rejected()
        self.assertFalse(self.fixture.launch.exists())

    def test_wrong_returned_scope_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(mode="native")):
            self.rejected()

    def test_boolean_returned_clock_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(elapsed_s=True)):
            self.rejected()

    def test_nonfinite_returned_clock_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(elapsed_s=math.nan)):
            self.rejected()

    def test_wrong_returned_receipt_hash_refuses(self) -> None:
        with self.mutate_admission(lambda result: result.update(receipt_sha256="0" * 64)):
            self.rejected()

    def test_candidate_semantic_drift_with_updated_receipt_hash_refuses(self) -> None:
        def mutate(result: dict[str, object]) -> None:
            candidate = json.loads(self.fixture.candidate.read_bytes())
            candidate["profile_sha256"] = "0" * 64
            result["receipt_sha256"] = write_json(self.fixture.candidate, candidate)
        with self.mutate_admission(mutate):
            self.rejected()

    def test_profile_drift_after_admission_with_returned_hash_rebound_refuses(self) -> None:
        def mutate(result: dict[str, object]) -> None:
            self.fixture.profile["base_revision"] = "DIFFERENT-ARTIFICIAL-BASE"
            self.fixture.save()
            result["profile_sha256"] = sha(self.fixture.profile_path.read_bytes())
        with self.mutate_admission(mutate):
            self.rejected()

    def test_contract_drift_after_admission_with_returned_hash_rebound_refuses(self) -> None:
        def mutate(result: dict[str, object]) -> None:
            self.fixture.contract["unplanned"] = "CHANGED AFTER ADMISSION"
            result["contract_sha256"] = write_json(self.fixture.contract_path, self.fixture.contract)
        with self.mutate_admission(mutate):
            self.rejected()

    def test_collector_drift_after_actual_admission_refuses(self) -> None:
        def mutate(result: dict[str, object]) -> None:
            raw = self.fixture.collector.read_bytes()
            self.fixture.collector.write_bytes(b"X" + raw[1:])
        with self.mutate_admission(mutate):
            self.rejected()

    def test_start_marker_fsync_failure_refuses_and_consumes(self) -> None:
        with mock.patch.object(gate_module, "_sync", side_effect=OSError("injected start fsync")):
            self.rejected()
        self.assertTrue(self.fixture.start.exists())
        self.assertFalse(self.fixture.candidate.exists())
        self.rejected()

    def test_ready_fsync_failure_refuses_and_consumes(self) -> None:
        original = gate_module._sync
        def sync(fd: int) -> None:
            if self.fixture.launch.exists():
                raise OSError("injected ready fsync")
            original(fd)
        with mock.patch.object(gate_module, "_sync", side_effect=sync):
            self.rejected()
        self.assertTrue(self.fixture.start.exists())
        self.rejected()

    def test_ready_directory_fsync_failure_refuses_and_consumes(self) -> None:
        original = gate_module._sync
        reached: list[bool] = []
        def sync(fd: int) -> None:
            if self.fixture.launch.exists() and stat.S_ISDIR(os.fstat(fd).st_mode):
                reached.append(True)
                raise OSError("injected ready directory fsync")
            original(fd)
        with mock.patch.object(gate_module, "_sync", side_effect=sync):
            self.rejected()
        self.assertEqual(reached, [True])
        self.assertTrue(self.fixture.start.exists())
        self.rejected()

    def test_collector_drift_after_ready_directory_fsync_refuses(self) -> None:
        original = gate_module._sync
        reached: list[bool] = []
        def sync(fd: int) -> None:
            original(fd)
            if self.fixture.launch.exists() and stat.S_ISDIR(os.fstat(fd).st_mode):
                reached.append(True)
                raw = self.fixture.collector.read_bytes()
                self.fixture.collector.write_bytes(b"X" + raw[1:])
        with mock.patch.object(gate_module, "_sync", side_effect=sync):
            self.rejected()
        self.assertEqual(reached, [True])
        self.assertTrue(self.fixture.launch.exists())

    def test_profile_drift_after_ready_directory_fsync_refuses(self) -> None:
        original = gate_module._sync
        reached: list[bool] = []
        def sync(fd: int) -> None:
            original(fd)
            if self.fixture.launch.exists() and stat.S_ISDIR(os.fstat(fd).st_mode):
                reached.append(True)
                self.fixture.profile["base_revision"] = "CHANGED-AT-FINAL-SEAL"
                self.fixture.save()
        with mock.patch.object(gate_module, "_sync", side_effect=sync):
            self.rejected()
        self.assertEqual(reached, [True])
        self.assertTrue(self.fixture.launch.exists())

    def test_late_ready_fsync_refuses_and_consumes(self) -> None:
        original = gate_module._sync
        def sync(fd: int) -> None:
            original(fd)
            if self.fixture.launch.exists():
                self.fixture.clock.value = 700.0
        with mock.patch.object(gate_module, "_sync", side_effect=sync):
            self.rejected()
        self.assertTrue(self.fixture.start.exists())
        self.rejected()

    def test_dispatch_failure_is_consumed_and_not_retried(self) -> None:
        calls: list[bool] = []
        def fail(*args: object) -> None:
            calls.append(True)
            raise RuntimeError("fake dispatcher refused")
        with self.assertRaises((gate_module.GateError, RuntimeError)):
            self.fixture.run(dispatch=fail)
        self.assertEqual(calls, [True])
        self.assertTrue(self.fixture.start.exists())
        self.assertTrue(self.fixture.launch.exists())
        self.rejected()
        self.assertEqual(calls, [True])


RUN_DIRECTORY: Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", default=os.environ.get("ARTIFICIAL_RUN_ROOT"))
    arguments = parser.parse_args()
    if not arguments.root:
        parser.error("a fresh evidence parent directory is required")
    parent = Path(arguments.root).resolve(strict=True)
    global RUN_DIRECTORY
    RUN_DIRECTORY = parent / ("artificial-" + uuid.uuid4().hex)
    RUN_DIRECTORY.mkdir(mode=0o700)
    output = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    log = output.getvalue().encode()
    with (RUN_DIRECTORY / "unittest.log").open("xb") as stream:
        stream.write(log)
        stream.flush()
        os.fsync(stream.fileno())
    print(log.decode(), end="")
    elapsed = time.monotonic() - STARTED
    record = {
        "schema": "ariadna.f18.supplemented-gate-artificial-qualification.v1",
        "qualification": "ARTIFICIAL_ONLY", "native_admission": "NATIVE_NOT_ADMITTED",
        "status": "test-pass-pending-external-clock-and-durable-receipt-check" if result.wasSuccessful() else "failed",
        "test_count": result.testsRun, "failures": len(result.failures),
        "errors": len(result.errors), "skipped": len(result.skipped),
        "elapsed_s_before_receipt": elapsed, "limit_s": 120,
        "evidence_limit_bytes": 2097152, "full_new_payload_bytes": 3578887,
        "fake_resource_count": 11, "sources": {name: {key: value for key, value in pin(HERE / name).items() if key != "path"} for name in SOURCE_NAMES},
        "scientific_imports_or_executions": 0, "real_payload_reads_or_mounts": 0,
        "native_positive_admission_tested": False, "old_94_test_campaign_repeated": False,
        "log_sha256": sha(log),
    }
    passed = result.wasSuccessful() and elapsed < 120 and len(log) < 2097152 - 65536
    name = "qualification.json" if passed else "qualification-failure.json"
    raw = (json.dumps(record, sort_keys=True, allow_nan=False) + "\n").encode()
    with (RUN_DIRECTORY / name).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(RUN_DIRECTORY, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    final_elapsed = time.monotonic() - STARTED
    evidence_bytes = sum(path.stat().st_size for path in RUN_DIRECTORY.iterdir() if path.is_file())
    if final_elapsed >= 120 or evidence_bytes > 2097152:
        print("FAIL: final durable evidence exceeded clock/byte limit", flush=True)
        return 2
    print(json.dumps({"evidence_directory": str(RUN_DIRECTORY), "passed": passed, "elapsed_s_after_fsync": final_elapsed, "evidence_bytes": evidence_bytes}, sort_keys=True), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
