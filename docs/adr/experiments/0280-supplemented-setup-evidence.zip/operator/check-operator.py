"""Artificial operator helpers only; never invokes main, mounts or live paths."""
import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import time

root=Path('/private/tmp/ariadna-f18-0280')
spec=importlib.util.spec_from_file_location('operator_checked',root/'prepare-actual.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
started=time.monotonic(); checks=[]
for name in ('prepare-actual.py','invoke-once.py'):
 ast.parse((root/name).read_bytes());checks.append(name+' AST')
with tempfile.TemporaryDirectory(prefix='ariadna-0280-artificial-',dir='/private/tmp') as temp:
 p=Path(temp)/'receipt.json';module.put(p,{'number':3,'status':'ARTIFICIAL'})
 assert json.loads(p.read_bytes())=={'number':3,'status':'ARTIFICIAL'};checks.append('durable JSON roundtrip')
 old=p.read_bytes()
 try:module.put(p,{'replacement':True})
 except FileExistsError:pass
 else:raise AssertionError('overwrite accepted')
 assert p.read_bytes()==old;checks.append('exclusive no overwrite')
 try:module.put(Path(temp)/'oversized',b'x'*65537,raw=True)
 except AssertionError:pass
 else:raise AssertionError('oversized receipt accepted')
 assert not (Path(temp)/'oversized').exists();checks.append('64KiB bound before write')
 try:module.encoded({'bad':float('nan')})
 except ValueError:pass
 else:raise AssertionError('nonfinite accepted')
 checks.append('nonfinite JSON refused')
 draft={'status':'PENDING_INDEPENDENT_REVIEW','pins':{'x':{'bytes':7,'sha256':'f'*64}}}
 intended=dict(draft,status='ADMITTED_ONCE')
 raw=module.encoded(intended)
 assert draft['status']=='PENDING_INDEPENDENT_REVIEW'
 assert module.digest(raw)==module.digest(module.encoded(dict(json.loads(module.encoded(draft)),status='ADMITTED_ONCE')))
 checks.append('unchanged profile intended-decision derivation')
result={'schema':'ariadna.f18.operator-artificial-check.v1','status':'PASS',
 'checks':checks,'count':len(checks),'elapsed_s':time.monotonic()-started,
 'native_or_actual_main_executed':False}
module.put(root/'operator-artificial-check.json',result)
print(json.dumps(result))
