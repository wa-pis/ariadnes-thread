"""Seal reviewed decision, invoke qualified gate once, retain return; always detach."""
from __future__ import annotations
from importlib.machinery import SourceFileLoader
import json
import os
from pathlib import Path
import signal
import subprocess
import time

operator = SourceFileLoader('_prepared_actual_operator', '/private/tmp/ariadna-f18-0280/prepare-actual.py').load_module()
P, MOUNT, OUTER, REPO = operator.P, operator.MOUNT, operator.OUTER, operator.REPO


def cleanup(process: subprocess.Popen[bytes] | None) -> dict[str, object]:
    groups: set[int] = set()
    if process is not None:
        # Snapshot descendants before killing the outer session; nested collectors use new sessions.
        raw = subprocess.check_output(['/bin/ps','-Ao','pid=,ppid=,pgid='], timeout=5)
        assert len(raw) <= 65536
        rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
        descendants = {process.pid}
        while True:
            expanded = descendants | {pid for pid, parent, group in rows if parent in descendants}
            if expanded == descendants:
                break
            descendants = expanded
        groups = {group for pid,parent,group in rows if pid in descendants}
        groups.add(process.pid)
    for name in ('parent.pgid','supervisor.pgid'):
        path = P / 'execution' / name
        if not path.exists():
            continue
        with path.open('rb') as stream:
            raw = stream.read(33)
        assert len(raw) <= 32 and raw.strip().isdigit(), 'invalid recorded PGID'
        groups.add(int(raw))
    for group in groups:
        assert group > 1 and group not in {os.getpid(), os.getpgrp()}
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
    if process is not None:
        process.wait(timeout=5)
    remaining = []
    for group in groups:
        try:
            os.killpg(group, 0)
        except ProcessLookupError:
            continue
        remaining.append(group)
    return {'status':'PASS' if not remaining else 'FAILED',
            'groups':sorted(groups),'remaining_groups':remaining}


def main() -> None:
    process = None
    profile = None
    try:
        started = json.loads((P / 'preflight-start.json').read_bytes())['started_s']
        profile_raw = (P / 'profile.json').read_bytes()
        profile = json.loads(profile_raw)
        review_raw = (P / 'independent-preflight-review.json').read_bytes()
        review = json.loads(review_raw)
        draft = json.loads((P / 'execution-decision-draft.json').read_bytes())
        assert draft['status'] == 'PENDING_INDEPENDENT_REVIEW'
        decision = dict(draft, status='ADMITTED_ONCE')
        decision_raw = operator.encoded(decision)
        assert review['status'] == 'PASS' and review['started_s'] == started
        assert review['base_revision'] == operator.BASE
        assert review['profile_sha256'] == operator.digest(profile_raw)
        assert review['execution_decision_sha256'] == operator.digest(decision_raw)
        assert profile['execution_decision'] == {'path':str(P / 'execution-decision.json'),
                                                 'sha256':operator.digest(decision_raw)}
        elapsed = time.monotonic() - started
        assert 0 <= review['elapsed_s'] <= elapsed < 600
        assert not os.path.lexists(P / 'execution-decision.json')
        operator.put(P / 'execution-decision.json', decision_raw, raw=True)
        assert 0 <= time.monotonic() - started < 600
        command = [str(OUTER),'-I','-B',str(P / 'dispatch-once.py'),
                   str(P / 'profile.json'),str(operator.CONTRACT),str(P / 'preflight-start.json')]
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True, cwd=REPO)
        operator.put(P / 'outer-dispatch.json', {'pid':process.pid,'pgid':process.pid,
            'started_s':started,'elapsed_s':time.monotonic()-started,
            'review_sha256':operator.digest(review_raw),'command':command,
            'failure_only_absolute_deadline_s':started+600+65})
        timed_out = False
        try:
            output, errors = process.communicate(timeout=max(0.001, started+600+65-time.monotonic()))
        except subprocess.TimeoutExpired:
            timed_out = True
            operator.put(P / 'outer-timeout-cleanup.json', cleanup(process))
            output, errors = process.communicate(timeout=5)
        assert len(output) + len(errors) <= 65536, 'combined outer log cap'
        operator.put(P / 'collector-actual-stdout.json', output, raw=True)
        operator.put(P / 'collector-actual-stderr.log', errors, raw=True)
        episode = P / 'episode-start.json'
        native_started = json.loads(episode.read_bytes())['started_s'] if episode.exists() else None
        try:
            actual = json.loads(output)
        except (ValueError, UnicodeDecodeError):
            actual = {}
        after_capture = time.monotonic() - native_started if native_started is not None else None
        candidate_ok = (process.returncode == 0 and not errors and not timed_out
            and actual.get('status') == 'passed' and actual.get('finalization') == 'checked-after-fsync'
            and after_capture is not None and 0 <= after_capture < 60)
        observation = {'schema':'ariadna.f18.supplemented-actual-tool-return.v1',
            'status':'PENDING_FINAL_DURABILITY_CHECK' if candidate_ok else 'failed',
            'returncode':process.returncode,'timed_out':timed_out,'raw_stdout_bytes':len(output),
            'raw_stderr_bytes':len(errors),'original_preflight_started_s':started,
            'observed_after_capture_fsync_s':after_capture,'collector_actual':actual}
        operator.put(P / 'collector-actual-return.json', observation)
        operator.put(P / 'collector-actual-observed.json', {'status':'PENDING_FINAL_DURABILITY_CHECK',
            'finalization':'pending-outer-readback',
            'return_sha256':operator.digest((P / 'collector-actual-return.json').read_bytes())})
        # Count all new episode records and controls, including logs; historical archives stay external.
        aggregate_bytes = sum(path.stat().st_size for path in P.rglob('*') if path.is_file())
        assert aggregate_bytes <= 2097152, 'aggregate new outer+inner evidence cap'
        final_elapsed = time.monotonic() - native_started if native_started is not None else None
        ok = candidate_ok and final_elapsed is not None and 0 <= final_elapsed < 60
        # This actual tool return, not the prefinal disk candidate, supplies terminal observation.
        print(json.dumps({'status':'passed' if ok else 'failed','returncode':process.returncode,
            'observed_after_observed_file_fsync_s':final_elapsed,
            'aggregate_episode_bytes_at_observation':aggregate_bytes,
            'finalization':'checked-after-fsync','within60s':final_elapsed is not None and 0 <= final_elapsed < 60}),flush=True)
    finally:
        try:
            operator.put(P / 'outer-group-cleanup.json', cleanup(process))
            if profile is not None:
                admission = operator.load_module('_actual_postcheck_admission', P / 'admission.py')
                checks = {}
                try:
                    for group in ('source_pins','native_pins','ledger_pins','control_pins'):
                        for name, pin in profile[group].items():
                            admission._pin(Path(name), pin, lambda: 0.0)
                        checks[group] = len(profile[group])
                    for row in json.loads((P / 'ro-readback.json').read_bytes())['resources']:
                        admission._pin(Path(profile['resources']) / row['name'], row, lambda: 0.0)
                    checks['resources'] = 11
                    observation = admission._live_observation(MOUNT, operator.IMAGE)
                    assert observation['read_only'] is True
                    operator.put(P / 'post-native-pins.json', {'status':'PASS','counts':checks,'mount':observation})
                except BaseException as exc:
                    operator.put(P / 'post-native-pins.json', {'status':'FAILED','counts':checks,
                        'error_type':type(exc).__name__,'message':str(exc)[:2048]})
        finally:
            if os.path.ismount(MOUNT):
                detached = subprocess.run(['/usr/bin/hdiutil','detach',str(MOUNT)],
                    capture_output=True, timeout=30, check=False)
                operator.put(P / 'detach.json', {'returncode':detached.returncode,
                    'unmounted':not os.path.ismount(MOUNT),
                    'stdout':detached.stdout[:4096].decode(errors='replace'),
                    'stderr':detached.stderr[:4096].decode(errors='replace')})
        result = subprocess.run([str(OUTER),'-I','-B',str(P / 'check-preservation.py'),'after'],
            cwd=REPO,capture_output=True,timeout=90,check=False)
        with (P / 'operational-after.json').open('rb') as stream:
            os.fsync(stream.fileno())
        operator.put(P / 'preservation-command.json', {'returncode':result.returncode,
            'stdout':result.stdout[:4096].decode(errors='replace'),
            'stderr':result.stderr[:4096].decode(errors='replace')})


if __name__ == '__main__':
    main()
