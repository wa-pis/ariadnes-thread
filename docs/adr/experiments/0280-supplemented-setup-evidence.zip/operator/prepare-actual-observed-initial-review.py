"""One operator sequence for ADR0277/0279; stops before independent review/dispatch."""
from __future__ import annotations
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

REPO = Path('/Users/agrudin/dev/my/ariadna')
EVIDENCE = REPO / 'docs/adr/experiments'
P = Path('/private/tmp/ariadna-f18-supplemented-setup-v1')
MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
IMAGE = MOUNT.parent / 'scratch.sparseimage'
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
BASE = 'fa726f953935e4cdad8e1ee74bcbf5b34fb6dbd4'
CONTRACT = EVIDENCE / '0277-supplemented-setup-contract.json'
CONTRACT_SHA = '6c2c80e441c9b08fc8de48b21bfed2c506e11d3a32b106277ead897bca3c7714'
ARCHIVES = {
 '0275-never-run-setup-evidence.zip':'fc7cb349728ae6304eb3619b291d84fda9da13d69e03e5a519caed9383b8db70',
 '0276-setup-resource-inventory-evidence.zip':'d317c2a69d1e5d176478a3f1731c22eae8614c8598296653081e7706fa24e009',
 '0278-artificial-provision-admission-evidence.zip':'76b2c10d5a35054fe0c16c8c2411132988e048f13c33ea75fcf6dff1e24387d8',
 '0279-once-only-execution-gate-evidence.zip':'3f73a181eebd3b98743d1c0011e44e2d3a4db8932777edf1399e3388b5b77f43',
}


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def put(path: Path, value: object, *, raw: bool = False) -> None:
    data = value if raw else encoded(value)
    assert isinstance(data, bytes) and len(data) <= 65536
    with path.open('xb') as stream:
        assert stream.write(data) == len(data)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def load_module(name: str, path: Path) -> object:
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> None:
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO, text=True).strip() == BASE
    assert subprocess.check_output(['git','branch','--show-current'], cwd=REPO, text=True).strip() == 'dev'
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=REPO).strip()
    assert not os.path.lexists(P) and not os.path.ismount(MOUNT)
    contents: dict[str, dict[str, bytes]] = {}
    for name, sha in ARCHIVES.items():
        raw = (EVIDENCE / name).read_bytes()
        assert digest(raw) == sha
        with zipfile.ZipFile(EVIDENCE / name) as archive:
            contents[name[:4]] = {n: archive.read(n) for n in archive.namelist()}
    contract_raw = CONTRACT.read_bytes()
    assert digest(contract_raw) == CONTRACT_SHA
    contract = json.loads(contract_raw)
    baseline = json.loads(contents['0276']['local-inventory.json'])
    reference = json.loads(contents['0275']['profile.json'])
    controls = {name: contents['0278']['prepared-controls/' + name] for name in (
        'call-once.py','launch-once.py','native-entry.py','supervisor-adapter.py',
        'run-once.py','native.sandbox','check-preservation.py')}
    controls.update({name: contents['0278'][name] for name in ('provision.py','admission.py')})
    for name, raw in controls.items():
        if name in {'provision.py','admission.py'}:
            continue
        old = contents['0275'][name]
        if name in {'run-once.py','native.sandbox','check-preservation.py'}:
            old = old.replace(b'/private/tmp/ariadna-f18-0275', str(P).encode())
        assert old == raw
    assert len(controls) == 9 and len(baseline['source_pins']) == 49
    assert len(baseline['native_pins']) == 10 and len(baseline['old_ledgers']) == 25
    gate_raw = contents['0279']['dispatch-once.py']
    assert digest(gate_raw) == 'c6900033e49502487bda9af79eb1f6b08a38ae6b70478ae0ec5689263c2a6f68'
    # Original actual clock starts before the first new episode write or mount.
    started = time.monotonic()
    P.mkdir()
    mounted = False

    def tick() -> float:
        elapsed = time.monotonic() - started
        assert 0 <= elapsed < 600, 'original600s preflight exhausted'
        return elapsed

    def command(argv: list[str], limit: float = 30) -> bytes:
        tick()
        result = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            timeout=min(limit, 600 - tick()), check=False)
        assert len(result.stdout) + len(result.stderr) <= 65536, 'operator command log cap'
        tick()
        if result.returncode:
            raise RuntimeError(f'{argv[0]} exit{result.returncode}: {result.stderr[:2048]!r}')
        return result.stdout

    def pin(path: Path, expected: dict[str, object] | None = None) -> dict[str, object]:
        tick()
        admission._directory(path.parent)
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            import stat
            info = os.fstat(fd)
            assert stat.S_ISREG(info.st_mode)
            sha = hashlib.sha256()
            size = 0
            while data := os.read(fd, 1024 * 1024):
                tick()
                sha.update(data)
                size += len(data)
            after = os.fstat(fd)
            assert info.st_size == size == after.st_size and info.st_mtime_ns == after.st_mtime_ns
            result = {'bytes':size,'sha256':sha.hexdigest()}
            assert expected is None or result == expected, f'pin drift:{path}'
            tick()
            return result
        finally:
            os.close(fd)

    def mount(read_only: bool) -> None:
        nonlocal mounted
        argv = ['/usr/bin/hdiutil','attach',str(IMAGE),'-nobrowse','-noautoopen','-mountpoint',str(MOUNT)]
        if read_only:
            argv.append('-readonly')
        command(argv)
        mounted = True
        observation = admission._live_observation(MOUNT, IMAGE)
        assert observation['read_only'] is read_only
        assert 0 < observation['capacity_bytes'] <= 8589934592
        tick()

    def detach() -> None:
        nonlocal mounted
        command(['/usr/bin/hdiutil','detach',str(MOUNT)])
        mounted = False
        assert not os.path.ismount(MOUNT)

    def resource_rows(rows: list[dict[str, object]]) -> None:
        assert set(str(f.relative_to(resources)) for f in resources.rglob('*') if f.is_file()) == {r['name'] for r in rows}
        for root, dirs, files in os.walk(resources, followlinks=False):
            assert all(not (Path(root) / n).is_symlink() for n in dirs + files)
        for row in rows:
            pin(resources / row['name'], {k:row[k] for k in ('bytes','sha256')})

    try:
        put(P / 'preflight-start.json', {'schema':'ariadna.f18.supplemented-preflight-start.v1',
            'started_s':started,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'base_revision':BASE,'authority':'ADR0277 + ADR0279; user continued-tests instruction',
            'retry_authorized':False})
        for name, raw in controls.items():
            put(P / name, raw, raw=True)
        put(P / 'dispatch-once.py', gate_raw, raw=True)
        admission = load_module('_supplemented_actual_admission', P / 'admission.py')
        provision = load_module('_supplemented_actual_provision', P / 'provision.py')
        command([str(OUTER),'-I','-B',str(P / 'check-preservation.py'),'before'], 90)
        with (P / 'operational-before.json').open('rb') as stream:
            os.fsync(stream.fileno())
        source_pins = {str(REPO / name):row for name,row in baseline['source_pins'].items()}
        native_pins = {row['path']:{k:row[k] for k in ('bytes','sha256')} for row in baseline['native_pins']}
        ledger_pins = {}
        for name, sha in baseline['old_ledgers'].items():
            row = pin(Path(name))
            assert row['sha256'] == sha
            ledger_pins[name] = row
        for name, row in source_pins.items():
            pin(Path(name), row)
        mount(True)
        resources = MOUNT / 'home/.tudat/resource'
        old_rows = [{'name':str(Path(r['path']).relative_to(resources)),
                     'bytes':r['bytes'],'sha256':r['sha256']} for r in baseline['existing_resources']]
        resource_rows(old_rows)
        assert not os.path.lexists(resources / 'earth_orientation')
        for name,row in native_pins.items():
            pin(Path(name), row)
        detach()
        mount(False)
        receipts = P / 'provision'
        receipts.mkdir()
        payloads = tuple(provision.Payload(row['name'],row['bytes'],row['sha256']) for row in contract['supplement'])
        outcome = provision.provision(Path('/Users/agrudin/.tudat/resource/earth_orientation'),
            resources, receipts, payloads, started_s=started)
        put(P / 'provision-outer-outcome.json', outcome)
        tick()
        rows = old_rows + [{'name':'earth_orientation/' + row['name'],
            'bytes':row['bytes'],'sha256':row['sha256']} for row in contract['supplement']]
        resource_rows(rows)
        detach()
        mount(True)
        resource_rows(rows)
        for name,row in native_pins.items():
            pin(Path(name), row)
        proof_paths = {'precharge':receipts / 'acquisition-precharge.json',
            'provision':receipts / 'provisioning-receipt.json',
            'outcome':P / 'provision-outer-outcome.json'}
        proofs = {name:{'path':str(path),'sha256':digest(path.read_bytes())} for name,path in proof_paths.items()}
        readback = {'schema':'ariadna.f18.supplemented-ro-readback.v1','mode':'native',
            'started_s':started,'elapsed_s':tick(),'read_only':True,'mount':str(MOUNT),
            'image':str(IMAGE),'resources':rows,
            **{name + '_sha256':proofs[name]['sha256'] for name in proofs}}
        put(P / 'ro-readback.json', readback)
        proofs['readback'] = {'path':str(P / 'ro-readback.json'),'sha256':digest((P / 'ro-readback.json').read_bytes())}
        groups = {'source_pins':source_pins,'native_pins':native_pins,'ledger_pins':ledger_pins,
                  'control_pins':{str(P / name):pin(P / name) for name in controls}}
        gate_pin = {'path':str(P / 'dispatch-once.py'),**pin(P / 'dispatch-once.py')}
        outer_pin = {'path':str(OUTER.resolve()),**pin(OUTER.resolve())}
        decision = {'schema':'ariadna.f18.supplemented-execution-decision.v1','stage':'F18.13',
            'mode':'native','status':'ADMITTED_ONCE','base_revision':BASE,'contract_sha256':CONTRACT_SHA,
            'expected_pins':groups,'outer_gate_pin':gate_pin,'outer_python_pin':outer_pin}
        put(P / 'execution-decision-draft.json', dict(decision,status='PENDING_INDEPENDENT_REVIEW'))
        profile = dict(reference, schema='ariadna.f18.supplemented-admission-profile.v1', mode='native',
            base_revision=BASE, work_directory=str(P / 'execution'), preflight_started_s=started,
            environment=contract['environment_unchanged'], **groups, contract_sha256=CONTRACT_SHA,
            execution_decision={'path':str(P / 'execution-decision.json'),'sha256':digest(encoded(decision))},
            mount=str(MOUNT),image=str(IMAGE),resources=str(resources),
            sandbox_profile=str(P / 'native.sandbox'),prelaunch_admission=str(P / 'launch-admission.json'),
            sandbox_sha256=groups['control_pins'][str(P / 'native.sandbox')]['sha256'],
            proofs=proofs,outer_gate=gate_pin,outer_python=outer_pin,
            authority='ADR0279 conditional one F18.13; actual independent review and direct gate still required')
        put(P / 'profile.json', profile)
        observation = admission._live_observation(MOUNT, IMAGE)
        put(P / 'operator-preflight.json', {'status':'READY_FOR_INDEPENDENT_REVIEW_NOT_ADMITTED',
            'started_s':started,'elapsed_s':tick(),'profile_sha256':digest(encoded(profile)),
            'observation':observation,'group_counts':{k:len(v) for k,v in groups.items()},
            'resources':len(rows),'resource_bytes':sum(r['bytes'] for r in rows)})
        tick()
        print(json.dumps({'status':'READY_FOR_INDEPENDENT_REVIEW_NOT_ADMITTED',
            'elapsed_s':tick(),'remaining_s':600-tick(),'namespace':str(P)}),flush=True)
    except BaseException as exc:
        if P.exists():
            put(P / 'operator-preflight-failure.json', {'status':'FAILED_NO_RETRY',
                'error_type':type(exc).__name__,'message':str(exc)[:2048],
                'started_s':started,'elapsed_s':time.monotonic()-started})
        if mounted or os.path.ismount(MOUNT):
            result = subprocess.run(['/usr/bin/hdiutil','detach',str(MOUNT)],
                capture_output=True,timeout=30,check=False)
            put(P / 'failed-preflight-detach.json', {'returncode':result.returncode,
                'unmounted':not os.path.ismount(MOUNT),'stdout':result.stdout[:4096].decode(errors='replace'),
                'stderr':result.stderr[:4096].decode(errors='replace')})
        raise


if __name__ == '__main__':
    main()
