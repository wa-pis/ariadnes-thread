"""Independent fixed F18.13 preflight readback; run only after actual READY."""
from __future__ import annotations

import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import time
from types import ModuleType
import zipfile

REPO = Path('/Users/agrudin/dev/my/ariadna')
ROOT = Path('/private/tmp/ariadna-f18-supplemented-setup-v1')
PREP = Path('/private/tmp/ariadna-f18-0280')
MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
BASE = 'fa726f953935e4cdad8e1ee74bcbf5b34fb6dbd4'
CONTRACT = REPO / 'docs/adr/experiments/0277-supplemented-setup-contract.json'
CONTRACT_SHA = '6c2c80e441c9b08fc8de48b21bfed2c506e11d3a32b106277ead897bca3c7714'
ADMISSION_SHA = '37e30013b68bc3cf141a339145b68c8f9e2b9e40ea5ba321db3652c23eebfa4f'
ARCHIVES = {
    '0275-never-run-setup-evidence.zip': 'fc7cb349728ae6304eb3619b291d84fda9da13d69e03e5a519caed9383b8db70',
    '0276-setup-resource-inventory-evidence.zip': 'd317c2a69d1e5d176478a3f1731c22eae8614c8598296653081e7706fa24e009',
    '0278-artificial-provision-admission-evidence.zip': '76b2c10d5a35054fe0c16c8c2411132988e048f13c33ea75fcf6dff1e24387d8',
    '0279-once-only-execution-gate-evidence.zip': '3f73a181eebd3b98743d1c0011e44e2d3a4db8932777edf1399e3388b5b77f43',
}
OPERATORS = {
    'prepare-actual.py': '824bf5ae296ca857daac1cdcd6b15004dea17957f9820d0c127ff74865776bd6',
    'invoke-once.py': 'd297f7d4d1069d852a0aa33266596c1090f11807e8a0f38ad403e0f9c8ef8613',
}


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def main() -> None:
    assert not os.path.lexists(ROOT / 'independent-preflight-review.json')
    raw = (ROOT / 'admission.py').read_bytes()
    assert len(raw) == 19584 and sha(raw) == ADMISSION_SHA
    helper = ModuleType('_independent_actual_readback_helpers')
    helper.__file__ = str(ROOT / 'admission.py')
    exec(compile(raw, helper.__file__, 'exec'), helper.__dict__)
    start_raw = helper._read(ROOT / 'preflight-start.json')
    start_record = helper._object(start_raw)
    started = start_record['started_s']
    assert type(started) in (int, float) and math.isfinite(started)
    assert start_record['base_revision'] == BASE and start_record['retry_authorized'] is False
    last = started

    def tick() -> float:
        nonlocal last
        current = time.monotonic()
        assert last <= current and 0 <= current - started < 600
        last = current
        return current - started

    def clean_git() -> None:
        for args, expected in ((['rev-parse', 'HEAD'], BASE), (['branch', '--show-current'], 'dev'),
                               (['status', '--porcelain'], '')):
            result = subprocess.check_output(['git', *args], cwd=REPO, text=True,
                                             timeout=min(10, 600 - tick())).strip()
            assert result == expected
        tick()

    tick()
    clean_git()
    packets = {}
    for name, digest in ARCHIVES.items():
        data = helper._read(REPO / 'docs/adr/experiments' / name, 2097152)
        assert sha(data) == digest
        packets[name[:4]] = zipfile.ZipFile(io.BytesIO(data))
        tick()
    baseline = helper._object(packets['0276'].read('local-inventory.json'))
    reference = helper._object(packets['0275'].read('profile.json'))
    contract_raw = helper._read(CONTRACT)
    assert sha(contract_raw) == CONTRACT_SHA
    contract = helper._object(contract_raw)
    profile_raw = helper._read(ROOT / 'profile.json')
    profile = helper._object(profile_raw)
    draft_raw = helper._read(ROOT / 'execution-decision-draft.json')
    draft = helper._object(draft_raw)
    assert draft['status'] == 'PENDING_INDEPENDENT_REVIEW'
    decision = dict(draft, status='ADMITTED_ONCE')  # Hash only; never write the live proof.
    decision_sha = sha(encoded(decision))
    assert profile['execution_decision'] == {'path': str(ROOT / 'execution-decision.json'),
                                              'sha256': decision_sha}
    assert profile['schema'] == 'ariadna.f18.supplemented-admission-profile.v1'
    assert profile['mode'] == draft['mode'] == 'native'
    assert draft['schema'] == 'ariadna.f18.supplemented-execution-decision.v1'
    assert draft['stage'] == 'F18.13' and profile['base_revision'] == draft['base_revision'] == BASE
    assert profile['contract_sha256'] == draft['contract_sha256'] == CONTRACT_SHA
    assert profile['preflight_started_s'] == started
    assert profile['repo'] == str(REPO) and profile['private_python'] == reference['private_python']
    assert profile['probe_input'] == reference['probe_input']
    assert encoded(profile['limits']) == encoded(reference['limits'])
    assert profile['kernel_sha256'] == reference['kernel_sha256']
    assert profile['environment'] == contract['environment_unchanged']
    assert profile['work_directory'] == str(ROOT / 'execution')
    assert profile['sandbox_profile'] == str(ROOT / 'native.sandbox')
    assert profile['prelaunch_admission'] == str(ROOT / 'launch-admission.json')
    for name in ('execution-decision.json', 'gate-start.json', 'admission-check.json',
                 'launch-admission.json', 'episode-start.json', 'execution'):
        assert not os.path.lexists(ROOT / name), name

    groups = draft['expected_pins']
    expected_source = {str(REPO / n): p for n, p in baseline['source_pins'].items()}
    expected_native = {p['path']: {k: p[k] for k in ('bytes', 'sha256')} for p in baseline['native_pins']}
    assert groups['source_pins'] == expected_source and len(expected_source) == 49
    assert groups['native_pins'] == expected_native and len(expected_native) == 10
    assert len(groups['ledger_pins']) == 25 and set(groups['ledger_pins']) == set(baseline['old_ledgers'])
    assert {n: p['sha256'] for n, p in groups['ledger_pins'].items()} == baseline['old_ledgers']
    names = ('call-once.py', 'launch-once.py', 'native-entry.py', 'supervisor-adapter.py',
             'run-once.py', 'native.sandbox', 'check-preservation.py', 'provision.py', 'admission.py')
    controls = {}
    for name in names:
        data = packets['0278'].read(('prepared-controls/' if name not in {'provision.py', 'admission.py'} else '') + name)
        if name not in {'provision.py', 'admission.py'}:
            original = packets['0275'].read(name)
            if name in {'run-once.py', 'native.sandbox', 'check-preservation.py'}:
                original = original.replace(b'/private/tmp/ariadna-f18-0275', str(ROOT).encode())
            assert data == original
        controls[str(ROOT / name)] = {'bytes': len(data), 'sha256': sha(data)}
    assert groups['control_pins'] == controls and len(controls) == 9
    assert set(groups) == {'source_pins', 'native_pins', 'ledger_pins', 'control_pins'}
    for group, pins in groups.items():
        assert profile[group] == pins
        for path, pin in pins.items():
            helper._pin(Path(path), pin, tick)
    for field, name in (('entry_sha256', 'native-entry.py'), ('adapter_sha256', 'supervisor-adapter.py'),
                        ('launch_sha256', 'launch-once.py'), ('caller_sha256', 'call-once.py'),
                        ('sandbox_sha256', 'native.sandbox')):
        assert profile[field] == controls[str(ROOT / name)]['sha256']
    gate_raw = packets['0279'].read('dispatch-once.py')
    gate_pin = {'path': str(ROOT / 'dispatch-once.py'), 'bytes': len(gate_raw), 'sha256': sha(gate_raw)}
    assert profile['outer_gate'] == draft['outer_gate_pin'] == gate_pin
    helper._pin(ROOT / 'dispatch-once.py', gate_pin, tick)
    outer = profile['outer_python']
    assert outer == draft['outer_python_pin'] and outer['path'] == str(OUTER.resolve())
    helper._pin(OUTER.resolve(), outer, tick)
    for name, digest in OPERATORS.items():
        assert sha(helper._read(PREP / name)) == digest

    resources = MOUNT / 'home/.tudat/resource'
    assert profile['mount'] == str(MOUNT) and profile['image'] == str(MOUNT.parent / 'scratch.sparseimage')
    assert profile['resources'] == str(resources)
    rows = [{'name': str(Path(p['path']).relative_to(resources)), 'bytes': p['bytes'], 'sha256': p['sha256']}
            for p in baseline['existing_resources']]
    rows += [{'name': 'earth_orientation/' + p['name'], 'bytes': p['bytes'], 'sha256': p['sha256']}
             for p in contract['supplement']]
    assert len(rows) == 11 and sum(r['bytes'] for r in rows) == 3710549
    actual = set()
    for directory, dirs, files in os.walk(resources, followlinks=False):
        assert all(not (Path(directory) / n).is_symlink() for n in dirs + files)
        actual.update(str((Path(directory) / n).relative_to(resources)) for n in files)
    assert actual == {r['name'] for r in rows}
    for row in rows:
        helper._pin(resources / row['name'], row, tick)
    proofs = {n: helper._proof(profile['proofs'][n]) for n in ('precharge', 'provision', 'outcome', 'readback')}
    charge, provision, outcome, readback = (proofs[n][0] for n in ('precharge', 'provision', 'outcome', 'readback'))
    payloads = [{k: p[k] for k in ('name', 'bytes', 'sha256')} for p in contract['supplement']]
    assert charge['schema'] == 'ariadna.f18.six-resource-precharge.v1' and charge['status'] == 'reserved_before_copy'
    assert charge['payloads'] == provision['payloads'] == payloads
    assert (charge['carried_bytes'], charge['additional_bytes'], charge['aggregate_bytes'], charge['ceiling_bytes']) == (497045495, 3578887, 500624382, 2147483648)
    assert provision['schema'] == 'ariadna.f18.six-resource-provision.v1'
    assert provision['status'] == 'completed-pending-outer-readback' and provision['completion_requires_outer_readback'] is True
    assert provision['resource_directory'] == str(resources) and provision['target_directory'] == str(resources / 'earth_orientation')
    assert provision['precharge_sha256'] == proofs['precharge'][1]
    assert outcome['status'] == 'passed' and outcome['finalization'] == 'checked-after-fsync'
    assert outcome['receipt_sha256'] == proofs['provision'][1]
    assert all(outcome.get(k) == v for k, v in provision.items() if k not in {'status', 'elapsed_s'})
    assert readback['schema'] == 'ariadna.f18.supplemented-ro-readback.v1' and readback['mode'] == 'native'
    assert readback['read_only'] is True and readback['mount'] == profile['mount'] and readback['image'] == profile['image']
    assert readback['resources'] == rows
    assert all(readback[n + '_sha256'] == proofs[n][1] for n in ('precharge', 'provision', 'outcome'))
    assert all(p['started_s'] == started for p in (charge, provision, outcome, readback))
    assert 0 <= provision['elapsed_s'] <= outcome['elapsed_s'] <= readback['elapsed_s'] <= tick()
    observation = helper._live_observation(MOUNT, Path(profile['image']))
    assert observation['read_only'] is True and 0 < observation['capacity_bytes'] <= 8589934592
    operational = helper._object(helper._read(ROOT / 'operational-before.json'))
    assert operational['status'] == 'passed' and operational['manifest_equal'] is True and operational['differences'] == []
    assert operational['baseline_file_sha256'] == '4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56'
    ready = helper._object(helper._read(ROOT / 'operator-preflight.json'))
    assert ready['status'] == 'READY_FOR_INDEPENDENT_REVIEW_NOT_ADMITTED' and ready['started_s'] == started
    assert ready['profile_sha256'] == sha(profile_raw) and ready['resources'] == 11 and ready['resource_bytes'] == 3710549
    clean_git()
    assert helper._read(ROOT / 'profile.json') == profile_raw and helper._read(ROOT / 'execution-decision-draft.json') == draft_raw
    assert helper._read(ROOT / 'preflight-start.json') == start_raw and helper._read(CONTRACT) == contract_raw
    aggregate = sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
    assert aggregate < 2097152 - 16384
    record = {'schema': 'ariadna.f18.independent-actual-preflight-review.v1', 'status': 'PASS',
              'started_s': started, 'elapsed_s': tick(), 'base_revision': BASE,
              'profile_sha256': sha(profile_raw), 'execution_decision_sha256': decision_sha,
              'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'groups': {n: len(v) for n, v in groups.items()}, 'resources': 11,
              'resource_bytes': 3710549, 'read_only_observation': observation,
              'aggregate_bytes_before_review': aggregate, 'native_calls': 0,
              'live_decision_written': False, 'profile_modified': False,
              'completion_requires_successful_reviewer_return': True,
              'scope': 'Independent actual readback only; no admit/gate/native/SPICE/integration. Prospective final decision hashed only.'}
    output = ROOT / 'independent-preflight-review.json'
    with output.open('xb') as stream:
        stream.write(encoded(record))
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    elapsed = tick()
    print(json.dumps({'status': 'PASS', 'started_s': started, 'elapsed_s_after_review_fsync': elapsed,
                      'remaining_s': 600 - elapsed, 'review_sha256': sha(output.read_bytes()),
                      'profile_sha256': sha(profile_raw), 'execution_decision_sha256': decision_sha}), flush=True)


if __name__ == '__main__':
    main()
