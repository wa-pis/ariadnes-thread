"""Artificial operator wiring only: no payload, mount or native execution."""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock
import uuid
import zipfile

STARTED = time.monotonic()
HERE = Path(__file__).resolve().parent


def load(name: str, filename: str) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


prepare = load("tested_prepare_operator", "prepare-actual.py")
invoke = load("tested_invoke_operator", "invoke-once.py")


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, sort_keys=True, allow_nan=False) + "\n")


class Clock:
    value = 201.0

    def __call__(self) -> float:
        return self.value


class FakeProcess:
    pid = 900101
    returncode = 0

    def __init__(self, root: Path, timeout: bool) -> None:
        self.timeout = timeout
        self.communications = 0
        self.waits = 0
        write_json(root / "episode-start.json", {"started_s": 200.0})

    def communicate(self, timeout: float) -> tuple[bytes, bytes]:
        self.communications += 1
        if self.timeout and self.communications == 1:
            raise subprocess.TimeoutExpired("ARTIFICIAL ONLY", timeout)
        return b'{"status":"passed","finalization":"checked-after-fsync"}\n', b""

    def wait(self, timeout: float) -> int:
        self.waits += 1
        return 0


class InvokeFixture:
    def __init__(self, root: Path, *, timeout: bool = False) -> None:
        self.root = root
        self.mount = root / "fabricated-mount"
        self.mount.mkdir()
        self.mounted = True
        self.clock = Clock()
        self.events: list[str] = []
        self.printed: list[dict[str, object]] = []
        self.commands: list[list[str]] = []
        self.process = FakeProcess(root, timeout)
        self.started = 100.0
        self.draft = {"status": "PENDING_INDEPENDENT_REVIEW", "base_revision": "ARTIFICIAL"}
        intended = dict(self.draft, status="ADMITTED_ONCE")
        decision_sha = prepare.digest(prepare.encoded(intended))
        profile = {"execution_decision": {"path": str(root / "execution-decision.json"), "sha256": decision_sha},
                   "resources": str(root / "fabricated-resources"),
                   **{group: {} for group in ("source_pins", "native_pins", "ledger_pins", "control_pins")}}
        write_json(root / "preflight-start.json", {"started_s": self.started})
        write_json(root / "profile.json", profile)
        write_json(root / "execution-decision-draft.json", self.draft)
        write_json(root / "independent-preflight-review.json", {
            "status": "PASS", "started_s": self.started, "base_revision": "ARTIFICIAL",
            "profile_sha256": prepare.digest((root / "profile.json").read_bytes()),
            "execution_decision_sha256": decision_sha, "elapsed_s": 1.0,
        })
        write_json(root / "ro-readback.json", {"resources": []})
        fake_admission = SimpleNamespace(_pin=lambda *args: None,
            _live_observation=lambda *args: {"read_only": True, "fixture": "ARTIFICIAL"})
        self.operator = SimpleNamespace(BASE="ARTIFICIAL", CONTRACT=root / "fabricated-contract.json",
            IMAGE=root / "fabricated-image-label", encoded=prepare.encoded, digest=prepare.digest,
            put=self.put, load_module=lambda *args: fake_admission)
        self.put_mode = "normal"

    def put(self, path: Path, value: object, *, raw: bool = False) -> None:
        self.events.append("begin:" + path.name)
        if path.name == "collector-actual-observed.json" and self.put_mode == "fsync-failure":
            with mock.patch.object(prepare.os, "fsync", side_effect=OSError("injected final fsync")):
                prepare.put(path, value, raw=raw)
        else:
            prepare.put(path, value, raw=raw)
        self.events.append("durable:" + path.name)
        if path.name == "collector-actual-observed.json" and self.put_mode == "late":
            self.clock.value = 260.0

    def run_command(self, command: list[str], **kwargs: object) -> object:
        self.commands.append(command)
        if command[:2] == ["/usr/bin/hdiutil", "detach"]:
            self.mounted = False
        else:
            write_json(self.root / "operational-after.json", {"fixture": "ARTIFICIAL"})
        return SimpleNamespace(returncode=0, stdout=b"ARTIFICIAL", stderr=b"")

    def printed_terminal(self, raw: str, **kwargs: object) -> None:
        self.events.append("terminal")
        self.printed.append(json.loads(raw))

    def patches(self, *, real_cleanup: bool = False) -> ExitStack:
        stack = ExitStack()
        for name, value in {"operator": self.operator, "P": self.root, "MOUNT": self.mount,
                            "OUTER": self.root / "fake-python-label", "REPO": self.root}.items():
            stack.enter_context(mock.patch.object(invoke, name, value))
        stack.enter_context(mock.patch.object(invoke.time, "monotonic", self.clock))
        stack.enter_context(mock.patch.object(invoke.os.path, "ismount", side_effect=lambda path: self.mounted))
        stack.enter_context(mock.patch.object(invoke.subprocess, "Popen", return_value=self.process))
        stack.enter_context(mock.patch.object(invoke.subprocess, "run", side_effect=self.run_command))
        stack.enter_context(mock.patch.object(invoke, "print", side_effect=self.printed_terminal, create=True))
        if not real_cleanup:
            stack.enter_context(mock.patch.object(invoke, "cleanup", return_value={"status": "PASS", "groups": [], "remaining_groups": []}))
        return stack


class WiringTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(dir=RUN_DIRECTORY)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()

    def test_timely_terminal_pass_only_after_final_durable_put(self) -> None:
        fixture = InvokeFixture(self.root)
        with fixture.patches():
            invoke.main()
        self.assertEqual(len(fixture.printed), 1)
        self.assertEqual(fixture.printed[0]["status"], "passed")
        self.assertIs(fixture.printed[0]["within60s"], True)
        self.assertLess(fixture.events.index("durable:collector-actual-observed.json"), fixture.events.index("terminal"))
        self.assertEqual(json.loads((self.root / "collector-actual-return.json").read_bytes())["status"], "PENDING_FINAL_DURABILITY_CHECK")
        self.assertEqual(json.loads((self.root / "collector-actual-observed.json").read_bytes())["finalization"], "pending-outer-readback")
        self.assertFalse(fixture.mounted)

    def test_final_put_advancing_clock_to_sixty_refuses_terminal_pass(self) -> None:
        fixture = InvokeFixture(self.root)
        fixture.put_mode = "late"
        with fixture.patches():
            invoke.main()
        self.assertIn("durable:collector-actual-observed.json", fixture.events)
        self.assertEqual(fixture.printed[0]["status"], "failed")
        self.assertIs(fixture.printed[0]["within60s"], False)
        self.assertEqual(fixture.printed[0]["observed_after_observed_file_fsync_s"], 60.0)
        self.assertFalse(fixture.mounted)

    def test_final_fsync_failure_produces_no_terminal_pass_and_detaches(self) -> None:
        fixture = InvokeFixture(self.root)
        fixture.put_mode = "fsync-failure"
        with fixture.patches(), self.assertRaisesRegex(OSError, "injected final fsync"):
            invoke.main()
        self.assertIn("begin:collector-actual-observed.json", fixture.events)
        self.assertNotIn("durable:collector-actual-observed.json", fixture.events)
        self.assertEqual(fixture.printed, [])
        self.assertFalse(fixture.mounted)

    def test_bad_review_still_cleans_up_and_detaches_without_launch(self) -> None:
        fixture = InvokeFixture(self.root)
        review = json.loads((self.root / "independent-preflight-review.json").read_bytes())
        review["status"] = "REJECT"
        write_json(self.root / "independent-preflight-review.json", review)
        with fixture.patches(), mock.patch.object(invoke.subprocess, "Popen", side_effect=AssertionError("must not launch")), self.assertRaises(AssertionError):
            invoke.main()
        self.assertIn("durable:outer-group-cleanup.json", fixture.events)
        self.assertFalse(fixture.mounted)
        self.assertEqual(fixture.process.communications, 0)
        self.assertEqual(fixture.printed, [])
        self.assertFalse((self.root / "execution-decision.json").exists())

    def test_timeout_kills_transitive_descendant_sessions_and_recorded_groups(self) -> None:
        fixture = InvokeFixture(self.root, timeout=True)
        execution = self.root / "execution"
        execution.mkdir()
        (execution / "parent.pgid").write_text("900201\n")
        (execution / "supervisor.pgid").write_text("900301\n")
        expected = {900101, 900102, 900103, 900201, 900301}
        alive = set(expected)
        killed: list[int] = []
        def kill(group: int, sig: int) -> None:
            if group not in alive:
                raise ProcessLookupError()
            if sig == signal.SIGKILL:
                killed.append(group)
                alive.remove(group)
            else:
                self.assertEqual(sig, 0)
        rows = b"900101 1 900101\n900102 900101 900102\n900103 900102 900103\n990001 1 990001\n"
        with fixture.patches(real_cleanup=True), mock.patch.object(invoke.subprocess, "check_output", return_value=rows), mock.patch.object(invoke.os, "killpg", side_effect=kill), mock.patch.object(invoke.os, "getpid", return_value=999900), mock.patch.object(invoke.os, "getpgrp", return_value=999901):
            invoke.main()
        self.assertEqual(set(killed), expected)
        self.assertEqual(alive, set())
        self.assertNotIn(990001, killed)
        self.assertGreaterEqual(fixture.process.waits, 1)
        self.assertEqual(fixture.process.communications, 2)
        self.assertEqual(fixture.printed[0]["status"], "failed")
        self.assertTrue(json.loads((self.root / "collector-actual-return.json").read_bytes())["timed_out"])
        self.assertFalse(fixture.mounted)

    def test_aggregate_overflow_refuses_before_terminal_print_and_detaches(self) -> None:
        fixture = InvokeFixture(self.root)
        (self.root / "fabricated-overflow.bin").write_bytes(b"X" * 2097152)
        with fixture.patches(), self.assertRaisesRegex(AssertionError, "aggregate new outer\\+inner evidence cap"):
            invoke.main()
        self.assertEqual(fixture.printed, [])
        self.assertFalse(fixture.mounted)

    def test_prepare_failure_receipt_error_cannot_suppress_detach(self) -> None:
        evidence = self.root / "fake-evidence"
        evidence.mkdir()
        episode = self.root / "fake-episode"
        mount = self.root / "fake-mount"
        fake_gate = b"ARTIFICIAL GATE; NEVER EXECUTE"
        names = ("call-once.py", "launch-once.py", "native-entry.py", "supervisor-adapter.py", "run-once.py", "native.sandbox", "check-preservation.py")
        controls = {name: ("ARTIFICIAL " + name).encode() for name in names}
        baseline = {"source_pins": {f"fake-source-{i}": {} for i in range(49)},
                    "native_pins": [{} for _ in range(10)], "old_ledgers": {f"fake-ledger-{i}": "x" for i in range(25)}}
        archives = {
            "0275-fake.zip": {"profile.json": b"{}", **controls},
            "0276-fake.zip": {"local-inventory.json": json.dumps(baseline).encode()},
            "0278-fake.zip": {**{"prepared-controls/" + key: value for key, value in controls.items()}, "provision.py": b"ARTIFICIAL", "admission.py": b"ARTIFICIAL"},
            "0279-fake.zip": {"dispatch-once.py": fake_gate},
        }
        archive_pins: dict[str, str] = {}
        for name, members in archives.items():
            path = evidence / name
            with zipfile.ZipFile(path, "w") as archive:
                for member, raw in members.items():
                    archive.writestr(member, raw)
            archive_pins[name] = prepare.digest(path.read_bytes())
        contract = evidence / "fake-contract.json"
        contract.write_bytes(b"{}")
        original_digest = prepare.digest
        def digest(raw: bytes) -> str:
            return "c6900033e49502487bda9af79eb1f6b08a38ae6b70478ae0ec5689263c2a6f68" if raw == fake_gate else original_digest(raw)
        def git(command: list[str], **kwargs: object) -> object:
            if command[1:3] == ["rev-parse", "HEAD"]:
                return "ARTIFICIAL\n"
            if command[1:3] == ["branch", "--show-current"]:
                return "dev\n"
            return b""
        completed = SimpleNamespace(returncode=0, stdout=b"ARTIFICIAL DETACH", stderr=b"")
        with ExitStack() as stack:
            for name, value in {"REPO": self.root, "EVIDENCE": evidence, "P": episode, "MOUNT": mount, "BASE": "ARTIFICIAL", "CONTRACT": contract, "CONTRACT_SHA": original_digest(b"{}"), "ARCHIVES": archive_pins}.items():
                stack.enter_context(mock.patch.object(prepare, name, value))
            stack.enter_context(mock.patch.object(prepare, "digest", side_effect=digest))
            put = stack.enter_context(mock.patch.object(prepare, "put", side_effect=OSError("injected receipt write failure")))
            command = stack.enter_context(mock.patch.object(prepare.subprocess, "run", return_value=completed))
            stack.enter_context(mock.patch.object(prepare.subprocess, "check_output", side_effect=git))
            stack.enter_context(mock.patch.object(prepare.os.path, "ismount", side_effect=[False, True, False]))
            loader = stack.enter_context(mock.patch.object(prepare, "load_module", side_effect=AssertionError("must not load native/helper payload")))
            with self.assertRaisesRegex(OSError, "injected receipt write failure"):
                prepare.main()
        self.assertEqual([call.args[0] for call in command.call_args_list], [["/usr/bin/hdiutil", "detach", str(mount)]])
        self.assertIn("operator-preflight-failure.json", [call.args[0].name for call in put.call_args_list])
        self.assertIn("failed-preflight-detach.json", [call.args[0].name for call in put.call_args_list])
        loader.assert_not_called()


RUN_DIRECTORY: Path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root")
    arguments = parser.parse_args()
    global RUN_DIRECTORY
    RUN_DIRECTORY = Path(arguments.root).resolve(strict=True) / ("artificial-" + uuid.uuid4().hex)
    RUN_DIRECTORY.mkdir(mode=0o700)
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    log = output.getvalue().encode()
    prepare.put(RUN_DIRECTORY / "unittest.log", log, raw=True)
    print(log.decode(), end="")
    record = {"schema": "ariadna.f18.operator-wiring-artificial-qualification.v1", "qualification": "ARTIFICIAL_ONLY",
              "native_admission": "NATIVE_NOT_ADMITTED", "test_count": result.testsRun,
              "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
              "elapsed_s_before_receipt": time.monotonic() - STARTED, "limit_s": 120, "evidence_limit_bytes": 2097152,
              "actual_resource_mount_native_actions": 0,
              "sources": {name: {"bytes": (HERE / name).stat().st_size, "sha256": prepare.digest((HERE / name).read_bytes())} for name in ("prepare-actual.py", "invoke-once.py", "test-operator-wiring.py")}}
    name = "qualification.json" if result.wasSuccessful() else "qualification-failure.json"
    prepare.put(RUN_DIRECTORY / name, record)
    elapsed = time.monotonic() - STARTED
    total = sum(path.stat().st_size for path in RUN_DIRECTORY.iterdir() if path.is_file())
    passed = result.wasSuccessful() and elapsed < 120 and total <= 2097152
    print(json.dumps({"passed": passed, "elapsed_after_receipt_fsync_s": elapsed, "evidence_bytes": total, "evidence_directory": str(RUN_DIRECTORY)}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
