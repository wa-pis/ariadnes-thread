from pathlib import Path
import ast,datetime,hashlib,json,os,time,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0281');e=r/'docs/adr/experiments';start=json.loads((p/'design-start.json').read_text())['started_s']
assert 0<=time.monotonic()-start<600
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(e/'0280-supplemented-setup-evidence.zip') as z:
 profile=json.loads(z.read('profile.json'));old_resources=json.loads(z.read('ro-readback.json'))['resources']
 old_counts=json.loads(z.read('execution/native-packet/packet/producer.json'))['counts']
old=json.loads((e/'0280-supplemented-setup-result.json').read_text())
assert old['native_setup_invocations']==1 and old_counts['integration_attempts']==0
source_groups={k:profile[k] for k in ('source_pins','native_pins','ledger_pins','control_pins')}
for name,pin in source_groups['source_pins'].items():
 raw=Path(name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
anchors=[]
for name,first,last,meaning in [
 ('src/space_nav/_owner_endpoint_fixture.py',42,97,'Original Budget maxima and precharge; narrow1/1/1 plus metadata must be independently enforced.'),
 ('src/space_nav/_owner_endpoint_fixture.py',99,173,'Original integrator/context/factory and forwardTrue integration; no settings or numerical changes.'),
 ('src/space_nav/_owner_endpoint_fixture.py',176,236,'Original metadata row meaning/completion and primitive endpoint decoder.'),
 ('src/space_nav/_owner_endpoint_fixture.py',310,345,'Full produce sequence would run extra never-run/visitors/lifetime/reverse; do not call it.'),
 ('src/space_nav/_owner_endpoint_audit.py',114,154,'Independent strict metadata and tighter coast literals.'),
 ('src/space_nav/_owner_endpoint_audit.py',238,279,'Epoch guard and exact-rational terminal norm/mass gates; no formula evaluated here.'),
 ('src/space_nav/_owner_setup_probe.py',29,71,'Never-run input/scope hardcodes; no retagging as completed evidence.'),
 ('src/space_nav/_owner_setup_probe.py',87,108,'Original setup counters hardcode integration0/functionlistempty; not a completed controller.'),
 ('src/space_nav/trajectory.py',1608,1641,'Original tighter RKDP87 coast profile literals.')]:
 raw=(r/name).read_bytes();lines=raw.decode().splitlines();excerpt='\n'.join(lines[first-1:last])+'\n'
 anchors.append({'path':name,'first_line':first,'last_line':last,'source_sha256':sha(raw),
  'excerpt':excerpt,'excerpt_sha256':sha(excerpt.encode()),'meaning':meaning})
node=ast.parse((r/'src/space_nav/_owner_endpoint_fixture.py').read_bytes())
initial=next(ast.literal_eval(n.value) for n in node.body if isinstance(n,ast.Assign) and any(isinstance(a,ast.Name) and a.id=='_INITIAL' for a in n.targets))
contract={
 'schema':'ariadna.f18.single-forward-completed-owner-design.v1','stage':'F18.14',
 'status':'DRAFT_FOR_INDEPENDENT_SOURCE_REVIEW_NOT_EXECUTION',
 'client_date':'2026-11-27','base_revision':json.loads((p/'design-start.json').read_text())['base_revision'],
 'question':'Can one newly constructed original forward simulator finish the fixed synthetic arc, prove its original completion/row metadata, and return its original chronological-last endpoint once?',
 'claim':'Single forward completed-owner readback conformance only. No full0267serial lifecycle/Time/carry/physical qualification.',
 'authority':{'F18.14':'Current source/saved design only within600s/2MiB including independent review.',
  'F18.15':'Ordinary reversible implementation/artificial qualification under standing continued-tests authority, after accepted design; no new native diagnostic execution.',
  'F18.16':'Not admitted by design/preparation. Distinct recorded execution choice plus clean committed base, qualified controls and fresh independent actual600s preflight required.'},
 'frozen_fixture':{'frame':'SYNTHETIC_INERTIAL','native_named_origin':'SSB','native_named_orientation':'J2000',
  'time_scale':'elapsed_seconds, not physical TDB ephemerides','arc_id':'forward','simulate':True,
  'start_s':0,'stop_s':1000,'initial_state_si_literal':list(initial),'initial_state_binary64_words':[x.hex() for x in initial],
  'uniform_acceleration_m_s2_literal':[0.0,0.1,0.0],'acceleration_semantics':'exact rational value of the existing binary64 float(0.1), not exact decimal1/10',
  'mass_rate_kg_s':0.0,'initial_mass_kg':2000.0,'body':'Spacecraft only',
  'coast_integrator':{'coefficient_set':'rkdp_87','relative_tolerance':1e-13,
   'absolute_tolerances_si':[1e-5,1e-5,1e-5,1e-8,1e-8,1e-8,1e-11],
   'initial_step_s':75.0,'minimum_step_s':1e-5,'maximum_step_s':21600.0,
   'assess_termination_on_minor_steps':False,'minimum_step_handling':'throw_exception_below_minimum',
   'accept_infinity_step':False,'accept_nan_step':False},
  'termination':'original time_termination1000, terminate_exactly_on_final_condition=True',
  'processing':{'clear_numerical_solution':False,'set_integrated_result':False},
  'factory':'Unchanged _owner_endpoint_fixture._native_factory(forward,True,budget)',
  'metadata':'Unchanged _owner_endpoint_fixture._metadata(owner) exactly once before visitor',
  'visitor':{'owner':'same live simulator','method':'_ariadna_original_endpoint','selector':True,
   'schema':'cartesian-position-m_velocity-m-s_mass-kg'},
  'excluded':'No produce(),never-run/reverse owner, extra visitor/wrong-schema test, initial endpoint read, GC/delete/clear/lifetime sequence, Python state-history export, realbody/ephemeris/engine/radiation/gravity model.'},
 'counts':{'context_checks':1,'factory_attempts':1,'integration_attempts':1,'metadata_attempts':1,
  'metadata_completed_on_success':1,'visitor_calls':1,'uniform_acceleration_callbacks_max':100000,
  'callback_count_rule':'record actual integer0..100000; not a total-native-RHS bound',
  'native_reported_function_evaluations':'one separately observed nonnegative integer from original metadata, no assumed equality with callback count',
  'zero':['spice_queries','SPICE kernel-data loads','real_archive_reads','optimizer_entries'],
  'precharge':'Enforce narrower1/1/1 plus metadata1 at each callsite before native entry. Budget maxima3/2/8 remain unchanged but do not admit extra work.',
  'partial_failure':'Precharged attempts are not completed integration/getters/visitors. Without final validsnapshot actual internal counts remain UNKNOWN; preserve traceprefix and first failure, no retry.'},
 'markers':['bootstrap-ready','import-ready','context-ready','factory-enter','factory-return',
  'metadata-enter','metadata-ready','visitor-enter','visitor-return','complete'],
 'independent_audit':{'runtime':'stdlib only; block newproducer/fixture/trajectory/TudatPy/numpy/scientific runtime imports',
  'input_schema':'ariadna-owner-completed-input-v1','scope':'single-forward-completed-owner-only',
  'input_keys':['schema','scope','mode','kernel_path','kernel_sha256','probe_sha256','owner_fixture_sha256','owner_auditor_sha256','trajectory_sha256','completed_auditor_sha256'],
  'native_injection':'Native mode forbids replacement hooks, cold-import identity/source/provenance/kernel/context/guard checks are required. Artificial hooks explicitlylabel injected and never nativePASS.',
  'metadata':'Require strict original metadata keys,7vector/performed/completed_successfully/exacttime termination, processed and propagated IDs(0,6),(6,1) and exact Spacecraft/SSB descriptions. performed alone is insufficient.',
  'endpoint':'Require primitive(int,float,tuple7finitefloat), exact schema and selected chronological epoch hour0/remainder1000.0; do not accept original decoder broader0or1000 domain as True-selector proof.',
  'reference':'Independent fixed literal binary64 initialrow and acceleration; Fraction conversion then r0+v0*dt+a*dt^2/2, v0+a*dt, m0, dt1000. No producer-supplied reference or fabricated missing rows/fullpacket.',
  'position_norm_max_m':0.001,'velocity_norm_max_m_s':1e-6,'mass_abs_error_max_kg':1e-9,
  'comparison':'Exact rational squared Euclidean norms and absolute mass gate; no tolerance relaxation.',
  'completion':'All10ordered newline/fsynced markers, finite monotone originalclock, strict arguments/counts/metadata/words/provenance/hashbindings, childexit0, independentauditPASS and observed post-fsync original60s outer continuation. Complete line or persisted pendingPASS alone is insufficient.'},
 'limits':{'current_source_review_s':600,'current_evidence_bytes':2097152,
  'artificial_focused_s':300,'required_frozen_regression_s':1800,
  'future_actual_preflight_s':600,'future_native_total_s':60,'producer_s':45,'audit_s':10,'finalization_s':5,
  'failure_only_outer_failsafe_s':65,'input_bytes':65536,'combined_logs_bytes':65536,
  'structured_outer_inner_bytes':2097152,'trace_bytes':4096,'marker_bytes':512,
  'scratch_bytes':8589934592,'acquisition_ceiling_bytes':2147483648,
  'carried_acquisition_bytes':500624382,'new_acquisition_bytes':0},
 'clock_rationale':'Retain0267/0277engineering ceilings, not measured completed-arc performance. 0280setup3.3675s does not predict integration duration. Source-design600s is separate from future actualpreflight600s and coldimport60s; no clock reset/extension. Enforce stop/partialaccounting if prerequisites or timely completion fail.',
 'reuse':{'unchanged_science':['Budget','_native_context','_native_factory','_metadata','_endpoint','_provenance','trajectory coast/translation+mass helpers'],
  'new_private_modules':['src/space_nav/_owner_completed_probe.py','src/space_nav/_owner_completed_audit.py'],
  'new_tests':'Artificial native-vs-injected/arguments/precharge/metadata/epoch/word/oracle/marker/counter/clock/fsync/byte/groupcleanup/outerwiring boundaries; no real completed-owner diagnostic.',
  'existing_helpers':'Reuse _import_probe guards and _owner_endpoint_run evidence/JSON/watchdog primitives directly; reuse old independent audit metadata/word validators as source-pinned stdlib helpers if helpful.',
  'no_shortcut':'Oldsetup_probe/_counts/schema/0278admit/0279fixeddecision cannot be retagged as completed1integration. Preserve old files. Target/schema/count/pin changes in any outercontrol require explicit newsourcepins, targeted artificial qualification and independent review; do not claim namespace-only or inherited nativepositive.',
  'admission':'Specify fresh narrow completed profile/admission/once-only continuation during preparation; reuse qualified mechanism, no generic orchestration framework. Concretechangedcontrolmatrix and sourcepins before futuredecision.'},
 'future_actual':{'namespace':'/private/tmp/ariadna-f18-forward-completed-v1','image':profile['image'],'mount':profile['mount'],
  'private_python':profile['private_python'],'kernel_sha256':profile['kernel_sha256'],
  'environment_unchanged':profile['environment'],'resource_count':11,'resources':old_resources,
  'resource_policy':'Verify retained11file identity after ROmount; do not provision/charge/copy another resource. Missingdrift or extra resource refuses launch.',
  'protected_groups':'Preserve old49source/10native/25oldledger, allold controls and0280episode/proofs/records; append newlyqualified sources/controlpins explicitly. No old49/9set or0278nativepositive falsely reused for a newscope.',
  'readiness':'Clean committeddev; no competing work, fresh exclusive namespace/consume marker, read-only image actualidentity/capacity, exactsource/kernel/env/resource/preservedledgerpins, independently reviewed new controls and distinct actualdecision within original600s before consumption. No current launch or mount.'},
 'historical_caveat':'0280qualifies only never-run setup/refusal.0269has unknowncounts/no trace; no cause is inferred and neither consumed packet is replayed.',
 'remaining_gates':['full0267eight-call/two-arc/lifetime fixture','F17/F17.1/F18.3','carry/concurrency','full-core ABI-FP','prior arithmetic','full-force seed/derivatives/guards/endpoint bounds','physicalF0/M3','admissiblecommandpair','99percentprobability/safety'],
 'source_anchors':anchors,
 'source_pins':source_groups['source_pins'],
 'reference_pins':{str(f.relative_to(r)):{'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in [e/'0267-owner-readback-design-evidence.zip',e/'0269-owner-timeout-result.json',e/'0280-supplemented-setup-result.json',e/'0280-supplemented-setup-evidence.zip',e/'0280-doc-verification.json']},
 'design_elapsed_s_before_draft':time.monotonic()-start,
 'scientific_formula_evaluated':False,'runtime_or_tests_executed':False}
assert time.monotonic()-start<600
with (p/'completed-owner-design-draft.json').open('x') as f:json.dump(contract,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'draft_bytes':(p/'completed-owner-design-draft.json').stat().st_size,'elapsed_s':time.monotonic()-start,'initial_literal_words_exported_only':True}))
