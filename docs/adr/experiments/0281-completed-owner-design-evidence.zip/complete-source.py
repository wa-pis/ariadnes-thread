import hashlib,json,os,pathlib,time
p=pathlib.Path('/private/tmp/ariadna-f18-0281')
a=json.loads((p/'design-start.json').read_text());d=json.loads((p/'completed-owner-design-draft.json').read_text());r=json.loads((p/'independent-design-review.json').read_text())
assert r['status']=='PASS' and not r['findings']
assert r['reviewed_contract']['sha256']==hashlib.sha256((p/'completed-owner-design-draft.json').read_bytes()).hexdigest()
assert time.monotonic()-a['started_s']<600
obj={'schema':'ariadna.f18.completed-owner-design-completion.v1','status':'SOURCE_DESIGN_ACCEPTED_NOT_EXECUTION','stage':'F18.14','base_revision':a['base_revision'],'original_started_s':a['started_s'],'review_sha256':hashlib.sha256((p/'independent-design-review.json').read_bytes()).hexdigest(),'contract_sha256':r['reviewed_contract']['sha256'],'elapsed_before_receipt_s':time.monotonic()-a['started_s'],'budget_s':600,'evidence_limit_bytes':2097152,'evidence_bytes_before_receipt':sum(x.stat().st_size for x in p.iterdir() if x.is_file()),'runtime_or_tests_executed':False,'scientific_formula_evaluated':False,'documentary_packaging':'separate source-only documentation/check phase after this accepted contract'}
with (p/'source-completion.json').open('x') as f:json.dump(obj,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
observed=time.monotonic()-a['started_s'];assert observed<600
with (p/'source-completion-observed.json').open('x') as f:json.dump({'schema':'ariadna.f18.source-completion-observation.v1','observed_post_receipt_and_directory_fsync_s':observed,'budget_s':600,'status':'PASS'},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'PASS','source_phase_postfsync_s':observed,'source_phase_bytes':sum(x.stat().st_size for x in p.iterdir() if x.is_file())}))
