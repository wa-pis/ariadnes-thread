from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0282');py='/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python'
sources=['src/space_nav/_owner_completed_probe.py','src/space_nav/_owner_completed_audit.py','tests/test_owner_completed_probe.py','tests/test_owner_completed_audit.py']
pins={n:{'bytes':(r/n).stat().st_size,'sha256':hashlib.sha256((r/n).read_bytes()).hexdigest()} for n in sources}
profile={'schema':'ariadna.f18.completed-owner-artificial-qualification-profile.v1','stage':'F18.15','base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'scope':'New completed producer/audit artificial qualification only; no actual completed-owner diagnostic, mount, real data replay, new native/SPICE/integration episode. Existing required live regressions permitted. Changed outer admission remains future separate preparation.','sources':pins,'focused_ceiling_s':300,'regression_ceiling_s':1800,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_episode_authorized':False}
with (p/'profile.json').open('x') as f:json.dump(profile,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
started=time.monotonic()
with (p/'focused.log').open('x') as log:
 cmd=[py,'-B','-m','pytest','-q','--offline',sources[2],sources[3],'--junitxml='+str(p/'focused.xml')]
 proc=subprocess.Popen(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 try:rc=proc.wait(timeout=300)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait();rc=124
 elapsed=time.monotonic()-started
 log.flush();os.fsync(log.fileno())
result={'schema':'ariadna.f18.completed-focused-exit.v1','exit_code':rc,'elapsed_s':elapsed,'budget_s':300,'command':cmd,'source_pins':pins}
with (p/'focused-exit.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'exit_code':rc,'elapsed_s':elapsed,'budget_s':300}),flush=True)
raise SystemExit(rc)
