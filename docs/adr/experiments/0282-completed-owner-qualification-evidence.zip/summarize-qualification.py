from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
p=Path('/private/tmp/ariadna-f18-0282');r=Path('/Users/agrudin/dev/my/ariadna');old=Path('/private/tmp/ariadna-f18-0274')
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
classes={'tests.test_owner_completed_probe','tests.test_owner_completed_audit'}
def junit(path):
 rows=ET.parse(path).findall('.//testcase');ids={x.get('classname','')+'::'+x.get('name','') for x in rows};assert len(rows)==len(ids)
 failed=[x.attrib for x in rows if x.find('failure') is not None or x.find('error') is not None]
 skipped={x.get('classname','')+'::'+x.get('name',''):x.find('skipped').get('message') for x in rows if x.find('skipped') is not None}
 new={x.get('classname','')+'::'+x.get('name','') for x in rows if x.get('classname','') in classes}
 return {'cases':len(rows),'passed':len(rows)-len(failed)-len(skipped),'failed':failed,'skipped':skipped,'new_cases':len(new),'sha256':sha(path),'bytes':path.stat().st_size},ids,new
profile=json.loads((p/'profile.json').read_text());review=json.loads((p/'independent-code-review.json').read_text());exit=json.loads((p/'regression-exit.json').read_text());freeze=json.loads((p/'frozen-after.json').read_text());focus=json.loads((p/'focused-exit.json').read_text());baseline=json.loads((p/'baseline-identity.json').read_text())
assert baseline['status']=='PASS' and baseline['package_test_environment_make_changes_since_baseline']==[]
old_qualification=json.loads((r/'docs/adr/experiments/0274-owner-setup-qualification.json').read_text())
for name,lane in (('portable.xml','portable'),('live.xml','live')):
 pin=baseline['junit_pins'][name]
 assert pin['bytes']==(old/name).stat().st_size and pin['sha256']==sha(old/name)==old_qualification[lane]['sha256']
assert review['reviewed_files']==profile['sources'] and review['findings']==[]
assert review['status']=='PASS' and exit['exit_code']==0 and exit['elapsed_s']<1800 and freeze['status']=='passed' and focus['exit_code']==0 and focus['elapsed_s']<300
f,fi,fn=junit(p/'focused.xml');a,ai,an=junit(p/'portable.xml');b,bi,bn=junit(p/'live.xml');oa,oai,_=junit(old/'portable.xml');ob,obi,_=junit(old/'live.xml')
assert not f['failed'] and not a['failed'] and not b['failed'] and f['passed']==212 and not f['skipped']
assert fi==fn==an and not bn and not ai&bi and ai==oai|fi and bi==obi
assert a['skipped']==oa['skipped'] and b['skipped']==ob['skipped'] and len(a['skipped'])==42
assert a['passed']==oa['passed']+212==8275 and b['passed']==ob['passed']==413
for name,pin in profile['sources'].items():assert {'bytes':(r/name).stat().st_size,'sha256':sha(r/name)}==pin,name
assert (p/'ruff.log').read_text().strip()=='All checks passed!'
protected=0
for row in subprocess.check_output(['git','ls-tree','-rz','HEAD'],cwd=r).split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t',1);raw=(r/name.decode()).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==meta.split()[2].decode(),name
 protected+=1
result={'schema':'ariadna.f18.completed-owner-artificial-qualification.v1','stage':'F18.15','status':'PASS_ARTIFICIAL_PREPARATION_ONLY','base_revision':profile['base_revision'],'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':profile['sources'],'focused':f,'focused_seconds':focus['elapsed_s'],'portable':a,'live':b,'combined_passed':a['passed']+b['passed'],'new_cases':212,'focused_not_double_counted':True,'lanes_disjoint':True,'prior_case_ids_and_skips_unchanged':True,'baseline_identity_sha256':sha(p/'baseline-identity.json'),'full_regression':exit,'checkout_frozen':freeze,'protected_base_blobs_unchanged_before_documentary_phase':protected,'independent_code_review':{'status':'PASS','sha256':sha(p/'independent-code-review.json')},'ruff':'PASS; --no-cache to avoid initial sandbox cache-write refusal; no code change','scope':'Original fixture/science/oldtests/dependencies unchanged; two minimal private modules+two artificialtest files only. New diagnostic native/SPICE/integration episode count0. Existing required live regressions retain their native/SPICE/integration scope.','unqualified':'Changed outer profile/control/admission and native completed-owner positive remain unqualified; full0267 owner/lifetime/carry/concurrency/full-coreABI-FP/priorarithmetic/full-force/physicalF0/M3/99percent/safety unchanged.','future_execution_authorized':False}
with (p/'qualification.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({k:result[k] for k in ('status','new_cases','combined_passed','protected_base_blobs_unchanged_before_documentary_phase')}))
