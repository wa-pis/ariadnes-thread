from pathlib import Path
import json,zipfile,hashlib,os
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0283');e=r/'docs/adr/experiments';x=json.loads((p/'mapping-result.json').read_text());assert json.loads((p/'source-completion.json').read_text())['status']=='PASS'
base='0283-completed-control-mapping';archive=e/(base+'-evidence.zip')
names=sorted(set(x['source_members'])|{'mapping-result.json','source-completion.json','seal-source.py'})
assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n in names:z.write(p/n,n)
x['evidence_archive']={'path':str(archive.relative_to(r)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_count':len(names),'expanded_bytes':sum((p/n).stat().st_size for n in names)}
assert x['evidence_archive']['expanded_bytes']<2097152
with (e/(base+'.json')).open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
adr=r/'docs/adr/0283-map-completed-owner-controls.md';assert not adr.exists();adr.write_text((p/'adr-draft.md').read_text())
common='''[ADR0283](../../../docs/adr/0283-map-completed-owner-controls.md) completes only
F18.15a.1 source/saved mapping: 8activecontrols +1externalgate;2byte-identical,
2namespace-only,4logic-changed plus changed gate; provision historical only.
Single entry group/2inherited children, explicit enclosing directory durability;
53source/10native/11retained/25oldledger +86saved0280member identities preserved.
Independent source review PASS within original600s/2MiB; no runtime tests/native.
F18.15a changed-control artificial implementation/qualification remains open;
actualF18.16 remains unadmitted. Next: fixed temporary controls and bounded
artificial wiring tests only, unchanged science/resources/gates.

'''
for n in ('proposal','design','tasks'):
 q=r/f'openspec/changes/refine-physical-trajectory/{n}.md';s=q.read_text();idx=s.find('[ADR0282]');assert idx>=0;s=s[:idx]+common+s[idx:]
 if n=='tasks':
  before='- [ ] F18.15a Prepare';assert before in s
  pos=s.index('- [ ] F18.16 ')
  s=s[:pos]+'- [x] F18.15a.1 Map exact completed outer controls on saved source within600s/2MiB including independent review, distinguish reuse/changed logic, pin53source/10native/11retained/25oldledger plus0280history, verify links/protected blobs/diff/strict and record ADR/CURRENT, commit/push. ADR0283: mapping accepted; two drafts and directory-durability correction retained, independent review PASS. No runtime tests or actual native episode. WholeF18.15a remains open until changed-control artificial qualification.\n'+s[pos:]
 q.write_text(s)
q=r/'openspec/ROADMAP.md';s=q.read_text();idx=s.index('[ADR0282]');s=s[:idx]+common.replace('../../../docs/adr/','../docs/adr/')+s[idx:];q.write_text(s)
q=r/'openspec/changes/refine-physical-trajectory/specs/research-trajectory-experiment/spec.md';s=q.read_text();needle='### Requirement: Bound realized-clock evidence without changing commands';assert needle in s
scenario='''#### Scenario: Qualify exact completed-owner outer controls without native authority

- **WHEN** F18.15a.1 maps saved0280controls and the qualified0282producer/auditor within600s/2MiB including independent review
- **THEN** the mapping SHALL name8activecontrols plus1externalgate, reuse caller/launcher byte-identically and sandbox/preservation by namespace only, classify entry/collector/admission/run-once/gate as changed logic, and retire active provisioning
- **AND** qualification SHALL retain one entry process group with two inherited child processes, whole-group cleanup even after leader exit, ten exact completed markers/schemas/counts, original60s45/10/5 and final enclosing-directory durability; partial failure or pending/saved PASS alone SHALL NOT establish completion
- **AND** only an explicit harmless artificial harness MAY override child commands; its real probe uses all six fake hooks and mode=injected, its actual guarded auditor runs separately, and native CLI/profile SHALL reject replacements before live reads with artificial native authority always false
- **AND** all49old plus4newsource pins,10native,11retained resources,25oldledger and all86saved0280members SHALL be preserved; fresh actual readback/admission cannot inherit historical timestamps, new acquisition SHALL be0, changed-control artificial checks SHALL finish within300s, and F18.16 SHALL remain unadmitted pending its distinct choice and fresh independent actual600s preflight

'''
s=s.replace(needle,scenario+needle);q.write_text(s)
q=r/'docs/adr/README.md';s=q.read_text();idx=s.index('- [0282');s=s[:idx]+'- [0283 — Completed-owner outer-control mapping](0283-map-completed-owner-controls.md) — F18.15a.1 source design/review only; exact reuse, single-group cleanup and outer directory durability. Changed-control artificial qualification remains open; no native admission.\n\n'+s[idx:];q.write_text(s)
q=r/'CURRENT_STATE.md';q.write_text('''# Current State

Updated: 2026-11-27. Keep under60lines; durable evidence in ADRs.

## Current result
[ADR0283](docs/adr/0283-map-completed-owner-controls.md): F18.15a.1 mapping accepted,
source/saved review only.8activecontrols+1externalgate:2byte-identical,
2namespace-only,4logic-changed+gate; no activeprovision. Singleentrygroup/2children
and final enclosing-directory durability explicit; independent review PASS
within original600s/2MiB.53source/10native/11resources/25oldledger+86saved0280members.
[Result](docs/adr/experiments/0283-completed-control-mapping.json).
[ADR0282](docs/adr/0282-qualify-artificial-completed-owner.md): F18.15 artificial
probe/audit complete;212focused,8275portable+413live=8688passes,
42unchangedarchival skips/0failures, frozen1592files/status; review/Ruff PASS.
No new diagnostic/tests/native runtime this mapping; passed campaigns not repeated.
ADR0281 fixes single forwardTrue/metadata/same-owner endpointTrue, synthetic
elapsed0–1000s and original SI gates.0280episode consumed; image detached.

## Next action and scheduler
ariadna-m3 ACTIVE every5minutes. F18.15a changed-control artificial preparation
and bounded qualification only, per0283exactmatrix; wholeF18.15a remains open.
Use existing guards/evidence/watchdogs, fixed temporary controls; pin changed bytes
before tests. Harmless explicit harness: outerartificial→probeinjected sixfakehooks,
separate real guarded auditor; native rejects overrides beforelive reads.
300s focused checks include originalclock/fsync/bytes/groupcleanup/refusal/noretry;
independent review/links/diff/strict/commit/push. Package/test changes require frozen
fullmake test1800s/Ruff; do not repeat unchanged8688regressions for temporary controls.
F18.16 remains unadmitted: distinct choice, clean committed base, fresh independently
observed actual600s preflight, original60s45/10/5 and byte/resource caps unchanged.
No actualnamespace/mount/resources/SPICE/integration diagnostic from artificialPASS.
Pause only for actual user decision/data/access/action; protect consumed history.

## Physical goal remains open
ADR0247 F0/hardware/sixcontrols unchanged. Full0267owner/lifetime,carry/concurrency/
fullcoreABI-FP/priorarithmetic/fullforce seed/derivatives/guards/endpointbounds open.
No admissiblepair,99percentprobability,physicalclosure/safety; strictM3/task3.9 and
M4–M6/ML/UI gates unchanged. Preserve moon_to_mars.py/main/remotes/history; devonly.
''')
print(json.dumps({'stage':'documentation packaging','archive':x['evidence_archive'],'source_elapsed_s':x['source_phase_elapsed_s']}))
