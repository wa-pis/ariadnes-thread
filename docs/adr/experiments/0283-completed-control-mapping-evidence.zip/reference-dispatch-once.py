"""Once-only bridge from observed supplemented admission to the old collector."""
from __future__ import annotations

from collections.abc import Callable
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time
from types import ModuleType

LIVE_ROOT = Path('/private/tmp/ariadna-f18-supplemented-setup-v1')
CONTRACT_PATH = Path('/Users/agrudin/dev/my/ariadna/docs/adr/experiments/0277-supplemented-setup-contract.json')
OUTER_PYTHON = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
_ADMISSION_BYTES = 19584
_ADMISSION_SHA256 = '37e30013b68bc3cf141a339145b68c8f9e2b9e40ea5ba321db3652c23eebfa4f'
_CANDIDATE_KEYS = {'schema', 'mode', 'status', 'native_launch_authorized', 'started_s',
                   'elapsed_s', 'profile_sha256', 'contract_sha256', 'resource_count',
                   'precharge_sha256', 'provision_sha256', 'outcome_sha256', 'finalization'}


class GateError(RuntimeError):
    """The consumed preparation cannot dispatch the collector."""


def _need(condition: bool, message: str) -> None:
    if not condition:
        raise GateError(message)


def _number(value: object) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _read(path: Path) -> bytes:
    _need(path.is_absolute() and '..' not in path.parts, 'absolute normalized proof path required')
    for parent in reversed(path.parents):
        _need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory proof ancestor')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        _need(stat.S_ISREG(info.st_mode) and info.st_size <= 65536, 'proof type/64KiB cap')
        raw = os.read(descriptor, 65537)
        _need(len(raw) == info.st_size and len(raw) <= 65536, 'proof short/oversized read')
        return raw
    finally:
        os.close(descriptor)


def _load_admission(path: Path) -> ModuleType:
    raw = _read(path)
    _need(len(raw) == _ADMISSION_BYTES and hashlib.sha256(raw).hexdigest() == _ADMISSION_SHA256,
          'qualified0278 admission source required')
    module = ModuleType('_ariadna_qualified_supplemented_admission')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def _sync(fd: int) -> None:
    os.fsync(fd)


def _write(path: Path, value: dict[str, object]) -> bytes:
    raw = (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()
    _need(len(raw) <= 65536, 'gate record64KiB cap')
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(descriptor, raw[offset:])
            _need(0 < count <= len(raw) - offset, 'gate short write')
            offset += count
        _sync(descriptor)
    finally:
        os.close(descriptor)
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        _sync(descriptor)
    finally:
        os.close(descriptor)
    return raw


def gate(
    profile_path: Path,
    contract_path: Path,
    *,
    mode: str,
    started_s: float,
    now: Callable[[], float] = time.monotonic,
    observe: Callable[[Path, Path], dict[str, object]] | None = None,
    dispatch: Callable[[], object] | None = None,
) -> dict[str, object]:
    """Call actual admission once; only native mode can exec the old collector."""
    try:
        return _gate(profile_path, contract_path, mode=mode, started_s=started_s,
                     now=now, observe=observe, dispatch=dispatch)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError) as exc:
        if isinstance(exc, GateError):
            raise
        raise GateError('supplemented outer gate: ' + str(exc)) from exc


def _gate(
    profile_path: Path, contract_path: Path, *, mode: str, started_s: float,
    now: Callable[[], float], observe: Callable[[Path, Path], dict[str, object]] | None,
    dispatch: Callable[[], object] | None,
) -> dict[str, object]:
    _need(type(mode) is str and mode in {'native', 'artificial'}, 'explicit gate mode required')
    _need(_number(started_s), 'finite inherited preflight start required')
    if mode == 'native':
        _need(now is time.monotonic and observe is None and dispatch is None,
              'native replacement clock/observer/dispatch forbidden')
        _need(profile_path == LIVE_ROOT / 'profile.json' and contract_path == CONTRACT_PATH
              and Path(__file__).resolve() == LIVE_ROOT / 'dispatch-once.py', 'fixed native gate paths')
        _need(Path(sys.executable).resolve() == OUTER_PYTHON.resolve(), 'fixed outer interpreter required')
    else:
        _need(callable(observe) and callable(dispatch), 'explicit artificial observer/dispatch required')
    last = float(started_s)

    def tick() -> float:
        nonlocal last
        current = now()
        _need(_number(current) and last <= current and 0 <= current - started_s < 600,
              'inherited600s preflight exhausted or incomparable')
        last = float(current)
        return last - started_s

    tick()
    root = profile_path.parent
    admission = _load_admission(root / 'admission.py')
    profile_raw, contract_raw = _read(profile_path), _read(contract_path)
    profile, contract = admission._object(profile_raw), admission._object(contract_raw)
    profile_sha, contract_sha = (hashlib.sha256(raw).hexdigest() for raw in (profile_raw, contract_raw))
    _need(profile['mode'] == mode and _number(profile['preflight_started_s'])
          and profile['preflight_started_s'] == started_s
          and profile['contract_sha256'] == contract_sha, 'gate profile mode/clock/contract')
    _need(profile['work_directory'] == str(root / 'execution'), 'fixed gate work namespace')
    decision, decision_sha = admission._proof(profile['execution_decision'])
    _need(decision['schema'] == 'ariadna.f18.supplemented-execution-decision.v1'
          and decision['stage'] == 'F18.13' and decision['mode'] == mode
          and decision['status'] == ('ADMITTED_ONCE' if mode == 'native' else 'ARTIFICIAL_EXECUTION_DECISION')
          and type(decision['base_revision']) is str and bool(decision['base_revision'])
          and decision['base_revision'] == profile['base_revision']
          and decision['contract_sha256'] == contract_sha, 'separate execution decision required')

    def checked_pin(value: object) -> tuple[Path, dict[str, object]]:
        _need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}, 'exact gate/interpreter pin')
        _need(type(value['path']) is str and type(value['bytes']) is int and value['bytes'] > 0
              and type(value['sha256']) is str
              and re.fullmatch(r'[0-9a-f]{64}', value['sha256']) is not None, 'typed gate/interpreter pin')
        path = Path(value['path'])
        pin = {'bytes': value['bytes'], 'sha256': value['sha256']}
        admission._pin(path, pin, tick)
        return path, pin

    _need(json.dumps(profile['outer_gate'], sort_keys=True, allow_nan=False)
          == json.dumps(decision['outer_gate_pin'], sort_keys=True, allow_nan=False)
          and json.dumps(profile['outer_python'], sort_keys=True, allow_nan=False)
          == json.dumps(decision['outer_python_pin'], sort_keys=True, allow_nan=False),
          'outer pins must match execution decision with exact numeric types')
    gate_path, gate_pin = checked_pin(profile['outer_gate'])
    python_path, python_pin = checked_pin(profile['outer_python'])
    _need(gate_path == Path(__file__).resolve(), 'outer gate self identity')
    if mode == 'native':
        _need(python_path == OUTER_PYTHON.resolve(), 'fixed outer binary pin')
    collector = root / 'run-once.py'
    collector_pin = profile['control_pins'][str(collector)]
    _need(str(gate_path) not in profile['control_pins'], 'outer gate must stay outside fixed control group')
    admission._pin(collector, collector_pin, tick)
    start, candidate, launch = (root / name for name in
                                ('gate-start.json', 'admission-check.json', 'launch-admission.json'))
    for path in (start, candidate, launch, root / 'episode-start.json', root / 'execution'):
        _need(not os.path.lexists(path), 'occupied once-only gate namespace: ' + str(path))
    marker: dict[str, object] = {
        'schema': 'ariadna.f18.supplemented-gate-start.v1', 'mode': mode,
        'started_s': started_s, 'elapsed_s': tick(), 'profile_sha256': profile_sha,
        'contract_sha256': contract_sha, 'execution_decision_sha256': decision_sha,
        'outer_gate_pin': profile['outer_gate'], 'retry_authorized': False,
    }
    marker_raw = _write(start, marker)
    tick()
    returned = admission.admit(profile_path, contract_path, candidate, mode=mode,
                               started_s=started_s, now=now, observe=observe)
    candidate_raw = _read(candidate)
    pending = admission._object(candidate_raw)
    candidate_sha = hashlib.sha256(candidate_raw).hexdigest()
    elapsed = tick()
    _need(type(returned) is dict and set(returned) == _CANDIDATE_KEYS | {'receipt_sha256'}
          and set(pending) == _CANDIDATE_KEYS, 'exact returned and pending admission shapes')
    _need(pending['schema'] == 'ariadna.f18.supplemented-admission.v1'
          and pending['mode'] == mode and pending['status'] == 'PENDING_DURABLE_ADMISSION'
          and pending['native_launch_authorized'] is False
          and pending['finalization'] == 'pending-outer-readback', 'pending disk candidate required')
    _need(type(returned['status']) is str
          and returned['status'] == ('PASS' if mode == 'native' else 'PASS_ARTIFICIAL_ADMISSION_ONLY')
          and returned['native_launch_authorized'] is (mode == 'native')
          and returned['finalization'] == 'checked-after-fsync'
          and returned['receipt_sha256'] == candidate_sha, 'observed completed admission required')
    _need(_number(pending['started_s']) and pending['started_s'] == started_s
          and _number(returned['started_s']) and returned['started_s'] == started_s
          and _number(pending['elapsed_s']) and _number(returned['elapsed_s'])
          and 0 <= pending['elapsed_s'] <= returned['elapsed_s'] <= elapsed
          and type(pending['resource_count']) is int and pending['resource_count'] == 11,
          'admission exact counts/ordered finite clock')
    _need(pending['profile_sha256'] == profile_sha and pending['contract_sha256'] == contract_sha,
          'admission immutable profile/contract binding')
    for name, proof_name in (('precharge_sha256', 'precharge'), ('provision_sha256', 'provision'),
                             ('outcome_sha256', 'outcome')):
        _need(pending[name] == profile['proofs'][proof_name]['sha256'], 'admission proof binding')
    changed = {'status', 'native_launch_authorized', 'finalization', 'elapsed_s'}
    for name in _CANDIDATE_KEYS - changed:
        _need(json.dumps(pending[name], sort_keys=True, allow_nan=False)
              == json.dumps(returned[name], sort_keys=True, allow_nan=False), 'returned admission drift: ' + name)

    def recheck() -> None:
        tick()
        _need(_read(profile_path) == profile_raw and _read(contract_path) == contract_raw
              and _read(candidate) == candidate_raw and _read(start) == marker_raw,
              'profile/contract/candidate/start changed after observed admission')
        _, current_decision_sha = admission._proof(profile['execution_decision'])
        _need(current_decision_sha == decision_sha, 'execution decision changed')
        admission._pin(gate_path, gate_pin, tick)
        admission._pin(python_path, python_pin, tick)
        admission._pin(collector, collector_pin, tick)
        _need(hashlib.sha256(_read(root / 'admission.py')).hexdigest() == _ADMISSION_SHA256,
              'qualified admission changed')
        if mode == 'native':
            _need(OUTER_PYTHON.resolve() == python_path, 'outer interpreter alias changed')
        _need(not os.path.lexists(root / 'episode-start.json') and not os.path.lexists(root / 'execution'),
              'episode/work became occupied')
        tick()

    recheck()
    ready: dict[str, object] = {
        'schema': 'ariadna.f18.setup-launch-admission.v1',
        'status': 'PASS' if mode == 'native' else 'ARTIFICIAL_READY',
        'mode': mode, 'native_launch_authorized': mode == 'native',
        'started_s': started_s, 'elapsed_s': tick(), 'profile_sha256': profile_sha,
        'contract_sha256': contract_sha, 'admission_receipt_sha256': candidate_sha,
        'execution_decision_sha256': decision_sha,
        'gate_start_sha256': hashlib.sha256(marker_raw).hexdigest(),
        'outer_gate_pin': profile['outer_gate'], 'outer_python_pin': profile['outer_python'],
        'finalization': 'pending-outer-dispatch', 'retry_authorized': False,
    }
    ready_raw = _write(launch, ready)
    recheck()
    _need(_read(launch) == ready_raw, 'final gate changed before dispatch')
    tick()
    if mode == 'native':
        os.execv(str(OUTER_PYTHON), [str(OUTER_PYTHON), '-I', '-B', str(collector)])
        raise GateError('native exec unexpectedly returned; attempt remains consumed')
    assert dispatch is not None
    dispatch()
    return dict(ready, finalization='checked-after-fsync', elapsed_s=last - started_s)


if __name__ == '__main__':
    try:
        _need(sys.argv[1:] == [str(LIVE_ROOT / 'profile.json'), str(CONTRACT_PATH),
                              str(LIVE_ROOT / 'preflight-start.json')], 'fixed native argument paths required')
        start_record = json.loads(_read(LIVE_ROOT / 'preflight-start.json'))
        gate(LIVE_ROOT / 'profile.json', CONTRACT_PATH, mode='native', started_s=start_record['started_s'])
    except (GateError, OSError, ValueError, KeyError, TypeError) as error:
        print(('outer gate refused: ' + str(error))[:2048], file=sys.stderr)
        raise SystemExit(2)
