from pathlib import Path
import json,time,hashlib,os
p=Path('/private/tmp/ariadna-f18-0283');start=json.loads((p/'start.json').read_text());draft=p/'mapping-v2.json';review=p/'independent-review-final.json';x=json.loads(review.read_text());assert x['status']=='PASS',x
pin=lambda b:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert hashlib.sha256(draft.read_bytes()).hexdigest() in review.read_text()
elapsed=time.monotonic()-start['started_s'];assert elapsed<600
members={q.name:pin(q.read_bytes()) for q in sorted(p.iterdir()) if q.is_file() and q.name!='seal-source.py'}
assert sum(v['bytes'] for v in members.values())<2097152
result={'schema':'ariadna.f18.completed-control-mapping-result.v1','status':'accepted-design','base_revision':start['base_revision'],'stage':'F18.15a.1','implementation':'Not started; wholeF18.15a remains open','contract':{'archive_member':'mapping-v2.json',**pin(draft.read_bytes())},'independent_review':{'archive_member':review.name,**pin(review.read_bytes())},'source_phase_elapsed_s':elapsed,'source_phase_limit_s':600,'source_phase_evidence_bytes':sum(v['bytes'] for v in members.values()),'source_phase_evidence_limit_bytes':2097152,'old_source_pins_checked':49,'appended_source_pins_checked':4,'source_count':53,'native_count':10,'retained_resource_count':11,'old_ledger_count':25,'additional_saved0280_members':86,'active_controls':8,'external_gate_count':1,'control_classes':{'byte_identical':['call-once.py','launch-once.py'],'namespace_only':['native.sandbox','check-preservation.py'],'logic_changed':['run-once.py','native-entry.py','supervisor-adapter.py','admission.py'],'external_logic_changed':['dispatch-once.py'],'historical_retired':['provision.py']},'runtime_tests_rerun':False,'actual_episode_admitted':False,'actual_namespace_created':False,'live_resource_payloads_read':False,'mount_native_import_spice_integration':False,'source_members':members,'documentary_phase':'Packaging/links/pins/strict/diff/protected-blob verification follows separately; not part of source600s.'}
with (p/'mapping-result.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
observed=time.monotonic()-start['started_s'];assert observed<600
with (p/'source-completion.json').open('x') as f:json.dump({'schema':'ariadna.f18.completed-mapping-observed.v1','status':'PASS','result_sha256':pin((p/'mapping-result.json').read_bytes())['sha256'],'observed_after_result_file_directory_fsync_s':observed,'limit_s':600},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'PASS','source_phase_elapsed_s':elapsed,'observed_after_fsync_s':observed,'bytes':result['source_phase_evidence_bytes']}))
