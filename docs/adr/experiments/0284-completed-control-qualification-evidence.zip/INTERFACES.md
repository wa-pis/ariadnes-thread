# F18.15a temporary controls — implementation coordination

Base8d7532d20827d691b93043b90d1ef8aa8664122e, ADR0283 mapping-v2 immutable source.
No tests/control imports/execution until root freezes exact sources and independent
review accepts. AST parsing allowed. No native/mount/SPICE/integration/livepayload.
Files live only /private/tmp/ariadna-f18-0284/controls and tests; future actual
/private/tmp/ariadna-f18-forward-completed-v1 MUST NOT be created.

Profile schema ariadna.f18.completed-control-profile.v1,
scope single-forward-completed-owner-only, mode native|artificial.
Exact top-level keys (no injected commands/clock/observer/replacement profile fields):
schema scope mode repo base_revision root work_directory preflight_started_s
outer_python private_python environment sandbox_profile source_pins native_pins
resource_pins resource_directory image mount ledger_pins history_archive
history_member_pins control_pins outer_gate contract kernel_sha256 probe_input
entry_sha256 launch_sha256 caller_sha256 adapter_sha256 sandbox_sha256
prelaunch_admission execution_decision

Pin objects {bytes:nonnegativeint,sha256:64lowerhex}; paths absolute where old source
pins already absolute; root relative source pins also allowed as exact saved source
mapping. historical archive pin object also path; ledger/native/control maps path->pin;
resource_pins list name/bytes/sha256 exact11, no reads outside artificial tree in tests.
History archive all86members pins incl zero-byte logs; old25ledger kept distinct.
contract pin object path->mapping-v2 file metadata, external outer_gate path+pin.
Probe input exactly qualified0282ten keys, mode native|injected. Native input mode
native; outerartificial->injected. Profile source53/native10/resources11/ledger25,
8activecontrols exactnames (no provision), separately pinned external gate.

Entry function run(profile_path:Path, started_s:float, *, artificial_commands=None)
returns collector dict; CLI only native, no command override fields/flags. Explicit
harmless artificial harness calls same function in child new session; modeartificial
requires commands and safe prefix, native forbids any before live reads. artificial
commands bounded pinned {producer:list[str], audit:list[str]} passed as function
argument only; native commandbuilder fixed actual completed modules. Defaultaudit
always actual guarded module, replacementaudit permitted only artificial failure tests.
Commands factory consumes actual packet input/path/start/deadline parameters; agree
exact callable shape between entry/collector/harness with root promptly.

Collector `collect(profile:dict, directory:Path, started_s:float, *, artificial_commands=None)`
creates fixed packet directory once, original60s clock; inheritedgroup children,
probe CLI --probe INPUT START DEADLINE, auditor CLI --audit INPUT REPORT OBS TRACE DEADLINE.
Native profile accepted only CLI fixed path/prefix guard and native authority proven
outside; no pretending artificial qualifies nativepositive. Entry records supervisor.pgid
at profile.work_directory, never parent.pgid, avoids setup controller imports.
Output schema ariadna.f18.completed-collector.v1, status passed|failed,
finalization checked-after-fsync|failed-after-fsync, physical_admission unavailable,
completion_requires_outer_finalization true. Failure retains partial unknown counts.
Entry exit0 iff collector passed+checked afterfsync, else2. External unchanged launcher
is schema agnostic; original outer watchdog kills entire entry group including children.
run-once adds directory durability explicitly before observed success<original60s.

Admission `admit(profile_path:Path, *, artificial_observer=None)` reads bounded exact
profile, rejects replacement args for native BEFORE live reads; artificial profile
requires explicitly harmless observer and never yields nativeauthority. Returns observed
postfsync result+candidate pin, disk candidate PENDING only. Fresh original600s checks,
no historytimestamp reuse or active provision. Native observeRO through unchanged
hdiutil read-only helper, resource readback; no native execution/import at admission.
External gate `dispatch(profile_path, *, artificial_observer=None, artificial_dispatch=None)`
self/externalinterpreter/contract/profile pins; calls admit directly once; exclusive
start/candidate/permit/work guard, observed binding/postseal rehash/dirfsync/original600s.
Artificial ARTIFICIAL_READY/nativeauthorizationfalse, harmlesscallback once; persisted
PASS never sufficient. Native forbids overrides, requires separate distinct execution
choice/cleancommittedbase/fresh independent admission and hardcoded run-once path.

root owns run-once/sandbox/preservation/call/launch copies and shared harness/profile.
agent collector owns native-entry.py + supervisor-adapter.py and tests_collector.py.
agent admission owns admission.py + dispatch-once.py and tests_admission.py.
No shared writes; root will review combined exact pin matrix then independent review.
