"""Fixed completed-owner prerequisite checker; importing executes no admission.

Only read/pin/readonly-observation primitives descend from0280. Historical proofs
are provenance, never fresh admission. Artificial readiness grants no native run.
"""
from __future__ import annotations

from collections.abc import Callable
import hashlib
import io
import json
import math
import os
from pathlib import Path
import plistlib
import re
import stat
import subprocess
import sys
import time
from typing import Any
import zipfile

CONTRACT_SHA256 = '20397decfe63f978648cfb220778e962410f3a26cab7690449183aae33e52dd8'
REPO = Path('/Users/agrudin/dev/my/ariadna')
LIVE_ROOT = Path('/private/tmp/ariadna-f18-forward-completed-v1')
LIVE_MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
LIVE_IMAGE = Path('/private/tmp/ariadna-f17-0263/scratch.sparseimage')
ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0284')
PROFILE_KEYS = set('schema scope mode repo base_revision root work_directory preflight_started_s outer_python private_python environment sandbox_profile source_pins native_pins resource_pins resource_directory image mount ledger_pins history_archive history_member_pins control_pins outer_gate contract kernel_sha256 probe_input entry_sha256 launch_sha256 caller_sha256 adapter_sha256 sandbox_sha256 prelaunch_admission execution_decision'.split())
PROBE_KEYS = set('schema scope mode kernel_path kernel_sha256 probe_sha256 owner_fixture_sha256 owner_auditor_sha256 trajectory_sha256 completed_auditor_sha256'.split())
CONTROL_NAMES = {'call-once.py', 'launch-once.py', 'native.sandbox', 'check-preservation.py',
                 'run-once.py', 'native-entry.py', 'supervisor-adapter.py', 'admission.py'}


class AdmissionError(RuntimeError):
    """Fixed completed-owner prerequisites are absent, stale or inconsistent."""


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise AdmissionError(message)


def _number(value: object) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


# Byte-identical low-level0280 primitives: _directory, _read, _object, _live_observation.
def _directory(path: Path) -> None:
    _need(path.is_absolute(), 'absolute directory required')
    for parent in [*reversed(path.parents), path]:
        _need(stat.S_ISDIR(parent.lstat().st_mode), 'non-directory or symlink ancestor')


def _read(path: Path, cap: int = 65536) -> bytes:
    _directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        _need(stat.S_ISREG(info.st_mode) and info.st_size <= cap, 'nonregular or oversized proof')
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            raw = stream.read(cap + 1)
        _need(len(raw) == info.st_size and len(raw) <= cap, 'proof changed or oversized')
        return raw
    finally:
        os.close(descriptor)


def _object(raw: bytes) -> dict[str, object]:
    def pairs(rows: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in rows:
            _need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result

    def invalid(value: str) -> None:
        raise AdmissionError('nonfinite JSON number: ' + value)

    result = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    _need(type(result) is dict, 'JSON object required')
    return result


def _live_observation(mount: Path, image: Path) -> dict[str, object]:
    _need(os.path.ismount(mount), 'live mount absent')
    fs = os.statvfs(mount)
    raw = subprocess.check_output(['/usr/bin/hdiutil', 'info', '-plist'], timeout=5)
    _need(len(raw) <= 65536, 'mount metadata capacity')
    info = plistlib.loads(raw)
    matches = [item for item in info['images'] if item.get('image-path') == str(image)
               and any(row.get('mount-point') == str(mount) for row in item.get('system-entities', []))]
    _need(len(matches) == 1, 'retained image/mount identity')
    return {'read_only': bool(fs.f_flag & os.ST_RDONLY), 'mount': str(mount),
            'image': str(image), 'capacity_bytes': fs.f_blocks * fs.f_frsize}


def _pin_shape(value: object) -> dict[str, Any]:
    _need(type(value) is dict and set(value) == {'bytes', 'sha256'}, 'exact pin shape')
    _need(type(value['bytes']) is int and value['bytes'] >= 0, 'nonnegative pinned length')
    _need(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None,
          'lowercase pinned digest')
    return value


def _pin(path: Path, expected: dict[str, object], tick: Callable[[], float]) -> None:
    """0280 bounded nofollow hash walk, extended to preserved zero-byte logs."""
    _pin_shape(expected)
    _directory(path.parent)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        _need(stat.S_ISREG(before.st_mode) and before.st_size == expected['bytes'], 'pinned size/type')
        digest = hashlib.sha256()
        remaining = expected['bytes']
        while remaining:
            tick()
            data = os.read(fd, min(remaining, 1024 * 1024))
            _need(bool(data), 'pinned short read')
            digest.update(data)
            remaining -= len(data)
        after = os.fstat(fd)
        _need(not os.read(fd, 1) and before.st_size == after.st_size
              and before.st_mtime_ns == after.st_mtime_ns
              and digest.hexdigest() == expected['sha256'], 'pinned bytes drift')
    finally:
        os.close(fd)
    tick()


def _path_pin(value: object) -> tuple[Path, dict[str, object]]:
    _need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}, 'path pin shape')
    _need(type(value['path']) is str, 'string pin path required')
    path = Path(value['path'])
    _need(path.is_absolute() and '..' not in path.parts, 'absolute normalized pin path required')
    return path, _pin_shape({k: value[k] for k in ('bytes', 'sha256')})


def _canonical_group(group: object, repo: Path) -> dict[str, dict[str, object]]:
    _need(type(group) is dict, 'pin group must be object')
    result: dict[str, dict[str, object]] = {}
    for name, pin in group.items():
        _need(type(name) is str, 'pin key must be path string')
        path = Path(name)
        path = path if path.is_absolute() else repo / path
        _need('..' not in path.parts and str(path) not in result, 'duplicate/unnormalized group path')
        result[str(path)] = _pin_shape(pin)
    return result


def _write(path: Path, value: dict[str, object]) -> bytes:
    raw = (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()
    _need(len(raw) <= 65536, 'record64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(fd, raw[offset:])
            _need(0 < count <= len(raw) - offset, 'record short write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return raw


def _clock(started_s: object) -> Callable[[], float]:
    _need(_number(started_s), 'finite inherited preflight start required')
    last = float(started_s)

    def tick() -> float:
        nonlocal last
        now = time.monotonic()
        _need(_number(now) and last <= now and 0 <= now - started_s < 600, 'original600s clock')
        last = now
        return now - started_s

    tick()
    return tick


def _profile(profile_path: Path, artificial_observer: object) -> tuple[bytes, dict[str, Any]]:
    if profile_path == LIVE_ROOT / 'profile.json':
        _need(artificial_observer is None, 'native replacement observer forbidden before live reads')
    else:
        _need(profile_path.is_absolute() and '..' not in profile_path.parts
              and profile_path.is_relative_to(ARTIFICIAL_ROOT), 'artificial profile escaped fake tree')
    raw = _read(profile_path)
    p = _object(raw)
    _need(set(p) == PROFILE_KEYS and p['schema'] == 'ariadna.f18.completed-control-profile.v1'
          and p['scope'] == 'single-forward-completed-owner-only', 'exact completed profile')
    _need(type(p['mode']) is str and p['mode'] in {'native', 'artificial'}, 'explicit profile mode')
    if p['mode'] == 'native':
        _need(artificial_observer is None, 'native replacement observer forbidden')
        _need(profile_path == LIVE_ROOT / 'profile.json' and p['root'] == str(LIVE_ROOT)
              and Path(__file__).resolve() == LIVE_ROOT / 'admission.py', 'fixed native admission path')
    else:
        _need(callable(artificial_observer) and profile_path.is_relative_to(ARTIFICIAL_ROOT)
              and profile_path.parent != ARTIFICIAL_ROOT and p['root'] == str(profile_path.parent),
              'explicit harmless artificial observer/fake prefix required')
    return raw, p


def _history(p: dict[str, Any], c: dict[str, Any], tick: Callable[[], float]) -> dict[str, Any]:
    path, pin = _path_pin(p['history_archive'])
    if p['mode'] == 'artificial':
        _need(path.is_relative_to(ARTIFICIAL_ROOT), 'artificial archive escaped fake tree')
    _need(_pin_shape({k: c['reference_archive'][k] for k in ('bytes', 'sha256')}) == pin,
          'history archive binding')
    _pin(path, pin, tick)
    raw = _read(path, 2097152)
    expected = p['history_member_pins']
    _need(type(expected) is dict and len(expected) == 86
          and expected == c['historical_0280_member_pins'], 'all86 history member pins')
    total = 0
    with zipfile.ZipFile(io.BytesIO(raw)) as packet:
        names = packet.namelist()
        _need(len(names) == len(set(names)) == 86 and set(names) == set(expected), 'exact86 history archive')
        for name, pin in expected.items():
            _need(not Path(name).is_absolute() and '..' not in Path(name).parts, 'relative history member')
            _pin_shape(pin)
            total += pin['bytes']
            _need(total <= 2097152 and packet.getinfo(name).file_size == pin['bytes'], 'history expanded cap')
            data = packet.read(name)
            _need(len(data) == pin['bytes'] and hashlib.sha256(data).hexdigest() == pin['sha256'],
                  'history member drift: ' + name)
            tick()
        return _object(packet.read('profile.json')) if p['mode'] == 'native' else {}


def admit(profile_path: Path, *, artificial_observer: Callable[[Path, Path], dict[str, object]] | None = None) -> dict[str, object]:
    """Return observed post-fsync prerequisites; disk candidate is never authority."""
    try:
        return _admit(profile_path, artificial_observer=artificial_observer)
    except (OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile) as exc:
        raise AdmissionError('completed admission: ' + str(exc)) from exc


def _admit(profile_path: Path, *, artificial_observer: Callable[[Path, Path], dict[str, object]] | None) -> dict[str, object]:
    profile_raw, p = _profile(profile_path, artificial_observer)
    tick = _clock(p['preflight_started_s'])
    repo, root = Path(p['repo']), profile_path.parent
    _need(p['work_directory'] == str(root / 'execution')
          and p['sandbox_profile'] == str(root / 'native.sandbox')
          and p['prelaunch_admission'] == str(root / 'launch-admission.json'), 'fixed completed namespaces')
    _need(all(not os.path.lexists(root / name) for name in
              ('execution', 'episode-start.json', 'admission-check.json', 'launch-admission.json')),
          'fresh unconsumed completed namespace')
    contract_path, contract_pin = _path_pin(p['contract'])
    if p['mode'] == 'artificial':
        _need(contract_path.is_relative_to(ARTIFICIAL_ROOT), 'artificial contract escaped fake tree')
    _pin(contract_path, contract_pin, tick)
    contract_raw = _read(contract_path)
    c = _object(contract_raw)
    _need(c['schema'] == 'ariadna.f18.completed-control-mapping.v1', 'completed mapping schema')
    if p['mode'] == 'native':
        _need(contract_pin['sha256'] == CONTRACT_SHA256 and repo == REPO
              and p['mount'] == str(LIVE_MOUNT) and p['image'] == str(LIVE_IMAGE)
              and p['resource_directory'] == str(LIVE_MOUNT / 'home/.tudat/resource')
              and c.get('qualification') is None, 'official native contract/retained paths')
        _need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True, timeout=5).strip() == p['base_revision']
              and subprocess.check_output(['git', 'branch', '--show-current'], cwd=repo, text=True, timeout=5).strip() == 'dev'
              and not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True, timeout=5).strip(),
              'clean committed native dev/base')
    else:
        _need(c.get('qualification') == 'ARTIFICIAL', 'fabricated contract label required')
    expected_sources = _canonical_group(c['old_source_pins'] | c['appended_source_pins'], repo)
    source_group = _canonical_group(p['source_pins'], repo)
    _need(len(c['old_source_pins']) == 49 and len(c['appended_source_pins']) == 4
          and len(source_group) == 53 and source_group == expected_sources, 'exact49+4 source pins')
    for field, expected, count in (('source_pins', expected_sources, 53),
                                    ('native_pins', c['native_pins'], 10),
                                    ('ledger_pins', c['historical_ledger_pins'], 25)):
        group = _canonical_group(p[field], repo)
        _need(len(group) == count and group == _canonical_group(expected, repo), 'exact pinned group: ' + field)
        for name, pin in group.items():
            if p['mode'] == 'artificial':
                _need(Path(name).is_relative_to(ARTIFICIAL_ROOT), 'artificial group escaped fake tree')
            _pin(Path(name), pin, tick)
    history = _history(p, c, tick)
    _need(p['environment'] == (c['environment_unchanged'] if p['mode'] == 'artificial' else history['environment']),
          'unchanged environment')
    if p['mode'] == 'native':
        _need(p['private_python'] == history['private_python'] and p['kernel_sha256'] == history['kernel_sha256'],
              'retained interpreter/kernel')
    for field in ('outer_python', 'outer_gate'):
        path, pin = _path_pin(p[field])
        if p['mode'] == 'artificial':
            _need(path.is_relative_to(ARTIFICIAL_ROOT) or
                  (field == 'outer_python' and path == Path(sys.executable).resolve()),
                  'artificial outer pin escaped declared harmless prefix')
        _pin(path, pin, tick)
    if p['mode'] == 'artificial':
        _need(p['private_python'] == p['outer_python']['path'], 'harmless artificial interpreter required')
    controls = _canonical_group(p['control_pins'], repo)
    _need(set(controls) == {str(root / name) for name in CONTROL_NAMES}, 'exact8 active controls')
    _need(p['outer_gate']['path'] == str(root / 'dispatch-once.py')
          and p['outer_gate']['path'] not in controls, 'external gate outside control group')
    for name, pin in controls.items():
        _pin(Path(name), pin, tick)
    for field, name in (('entry_sha256', 'native-entry.py'), ('launch_sha256', 'launch-once.py'),
                        ('caller_sha256', 'call-once.py'), ('adapter_sha256', 'supervisor-adapter.py'),
                        ('sandbox_sha256', 'native.sandbox')):
        _need(p[field] == controls[str(root / name)]['sha256'], 'control hash binding: ' + field)
    rows = p['resource_pins']
    _need(type(rows) is list and len(rows) == 11 and rows == c['retained_resources'], 'exact11 retained resources')
    resources, mount, image = Path(p['resource_directory']), Path(p['mount']), Path(p['image'])
    if p['mode'] == 'artificial':
        _need(all(path.is_relative_to(ARTIFICIAL_ROOT) for path in (resources, mount, image)),
              'artificial resources/image escaped fake tree')
    _directory(resources)
    names: set[str] = set()
    for row in rows:
        _need(type(row) is dict and set(row) == {'name', 'bytes', 'sha256'} and type(row['name']) is str,
              'exact resource row')
        name = Path(row['name'])
        _need(not name.is_absolute() and '..' not in name.parts and str(name) not in names, 'relative unique resource')
        names.add(str(name))
        _pin(resources / name, {k: row[k] for k in ('bytes', 'sha256')}, tick)
    actual: set[str] = set()
    for directory, dirs, files in os.walk(resources, followlinks=False):
        for name in dirs:
            _need(not (Path(directory) / name).is_symlink(), 'resource symlink directory')
        for name in files:
            actual.add(str((Path(directory) / name).relative_to(resources)))
        tick()
    _need(actual == names, 'exact resource inventory')
    probe = p['probe_input']
    _need(type(probe) is dict and set(probe) == PROBE_KEYS
          and probe['schema'] == 'ariadna-owner-completed-input-v1'
          and probe['scope'] == 'single-forward-completed-owner-only'
          and probe['mode'] == ('native' if p['mode'] == 'native' else 'injected')
          and probe['kernel_sha256'] == p['kernel_sha256'], 'exact completed probe input')
    for field in PROBE_KEYS - {'schema', 'scope', 'mode', 'kernel_path'}:
        _need(type(probe[field]) is str and re.fullmatch('[0-9a-f]{64}', probe[field]) is not None, 'probe digest')
    for field, name in (('probe_sha256', '_owner_completed_probe.py'),
                        ('owner_fixture_sha256', '_owner_endpoint_fixture.py'),
                        ('owner_auditor_sha256', '_owner_endpoint_audit.py'),
                        ('trajectory_sha256', 'trajectory.py'),
                        ('completed_auditor_sha256', '_owner_completed_audit.py')):
        if p['mode'] == 'native':
            _need(probe[field] == source_group[str(repo / 'src/space_nav' / name)]['sha256'], 'probe source binding')
    _need(type(probe['kernel_path']) is str and probe['kernel_path'] in p['native_pins']
          and p['native_pins'][probe['kernel_path']]['sha256'] == probe['kernel_sha256'], 'probe kernel binding')
    observed = artificial_observer(image, mount) if artificial_observer is not None else _live_observation(mount, image)
    _need(type(observed) is dict and set(observed) == {'image', 'mount', 'read_only', 'capacity_bytes'}
          and observed['image'] == str(image) and observed['mount'] == str(mount)
          and observed['read_only'] is True and type(observed['capacity_bytes']) is int
          and 0 < observed['capacity_bytes'] <= 8589934592, 'fresh retained readonly image observation')
    _need(_read(profile_path) == profile_raw, 'profile changed during admission')
    result: dict[str, object] = {'schema': 'ariadna.f18.completed-admission.v1', 'mode': p['mode'],
        'status': 'PENDING_DURABLE_ADMISSION', 'native_launch_authorized': False,
        'started_s': p['preflight_started_s'], 'elapsed_s': tick(),
        'profile_sha256': hashlib.sha256(profile_raw).hexdigest(), 'contract_sha256': contract_pin['sha256'],
        'resource_count': 11, 'source_count': 53, 'native_count': 10, 'ledger_count': 25,
        'history_count': 86, 'control_count': 8, 'read_only_observation': observed,
        'finalization': 'pending-outer-readback'}
    candidate = root / 'admission-check.json'
    raw = _write(candidate, result)
    observed_elapsed = tick()
    _need(_read(candidate) == raw, 'candidate changed after fsync')
    return dict(result, status='PASS_NATIVE_ADMISSION_ONLY' if p['mode'] == 'native' else 'ARTIFICIAL_READY',
                finalization='checked-after-fsync', elapsed_s=observed_elapsed,
                receipt_sha256=hashlib.sha256(raw).hexdigest())
