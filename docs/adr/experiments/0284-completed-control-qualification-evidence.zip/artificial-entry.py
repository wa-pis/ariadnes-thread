"""Explicit artificial entry-function seam; never a native CLI replacement flag."""
from __future__ import annotations
import importlib.util,json,sys
from pathlib import Path

def main()->int:
    path=Path(sys.argv[1]);profile=json.loads(path.read_bytes());entry=path.parent/'native-entry.py'
    spec=importlib.util.spec_from_file_location('qualified_artificial_entry',entry);assert spec and spec.loader
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    report=module.run(path,float(sys.argv[2]),artificial_commands=json.loads(sys.argv[3]))
    print(json.dumps(report,sort_keys=True),flush=True)
    return 0 if report.get('status')=='passed'and report.get('finalization')=='checked-after-fsync'else 2
if __name__=='__main__':raise SystemExit(main())
