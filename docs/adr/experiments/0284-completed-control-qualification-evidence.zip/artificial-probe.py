"""Harmless fake-owner child calling the actual qualified producer with six hooks."""
from __future__ import annotations
import json,sys
from pathlib import Path
from types import ModuleType,SimpleNamespace
from space_nav import _owner_completed_probe as producer
from space_nav._owner_endpoint_fixture import Budget

def main()->int:
    assert len(sys.argv)==5 and sys.argv[1]=='--probe'
    source=Path(sys.argv[2]);profile=json.loads(source.read_bytes());started=float(sys.argv[3]);deadline=float(sys.argv[4])
    kernel=ModuleType('tudatpy.kernel');kernel.__file__=profile['kernel_path'];sys.modules['tudatpy.kernel']=kernel
    mass='Mass state of body Spacecraft'
    results=SimpleNamespace(propagation_is_performed=True,integration_completed_successfully=True,
        propagated_state_vector_length=7,total_number_of_function_evaluations=41,
        termination_details=SimpleNamespace(termination_reason='termination_condition_reached',terminated_on_exact_condition=True),
        processed_state_ids={(0,6):'Translational state, in Cartesian elements, of body Spacecraft w.r.t. SSB',(6,1):mass},
        propagated_state_ids={(0,6):'Translational state (Cowell formulation) of body Spacecraft w.r.t. SSB',(6,1):mass})
    budget=Budget(started)
    class Owner:
        propagation_results=results
        def _ariadna_original_endpoint(self,selector:bool,schema:str)->object:
            assert selector is True and schema=='cartesian-position-m_velocity-m-s_mass-kg'
            return (0,1000.0,(10000000.0,1050000.0,0.0,0.0,1100.0,0.0,2000.0))
    def prepare(value:float)->object:
        assert value==started;return budget
    def import_spice()->object:return None
    def guard(actual:object,spice:object)->None:assert actual is budget and spice is None
    def context()->object:return [53,53,8]
    def provenance()->object:return {'producer_sha256':profile['owner_fixture_sha256'],'auditor_sha256':profile['owner_auditor_sha256'],'trajectory_sha256':profile['trajectory_sha256']}
    def factory(arc_id:str,simulate:bool,actual:Budget)->object:
        assert arc_id=='forward'and simulate is True and actual is budget
        budget.acceleration_callbacks=3;return Owner()
    report=producer.probe(source.read_bytes(),source.parent/'trace.jsonl',started_s=started,deadline_s=deadline,
        prepare=prepare,import_spice=import_spice,guard_spice=guard,context=context,provenance=provenance,factory=factory)
    sys.stdout.buffer.write(producer._json_bytes(report));return 0
if __name__=='__main__':raise SystemExit(main())
