"""Run only the unresolved artificial OS-group cleanup case; no controls changed."""
from __future__ import annotations
import hashlib,json,os,sys,time,unittest
from pathlib import Path
ROOT=Path('/private/tmp/ariadna-f18-0284')
TEST='tests_outer.OuterTests.test_unchanged_caller_supervise_cleans_whole_group_after_leader_exit'

def main()->int:
    started=time.monotonic();deadline=started+300
    prior=json.loads((ROOT/'qualification.json').read_text());assert prior['tests_run']==57 and prior['errors']==1 and prior['failures']==0
    failed=[v for v in prior['records']if v['status']!='passed'];assert len(failed)==1 and failed[0]['id']==TEST
    for name,pin in json.loads((ROOT/'qualified-sources.json').read_text())['files'].items():
        data=Path(name).read_bytes();assert pin=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},name
    sys.path.insert(0,str(ROOT));suite=unittest.defaultTestLoader.loadTestsFromName(TEST)
    with(ROOT/'targeted-cleanup.stderr.log').open('x')as log:
        result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite);log.flush();os.fsync(log.fileno())
    record={'schema':'ariadna.f18.completed-cleanup-targeted.v1','status':'PASS'if result.wasSuccessful()else'FAIL',
            'test_id':TEST,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
            'limit_s':300,'elapsed_before_receipt_s':time.monotonic()-started,'prior_campaign_sha256':hashlib.sha256((ROOT/'qualification.json').read_bytes()).hexdigest(),
            'execution_profile':'Explicitly escalated OS process rights; same frozen test/control sources. Sandbox cause remains an inference.',
            'passed56_not_repeated':True,'native_episode':False,'native_authority':False,'spice_queries':0,'integrations':0}
    with(ROOT/'targeted-cleanup.json').open('x')as stream:json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    fd=os.open(ROOT,os.O_RDONLY);os.fsync(fd);os.close(fd);elapsed=time.monotonic()-started
    ok=result.wasSuccessful()and result.testsRun==1 and elapsed<300
    print(json.dumps({'status':'PASS'if ok else'FAIL','test_id':TEST,'observed_after_fsync_s':elapsed,'within300s':elapsed<300}),flush=True)
    return 0 if ok else 2
if __name__=='__main__':raise SystemExit(main())
