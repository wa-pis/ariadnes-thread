"""Observed once-only bridge for the fixed completed-owner profile.

The saved candidate remains pending. Only this direct, freshly observed and
post-seal rechecked continuation can dispatch; artificial dispatch is harmless.
"""
from __future__ import annotations

from collections.abc import Callable
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from types import ModuleType

LIVE_ROOT = Path('/private/tmp/ariadna-f18-forward-completed-v1')
ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0284/artificial')
OUTER_PYTHON = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python').resolve()
CONTRACT_SHA256 = '20397decfe63f978648cfb220778e962410f3a26cab7690449183aae33e52dd8'
ADMISSION_BYTES = 0  # Frozen from reviewed admission.py before any qualification.
ADMISSION_SHA256 = 'UNFROZEN'
_CANDIDATE_KEYS = set('schema mode status native_launch_authorized started_s elapsed_s profile_sha256 contract_sha256 resource_count source_count native_count ledger_count history_count control_count read_only_observation finalization'.split())


class GateError(RuntimeError):
    """The fixed, unconsumed completed-owner continuation cannot dispatch."""


def _need(ok: bool, message: str) -> None:
    if not ok:
        raise GateError(message)


def _number(value: object) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


# Byte-identical0280 outer-gate bounded nofollow reader.
def _read(path: Path) -> bytes:
    _need(path.is_absolute() and '..' not in path.parts, 'absolute normalized proof path required')
    for parent in reversed(path.parents):
        _need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory proof ancestor')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        _need(stat.S_ISREG(info.st_mode) and info.st_size <= 65536, 'proof type/64KiB cap')
        raw = os.read(descriptor, 65537)
        _need(len(raw) == info.st_size and len(raw) <= 65536, 'proof short/oversized read')
        return raw
    finally:
        os.close(descriptor)


def _write(path: Path, value: dict[str, object]) -> bytes:
    raw = (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()
    _need(len(raw) <= 65536, 'gate record64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(fd, raw[offset:])
            _need(0 < count <= len(raw) - offset, 'gate short write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return raw


def _load_admission(path: Path) -> ModuleType:
    raw = _read(path)
    _need(len(raw) == ADMISSION_BYTES and hashlib.sha256(raw).hexdigest() == ADMISSION_SHA256,
          'qualified completed admission source required')
    module = ModuleType('_ariadna_qualified_completed_admission')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def dispatch(profile_path: Path, *,
             artificial_observer: Callable[[Path, Path], dict[str, object]] | None = None,
             artificial_dispatch: Callable[[], object] | None = None) -> dict[str, object]:
    """Direct admission once; no saved PASS grants a resumed native attempt."""
    try:
        return _dispatch(profile_path, artificial_observer=artificial_observer,
                         artificial_dispatch=artificial_dispatch)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError) as exc:
        if isinstance(exc, GateError):
            raise
        raise GateError('completed gate: ' + str(exc)) from exc


def _dispatch(profile_path: Path, *,
              artificial_observer: Callable[[Path, Path], dict[str, object]] | None,
              artificial_dispatch: Callable[[], object] | None) -> dict[str, object]:
    if profile_path == LIVE_ROOT / 'profile.json':
        _need(artificial_observer is None and artificial_dispatch is None,
              'native replacement observer/dispatch forbidden before live reads')
    else:
        _need(profile_path.is_absolute() and '..' not in profile_path.parts
              and profile_path.is_relative_to(ARTIFICIAL_ROOT), 'fixed artificial profile prefix required')
    # No external control is imported until its qualified source has been checked.
    profile_raw = _read(profile_path)
    raw_profile = json.loads(profile_raw)
    _need(type(raw_profile) is dict and raw_profile.get('mode') in {'native', 'artificial'}, 'gate mode required')
    mode = raw_profile['mode']
    if mode == 'native':
        _need(artificial_observer is None and artificial_dispatch is None,
              'native replacement observer/dispatch forbidden')
        _need(profile_path == LIVE_ROOT / 'profile.json'
              and Path(__file__).resolve() == LIVE_ROOT / 'dispatch-once.py'
              and Path(sys.executable).resolve() == OUTER_PYTHON, 'fixed native gate/interpreter')
    else:
        _need(callable(artificial_observer) and callable(artificial_dispatch),
              'explicit harmless artificial observer/dispatch required')
    root = profile_path.parent
    admission = _load_admission(root / 'admission.py')
    p = admission._object(profile_raw)
    _need(set(p) == admission.PROFILE_KEYS, 'exact fixed profile fields required')
    tick = admission._clock(p['preflight_started_s'])
    started_s = p['preflight_started_s']
    _need(p['root'] == str(root) and p['work_directory'] == str(root / 'execution'), 'fixed completed namespace')
    contract_path, contract_pin = admission._path_pin(p['contract'])
    if mode == 'artificial':
        _need(contract_path.is_relative_to(ARTIFICIAL_ROOT), 'artificial contract escaped fake tree')
    admission._pin(contract_path, contract_pin, tick)
    contract_raw = _read(contract_path)
    profile_sha = hashlib.sha256(profile_raw).hexdigest()
    contract_sha = hashlib.sha256(contract_raw).hexdigest()
    _need(contract_sha == contract_pin['sha256'], 'contract binding')
    if mode == 'native':
        _need(contract_sha == CONTRACT_SHA256, 'official native completed contract required')
    gate_path, gate_pin = admission._path_pin(p['outer_gate'])
    python_path, python_pin = admission._path_pin(p['outer_python'])
    _need(gate_path == Path(__file__).resolve() and str(gate_path) not in p['control_pins'], 'external gate self identity')
    if mode == 'native':
        _need(python_path == OUTER_PYTHON, 'fixed outer interpreter pin')
    decision_path, decision_pin = admission._path_pin(p['execution_decision'])
    if mode == 'artificial':
        _need(all(path.is_relative_to(ARTIFICIAL_ROOT) for path in (contract_path, gate_path, decision_path)),
              'artificial proof path escaped fake tree')
        _need(python_path.is_relative_to(ARTIFICIAL_ROOT) or python_path == Path(sys.executable).resolve(),
              'harmless artificial interpreter required')
    for path, pin in ((gate_path, gate_pin), (python_path, python_pin), (decision_path, decision_pin)):
        admission._pin(path, pin, tick)
    decision_raw = _read(decision_path)
    decision = admission._object(decision_raw)
    expected_groups = {name: p[name] for name in (
        'source_pins', 'native_pins', 'resource_pins', 'ledger_pins',
        'history_member_pins', 'control_pins', 'history_archive', 'contract')}
    _need(set(decision) == {'schema', 'stage', 'mode', 'status', 'base_revision',
                           'contract_sha256', 'expected_pins', 'outer_gate_pin', 'outer_python_pin'}
          and decision['schema'] == 'ariadna.f18.completed-execution-decision.v1'
          and decision['stage'] == 'F18.16' and decision['mode'] == mode
          and decision['status'] == ('ADMITTED_ONCE' if mode == 'native' else 'ARTIFICIAL_EXECUTION_DECISION')
          and type(decision['base_revision']) is str and decision['base_revision'] == p['base_revision']
          and decision['contract_sha256'] == contract_sha
          and json.dumps(decision['expected_pins'], sort_keys=True, allow_nan=False)
              == json.dumps(expected_groups, sort_keys=True, allow_nan=False)
          and json.dumps(decision['outer_gate_pin'], sort_keys=True, allow_nan=False)
              == json.dumps(p['outer_gate'], sort_keys=True, allow_nan=False)
          and json.dumps(decision['outer_python_pin'], sort_keys=True, allow_nan=False)
              == json.dumps(p['outer_python'], sort_keys=True, allow_nan=False),
          'distinct fixed execution decision required')
    start, candidate, launch = (root / name for name in
                                ('gate-start.json', 'admission-check.json', 'launch-admission.json'))
    for path in (start, candidate, launch, root / 'episode-start.json', root / 'execution'):
        _need(not os.path.lexists(path), 'occupied once-only completed namespace: ' + str(path))
    marker: dict[str, object] = {'schema': 'ariadna.f18.completed-gate-start.v1', 'mode': mode,
        'started_s': started_s, 'elapsed_s': tick(), 'profile_sha256': profile_sha,
        'contract_sha256': contract_sha, 'execution_decision_sha256': decision_pin['sha256'],
        'outer_gate_pin': p['outer_gate'], 'retry_authorized': False}
    marker_raw = _write(start, marker)
    tick()
    returned = admission.admit(profile_path, artificial_observer=artificial_observer)
    candidate_raw = _read(candidate)
    pending = admission._object(candidate_raw)
    candidate_sha = hashlib.sha256(candidate_raw).hexdigest()
    elapsed = tick()
    _need(type(returned) is dict and set(pending) == _CANDIDATE_KEYS
          and set(returned) == _CANDIDATE_KEYS | {'receipt_sha256'},
          'exact returned/pending admission shapes')
    _need(pending['schema'] == 'ariadna.f18.completed-admission.v1' and pending['mode'] == mode
          and pending['status'] == 'PENDING_DURABLE_ADMISSION'
          and pending['native_launch_authorized'] is False
          and pending['finalization'] == 'pending-outer-readback', 'disk candidate is pending only')
    _need(returned['status'] == ('PASS_NATIVE_ADMISSION_ONLY' if mode == 'native' else 'ARTIFICIAL_READY')
          and returned['native_launch_authorized'] is False
          and returned['finalization'] == 'checked-after-fsync'
          and returned['receipt_sha256'] == candidate_sha, 'observed direct admission required')
    _need(_number(pending['elapsed_s']) and _number(returned['elapsed_s'])
          and 0 <= pending['elapsed_s'] <= returned['elapsed_s'] <= elapsed, 'ordered original600s observations')
    _need(_number(pending['started_s']) and pending['started_s'] == started_s, 'original admission start binding')
    for field, expected in (('resource_count', 11), ('source_count', 53), ('native_count', 10),
                            ('ledger_count', 25), ('history_count', 86), ('control_count', 8)):
        _need(type(pending[field]) is int and pending[field] == expected, 'exact admission count: ' + field)
    _need(pending['profile_sha256'] == profile_sha and pending['contract_sha256'] == contract_sha,
          'admission bound to original profile/contract')
    for field in set(pending) - {'status', 'elapsed_s', 'finalization'}:
        _need(json.dumps(returned[field], sort_keys=True, allow_nan=False)
              == json.dumps(pending[field], sort_keys=True, allow_nan=False), 'returned admission drift: ' + field)

    def recheck() -> None:
        tick()
        _need(_read(profile_path) == profile_raw and _read(contract_path) == contract_raw
              and _read(candidate) == candidate_raw and _read(start) == marker_raw
              and _read(decision_path) == decision_raw, 'proof changed after observed admission')
        admission._pin(gate_path, gate_pin, tick)
        admission._pin(python_path, python_pin, tick)
        _need(hashlib.sha256(_read(root / 'admission.py')).hexdigest() == ADMISSION_SHA256,
              'qualified admission changed')
        repo = Path(p['repo'])
        for field in ('source_pins', 'native_pins', 'ledger_pins', 'control_pins'):
            for path, pin in admission._canonical_group(p[field], repo).items():
                admission._pin(Path(path), pin, tick)
        for row in p['resource_pins']:
            admission._pin(Path(p['resource_directory']) / row['name'],
                           {k: row[k] for k in ('bytes', 'sha256')}, tick)
        resource_names: set[str] = set()
        resources = Path(p['resource_directory'])
        for directory, dirs, files in os.walk(resources, followlinks=False):
            _need(all(not (Path(directory) / name).is_symlink() for name in dirs),
                  'resource directory changed to symlink')
            resource_names.update(str((Path(directory) / name).relative_to(resources)) for name in files)
            tick()
        _need(resource_names == {row['name'] for row in p['resource_pins']},
              'resource inventory changed after admission')
        history_path, history_pin = admission._path_pin(p['history_archive'])
        admission._pin(history_path, history_pin, tick)
        _need(not os.path.lexists(root / 'episode-start.json') and not os.path.lexists(root / 'execution'),
              'episode/work became occupied')
        tick()

    recheck()
    ready: dict[str, object] = {'schema': 'ariadna.f18.completed-launch-admission.v1',
        'status': 'PASS' if mode == 'native' else 'ARTIFICIAL_READY', 'mode': mode,
        'native_launch_authorized': mode == 'native', 'started_s': started_s,
        'elapsed_s': tick(), 'profile_sha256': profile_sha, 'contract_sha256': contract_sha,
        'admission_receipt_sha256': candidate_sha, 'execution_decision_sha256': decision_pin['sha256'],
        'gate_start_sha256': hashlib.sha256(marker_raw).hexdigest(), 'outer_gate_pin': p['outer_gate'],
        'outer_python_pin': p['outer_python'], 'finalization': 'pending-outer-dispatch', 'retry_authorized': False}
    ready_raw = _write(launch, ready)
    recheck()
    _need(_read(launch) == ready_raw, 'final launch seal changed')
    tick()
    if mode == 'native':
        os.execv(str(OUTER_PYTHON), [str(OUTER_PYTHON), '-I', '-B', str(root / 'run-once.py')])
        raise GateError('native exec unexpectedly returned; attempt remains consumed')
    assert artificial_dispatch is not None
    artificial_dispatch()
    tick()
    return dict(ready, elapsed_s=time.monotonic() - started_s, finalization='checked-after-fsync')


if __name__ == '__main__':
    try:
        _need(sys.argv[1:] == [str(LIVE_ROOT / 'profile.json')], 'fixed native argument path required')
        dispatch(LIVE_ROOT / 'profile.json')
    except (GateError, OSError, ValueError, TypeError) as error:
        print(('completed gate refused: ' + str(error))[:2048], file=sys.stderr)
        raise SystemExit(2)
