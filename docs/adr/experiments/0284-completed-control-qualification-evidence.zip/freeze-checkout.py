from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0284')
names=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0')
files={}
for n in names:
 if not n:continue
 q=r/n;b=q.read_bytes();files[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
state={'schema':'ariadna.f18.completed-controls-frozen-checkout.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'git_status':subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True),'files':files}
assert state['head']=='8d7532d20827d691b93043b90d1ef8aa8664122e'and not state['git_status']
if sys.argv[1]=='after':
 before=json.loads((p/'frozen-before.json').read_text());assert state==before
for n,v in json.loads((p/'qualified-sources.json').read_text())['files'].items():
 b=Path(n).read_bytes();assert v=={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},n
with(p/('frozen-'+sys.argv[1]+'.json')).open('x')as f:json.dump(state,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'status':'PASS','phase':sys.argv[1],'tracked_files':len(files),'head':state['head'],'git_status':'clean'}))
