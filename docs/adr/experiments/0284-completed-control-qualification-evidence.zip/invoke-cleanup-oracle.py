"""Observe one bounded artificial campaign through cleanup and durable receipts."""
from __future__ import annotations
import hashlib,json,os,selectors,signal,subprocess,time
from pathlib import Path
ROOT=Path('/private/tmp/ariadna-f18-0284')
PYTHON='/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python'

def main()->int:
    start=time.monotonic();deadline=start+300
    process=subprocess.Popen([PYTHON,'-I','-B',str(ROOT/'complete-cleanup-oracle.py')],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    assert process.stdout is not None and process.stderr is not None
    retained={1:bytearray(),2:bytearray()};failure=None
    try:
        with selectors.DefaultSelector()as selector:
            selector.register(process.stdout,selectors.EVENT_READ,1);selector.register(process.stderr,selectors.EVENT_READ,2)
            while selector.get_map():
                if time.monotonic()>=deadline:raise RuntimeError('artificial300s deadline')
                for key,_ in selector.select(.05):
                    data=os.read(key.fileobj.fileno(),8192)
                    if not data:selector.unregister(key.fileobj);continue
                    available=max(0,65536-sum(len(v)for v in retained.values()))
                    retained[key.data].extend(data[:available])
                    if len(data)>available:raise RuntimeError('artificial combined log64KiB cap')
            process.wait(timeout=max(.001,deadline-time.monotonic()))
    except (RuntimeError,OSError,subprocess.TimeoutExpired)as exc:
        failure=f'{type(exc).__name__}: {exc}'
    finally:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=1);process.stdout.close();process.stderr.close()
        for name in ('supervisor.pgid','parent.pgid'):
            for path in (ROOT/'artificial').rglob(name):
                if path.is_symlink():continue
                data=path.read_bytes()
                if len(data)<=32 and data.strip().isdigit():
                    group=int(data)
                    if group>1 and group not in(os.getpid(),os.getpgrp()):
                        try:os.killpg(group,signal.SIGKILL)
                        except ProcessLookupError:pass
    for name,data in(('cleanup-oracle-outer.stdout.json',retained[1]),('cleanup-oracle-outer.stderr.log',retained[2])):
        with(ROOT/name).open('xb')as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    result={'schema':'ariadna.f18.completed-cleanup-cleanup-oracle-outer.v1','returncode':process.returncode,'failure':failure,'started_s':start,'limit_s':300,'elapsed_before_receipt_s':time.monotonic()-start,'stdout_bytes':len(retained[1]),'stderr_bytes':len(retained[2]),'qualified_child_sha256':hashlib.sha256((ROOT/'complete-cleanup-oracle.py').read_bytes()).hexdigest()}
    with(ROOT/'cleanup-oracle-outer.json').open('x')as stream:json.dump(result,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    fd=os.open(ROOT,os.O_RDONLY);os.fsync(fd);os.close(fd)
    observed=time.monotonic()-start
    ok=process.returncode==0 and failure is None and observed<300
    print(json.dumps({'status':'PASS'if ok else'FAIL','observed_after_outer_fsync_s':observed,'returncode':process.returncode,'failure':failure,'stdout_bytes':len(retained[1]),'stderr_bytes':len(retained[2])}),flush=True)
    return 0 if ok else 2
if __name__=='__main__':raise SystemExit(main())
