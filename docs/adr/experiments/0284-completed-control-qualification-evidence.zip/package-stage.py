from pathlib import Path
import hashlib,json,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0284');e=r/'docs/adr/experiments'
x=json.loads((p/'qualification-summary.json').read_text());assert x['status']=='PASS_ARTIFICIAL_QUALIFICATION_ONLY'
files=sorted(q for q in p.rglob('*')if q.is_file()and'artificial'not in q.relative_to(p).parts)
expanded=sum(q.stat().st_size for q in files);assert expanded<2097152
index={str(q.relative_to(p)):{'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}for q in files}
archive=e/'0284-completed-control-qualification-evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for q in files:z.write(q,str(q.relative_to(p)))
x['evidence_archive']={'path':str(archive.relative_to(r)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'expanded_bytes':expanded,'member_count':len(index),'members':index}
with(e/'0284-completed-control-qualification.json').open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
adr=r/'docs/adr/0284-qualify-completed-owner-controls.md';assert not adr.exists();adr.write_text((p/'adr-draft.md').read_text())
common='''[ADR0284](../../../docs/adr/0284-qualify-completed-owner-controls.md) completes
F18.15a artificial qualification only:57distinct cases satisfied across59method
executions; initial56pass/1EPERMerror and unchanged target1error preserved, then
only revised failure-path oracle1pass with independent known-PID inactivity proof.
Nine controls and other56methods unchanged;1600checkout files/status frozen.
Two raw real-probe/fake-owner→guarded-audit positive packets independently reviewed.
No native-positive/reaping/physical qualification. Scheduler PAUSED pending the
separate F18.16 execution choice; original actual600s/60s45-10-5 limits unchanged.

'''
for n in ('proposal','design','tasks'):
 q=r/f'openspec/changes/refine-physical-trajectory/{n}.md';s=q.read_text();pos=s.index('[ADR0283]');s=s[:pos]+common+s[pos:]
 if n=='tasks':
  marker='- [ ] F18.15a Prepare';assert marker in s;s=s.replace(marker,'- [x] F18.15a Prepare',1)
  line_start=s.index('- [x] F18.15a Prepare');line_end=s.index('\n',line_start)
  s=s[:line_end]+' ADR0284: artificial qualification accepted;57unique cases/59method executions, two EPERM failures retained,56successes not repeated, corrected failure-oracle1PASS with actual kill-call and independent no-running-owned-PID witness; all9controls unchanged. Both raw positive packets and1600file/status freeze independently reviewed. Native/reaping/physical path remains unqualified; PAUSED for distinct F18.16 choice.'+s[line_end:]
 q.write_text(s)
q=r/'openspec/ROADMAP.md';s=q.read_text();pos=s.index('[ADR0283]');s=s[:pos]+common.replace('../../../docs/adr/','../docs/adr/')+s[pos:];q.write_text(s)
q=r/'docs/adr/README.md';s=q.read_text();pos=s.index('- [0283');s=s[:pos]+'- [0284 — Completed-owner outer-control qualification](0284-qualify-completed-owner-controls.md) — F18.15a artificial scope complete;57unique cases across59executions, two failures preserved and one failure-oracle correction with independent process witness. Native F18.16 awaits distinct choice; scheduler paused.\n\n'+s[pos:];q.write_text(s)
q=r/'openspec/changes/refine-physical-trajectory/specs/research-trajectory-experiment/spec.md';s=q.read_text();needle='### Requirement: Bound realized-clock evidence without changing commands';assert needle in s
scenario='''#### Scenario: Independently witness cleanup refusal without masking it

- **WHEN** an artificial leader-exit cleanup case raises EPERM instead of returning a failure object
- **THEN** qualification SHALL preserve the original failure and SHALL NOT suppress that runtime exception or infer its cause; a revised failure-path oracle MAY accept refusal only after recording the actual first successful group SIGKILL, the exact owned PID/PGID/UID identities and a bounded independent raw process witness proving no running owned member
- **AND** malformed/unknown identity, failed first kill, unexpected exception, live member or failed witness SHALL fail qualification; verified absence or a non-running zombie SHALL NOT imply general reaping, native caller success or physical qualification
- **AND** the revised test/source pins and prior successes SHALL remain separately attributable, passed unchanged cases SHALL NOT be repeated without reason, and raw positive producer/auditor/outer observations SHALL be retained and independently reviewed before F18.15a completion; F18.16 still requires its distinct recorded choice and fresh actual admission

'''
s=s.replace(needle,scenario+needle);q.write_text(s)
(r/'CURRENT_STATE.md').write_text('''# Current State

Updated: 2026-11-27. Keep under60lines; durable evidence in ADRs.

## Current result
[ADR0284](docs/adr/0284-qualify-completed-owner-controls.md): F18.15a artificial
outer-control qualification complete.57distinct cases satisfied across59executions:
initial56pass/1EPERMerror, unchangedtarget1error, revisedfailureoracle1pass.
BothFAILs retained;56successfulmethods not repeated; ninecontrol bytes unchanged.
Revisedtest requires actual firstSIGKILL success, visible secondEPERM refusal and
independent bounded known-PID inactivity proof. No nativecaller-success/reaping claim.
Two raw actualprobe/sixfakehooks→separate guarded-auditor positive packets saved
and independently reviewed.1600trackedfiles/status frozen; image detached.
[Result](docs/adr/experiments/0284-completed-control-qualification.json).
Original source/science/oldtests/CI/deps preserved. Prior0282required8688passes/
42archivalskips/Ruff unchanged; no repeat and no new native/SPICE/integration.

## Next action and scheduler
ariadna-m3 PAUSED pending distinct F18.16 execution choice required by OpenSpec.
Concrete proposal: one original synthetic forwardTrue→metadata→same-owner endpoint
at elapsed1000s; fresh independently observed actualpreflight<=600s, then60s
inclusive45/10/5, unchanged SI gates/53source/10native/11resources/25oldledger/
86history identities and exact qualified8controls+externalgate. No retry/acquisition.
Actualnamespace /private/tmp/ariadna-f18-forward-completed-v1 not created.
Artificial PASS never admits native; sandbox/private-native-CLI positive unverified.
If chosen, record choice first and bind qualified bytes to clean committeddev before
fresh readonly admission/once-only consumption. Preserve consumed0280namespace;
F18.9unqualified and0269cause/countsUNKNOWN. Do not repeat successful campaigns.

## Physical goal remains open
ADR0247 F0/hardware/sixcontrols unchanged. Full0267owner/lifetime/carry/concurrency/
fullcoreABI-FP/priorarithmetic/fullforce seed/derivatives/guards/endpointbounds open.
No admissiblepair,99percentprobability,physicalclosure/safety; strictM3/task3.9 and
M4–M6/ML/UI gates unchanged. Preserve moon_to_mars.py/main/remotes/history; devonly.
''')
print(json.dumps({'archive_bytes':archive.stat().st_size,'expanded_bytes':expanded,'members':len(index),'unique_cases':x['unique_cases_satisfied']}))
