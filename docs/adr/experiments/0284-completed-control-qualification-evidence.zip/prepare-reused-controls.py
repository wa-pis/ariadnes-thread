from pathlib import Path
import hashlib,json,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0284');c=p/'controls'
old='/private/tmp/ariadna-f18-supplemented-setup-v1';new='/private/tmp/ariadna-f18-forward-completed-v1'
with zipfile.ZipFile(r/'docs/adr/experiments/0280-supplemented-setup-evidence.zip')as z:
 for n in ('call-once.py','launch-once.py','native.sandbox','check-preservation.py'):
  b=z.read(n);out=b if n in('call-once.py','launch-once.py')else b.replace(old.encode(),new.encode());assert n in('call-once.py','launch-once.py')or b.count(old.encode())==1
  with(c/n).open('xb')as f:f.write(out)
 b=z.read('run-once.py');s=b.decode().replace(old,new).replace('ariadna.f18.setup-caller-tool-observation.v1','ariadna.f18.completed-caller-tool-observation.v1')
 insertion='''\ndef sync_directories(root: Path, deadline_s: float) -> None:
    """Seal every containing directory before terminal original-clock observation."""
    directories = [root]
    for path in root.rglob('*'):
        if path.is_symlink():
            raise RuntimeError('symlink in enclosing evidence tree')
        if path.is_dir():
            directories.append(path)
    for path in sorted(directories, key=lambda item: len(item.parts), reverse=True):
        if time.monotonic() >= deadline_s:
            raise RuntimeError('original deadline exhausted before directory fsync')
        descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        if time.monotonic() >= deadline_s:
            raise RuntimeError('original deadline exhausted after directory fsync')
\n'''
 s=s.replace("p=Path('"+new+"')",insertion+"p=Path('"+new+"')",1)
 s=s.replace('observed=time.monotonic()-start if start is not None else None',"sync_directories(p, start+60 if start is not None else entered+65)\nobserved=time.monotonic()-start if start is not None else None",1)
 with(c/'run-once.py').open('x')as f:f.write(s)
print('Five reused/narrow changed controls prepared without execution')
