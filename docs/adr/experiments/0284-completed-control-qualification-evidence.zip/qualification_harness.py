"""Artificial fixtures only; importing creates no files or native context."""
from __future__ import annotations
import hashlib,importlib.util,json,os,shutil,subprocess,sys,time,zipfile
from pathlib import Path
from typing import Any

ROOT=Path('/private/tmp/ariadna-f18-0284')
ARTIFICIAL=ROOT/'artificial'
REPO=Path('/Users/agrudin/dev/my/ariadna')
PYTHON=Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python3.12').resolve()
CONTROL_NAMES=('call-once.py','launch-once.py','native.sandbox','check-preservation.py','run-once.py','native-entry.py','supervisor-adapter.py','admission.py')
EXPECTED_GROUPS=('source_pins','native_pins','resource_pins','ledger_pins','history_member_pins','control_pins','history_archive','contract')

def raw(value:object)->bytes:
    return (json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode()

def pin(path:Path)->dict[str,object]:
    data=path.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def path_pin(path:Path)->dict[str,object]:
    return {'path':str(path),**pin(path)}

def save(path:Path,value:object)->None:
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw(value))

def load_control(name:str,source:Path|None=None)->Any:
    path=ROOT/'controls'/name if source is None else source
    spec=importlib.util.spec_from_file_location('qualification_'+name.replace('-','_').replace('.','_')+str(time.monotonic_ns()),path)
    assert spec is not None and spec.loader is not None
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def observer(image:Path,mount:Path)->dict[str,object]:
    return {'image':str(image),'mount':str(mount),'read_only':True,'capacity_bytes':8*1024**3}

def bind_profile(profile_path:Path,profile:dict[str,Any])->None:
    """Refresh declared fake decision/profile after a deliberate test mutation."""
    decision={'schema':'ariadna.f18.completed-execution-decision.v1','stage':'F18.16',
              'mode':'artificial','status':'ARTIFICIAL_EXECUTION_DECISION',
              'base_revision':profile['base_revision'],'contract_sha256':profile['contract']['sha256'],
              'expected_pins':{k:profile[k]for k in EXPECTED_GROUPS},
              'outer_gate_pin':profile['outer_gate'],'outer_python_pin':profile['outer_python']}
    target=Path(profile['execution_decision']['path'])
    save(target,decision);profile['execution_decision']=path_pin(target);save(profile_path,profile)

def make_profile(case_dir:Path)->tuple[Path,dict[str,Any]]:
    """Full cardinality/full resource-volume fake profile, never native authority."""
    assert case_dir.is_relative_to(ARTIFICIAL) and not case_dir.exists()
    case_dir.mkdir(parents=True)
    episode=case_dir/'episode';episode.mkdir()
    fixture=case_dir/'fixtures';fixture.mkdir()
    controls=ROOT/'controls'
    for name in (*CONTROL_NAMES,'dispatch-once.py'):shutil.copyfile(controls/name,episode/name)
    source={}
    for index in range(53):
        path=fixture/'sources'/f'source-{index:02d}.py';path.parent.mkdir(exist_ok=True);path.write_text(f'# fabricated source role{index}\n');source[str(path)]=pin(path)
    native={}
    for index in range(10):
        path=fixture/'native'/f'role-{index:02d}.bin';path.parent.mkdir(exist_ok=True);path.write_bytes(f'not executable: native role{index}'.encode());native[str(path)]=pin(path)
    ledger={}
    for index in range(25):
        path=fixture/'ledger'/f'proof-{index:02d}.json';save(path,{'fake_old_ledger':index});ledger[str(path)]=pin(path)
    with zipfile.ZipFile(REPO/'docs/adr/experiments/0283-completed-control-mapping-evidence.zip')as z:
        real=json.loads(z.read('mapping-v2.json'))
    resource_directory=fixture/'volume'/'resources';rows=[]
    for index,row in enumerate(real['retained_resources']):
        path=resource_directory/row['name'];path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(bytes([65+index])*row['bytes']);rows.append({'name':row['name'],**pin(path)})
    history_archive=fixture/'history.zip';members={}
    with zipfile.ZipFile(history_archive,'x',compression=zipfile.ZIP_DEFLATED)as z:
        for index,name in enumerate(real['historical_0280_member_pins']):
            data=b''if name.endswith('.log')else raw({'fabricated_history_member':name,'index':index})
            z.writestr(name,data);members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    image=fixture/'fake-image.bin';image.write_bytes(b'not a disk image')
    environment={'PYTHONPATH':str(REPO/'src'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1',
                 'LANG':'C','LC_ALL':'C','PATH':'/usr/bin:/bin:/usr/sbin:/sbin'}
    contract={'schema':'ariadna.f18.completed-control-mapping.v1','qualification':'ARTIFICIAL',
              'old_source_pins':dict(list(source.items())[:49]),'appended_source_pins':dict(list(source.items())[49:]),
              'native_pins':native,'retained_resources':rows,'historical_ledger_pins':ledger,
              'historical_0280_member_pins':members,'environment_unchanged':environment,
              'reference_archive':path_pin(history_archive)}
    contract_path=fixture/'mapping.json';save(contract_path,contract)
    package=REPO/'src/space_nav';kernel=Path(next(iter(native)))
    fields={'probe_sha256':'_owner_completed_probe.py','owner_fixture_sha256':'_owner_endpoint_fixture.py',
            'owner_auditor_sha256':'_owner_endpoint_audit.py','trajectory_sha256':'trajectory.py',
            'completed_auditor_sha256':'_owner_completed_audit.py'}
    probe={'schema':'ariadna-owner-completed-input-v1','scope':'single-forward-completed-owner-only','mode':'injected',
           'kernel_path':str(kernel),'kernel_sha256':pin(kernel)['sha256'],
           **{key:pin(package/name)['sha256']for key,name in fields.items()}}
    profile={'schema':'ariadna.f18.completed-control-profile.v1','scope':'single-forward-completed-owner-only',
        'mode':'artificial','repo':str(REPO),'base_revision':'8d7532d20827d691b93043b90d1ef8aa8664122e',
        'root':str(episode),'work_directory':str(episode/'execution'),'preflight_started_s':time.monotonic(),
        'outer_python':path_pin(PYTHON),'private_python':str(PYTHON),'environment':environment,
        'sandbox_profile':str(episode/'native.sandbox'),'source_pins':source,'native_pins':native,
        'resource_pins':rows,'resource_directory':str(resource_directory),'image':str(image),'mount':str(fixture/'volume'),
        'ledger_pins':ledger,'history_archive':path_pin(history_archive),'history_member_pins':members,
        'control_pins':{str(episode/name):pin(episode/name)for name in CONTROL_NAMES},
        'outer_gate':path_pin(episode/'dispatch-once.py'),'contract':path_pin(contract_path),
        'kernel_sha256':probe['kernel_sha256'],'probe_input':probe,
        'entry_sha256':pin(episode/'native-entry.py')['sha256'],'launch_sha256':pin(episode/'launch-once.py')['sha256'],
        'caller_sha256':pin(episode/'call-once.py')['sha256'],'adapter_sha256':pin(episode/'supervisor-adapter.py')['sha256'],
        'sandbox_sha256':pin(episode/'native.sandbox')['sha256'],'prelaunch_admission':str(episode/'launch-admission.json'),
        'execution_decision':{'path':str(fixture/'decision.json'),'bytes':0,'sha256':'0'*64}}
    wrapper=case_dir/'probe-wrapper.py';shutil.copyfile(ROOT/'artificial-probe.py',wrapper)
    profile_path=episode/'profile.json';bind_profile(profile_path,profile)
    assert len(profile_path.read_bytes())<65536 and sum(v['bytes']for v in rows)==3710549
    return profile_path,profile

def artificial_commands(case_dir:Path)->dict[str,object]:
    path=case_dir/'probe-wrapper.py'
    return {'producer':path_pin(path),'audit':None}

def run_entry(profile_path:Path,commands:object,started_s:float|None=None)->dict[str,Any]:
    profile=json.loads(profile_path.read_bytes());work=Path(profile['work_directory']);work.mkdir()
    started=time.monotonic()if started_s is None else started_s
    command=[str(PYTHON),'-I','-B',str(ROOT/'artificial-entry.py'),str(profile_path),repr(started),json.dumps(commands)]
    process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        out,err=process.communicate(timeout=max(.01,min(65,started+60-time.monotonic())))
    except subprocess.TimeoutExpired:
        out=err=b''
        raise
    finally:
        try:os.killpg(process.pid,9)
        except ProcessLookupError:pass
        process.wait(timeout=1)
    gone=False
    until=min(started+60,time.monotonic()+.2)
    while time.monotonic()<until:
        try:os.killpg(process.pid,0)
        except ProcessLookupError:gone=True;break
        time.sleep(.005)
    return {'returncode':process.returncode,'exit_code':process.returncode,'elapsed_s':time.monotonic()-started,'group_gone':gone,'stdout':out,'stderr':err,
            'report':json.loads(out)if out else None,'entry_pgid':process.pid}

retained_positives: dict[str,dict[str,object]] = {}

def retain_positive(name:str,episode:Path,returned:bytes)->None:
    """Retain successful artificial raw bytes before unittest fixture cleanup."""
    assert episode.is_relative_to(ARTIFICIAL) and len(returned)<=65536
    profile=json.loads((episode/'profile.json').read_bytes())
    assert profile['mode']=='artificial' and profile['probe_input']['mode']=='injected'
    kernel=Path(profile['probe_input']['kernel_path']);assert kernel.is_relative_to(ARTIFICIAL)
    target=ROOT/'retained'/name;target.mkdir(parents=True,exist_ok=False)
    shutil.copytree(episode/'execution',target/'execution',symlinks=False)
    shutil.copyfile(episode/'profile.json',target/'profile.json')
    shutil.copyfile(kernel,target/'fabricated-kernel.bin')
    (target/'outer-return.json').write_bytes(returned)
    files={}
    for path in target.rglob('*'):
        if path.is_file():
            data=path.read_bytes();files[str(path.relative_to(target))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
            with path.open('rb')as stream:os.fsync(stream.fileno())
    assert sum(v['bytes']for v in files.values())<2097152
    dirs=[target,*[v for v in target.rglob('*')if v.is_dir()]]
    for path in sorted(dirs,key=lambda v:len(v.parts),reverse=True):
        fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
    fd=os.open(target.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
    retained_positives[name]={'files':files,'scope':'Artificial raw bytes, original path labels preserved; no replay or native-positive claim.'}
