import ast,hashlib,json,pathlib
p=pathlib.Path('/private/tmp/ariadna-f18-0284')
refs=pathlib.Path('/private/tmp/ariadna-f18-0283')
rows=[]
for oldname,newname,names in [('reference-admission.py','admission.py',['_directory','_read','_object','_live_observation']),('reference-dispatch-once.py','dispatch-once.py',['_read'])]:
 old=(refs/oldname).read_text();new=(p/'controls'/newname).read_text()
 oldnodes={x.name:x for x in ast.parse(old).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))};newnodes={x.name:x for x in ast.parse(new).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
 for name in names:
  a=oldnodes[name];b=newnodes[name]
  original='\n'.join(old.splitlines()[a.lineno-1:a.end_lineno])
  current='\n'.join(new.splitlines()[b.lineno-1:b.end_lineno])
  assert original==current,(newname,name)
  rows.append({'old_path':str(refs/oldname),'old_lines':[a.lineno,a.end_lineno],'new_path':str(p/'controls'/newname),'new_lines':[b.lineno,b.end_lineno],'function':name,'bytes':len(current.encode()),'sha256':hashlib.sha256(current.encode()).hexdigest(),'classification':'byte-identical low-level primitive'})
for name in ['admission.py','dispatch-once.py']:
 ast.parse((p/'controls'/name).read_text())
ast.parse((p/'tests_admission.py').read_text())
result={'schema':'ariadna.f18.completed-admission-lowlevel-reuse.v1','status':'PASS_STATIC_ONLY','byte_identical_primitives':rows,'changed_primitives':{'admission._pin':'new exact-pin validation; retain nofollow/hashwalk, allow nonnegative length for zero-byte historical logs and check clock after read','number':'reject integer-overflow/nonfinite/bool','authority':'old admit()/dispatch authority not imported or reused; fixed new schema/counts/history/resources/control bindings'},'control_imports_or_tests':0,'native_mount_spice_integration':0}
(p/'admission-reuse-static.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'reused_primitives':len(rows)}))
