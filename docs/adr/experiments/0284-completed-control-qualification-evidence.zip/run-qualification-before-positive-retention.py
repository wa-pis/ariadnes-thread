"""One externally supervised artificial campaign; no native authority is produced."""
from __future__ import annotations
import hashlib,json,os,sys,time,traceback,unittest
from pathlib import Path
from typing import Any
ROOT=Path('/private/tmp/ariadna-f18-0284')

class Result(unittest.TextTestResult):
    records:list[dict[str,Any]]
    def __init__(self,*args:Any,**kwargs:Any)->None:
        super().__init__(*args,**kwargs);self.records=[];self.began=0.0
    def startTest(self,test:unittest.TestCase)->None:
        self.began=time.monotonic();super().startTest(test)
    def _record(self,test:unittest.TestCase,status:str)->None:
        self.records.append({'id':test.id(),'status':status,'elapsed_s':time.monotonic()-self.began})
    def addSuccess(self,test:unittest.TestCase)->None:
        self._record(test,'passed');super().addSuccess(test)
    def addFailure(self,test:unittest.TestCase,err:Any)->None:
        self._record(test,'failed');super().addFailure(test,err)
    def addError(self,test:unittest.TestCase,err:Any)->None:
        self._record(test,'error');super().addError(test,err)
    def addSkip(self,test:unittest.TestCase,reason:str)->None:
        self._record(test,'skipped');super().addSkip(test,reason)

def main()->int:
    target=Path(sys.argv[1]);started=float(sys.argv[2]);deadline=float(sys.argv[3]);assert deadline==started+300
    frozen=json.loads((ROOT/'qualified-sources.json').read_text())
    for name,pin in frozen['files'].items():
        data=Path(name).read_bytes();assert pin=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},name
    assert time.monotonic()<deadline
    sys.path.insert(0,str(ROOT))
    suite=unittest.defaultTestLoader.loadTestsFromNames(['tests_admission','tests_collector','tests_outer'])
    result=unittest.TextTestRunner(stream=sys.stderr,verbosity=2,resultclass=Result).run(suite)
    output={'schema':'ariadna.f18.completed-controls-artificial-qualification.v1','status':'PASS'if result.wasSuccessful()else'FAIL',
        'started_s':started,'deadline_s':deadline,'limit_s':300,'prefinal_elapsed_s':time.monotonic()-started,
        'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
        'records':result.records,'actual_native_episode':False,'native_authority':False,'mounts':0,'spice_queries':0,'integrations':0,
        'qualification_scope':['Real entry function/collector -> actual probe sixfakehooks -> separate actualguarded auditor, artificial input mode injected.',
            'Unchanged launcher exact native command asserted, actual execution seam replaced by harmless entry-function child; sandbox/private-native-CLI unexercised.',
            'Unchanged caller.supervise actual child/group cleanup, not full nativepacket positive.',
            'Changed run-once test-only root literal translation and harmless callerfixture; original/translated sources checked.',
            'Full-count fabricated53source/10native/11resources3710549B/25ledger/86history and8controls+externalgate admission, no nativepositive.']}
    with target.open('x')as stream:json.dump(output,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    fd=os.open(target.parent,os.O_RDONLY);os.fsync(fd);os.close(fd)
    elapsed=time.monotonic()-started
    print(json.dumps({'status':output['status'],'tests_run':result.testsRun,'observed_after_result_fsync_s':elapsed,'within300s':elapsed<300}),flush=True)
    return 0 if result.wasSuccessful()and elapsed<300 else 2
if __name__=='__main__':raise SystemExit(main())
