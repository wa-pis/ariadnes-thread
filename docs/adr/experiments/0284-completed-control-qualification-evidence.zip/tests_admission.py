"""Fabricated completed admission/gate only; execute solely in frozen campaign."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from types import ModuleType
import unittest
from unittest.mock import patch

from qualification_harness import make_profile

ROOT = Path('/private/tmp/ariadna-f18-0284/artificial')


def _load(path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location('artificial_' + path.stem.replace('-', '_'), path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _encode(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def _readonly(image: Path, mount: Path) -> dict[str, object]:
    return {'image': str(image), 'mount': str(mount), 'read_only': True, 'capacity_bytes': 8388608}


class AdmissionTests(unittest.TestCase):
    def setUp(self) -> None:
        ROOT.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix='admission-', dir=ROOT)
        self.addCleanup(self.temp.cleanup)
        self.path, self.profile = make_profile(Path(self.temp.name) / 'case')
        self.case = self.path.parent
        self.admission = _load(self.case / 'admission.py')

    def save(self) -> None:
        self.path.write_bytes(_encode(self.profile))

    def admit(self, observer: object = _readonly) -> dict[str, object]:
        return self.admission.admit(self.path, artificial_observer=observer)

    def test_full_volume_and_all_preserved_group_counts(self) -> None:
        result = self.admit()
        self.assertEqual(result['status'], 'ARTIFICIAL_READY')
        self.assertIs(result['native_launch_authorized'], False)
        self.assertEqual(result['finalization'], 'checked-after-fsync')
        self.assertEqual([result[k] for k in ('source_count', 'native_count', 'resource_count',
                                             'ledger_count', 'history_count', 'control_count')],
                         [53, 10, 11, 25, 86, 8])
        self.assertEqual(sum(row['bytes'] for row in self.profile['resource_pins']), 3710549)
        raw = (self.case / 'admission-check.json').read_bytes()
        pending = json.loads(raw)
        self.assertEqual(pending['status'], 'PENDING_DURABLE_ADMISSION')
        self.assertEqual(pending['finalization'], 'pending-outer-readback')
        self.assertIs(pending['native_launch_authorized'], False)
        self.assertEqual(result['receipt_sha256'], hashlib.sha256(raw).hexdigest())
        self.assertGreaterEqual(result['elapsed_s'], pending['elapsed_s'])
        self.assertFalse((self.case / 'execution').exists())

    def test_empty_history_logs_are_preserved(self) -> None:
        empty = [pin for pin in self.profile['history_member_pins'].values() if pin['bytes'] == 0]
        self.assertTrue(empty)
        self.assertTrue(all(pin['sha256'] == hashlib.sha256(b'').hexdigest() for pin in empty))
        self.assertEqual(self.admit()['status'], 'ARTIFICIAL_READY')

    def test_native_replacement_is_rejected_before_any_read(self) -> None:
        with patch.object(self.admission, '_read', side_effect=AssertionError('live read')):
            with self.assertRaisesRegex(self.admission.AdmissionError, 'replacement observer'):
                self.admission.admit(self.admission.LIVE_ROOT / 'profile.json', artificial_observer=_readonly)

    def test_artificial_requires_explicit_observer(self) -> None:
        with self.assertRaisesRegex(self.admission.AdmissionError, 'artificial observer'):
            self.admit(None)

    def test_native_mode_rejects_override_before_pin_reads(self) -> None:
        self.profile['mode'] = 'native'
        self.save()
        with patch.object(self.admission, '_pin', side_effect=AssertionError('live pin')):
            with self.assertRaisesRegex(self.admission.AdmissionError, 'replacement observer'):
                self.admit()

    def test_profile_extra_command_field_refuses(self) -> None:
        self.profile['commands'] = {'producer': ['/bin/true']}
        self.save()
        with self.assertRaisesRegex(self.admission.AdmissionError, 'exact completed profile'):
            self.admit()

    def test_profile_symlink_refuses(self) -> None:
        actual = self.case / 'real-profile.json'
        self.path.rename(actual)
        self.path.symlink_to(actual)
        with self.assertRaises(self.admission.AdmissionError):
            self.admit()

    def test_profile_duplicate_and_nonfinite_json_refuse(self) -> None:
        original = self.path.read_bytes()
        for raw in (original.replace(b'{', b'{"mode":"native",', 1), b'{"mode":NaN}'):
            with self.subTest(raw=raw[:30]):
                self.path.write_bytes(raw)
                with self.assertRaises(self.admission.AdmissionError):
                    self.admit()

    def test_resource_extra_or_symlink_refuses(self) -> None:
        resources = Path(self.profile['resource_directory'])
        extra = resources / 'unlisted.txt'
        extra.write_bytes(b'extra')
        with self.assertRaisesRegex(self.admission.AdmissionError, 'resource inventory'):
            self.admit()
        extra.unlink()
        row = self.profile['resource_pins'][0]
        target = resources / row['name']
        saved = self.case / 'saved-resource'
        target.rename(saved)
        target.symlink_to(saved)
        with self.assertRaises(self.admission.AdmissionError):
            self.admit()

    def test_each_pinned_group_tamper_refuses(self) -> None:
        for group in ('source_pins', 'native_pins', 'ledger_pins', 'control_pins'):
            name = next(iter(self.profile[group]))
            target = Path(name)
            if not target.is_absolute():
                target = Path(self.profile['repo']) / target
            original = target.read_bytes()
            with self.subTest(group=group):
                target.write_bytes(original + b'changed')
                with self.assertRaises(self.admission.AdmissionError):
                    self.admit()
                target.write_bytes(original)

    def test_missing_history_member_pin_refuses(self) -> None:
        self.profile['history_member_pins'].pop(next(iter(self.profile['history_member_pins'])))
        self.save()
        with self.assertRaisesRegex(self.admission.AdmissionError, '86'):
            self.admit()

    def test_bad_probe_scope_and_counts_refuse(self) -> None:
        self.profile['probe_input']['schema'] = 'ariadna-owner-setup-input-v1'
        self.save()
        with self.assertRaisesRegex(self.admission.AdmissionError, 'completed probe input'):
            self.admit()

    def test_false_readonly_bad_capacity_and_wrong_image_refuse(self) -> None:
        for field, value in (('read_only', False), ('capacity_bytes', True),
                              ('capacity_bytes', 8589934593), ('image', '/other')):
            with self.subTest(field=field):
                def observer(image: Path, mount: Path) -> dict[str, object]:
                    return dict(_readonly(image, mount), **{field: value})
                with self.assertRaisesRegex(self.admission.AdmissionError, 'readonly image'):
                    self.admit(observer)

    def test_original_clock_expiry_and_reversal_refuse(self) -> None:
        start = self.profile['preflight_started_s']
        with patch.object(self.admission.time, 'monotonic', return_value=start + 600):
            with self.assertRaisesRegex(self.admission.AdmissionError, '600s'):
                self.admit()
        with patch.object(self.admission.time, 'monotonic', side_effect=[start, start + 0.1, start - 0.1]):
            with self.assertRaisesRegex(self.admission.AdmissionError, '600s'):
                self.admit()

    def test_failed_fsync_retains_pending_and_never_observed_pass(self) -> None:
        with patch.object(self.admission.os, 'fsync', side_effect=OSError('artificial fsync refusal')):
            with self.assertRaisesRegex(self.admission.AdmissionError, 'fsync refusal'):
                self.admit()
        pending = json.loads((self.case / 'admission-check.json').read_bytes())
        self.assertEqual(pending['status'], 'PENDING_DURABLE_ADMISSION')
        self.assertIs(pending['native_launch_authorized'], False)

    def test_stale_candidate_cannot_resume(self) -> None:
        (self.case / 'admission-check.json').write_bytes(b'{"status":"PASS"}')
        with self.assertRaises(self.admission.AdmissionError):
            self.admit()


class GateTests(unittest.TestCase):
    def setUp(self) -> None:
        ROOT.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix='gate-', dir=ROOT)
        self.addCleanup(self.temp.cleanup)
        self.path, self.profile = make_profile(Path(self.temp.name) / 'case')
        self.case = self.path.parent
        self.gate = _load(self.case / 'dispatch-once.py')
        self.calls: list[str] = []

    def dispatch(self, observer: object = _readonly) -> dict[str, object]:
        return self.gate.dispatch(self.path, artificial_observer=observer,
                                  artificial_dispatch=lambda: self.calls.append('dispatch'))

    def test_direct_admission_dispatch_once_and_persisted_candidate_not_authority(self) -> None:
        result = self.dispatch()
        self.assertEqual(self.calls, ['dispatch'])
        self.assertEqual(result['status'], 'ARTIFICIAL_READY')
        self.assertIs(result['native_launch_authorized'], False)
        self.assertEqual(result['finalization'], 'checked-after-fsync')
        pending = json.loads((self.case / 'admission-check.json').read_bytes())
        self.assertEqual(pending['status'], 'PENDING_DURABLE_ADMISSION')
        self.assertIs(pending['native_launch_authorized'], False)
        with self.assertRaisesRegex(self.gate.GateError, 'occupied'):
            self.dispatch()
        self.assertEqual(self.calls, ['dispatch'])

    def test_native_replacements_refuse_before_any_read(self) -> None:
        with patch.object(self.gate, '_read', side_effect=AssertionError('live read')):
            for kwargs in ({'artificial_observer': _readonly}, {'artificial_dispatch': lambda: None}):
                with self.subTest(kwargs=tuple(kwargs)):
                    with self.assertRaisesRegex(self.gate.GateError, 'replacement'):
                        self.gate.dispatch(self.gate.LIVE_ROOT / 'profile.json', **kwargs)
        self.assertEqual(self.calls, [])

    def test_each_preoccupied_once_only_artifact_refuses(self) -> None:
        for name in ('gate-start.json', 'admission-check.json', 'launch-admission.json',
                     'episode-start.json', 'execution'):
            artifact = self.case / name
            artifact.write_bytes(b'{"status":"PASS"}')
            with self.subTest(name=name):
                with self.assertRaisesRegex(self.gate.GateError, 'occupied'):
                    self.dispatch()
                artifact.unlink()
        self.assertEqual(self.calls, [])

    def test_dangling_once_marker_refuses(self) -> None:
        (self.case / 'gate-start.json').symlink_to(self.case / 'absent')
        with self.assertRaisesRegex(self.gate.GateError, 'occupied'):
            self.dispatch()
        self.assertEqual(self.calls, [])

    def test_observer_mutation_is_caught_by_post_admission_rehash(self) -> None:
        target = Path(next(iter(self.profile['source_pins'])))
        def observer(image: Path, mount: Path) -> dict[str, object]:
            target.write_bytes(target.read_bytes() + b'late mutation')
            return _readonly(image, mount)
        with self.assertRaises(self.gate.GateError):
            self.dispatch(observer)
        self.assertEqual(self.calls, [])
        self.assertTrue((self.case / 'gate-start.json').exists())

    def test_observer_added_resource_is_caught_by_post_admission_inventory(self) -> None:
        def observer(image: Path, mount: Path) -> dict[str, object]:
            (Path(self.profile['resource_directory']) / 'late-extra').write_bytes(b'extra')
            return _readonly(image, mount)
        with self.assertRaisesRegex(self.gate.GateError, 'resource inventory changed'):
            self.dispatch(observer)
        self.assertEqual(self.calls, [])

    def test_profile_change_after_final_seal_refuses_dispatch(self) -> None:
        original = self.gate._write
        def write(path: Path, value: dict[str, object]) -> bytes:
            raw = original(path, value)
            if path.name == 'launch-admission.json':
                self.path.write_bytes(self.path.read_bytes() + b' ')
            return raw
        with patch.object(self.gate, '_write', side_effect=write):
            with self.assertRaisesRegex(self.gate.GateError, 'proof changed'):
                self.dispatch()
        self.assertEqual(self.calls, [])

    def test_gate_file_or_directory_fsync_failure_cannot_dispatch(self) -> None:
        with patch.object(self.gate.os, 'fsync', side_effect=OSError('gate fsync refusal')):
            with self.assertRaisesRegex(self.gate.GateError, 'fsync refusal'):
                self.dispatch()
        self.assertEqual(self.calls, [])

    def test_separate_execution_decision_is_required(self) -> None:
        path = Path(self.profile['execution_decision']['path'])
        decision = json.loads(path.read_bytes())
        decision['stage'] = 'F18.13'
        raw = _encode(decision)
        path.write_bytes(raw)
        self.profile['execution_decision'].update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        self.path.write_bytes(_encode(self.profile))
        with self.assertRaisesRegex(self.gate.GateError, 'execution decision'):
            self.dispatch()
        self.assertEqual(self.calls, [])

    def test_fresh_clock_not_a_saved_pass_permit(self) -> None:
        start = self.profile['preflight_started_s']
        with patch.object(self.gate.time, 'monotonic', return_value=start + 600):
            with self.assertRaisesRegex(self.gate.GateError, '600s'):
                self.dispatch()
        self.assertEqual(self.calls, [])


if __name__ == '__main__':
    unittest.main()
