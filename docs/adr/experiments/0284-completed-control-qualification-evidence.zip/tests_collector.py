"""Artificial fixed collector boundaries; only the frozen campaign may execute."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
from typing import Any
import unittest
from unittest.mock import patch

from qualification_harness import artificial_commands, load_control, make_profile, pin, raw, run_entry

ROOT = Path('/private/tmp/ariadna-f18-0284')
ARTIFICIAL = ROOT / 'artificial'
SCOPE = 'single-forward-completed-owner-only'
PHASES = ('bootstrap-ready', 'import-ready', 'context-ready', 'factory-enter',
          'factory-return', 'metadata-enter', 'metadata-ready', 'visitor-enter',
          'visitor-return', 'complete')


class CollectorTests(unittest.TestCase):
    def setUp(self) -> None:
        ARTIFICIAL.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(prefix='collector-', dir=ARTIFICIAL)
        self.addCleanup(self.temp.cleanup)
        self.case = Path(self.temp.name) / 'case'
        self.path, self.profile = make_profile(self.case)
        self.entry = load_control('native-entry.py', self.path.parent / 'native-entry.py')
        self.adapter = load_control('supervisor-adapter.py', self.path.parent / 'supervisor-adapter.py')
        self.commands = artificial_commands(self.case)
        self.work = Path(self.profile['work_directory'])
        self.packet = self.work / 'native-packet'
        self.started = time.monotonic()
        self.worker_calls: list[tuple[str, float, bool]] = []

    def _producer(self) -> dict[str, object]:
        data = self.profile['probe_input']
        return {
            'schema': 'ariadna-owner-completed-report-v1', 'scope': SCOPE, 'mode': 'injected',
            'status': 'passed', 'physical_admission': 'unavailable',
            **{field: data[field] for field in ('kernel_path', 'kernel_sha256', 'probe_sha256',
                                               'completed_auditor_sha256')},
            'context_checks': 1, 'metadata_attempts': 1,
            'counts': {'factory_attempts': 1, 'integration_attempts': 1, 'visitor_calls': 1,
                       'spice_queries': 0, 'kernel_reads': 0, 'real_archive_reads': 0,
                       'optimizer_entries': 0, 'acceleration_callbacks': 3,
                       'native_reported_function_evaluations': [41]},
        }

    def _fake_worker(self, command: list[str], output: Path, errors: Path,
                     deadline_s: float, evidence: Any, *,
                     inherited_group: bool = False) -> dict[str, object]:
        """Literal control fixtures only; the connected positive uses real auditor."""
        kind = 'producer' if '--probe' in command else 'audit'
        self.worker_calls.append((kind, deadline_s, inherited_group))
        if kind == 'producer':
            encoded = raw(self._producer())
            evidence.write(output, encoded)
            with (output.parent / 'trace.jsonl').open('xb') as stream:
                for index, phase in enumerate(PHASES):
                    marker = {'schema': 'ariadna-owner-completed-marker-v1', 'scope': SCOPE,
                              'index': index, 'phase': phase,
                              'elapsed_s': time.monotonic() - self.started}
                    if index == 9:
                        marker['report_sha256'] = hashlib.sha256(encoded).hexdigest()
                    stream.write(raw(marker))
                stream.flush()
                os.fsync(stream.fileno())
        else:
            producer_raw = (output.parent / 'producer.json').read_bytes()
            evidence.write(output, raw({
                'schema': 'ariadna-owner-completed-audit-v1', 'scope': SCOPE,
                'mode': 'injected', 'status': 'passed', 'physical_admission': 'unavailable',
                'markers_checked': 10,
                'kernel_sha256': self.profile['probe_input']['kernel_sha256'],
                'report_sha256': hashlib.sha256(producer_raw).hexdigest(),
                'completion_requires_outer_finalization': True,
            }))
        return {'exit_code': 0, 'elapsed_s': 0.001}

    def _collect(self, worker: Any = None) -> dict[str, object]:
        self.work.mkdir(exist_ok=True)
        with patch.object(self.adapter.os, 'getpgrp', return_value=os.getpid()), \
                patch.object(self.adapter.os, 'getsid', return_value=os.getpid()), \
                patch.object(self.adapter, '_watch_worker',
                             side_effect=self._fake_worker if worker is None else worker):
            return self.adapter.collect(self.profile, self.packet, self.started,
                                        artificial_commands=self.commands)

    def test_connected_real_probe_and_guarded_auditor_one_entry_group(self) -> None:
        result = run_entry(self.path, self.commands)
        self.assertEqual(result['returncode'], 0, result['stderr'])
        report = result['report']
        self.assertEqual(report['schema'], 'ariadna.f18.completed-collector.v1')
        self.assertEqual(report['status'], 'passed')
        self.assertEqual(report['finalization'], 'checked-after-fsync')
        self.assertEqual(report['mode'], 'artificial')
        self.assertEqual(report['physical_admission'], 'unavailable')
        self.assertIs(report['completion_requires_outer_finalization'], True)
        self.assertEqual([row['kind'] for row in report['workers']], ['producer', 'audit'])
        producer = json.loads((self.packet / 'producer.json').read_bytes())
        audit = json.loads((self.packet / 'audit.json').read_bytes())
        self.assertEqual(producer['mode'], 'injected')
        self.assertEqual(producer['metadata_attempts'], 1)
        self.assertEqual(producer['counts']['integration_attempts'], 1)
        self.assertEqual(audit['markers_checked'], 10)
        self.assertEqual(audit['report_sha256'], hashlib.sha256(
            (self.packet / 'producer.json').read_bytes()).hexdigest())
        self.assertEqual(len((self.packet / 'trace.jsonl').read_bytes().splitlines()), 10)
        self.assertFalse((self.work / 'parent.pgid').exists())
        self.assertEqual(int((self.work / 'supervisor.pgid').read_text()), result['entry_pgid'])
        with self.assertRaises(ProcessLookupError):
            os.killpg(result['entry_pgid'], 0)
        self.assertLess(report['elapsed_after_final_fsync_s'], 60)
        self.assertLessEqual(report['structured_bytes'], 2 * 1024**2)
        self.assertLessEqual(report['log_bytes'], 65536)

        from qualification_harness import retain_positive
        retain_positive('entry-connected', Path(self.profile['root']), result['stdout'])

    def test_pending_disk_receipt_is_not_observed_completion(self) -> None:
        result = self._collect()
        self.assertEqual(result['status'], 'passed')
        self.assertEqual(result['finalization'], 'checked-after-fsync')
        pending = json.loads((self.packet / 'receipt.json').read_bytes())
        self.assertEqual(pending['finalization'], 'pending-after-fsync-observation')
        self.assertIs(pending['completion_requires_outer_finalization'], True)
        self.assertEqual(self.worker_calls[0], ('producer', self.started + 45, True))
        self.assertLessEqual(self.worker_calls[1][1], self.started + 55)
        self.assertTrue(self.worker_calls[1][2])
        self.assertEqual(result['actual_partial_counts']['native_reported_function_evaluations'], [41])

    def test_second_collection_refuses_without_reentry(self) -> None:
        self.assertEqual(self._collect()['status'], 'passed')
        calls = list(self.worker_calls)
        with self.assertRaises(FileExistsError):
            self._collect()
        self.assertEqual(self.worker_calls, calls)

    def test_native_override_refused_before_any_live_reads(self) -> None:
        with patch.object(self.entry, '_read_profile', side_effect=AssertionError('live read')):
            with self.assertRaisesRegex(RuntimeError, 'artificial|replacement'):
                self.entry.run(self.entry._NATIVE_ROOT / 'profile.json', self.started,
                               artificial_commands=self.commands)
        native = dict(self.profile, mode='native', root=str(self.entry._NATIVE_ROOT))
        with patch.object(self.adapter, '_json_bytes', side_effect=AssertionError('live read')):
            with self.assertRaisesRegex(RuntimeError, 'native forbids'):
                self.adapter.collect(native, self.packet, self.started,
                                     artificial_commands=self.commands)

    def test_native_profile_inside_fake_tree_still_refuses_replacements(self) -> None:
        self.profile['mode'] = 'native'
        self.path.write_bytes(raw(self.profile))
        with patch.object(self.entry.hashlib, 'sha256', side_effect=AssertionError('pin read')):
            with self.assertRaisesRegex(RuntimeError, 'native forbids'):
                self.entry.run(self.path, self.started, artificial_commands=self.commands)

    def test_cli_has_no_artificial_flags_or_recursive_parent(self) -> None:
        with patch.object(self.entry.sys, 'argv', ['entry', str(self.path), '0', '--parent']):
            with self.assertRaisesRegex(RuntimeError, 'original clock only'):
                self.entry.main()

    def test_artificial_profile_command_field_or_symlink_refuses(self) -> None:
        original = self.path.read_bytes()
        self.profile['commands'] = self.commands
        self.path.write_bytes(raw(self.profile))
        with self.assertRaisesRegex(RuntimeError, 'fixed completed entry profile'):
            self.entry.run(self.path, self.started, artificial_commands=self.commands)
        self.path.write_bytes(original)
        saved = self.path.with_name('saved-profile.json')
        self.path.rename(saved)
        self.path.symlink_to(saved)
        with self.assertRaisesRegex(RuntimeError, 'unsafe'):
            self.entry.run(self.path, self.started, artificial_commands=self.commands)

    def test_artificial_interpreter_mismatch_refuses_before_entry_marker(self) -> None:
        self.profile['outer_python']['path'] = '/not/the/current/python'
        self.path.write_bytes(raw(self.profile))
        with self.assertRaisesRegex(RuntimeError, 'interpreter'):
            self.entry.run(self.path, self.started, artificial_commands=self.commands)
        self.assertFalse(self.work.exists())

    def test_entry_requires_one_new_session(self) -> None:
        with patch.object(self.entry.os, 'getpgrp', return_value=os.getpid() + 1):
            with self.assertRaisesRegex(RuntimeError, 'isolated session'):
                self.entry.run(self.path, self.started, artificial_commands=self.commands)
        self.assertFalse(self.work.exists())

    def test_descriptor_pin_symlink_outside_and_nonregular_refuse(self) -> None:
        good = self.commands['producer']
        path = Path(good['path'])
        for defect in ('pin', 'symlink', 'outside', 'nonregular'):
            with self.subTest(defect=defect):
                if defect == 'pin':
                    descriptor = dict(good, sha256='0' * 64)
                elif defect == 'outside':
                    descriptor = dict(good, path='/private/tmp/no-harmless-wrapper.py')
                elif defect == 'nonregular':
                    folder = self.case / 'folder-wrapper'
                    folder.mkdir()
                    descriptor = dict(good, path=str(folder))
                else:
                    link = self.case / 'linked-wrapper.py'
                    link.symlink_to(path)
                    descriptor = dict(good, path=str(link))
                with self.assertRaises((RuntimeError, OSError)):
                    self.adapter._descriptor(descriptor)

    def test_native_default_commands_are_fixed_modules_and_original_arguments(self) -> None:
        native = dict(self.profile, mode='native')
        source = self.packet / 'input.json'
        command = self.adapter._commands(native, 'producer', source, 10.0, 55.0, None)
        self.assertEqual(command, [native['private_python'], '-B', '-m',
                                  'space_nav._owner_completed_probe', '--probe', str(source),
                                  '10.0', '55.0'])
        audit = self.adapter._commands(native, 'audit', source, 10.0, 65.0, None)
        self.assertEqual(audit[:5], [native['private_python'], '-B', '-m',
                                    'space_nav._owner_completed_audit', '--audit'])
        self.assertEqual(audit[-1], '65.0')

    def test_producer_failure_preserves_partial_trace_unknown_counts_and_no_audit(self) -> None:
        def failure(command: list[str], output: Path, errors: Path, deadline_s: float,
                    evidence: Any, *, inherited_group: bool = False) -> dict[str, object]:
            self.worker_calls.append(('producer', deadline_s, inherited_group))
            (output.parent / 'trace.jsonl').write_bytes(raw({'phase': 'factory-enter'}))
            evidence.write(errors, b'artificial child failed')
            return {'exit_code': 2, 'elapsed_s': 0.001}
        result = self._collect(failure)
        self.assertEqual(result['status'], 'failed')
        self.assertIn('UNKNOWN', result['actual_partial_counts'])
        self.assertEqual(len(self.worker_calls), 1)
        self.assertEqual((self.packet / 'trace.jsonl').read_bytes(), raw({'phase': 'factory-enter'}))

    def test_forged_report_mode_schema_count_and_hash_stop_before_audit(self) -> None:
        original = self._producer
        for field, value in (('mode', 'native'), ('schema', 'ariadna-owner-setup-report-v1'),
                             ('metadata_attempts', True), ('kernel_sha256', '0' * 64)):
            with self.subTest(field=field):
                report = original()
                report[field] = value
                with patch.object(self, '_producer', return_value=report):
                    result = self._collect()
                self.assertEqual(result['status'], 'failed')
                self.assertEqual(len(self.worker_calls), 1)
                for path in self.packet.iterdir():
                    path.unlink()
                self.packet.rmdir()
                self.worker_calls.clear()

    def test_audit_failure_never_turns_valid_producer_into_completion(self) -> None:
        def failure(command: list[str], output: Path, errors: Path, deadline_s: float,
                    evidence: Any, *, inherited_group: bool = False) -> dict[str, object]:
            result = self._fake_worker(command, output, errors, deadline_s, evidence,
                                       inherited_group=inherited_group)
            if '--audit' in command:
                return dict(result, exit_code=2)
            return result
        result = self._collect(failure)
        self.assertEqual(result['status'], 'failed')
        self.assertIn('audit failed', result['failure'])
        self.assertIn('producer_observed_counts', result)
        self.assertIn('UNKNOWN', result['actual_partial_counts'])

    def test_unknown_original_time_and_stale_start_refuse_before_children(self) -> None:
        for started in (float('nan'), time.monotonic() + 10, time.monotonic() - 61):
            with self.subTest(started=started):
                self.work.mkdir(exist_ok=True)
                with patch.object(self.adapter.os, 'getpgrp', return_value=os.getpid()), \
                        patch.object(self.adapter.os, 'getsid', return_value=os.getpid()):
                    with self.assertRaises(RuntimeError):
                        self.adapter.collect(self.profile, self.packet, started,
                                             artificial_commands=self.commands)
                self.assertFalse(self.packet.exists())

    def test_input_and_combined_log_overflow_never_complete(self) -> None:
        self.profile['probe_input']['padding'] = 'x' * 65536
        with self.assertRaisesRegex(RuntimeError, 'byte cap'):
            self._collect()
        self.assertFalse(self.packet.exists())
        self.profile['probe_input'].pop('padding')

        def overflow(command: list[str], output: Path, errors: Path, deadline_s: float,
                     evidence: Any, *, inherited_group: bool = False) -> dict[str, object]:
            evidence.write(errors, b'x' * 65537)
            raise AssertionError('overflow must refuse first')
        result = self._collect(overflow)
        self.assertEqual(result['status'], 'failed')
        self.assertLessEqual(result['log_bytes'], 65536)

    def test_trace_overflow_is_retained_only_up_to_cap_and_refused(self) -> None:
        def overflow(command: list[str], output: Path, errors: Path, deadline_s: float,
                     evidence: Any, *, inherited_group: bool = False) -> dict[str, object]:
            result = self._fake_worker(command, output, errors, deadline_s, evidence,
                                       inherited_group=inherited_group)
            (output.parent / 'trace.jsonl').write_bytes(b'x' * 4097)
            return result
        result = self._collect(overflow)
        self.assertEqual(result['status'], 'failed')
        self.assertLessEqual((self.packet / 'trace.jsonl').stat().st_size, 4096)

    def test_file_fsync_failure_never_runs_next_child(self) -> None:
        original = self.adapter._sync
        calls: list[str] = []

        def failure(path: Path) -> None:
            calls.append(path.name)
            if path.name == 'observation.json':
                raise OSError('artificial observation fsync failure')
            original(path)
        with patch.object(self.adapter, '_sync', side_effect=failure):
            result = self._collect()
        self.assertEqual(result['status'], 'failed')
        self.assertEqual([row[0] for row in self.worker_calls], ['producer'])
        self.assertIn('observation fsync failure', result['failure'])

    def test_packet_directory_fsync_failure_does_not_return_success(self) -> None:
        with patch.object(self.adapter, '_directory_sync', side_effect=OSError('directory fsync failed')):
            result = self._collect()
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['finalization'], 'failed-after-fsync')
        self.assertEqual(json.loads((self.packet / 'receipt.json').read_bytes())['finalization'],
                         'pending-after-fsync-observation')

    def test_final_directory_fsync_delay_is_checked_on_original_sixty_seconds(self) -> None:
        original_check = self.adapter._check
        delayed = [False]

        def check(deadline_s: float, minimum_s: float) -> float:
            if delayed[0]:
                raise self.adapter.RunError('absolute deadline exhausted after directory fsync')
            return original_check(deadline_s, minimum_s)

        def sync(path: Path) -> None:
            delayed[0] = True
        with patch.object(self.adapter, '_directory_sync', side_effect=sync), \
                patch.object(self.adapter, '_check', side_effect=check):
            result = self._collect()
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['finalization'], 'failed-after-fsync')
        self.assertIn('deadline', result['failure'])


if __name__ == '__main__':
    unittest.main()
