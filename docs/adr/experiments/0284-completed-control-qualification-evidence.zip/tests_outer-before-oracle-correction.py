"""Explicit artificial outer-control seams; no native CLI or sandbox positive claim."""
from __future__ import annotations
import ast,hashlib,importlib.util,json,os,signal,subprocess,sys,tempfile,time,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from qualification_harness import ARTIFICIAL,CONTROL_NAMES,PYTHON,REPO,ROOT,artificial_commands,load_control,make_profile,pin,raw,run_entry,save

class OuterTests(unittest.TestCase):
    def setUp(self)->None:
        ARTIFICIAL.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=ARTIFICIAL)
        self.addCleanup(self.temp.cleanup)
        self.case=Path(self.temp.name)/'case'

    def test_exact_reused_controls_and_namespace_policies(self)->None:
        with zipfile.ZipFile(REPO/'docs/adr/experiments/0280-supplemented-setup-evidence.zip')as z:
            for name in ('call-once.py','launch-once.py'):
                self.assertEqual((ROOT/'controls'/name).read_bytes(),z.read(name))
            for name in ('native.sandbox','check-preservation.py'):
                old=z.read(name);self.assertEqual(old.count(b'/private/tmp/ariadna-f18-supplemented-setup-v1'),1)
                self.assertEqual((ROOT/'controls'/name).read_bytes(),old.replace(b'/private/tmp/ariadna-f18-supplemented-setup-v1',b'/private/tmp/ariadna-f18-forward-completed-v1'))
        self.assertNotIn('provision.py',CONTROL_NAMES)

    def test_unchanged_caller_supervise_cleans_whole_group_after_leader_exit(self)->None:
        caller=load_control('call-once.py')
        self.case.mkdir();work=self.case/'execution';work.mkdir()
        child=self.case/'leader.py'
        child.write_text("import os,subprocess,sys,time\nfrom pathlib import Path\nPath(sys.argv[1]).write_text(str(os.getpgrp()))\nsubprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'])\n")
        start=time.monotonic()
        result,out=caller.supervise([str(PYTHON),'-I','-B',str(child),str(work/'supervisor.pgid')],work,start,seconds=.15)
        self.assertIsNotNone(result['failure'])
        self.assertLess(time.monotonic()-start,2)
        self.assertIsNone(result['groups']['parent.pgid'])
        self.assertIsInstance(result['groups']['supervisor.pgid'],int)

    def test_unchanged_caller_never_restarts_an_exhausted_original_clock(self)->None:
        caller=load_control('call-once.py');self.case.mkdir()
        with patch.object(caller.subprocess,'Popen',side_effect=AssertionError('must not spawn')):
            with self.assertRaisesRegex(RuntimeError,'inherited caller deadline'):
                caller.supervise(['forbidden'],self.case,time.monotonic()-60)

    def test_launcher_exact_native_command_then_explicit_harmless_entry_function_seam(self)->None:
        profile_path,profile=make_profile(self.case);save(Path(profile['prelaunch_admission']),{'status':'PASS','qualification':'ARTIFICIAL ONLY'})
        commands=artificial_commands(self.case)
        script=self.case/'launch-harness.py'
        script.write_text('''import importlib.util,json,sys
from pathlib import Path
root=Path(sys.argv[1]);profile=json.loads((root/'profile.json').read_bytes());start=float(sys.argv[2]);commands=json.loads(sys.argv[3])
sys.path.insert(0,str(Path(profile['repo'])/'src'))
from space_nav import _owner_endpoint_run as controller
original=controller._watch_worker
calls=[]
def harmless(command,output,errors,deadline,evidence,**kwargs):
 expected=['/usr/bin/sandbox-exec','-f',profile['sandbox_profile'],profile['private_python'],'-B',str(root/'native-entry.py'),str(root/'profile.json'),repr(start)]
 assert list(command)==expected and not kwargs
 calls.append('native-command-asserted-but-not-executed')
 safe=[profile['outer_python']['path'],'-I','-B','/private/tmp/ariadna-f18-0284/artificial-entry.py',str(root/'profile.json'),repr(start),json.dumps(commands)]
 return original(safe,output,errors,deadline,evidence)
controller._watch_worker=harmless
spec=importlib.util.spec_from_file_location('launcher',root/'launch-once.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sys.argv=['launch-once.py',str(root/'profile.json'),repr(start)]
code=m.main();assert len(calls)==1
raise SystemExit(code)
''')
        start=time.monotonic();caller=load_control('call-once.py')
        summary,output=caller.supervise([str(PYTHON),'-I','-B',str(script),str(profile_path.parent),repr(start),json.dumps(commands)],Path(profile['work_directory']),start,seconds=5)
        self.assertEqual(summary['returncode'],0,summary)
        self.assertIsNone(summary['failure'],summary)
        report=json.loads(output);self.assertEqual(report['status'],'passed');self.assertTrue(report['group_cleanup_completed'])
        self.assertIsNone(report['parent_pgid'])
        self.assertFalse((Path(profile['work_directory'])/'parent.pgid').exists())
        self.assertEqual(report['supervisor']['schema'],'ariadna.f18.completed-collector.v1')
        from qualification_harness import retain_positive
        retain_positive('launcher-substituted', profile_path.parent, output)

    def _translated_run_once(self,*,defect:str|None=None)->subprocess.CompletedProcess[bytes]:
        """Only root literal is translated; caller is an explicit harmless fixture."""
        self.case.mkdir();p=self.case
        source=(ROOT/'controls/run-once.py').read_text();literal='/private/tmp/ariadna-f18-forward-completed-v1'
        self.assertEqual(source.count(literal),1)
        translated=source.replace(literal,str(p));self.assertEqual(translated.replace(str(p),literal),source)
        script=p/'run-once-test-copy.py';script.write_text(translated)
        save(p/'launch-admission.json',{'status':'PASS','qualification':'ARTIFICIAL CALLER FIXTURE'})
        save(p/'profile.json',{})
        code="""import json,sys,time
from pathlib import Path
p=Path(sys.argv[1]).parent
started=time.monotonic()SHIFT
(p/'execution').mkdir()
(p/'execution'/'supervisor.pgid').write_text(str(__import__('os').getpgrp()))
(p/'episode-start.json').write_text(json.dumps({'started_s':started}))
EXTRA
print(json.dumps({'status':'passed','within60s':True}),flush=True)
"""
        extra="pass";shift=""
        if defect=='structured-overflow':extra="(p/'execution'/'oversize.bin').write_bytes(b'x'*2097153)"
        if defect=='log-overflow':extra="(p/'execution'/'oversize.log').write_bytes(b'x'*65537)"
        if defect=='expired':shift='-60.0'
        if defect=='symlink':extra="(p/'execution'/'dangling').symlink_to(p/'not-present')"
        (p/'call-once.py').write_text(code.replace('SHIFT',shift).replace('EXTRA',extra))
        command=[str(PYTHON),'-I','-B',str(script)]
        process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        try:
            output,errors=process.communicate(timeout=4)
        finally:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            record=p/'execution'/'supervisor.pgid'
            if record.exists():
                group=int(record.read_text());self.assertGreater(group,1);self.assertNotIn(group,(os.getpid(),os.getpgrp()))
                try:os.killpg(group,signal.SIGKILL)
                except ProcessLookupError:pass
            process.wait(timeout=1)
        return subprocess.CompletedProcess(command,process.returncode,output,errors)

    def test_run_once_translated_body_success_observes_final_directory_durability(self)->None:
        result=self._translated_run_once();self.assertEqual(result.returncode,0,result.stderr.decode())
        record=json.loads(result.stdout);self.assertEqual(record['status'],'passed');self.assertEqual(record['finalization'],'checked-after-fsync')
        self.assertLess(record['observed_after_observation_fsync_s'],60)
        self.assertIsNone(record['observation']['groups']['parent.pgid']);self.assertIsInstance(record['observation']['groups']['supervisor.pgid'],int)

    def test_run_once_rejects_total_outer_inner_structured_overflow(self)->None:
        result=self._translated_run_once(defect='structured-overflow');self.assertNotEqual(result.returncode,0);self.assertNotIn(b'"status": "passed"',result.stdout)
    def test_run_once_rejects_total_combined_logs(self)->None:
        result=self._translated_run_once(defect='log-overflow');self.assertNotEqual(result.returncode,0)
    def test_run_once_rejects_expired_original_clock(self)->None:
        result=self._translated_run_once(defect='expired');self.assertNotEqual(result.returncode,0)
    def test_run_once_rejects_nonregular_evidence(self)->None:
        result=self._translated_run_once(defect='symlink');self.assertNotEqual(result.returncode,0)

    def _functions(self)->dict[str,object]:
        tree=ast.parse((ROOT/'controls/run-once.py').read_text());selected=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
        namespace={};exec(compile(ast.Module(body=selected,type_ignores=[]),'run-once-functions','exec'),namespace);return namespace

    def test_directory_fsync_error_and_post_fsync_late_clock_refuse(self)->None:
        self.case.mkdir();namespace=self._functions();sync=namespace['sync_directories']
        with patch('os.fsync',side_effect=OSError('artificial fsync fault')):
            with self.assertRaises(OSError):sync(self.case,time.monotonic()+1)
        start=time.monotonic()
        with patch('time.monotonic',side_effect=[start,start+61]):
            with self.assertRaisesRegex(RuntimeError,'after directory fsync'):sync(self.case,start+60)

    def test_stalled_directory_fsync_is_bounded_by_external_watchdog(self)->None:
        self.case.mkdir();script=self.case/'stall.py'
        script.write_text("import ast,os,time\nfrom pathlib import Path\ntree=ast.parse(Path('/private/tmp/ariadna-f18-0284/controls/run-once.py').read_text());ns={}\nexec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),'functions','exec'),ns)\nos.fsync=lambda *args:time.sleep(30)\nns['sync_directories'](Path(__file__).parent,time.monotonic()+60)\n")
        caller=load_control('call-once.py');start=time.monotonic();result,out=caller.supervise([str(PYTHON),'-I','-B',str(script)],self.case,start,seconds=.15)
        self.assertIsNotNone(result['failure']);self.assertLess(time.monotonic()-start,2)
