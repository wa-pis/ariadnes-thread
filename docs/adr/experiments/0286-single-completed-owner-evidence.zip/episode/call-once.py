"""Fixed caller watchdog for the qualified F18.3 profile; stdlib only."""
from pathlib import Path
import datetime,hashlib,json,math,os,signal,subprocess,sys,time

def kill_group_record(path):
    if not path.exists():return None
    with path.open('rb')as f:raw=f.read(33)
    if len(raw)>32 or not raw.strip().isdigit():raise RuntimeError('invalid PGID record')
    group=int(raw)
    if group<=1 or group in {os.getpid(),os.getpgrp()}:raise RuntimeError('unsafe PGID')
    try:os.killpg(group,signal.SIGKILL)
    except ProcessLookupError:pass
    return group

def supervise(command,work,started,seconds=60):
    remaining=started+seconds-time.monotonic()
    if not 0<remaining<=seconds:raise RuntimeError('inherited caller deadline exhausted')
    process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    output=errors=b'';failure=None
    try:
        output,errors=process.communicate(timeout=max(0.001,started+seconds-time.monotonic()))
    except subprocess.TimeoutExpired:
        failure='caller absolute deadline exhausted'
    finally:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        groups={}
        for name in ('parent.pgid','supervisor.pgid'):groups[name]=kill_group_record(work/name)
        process.wait(timeout=1)
        process.stdout.close();process.stderr.close()
    if len(output)>32768 or errors:failure=failure or 'caller output/log partition'
    return {'returncode':process.returncode,'failure':failure,'groups':groups,'elapsed_after_cleanup_s':time.monotonic()-started},output[:32768]

def main():
    profile_path=Path(sys.argv[1]);root=profile_path.parent;profile=json.loads(profile_path.read_bytes());work=Path(profile['work_directory'])
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=profile['caller_sha256']:raise RuntimeError('caller pin')
    if work.exists():raise RuntimeError('exclusive native namespace already exists')
    start=time.monotonic();preflight=start-float(profile['preflight_started_s']);assert 0<=preflight<600
    with(root/'episode-start.json').open('x')as f:
        json.dump({'schema':'ariadna.f18.native-start.v1','started_s':start,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preflight_elapsed_s':preflight,'deadline_s':start+60,'profile_sha256':hashlib.sha256(profile_path.read_bytes()).hexdigest(),'retry_authorized':False},f,sort_keys=True);f.flush();os.fsync(f.fileno())
    report,raw=supervise([sys.executable,'-I','-B',str(root/'launch-once.py'),str(profile_path),repr(start)],work,start)
    report['launcher']=json.loads(raw)if raw else None
    with(root/'caller-output.json').open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
    report['elapsed_after_output_fsync_s']=time.monotonic()-start
    report['status']='passed'if report['failure']is None and report['returncode']==0 and report['launcher']['status']=='passed' and report['elapsed_after_output_fsync_s']<60 else 'failed'
    total=sum(x.stat().st_size for x in work.rglob('*')if x.is_file()and not x.name.endswith('.log'))+len(raw)+(root/'episode-start.json').stat().st_size
    report['total_structured_bytes_before_caller_receipt']=total
    summary={k:v for k,v in report.items()if k!='launcher'};encoded=(json.dumps(summary,sort_keys=True)+'\n').encode();assert len(encoded)<=2048 and total+len(encoded)<2097152
    with(root/'caller-finalization.json').open('xb')as f:f.write(encoded);f.flush();os.fsync(f.fileno())
    observed=time.monotonic()-start
    print(json.dumps({'status':report['status'],'observed_after_caller_finalization_fsync_s':observed,'within60s':observed<60,'summary':summary},sort_keys=True))
    return 0 if report['status']=='passed'and observed<60 else 2
if __name__=='__main__':raise SystemExit(main())
