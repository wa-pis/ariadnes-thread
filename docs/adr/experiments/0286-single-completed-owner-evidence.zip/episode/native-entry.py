"""One fixed ADR0283 entry session; native CLI has no replacement options."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import sys
from typing import Any

_ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0284/artificial')
_NATIVE_ROOT = Path('/private/tmp/ariadna-f18-forward-completed-v1')
_KEYS = set('schema scope mode repo base_revision root work_directory preflight_started_s '
            'outer_python private_python environment sandbox_profile source_pins native_pins '
            'resource_pins resource_directory image mount ledger_pins history_archive '
            'history_member_pins control_pins outer_gate contract kernel_sha256 probe_input '
            'entry_sha256 launch_sha256 caller_sha256 adapter_sha256 sandbox_sha256 '
            'prelaunch_admission execution_decision'.split())


def _safe_artificial(path: Path) -> None:
    if not path.is_absolute() or '..' in path.parts or '\0' in str(path):
        raise RuntimeError('absolute safe artificial path required')
    try:
        parts = path.relative_to(_ARTIFICIAL_ROOT).parts
    except ValueError as exc:
        raise RuntimeError('replacement commands forbidden outside artificial prefix') from exc
    current = _ARTIFICIAL_ROOT
    for component in ('', *parts):
        if component:
            current /= component
        mode = current.lstat().st_mode
        if stat.S_ISLNK(mode) or (current != path and not stat.S_ISDIR(mode)):
            raise RuntimeError('unsafe artificial profile ancestor')


def _read_profile(path: Path) -> dict[str, Any]:
    def unique(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise RuntimeError('duplicate profile field')
            result[key] = value
        return result

    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise RuntimeError('regular profile file required')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(65537)
    finally:
        os.close(fd)
    if len(raw) > 65536:
        raise RuntimeError('profile64KiB cap')
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite profile value: ' + value)

    profile = json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)
    if (type(profile) is not dict or set(profile) != _KEYS
            or profile['schema'] != 'ariadna.f18.completed-control-profile.v1'
            or profile['scope'] != 'single-forward-completed-owner-only'):
        raise RuntimeError('fixed completed entry profile required')
    return profile


def _directory_sync(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def run(profile_path: Path, started_s: float, *,
        artificial_commands: object = None) -> dict[str, object]:
    """Enter one session and collector; no recursive parent process is created."""
    if artificial_commands is not None:
        # This check happens before reading any non-artificial profile/resource.
        _safe_artificial(profile_path)
    elif profile_path != _NATIVE_ROOT / 'profile.json':
        raise RuntimeError('native entry requires fixed native profile path')
    profile = _read_profile(profile_path)
    mode = profile['mode']
    if mode == 'native':
        if artificial_commands is not None:
            raise RuntimeError('native forbids command replacements')
        if Path(profile['root']) != _NATIVE_ROOT or profile_path.parent != _NATIVE_ROOT:
            raise RuntimeError('fixed native namespace required')
        interpreter = profile['private_python']
    elif mode == 'artificial':
        if artificial_commands is None:
            raise RuntimeError('artificial entry requires explicit harmless commands')
        _safe_artificial(Path(profile['root']))
        _safe_artificial(profile_path)
        interpreter = profile['outer_python']['path']
    else:
        raise RuntimeError('fixed native/artificial entry mode required')
    if (type(interpreter) is not str
            or Path(sys.executable).resolve() != Path(interpreter).resolve()):
        raise RuntimeError('entry interpreter identity mismatch')
    if (os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0)):
        raise RuntimeError('entry requires one isolated session')
    if (type(started_s) not in (int, float) or not math.isfinite(started_s)):
        raise RuntimeError('finite original entry clock required')
    root, work = Path(profile['root']), Path(profile['work_directory'])
    if (profile_path.parent != root or work != root / 'execution'
            or (work / 'parent.pgid').exists()):
        raise RuntimeError('fixed single-entry work path without parent.pgid required')
    if mode == 'artificial':
        _safe_artificial(work)
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != profile['entry_sha256']:
        raise RuntimeError('entry source pin mismatch')
    adapter_path = Path(__file__).with_name('supervisor-adapter.py')
    if hashlib.sha256(adapter_path.read_bytes()).hexdigest() != profile['adapter_sha256']:
        raise RuntimeError('completed collector source pin mismatch')
    if mode == 'native':
        sys.path.insert(0, str(Path(profile['repo']) / 'src'))
    from space_nav._owner_endpoint_run import _check, _json_bytes
    _check(float(started_s) + 60, float(started_s))
    raw = (str(os.getpgrp()) + '\n').encode('ascii')
    if len(raw) > 32:
        raise RuntimeError('entry PGID exceeds fixed32B cap')
    with (work / 'supervisor.pgid').open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    _directory_sync(work)
    _check(float(started_s) + 60, float(started_s))
    spec = importlib.util.spec_from_file_location('completed_packet_collector', adapter_path)
    if spec is None or spec.loader is None:
        raise RuntimeError('fixed completed collector unavailable')
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    result = adapter.collect(profile, work / 'native-packet', float(started_s),
                             artificial_commands=artificial_commands)
    # Encoding is bounded here; the unchanged launcher owns group cleanup and
    # enclosing finalization after this entry has returned its observation.
    if len(_json_bytes(result)) > 65536:
        raise RuntimeError('entry result64KiB cap')
    return result


def main() -> int:
    """Native CLI only; replacement arguments never enter its parser/profile."""
    if len(sys.argv) != 3:
        raise RuntimeError('fixed native entry requires profile and original clock only')
    result = run(Path(sys.argv[1]), float(sys.argv[2]))
    sys.stdout.write(json.dumps(result, sort_keys=True, allow_nan=False) + '\n')
    sys.stdout.flush()
    return 0 if (result.get('status') == 'passed'
                 and result.get('finalization') == 'checked-after-fsync') else 2


if __name__ == '__main__':
    raise SystemExit(main())
