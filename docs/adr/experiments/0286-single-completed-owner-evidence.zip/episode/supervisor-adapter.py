"""Fixed ADR0283 completed packet collector; no native work on import."""
from __future__ import annotations

from collections.abc import Mapping
import hashlib
import math
import os
from pathlib import Path
import stat
import sys
from typing import Any

from space_nav._import_probe import _check, _retain_trace, _start
from space_nav._owner_endpoint_run import (
    AUDIT_BYTES, EVIDENCE_BYTES, INPUT_BYTES, LOG_BYTES, REPORT_BYTES, RunError,
    _Evidence, _decode, _json_bytes, _now, _read, _sync, _watch_worker,
)

_ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0284/artificial')
_NATIVE_ROOT = Path('/private/tmp/ariadna-f18-forward-completed-v1')
_SCOPE = 'single-forward-completed-owner-only'
_PHASES = ('bootstrap-ready', 'import-ready', 'context-ready', 'factory-enter',
           'factory-return', 'metadata-enter', 'metadata-ready', 'visitor-enter',
           'visitor-return', 'complete')


def _directory_sync(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _safe_artificial(path: Path) -> None:
    """Reject outside paths and symlink ancestors before harmless fixture reads."""
    if not path.is_absolute() or '..' in path.parts or '\0' in str(path):
        raise RunError('absolute safe artificial path required')
    try:
        relative = path.relative_to(_ARTIFICIAL_ROOT)
    except ValueError as exc:
        raise RunError('artificial path outside fixed safe prefix') from exc
    current = _ARTIFICIAL_ROOT
    for component in ('', *relative.parts):
        if component:
            current /= component
        try:
            value = current.lstat()
        except FileNotFoundError:
            if current != path:
                raise RunError('missing artificial ancestor') from None
            return
        if stat.S_ISLNK(value.st_mode):
            raise RunError('symlink artificial path forbidden')
        if current != path and not stat.S_ISDIR(value.st_mode):
            raise RunError('non-directory artificial ancestor')


def _descriptor(value: object) -> Path:
    if type(value) is not dict or set(value) != {'path', 'bytes', 'sha256'}:
        raise RunError('fixed pinned artificial script descriptor required')
    path, size, digest = value['path'], value['bytes'], value['sha256']
    if (type(path) is not str or type(size) is not int or not 0 < size <= INPUT_BYTES
            or type(digest) is not str or len(digest) != 64
            or any(c not in '0123456789abcdef' for c in digest)):
        raise RunError('invalid bounded artificial script pin')
    target = Path(path)
    _safe_artificial(target)
    fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise RunError('artificial script must be regular')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(INPUT_BYTES + 1)
    finally:
        os.close(fd)
    if len(raw) != size or hashlib.sha256(raw).hexdigest() != digest:
        raise RunError('artificial command script pin mismatch')
    return target


def _commands(profile: Mapping[str, Any], kind: str, source: Path,
              started_s: float, deadline_s: float,
              artificial_commands: object) -> list[str]:
    if kind not in {'producer', 'audit'}:
        raise RunError('fixed worker role required')
    mode = profile.get('mode')
    if mode == 'native':
        if artificial_commands is not None:
            raise RunError('native forbids replacement commands')
        prefix = [profile['private_python'], '-B', '-m',
                  'space_nav._owner_completed_probe' if kind == 'producer'
                  else 'space_nav._owner_completed_audit']
    elif mode == 'artificial':
        _safe_artificial(Path(profile['root']))
        if (type(artificial_commands) is not dict
                or set(artificial_commands) != {'producer', 'audit'}):
            raise RunError('artificial mode requires explicit bounded script descriptors')
        descriptor = artificial_commands[kind]
        if descriptor is None and kind == 'audit':
            prefix = [profile['outer_python']['path'], '-I', '-B', '-m',
                      'space_nav._owner_completed_audit']
        else:
            prefix = [profile['outer_python']['path'], '-I', '-B', str(_descriptor(descriptor))]
    else:
        raise RunError('fixed collector mode required')
    if kind == 'producer':
        args = ['--probe', str(source), repr(started_s), repr(deadline_s)]
    else:
        args = ['--audit', str(source), str(source.parent / 'producer.json'),
                str(source.parent / 'observation.json'), str(source.parent / 'trace.jsonl'),
                repr(deadline_s)]
    command = prefix + args
    if (any(type(part) is not str or '\0' in part for part in command)
            or len(_json_bytes(command)) > INPUT_BYTES):
        raise RunError('bounded literal command required')
    return command


def _producer_summary(report: dict[str, Any], profile: Mapping[str, Any]) -> None:
    expected_mode = 'native' if profile['mode'] == 'native' else 'injected'
    if (report.get('schema') != 'ariadna-owner-completed-report-v1'
            or report.get('scope') != _SCOPE or report.get('mode') != expected_mode
            or report.get('status') != 'passed'
            or report.get('physical_admission') != 'unavailable'):
        raise RunError('completed producer schema/mode/status mismatch')
    for field in ('kernel_path', 'kernel_sha256', 'probe_sha256', 'completed_auditor_sha256'):
        if report.get(field) != profile['probe_input'][field]:
            raise RunError('completed producer identity mismatch: ' + field)
    for field in ('context_checks', 'metadata_attempts'):
        if type(report.get(field)) is not int or report[field] != 1:
            raise RunError('completed producer scope count mismatch: ' + field)
    counts = report.get('counts')
    if type(counts) is not dict:
        raise RunError('completed producer counts required')
    for field, value in {'factory_attempts': 1, 'integration_attempts': 1,
                         'visitor_calls': 1, 'spice_queries': 0, 'kernel_reads': 0,
                         'real_archive_reads': 0, 'optimizer_entries': 0}.items():
        if type(counts.get(field)) is not int or counts[field] != value:
            raise RunError('completed producer count mismatch: ' + field)
    callbacks = counts.get('acceleration_callbacks')
    functions = counts.get('native_reported_function_evaluations')
    if (type(callbacks) is not int or not 0 <= callbacks <= 100000
            or type(functions) is not list or len(functions) != 1
            or type(functions[0]) is not int or functions[0] < 0):
        raise RunError('completed producer telemetry mismatch')


def collect(profile: dict[str, Any], directory: Path, started_s: float, *,
            artificial_commands: object = None) -> dict[str, object]:
    """Collect one inherited-group producer and separate guarded saved audit.

    Caller admission and enclosing entry-group cleanup/finalization remain required.
    No persisted successful receipt by itself authorizes another invocation.
    """
    mode = profile.get('mode')
    if mode == 'native' and artificial_commands is not None:
        raise RunError('native forbids replacement commands before live reads')
    if mode == 'artificial':
        _safe_artificial(directory)
        if artificial_commands is None:
            raise RunError('artificial commands required')
    elif mode != 'native' or Path(profile['root']) != _NATIVE_ROOT:
        raise RunError('fixed native namespace required')
    if (os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0)):
        raise RunError('collector requires inherited isolated entry session')
    entered = _now()
    started_s = _start(started_s, entered)
    last = _check(started_s + 60, entered)
    if (profile.get('schema') != 'ariadna.f18.completed-control-profile.v1'
            or profile.get('scope') != _SCOPE
            or directory != Path(profile['work_directory']) / 'native-packet'):
        raise RunError('fixed completed collector profile/path required')
    raw = _json_bytes(profile['probe_input'])
    input_data = _decode(raw, INPUT_BYTES)
    if (input_data.get('schema') != 'ariadna-owner-completed-input-v1'
            or input_data.get('scope') != _SCOPE
            or input_data.get('mode') != ('native' if mode == 'native' else 'injected')):
        raise RunError('completed probe input mode/scope mismatch')
    directory.mkdir(parents=False, exist_ok=False)
    evidence = _Evidence(directory, LOG_BYTES)
    evidence.caps.update({'producer.json': REPORT_BYTES, 'audit.json': REPORT_BYTES,
                          'observation.json': REPORT_BYTES})
    source = directory / 'input.json'
    result: dict[str, Any] = {
        'schema': 'ariadna.f18.completed-collector.v1', 'scope': _SCOPE, 'mode': mode,
        'status': 'failed', 'failure': None, 'physical_admission': 'unavailable',
        'completion_requires_outer_finalization': True, 'workers': [],
        'original_started_s': started_s, 'finalization': 'pending-after-fsync-observation',
        'actual_partial_counts': 'UNKNOWN until validated completed producer report',
    }
    try:
        evidence.write(source, raw)
        _sync(source)
        last = _check(started_s + 45, last)
        output, errors = directory / 'producer.json', directory / 'producer.stderr.log'
        evidence.write(output, b'')
        evidence.write(errors, b'')
        producer = _watch_worker(_commands(profile, 'producer', source, started_s,
                                           started_s + 45, artificial_commands),
                                 output, errors, started_s + 45, evidence,
                                 inherited_group=True)
        result['workers'].append({'kind': 'producer', **producer})
        last = _check(started_s + 45, last)
        finished = last - started_s
        if producer['exit_code'] != 0:
            raise RunError('completed producer child failed; partial counts UNKNOWN')
        with output.open('rb') as stream:
            producer_raw = stream.read(REPORT_BYTES + 1)
        producer_report = _decode(producer_raw, REPORT_BYTES)
        _producer_summary(producer_report, profile)
        result['producer_observed_counts'] = producer_report['counts']
        trace = _retain_trace(directory, evidence)
        if len(trace.splitlines()) != 10:
            raise RunError('completed collector requires ten markers')
        _sync(output)
        last = _check(started_s + 45, last)
        observation = {
            'schema': 'ariadna-owner-completed-observation-v1', 'exit_code': 0,
            'producer_elapsed_s': finished, 'finalized_elapsed_s': last - started_s,
            'trace_sha256': hashlib.sha256(trace).hexdigest(),
            'report_sha256': hashlib.sha256(producer_raw).hexdigest(),
            'probe_sha256': input_data['probe_sha256'], 'finalization': 'checked-after-fsync',
        }
        evidence.write(directory / 'observation.json', _json_bytes(observation))
        _sync(directory / 'observation.json')
        last = _check(started_s + 45, last)
        cutoff = min(last + 10, started_s + 55)
        output, errors = directory / 'audit.json', directory / 'audit.stderr.log'
        evidence.write(output, b'')
        evidence.write(errors, b'')
        audited = _watch_worker(_commands(profile, 'audit', source, started_s,
                                          cutoff, artificial_commands),
                                output, errors, cutoff, evidence, inherited_group=True)
        result['workers'].append({'kind': 'audit', **audited})
        last = _check(cutoff, last)
        audit = _read(output, AUDIT_BYTES)
        if (audited['exit_code'] != 0 or audit.get('schema') != 'ariadna-owner-completed-audit-v1'
                or audit.get('scope') != _SCOPE or audit.get('mode') != input_data['mode']
                or audit.get('status') != 'passed' or type(audit.get('markers_checked')) is not int
                or audit['markers_checked'] != 10
                or audit.get('kernel_sha256') != input_data['kernel_sha256']
                or audit.get('report_sha256') != hashlib.sha256(producer_raw).hexdigest()
                or audit.get('completion_requires_outer_finalization') is not True
                or audit.get('physical_admission') != 'unavailable'):
            raise RunError('independent completed audit failed or identity/scope mismatch')
        result['actual_partial_counts'] = producer_report['counts']
        result['status'] = 'passed'
    except (RunError, OSError, ValueError, TypeError, KeyError) as exc:
        result['failure'] = f'{type(exc).__name__}: {exc}'[:2048]
    if (directory / 'trace.jsonl').exists() and 'trace.jsonl' not in evidence.used:
        try:
            _retain_trace(directory, evidence)
        except (RunError, OSError, ValueError) as exc:
            result['status'] = 'failed'
            result['failure'] = result['failure'] or f'{type(exc).__name__}: {exc}'[:2048]
    evidence.write(directory / 'receipt.json', _json_bytes(result))
    try:
        for path in directory.iterdir():
            _sync(path)
            last = _check(started_s + 60, last)
        _directory_sync(directory)
        last = _check(started_s + 60, last)
    except (RunError, OSError, ValueError) as exc:
        result['status'] = 'failed'
        result['failure'] = result['failure'] or f'{type(exc).__name__}: {exc}'[:2048]
        result['finalization'] = 'failed-after-fsync'
    else:
        result['finalization'] = 'checked-after-fsync'
    result['structured_bytes'] = evidence.structured
    result['log_bytes'] = evidence.logs
    result['elapsed_after_final_fsync_s'] = last - started_s
    if evidence.structured > EVIDENCE_BYTES or evidence.logs > LOG_BYTES:
        result['status'] = 'failed'
        result['failure'] = result['failure'] or 'aggregate evidence cap exceeded'
    return result
