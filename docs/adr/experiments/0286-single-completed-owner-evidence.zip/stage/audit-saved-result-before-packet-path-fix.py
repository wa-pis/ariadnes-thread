"""One guarded canonical audit of saved F18.16 files; no native execution."""
import time
started = time.monotonic()
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys

root = Path('/private/tmp/ariadna-f18-0285')
episode = Path('/private/tmp/ariadna-f18-forward-completed-v1')
packet = episode / 'execution/native-packet/packet'
outer_python = '/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python'
deadline = started + 10.0
bootstrap = r'''
import importlib.abc,sys,types
blocked=('tudatpy','numpy','scipy','spiceypy','cspyce','space_nav._owner_completed_probe',
         'space_nav._owner_endpoint_fixture','space_nav._owner_endpoint_run',
         'space_nav.trajectory','space_nav.ephemeris','space_nav.transfer')
class Guard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if any(fullname==p or fullname.startswith(p+'.') for p in blocked):
            raise ImportError('saved audit forbids '+fullname)
sys.meta_path.insert(0,Guard())
package=types.ModuleType('space_nav')
package.__path__=['/Users/agrudin/dev/my/ariadna/src/space_nav']
sys.modules['space_nav']=package
from space_nav._owner_completed_audit import main
raise SystemExit(main())
'''
command = [outer_python, '-I', '-B', '-c', bootstrap, '--audit', str(packet/'input.json'),
           str(packet/'producer.json'), str(packet/'observation.json'), str(packet/'trace.jsonl'), repr(deadline)]
process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
failure = None
try:
    output, errors = process.communicate(timeout=max(0.001, deadline-time.monotonic()))
except subprocess.TimeoutExpired:
    failure = 'separate saved-audit10s clock exhausted; no rerun'
    os.killpg(process.pid, signal.SIGKILL)
    output, errors = process.communicate(timeout=1)
finally:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=1)
assert len(output) <= 65536 and len(errors) <= 65536
for name, raw in [('canonical-saved-audit.stdout.json', output), ('canonical-saved-audit.stderr.log', errors)]:
    with (root/name).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
try:
    result = json.loads(output)
except (ValueError, UnicodeError):
    result = None
before = time.monotonic()-started
passed = (failure is None and process.returncode == 0 and not errors and type(result) is dict
          and result.get('status') == 'passed' and result.get('markers_checked') == 10 and before < 10)
receipt = {'schema': 'ariadna.f18.canonical-saved-audit-observation.v1',
           'status': 'passed' if passed else 'failed', 'returncode': process.returncode,
           'failure': failure, 'started_s': started, 'deadline_s': deadline,
           'elapsed_after_output_fsync_s': before, 'stdout_bytes': len(output), 'stderr_bytes': len(errors),
           'stdout_sha256': hashlib.sha256(output).hexdigest(), 'stderr_sha256': hashlib.sha256(errors).hexdigest(),
           'canonical_result': result, 'native_imports': 0, 'producer_imports': 0,
           'spice_queries': 0, 'integrations': 0, 'attempts': 1,
           'clock_scope': 'Separate saved-result review; does not extend actual600/60s clocks.',
           'finalization': 'pending-after-fsync-observation'}
with (root/'canonical-saved-audit.external-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
    stream.flush()
    os.fsync(stream.fileno())
fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
try:
    os.fsync(fd)
finally:
    os.close(fd)
observed = time.monotonic()-started
ok = passed and observed < 10
print(json.dumps({'status': 'passed' if ok else 'failed', 'returncode': process.returncode,
                  'observed_after_external_receipt_fsync_s': observed,
                  'within10s': observed < 10, 'finalization': 'checked-after-fsync' if ok else 'failed-after-fsync',
                  'canonical_result': result}, sort_keys=True, allow_nan=False), flush=True)
raise SystemExit(0 if ok else 2)
