from pathlib import Path
from urllib.parse import unquote
import hashlib,json,os,re,subprocess,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0285');base='24d4982985b8160a1f650e18bb599b63f56e70de'
changed={'CURRENT_STATE.md','docs/adr/README.md','openspec/ROADMAP.md',*[f'openspec/changes/refine-physical-trajectory/{n}.md'for n in('proposal','design','tasks')]}
new={'docs/adr/0285-authorize-one-completed-owner.md','docs/adr/experiments/0285-completed-owner-user-choice.json'}
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert git('rev-parse','HEAD')==base and git('branch','--show-current')=='dev' and not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').splitlines())==changed
assert set(git('ls-files','--others','--exclude-standard').splitlines())==new
protected=0
for row in subprocess.check_output(['git','ls-tree','-rz',base],cwd=r).split(b'\0'):
 if not row:continue
 meta,n=row.split(b'\t',1);name=n.decode()
 if name in changed:continue
 raw=(r/name).read_bytes();assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==meta.split()[2].decode(),name
 protected+=1
x=json.loads((r/'docs/adr/experiments/0285-completed-owner-user-choice.json').read_text());assert x['user_reply']=='разрешаю'and x['decision']=='AUTHORIZE_ONE_CONDITIONAL_EPISODE'and x['stage']=='F18.16'and x['native_admission']=='NOT_ESTABLISHED_BY_THIS_CHOICE'and x['execution_status']=='NOT_STARTED'
assert x['caps']=={'preflight_s_exclusive':600,'native_inclusive_s_exclusive':60,'producer_s':45,'audit_s':10,'finalization_s':5,'failure_only_failsafe_s':65,'input_combined_logs_bytes':65536,'aggregate_structured_bytes':2097152,'trace_bytes':4096,'marker_bytes':512,'context_attempts':1,'factory_attempts':1,'integration_attempts':1,'metadata_attempts':1,'visitor_attempts':1,'callback_max':100000,'new_acquisition_bytes':0}
assert x['unchanged_gates']=={'position_m':.001,'velocity_m_s':1e-6,'mass_kg':1e-9}and not x['automatic_retry_authorized']and not x['scientific_contract_change_authorized']
a=x['qualification_archive'];assert pin((r/a['path']).read_bytes())=={k:a[k]for k in('bytes','sha256')}
with zipfile.ZipFile(r/a['path'])as z:assert z.testzip()is None and len(z.namelist())==122
links=0
for name in sorted(changed|{n for n in new if n.endswith('.md')}):
 for d in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(r/name).read_text()):
  d=d.strip('<>')
  if '://'in d or d.startswith(('mailto:','data:')):continue
  path,_,frag=d.partition('#');dest=((r/name).parent/unquote(path)).resolve()if path else r/name;assert dest.exists(),(name,d);links+=1
assert '- [ ] F18.16 'in(r/'openspec/changes/refine-physical-trajectory/tasks.md').read_text()
assert len((r/'CURRENT_STATE.md').read_text().splitlines())<60
assert not os.path.lexists('/private/tmp/ariadna-f18-forward-completed-v1')and not os.path.ismount('/private/tmp/ariadna-f17-0263/volume')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
v=subprocess.run(['openspec','validate','refine-physical-trajectory','--strict'],cwd=r,capture_output=True,text=True,timeout=60);assert v.returncode==0,v.stdout+v.stderr
res={'schema':'ariadna.f18.user-choice-documentation-check.v1','status':'PASS','base_revision':base,'protected_prior_blobs':protected,'local_links':links,'strict_openspec':{'exit_code':0,'output':v.stdout.strip()},'checked_files':{n:pin((r/n).read_bytes())for n in sorted(changed|new)},'native_admission':False,'runtime_tests_rerun':False}
with(p/'authorization-doc-checks.json').open('x')as f:json.dump(res,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:v for k,v in res.items()if k!='checked_files'}))
