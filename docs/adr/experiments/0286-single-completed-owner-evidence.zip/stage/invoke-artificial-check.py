"""One bounded artificial wiring invocation with frozen checkout and exact source pins."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,sys,time
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0285');op=p/'operator';base='c9b8b565eb39281a6228d28112932398c31edf5d'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def put(path,value):
 raw=(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode();assert len(raw)<=2097152
 with path.open('xb')as f:assert f.write(raw)==len(raw);f.flush();os.fsync(f.fileno())
 fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);os.fsync(fd);os.close(fd)
def frozen():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=r).decode().split('\0');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
 assert head==base and not status
 return {'head':head,'git_status':status,'files':{n:pin((r/n).read_bytes())for n in names if n}}
def sources():
 x=json.loads((op/'operator-pins.json').read_text());assert x['schema']=='ariadna.f18.completed-operator-pins.v1'
 for n,v in x['files'].items():assert pin(Path(n).read_bytes())==v,n
 return pin((op/'operator-pins.json').read_bytes())
assert not os.path.lexists('/private/tmp/ariadna-f18-forward-completed-v1') and not os.path.ismount('/private/tmp/ariadna-f17-0263/volume')
before=frozen();manifest=sources();put(p/'operator-frozen-before.json',before)
started=time.monotonic();deadline=started+120
process=subprocess.Popen([sys.executable,'-I','-B',str(op/'test-operator-wiring.py')],cwd=r,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
failure=None
try:out,err=process.communicate(timeout=max(.001,deadline-time.monotonic()))
except subprocess.TimeoutExpired:
 failure='artificial120s exhausted; no success'
 os.killpg(process.pid,signal.SIGKILL);out,err=process.communicate(timeout=1)
finally:
 try:os.killpg(process.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 process.wait(timeout=1)
assert len(out)+len(err)<=65536
for n,raw in [('operator-artificial.stdout.json',out),('operator-artificial.stderr.log',err)]:
 with(p/n).open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
after=frozen();assert after==before and sources()==manifest
log=err.decode('utf-8');cases=[line for line in log.splitlines()if line.startswith('test_') and line.endswith(' ... ok')];match=re.search(r'\nRan (\d+) tests? in [^\n]+\n\nOK\n?$',log)
okay=match is not None and int(match.group(1))==len(cases)==8 and out==b''
result={'status':'PASS'if okay and process.returncode==0 else'FAIL','tests_run':int(match.group(1))if match else None,'passed_case_lines':cases,'skips':0 if okay else None,'raw_unittest_log_retained':True}
assert not os.path.lexists('/private/tmp/ariadna-f18-forward-completed-v1') and not os.path.ismount('/private/tmp/ariadna-f17-0263/volume')
passed=failure is None and process.returncode==0 and okay and time.monotonic()<deadline
x={'schema':'ariadna.f18.completed-operator-artificial-observation.v1','status':'PASS'if passed else'FAIL','returncode':process.returncode,'failure':failure,'result':result,'stdout':pin(out),'stderr':pin(err),'operator_manifest':manifest,'tracked_files_unchanged':len(before['files']),'git_status_unchanged':True,'elapsed_before_receipt_fsync_s':time.monotonic()-started,'native_episode':False,'mount':False,'spice_queries':0,'finalization':'pending-outer-return'}
put(p/'operator-artificial-observation.json',x)
elapsed=time.monotonic()-started;okay=passed and elapsed<120
print(json.dumps({'status':'PASS'if okay else'FAIL','returncode':process.returncode,'observed_after_receipt_and_directory_fsync_s':elapsed,'within120s':elapsed<120,'manifest':manifest,'tracked_files_unchanged':len(before['files']),'case_result':result,'finalization':'checked-after-fsync'}),flush=True)
raise SystemExit(0 if okay else 2)
