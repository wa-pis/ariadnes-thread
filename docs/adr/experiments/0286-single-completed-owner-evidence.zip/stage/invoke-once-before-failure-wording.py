"""Seal one independently reviewed decision; retain packet and terminal cleanup separately."""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from typing import Any

OPERATOR = Path('/private/tmp/ariadna-f18-0285/operator')


def _prepare() -> Any:
    spec = importlib.util.spec_from_file_location('_completed_operator_prepare', OPERATOR / 'prepare-actual.py')
    if spec is None or spec.loader is None:
        raise RuntimeError('operator source unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def reviewed_decision(operator: Any, base: str) -> tuple[dict[str, Any], dict[str, Any], float]:
    """A pending disk receipt requires a distinct successful observed reviewer return."""
    operator.git_base(base)
    manifest_raw, _ = operator.operator_manifest()
    p = operator.P
    start = operator.object_value(operator.read(p / 'preflight-start.json'))
    profile_raw = operator.read(p / 'profile.json')
    profile = operator.object_value(profile_raw)
    ready = operator.object_value(operator.read(p / 'operator-preflight.json'))
    draft = operator.object_value(operator.read(p / 'execution-decision-draft.json'))
    review_raw = operator.read(p / 'independent-preflight-review.json')
    review = operator.object_value(review_raw)
    observed = operator.object_value(operator.read(p / 'independent-review-observation.json'))
    operator.need(draft['status'] == 'PENDING_INDEPENDENT_REVIEW', 'unreviewed decision shape')
    decision = dict(draft, status='ADMITTED_ONCE')
    decision_raw = operator.encoded(decision)
    binding = {'started_s': start['started_s'], 'base_revision': base,
        'profile_sha256': operator.digest(profile_raw),
        'execution_decision_sha256': operator.digest(decision_raw),
        'operator_manifest_sha256': operator.digest(manifest_raw),
        'auth_choice_sha256': operator.digest(operator.read(operator.REPO / operator.CHOICE))}
    operator.need(start['base_revision'] == base and start['retry_authorized'] is False
        and ready['status'] == 'READY_FOR_INDEPENDENT_REVIEW', 'preflight binding')
    for name, expected in binding.items():
        operator.need(ready[name] == expected and review[name] == expected, 'review binding drift: ' + name)
    operator.need(review['schema'] == 'ariadna.f18.completed-independent-preflight-review.v1'
        and review['status'] == 'PENDING_DURABLE_REVIEW'
        and review['completion_requires_successful_reviewer_return'] is True, 'pending reviewer receipt required')
    operator.need(observed['schema'] == 'ariadna.f18.completed-review-observation.v1'
        and type(observed['returncode']) is int and observed['returncode'] == 0, 'successful external reviewer return required')
    returned = observed['reviewer_return']
    operator.need(returned['status'] == 'PASS_INDEPENDENT_REVIEW'
        and returned['review_sha256'] == operator.digest(review_raw), 'reviewer output receipt drift')
    for name, expected in binding.items():
        operator.need(returned[name] == expected, 'reviewer return binding drift: ' + name)
    started = start['started_s']
    now = time.monotonic()
    operator.need(type(started) in (int, float) and type(observed['observed_s']) in (int, float)
        and 0 <= returned['elapsed_s_after_review_fsync'] <= observed['observed_s'] - started
        <= now - started < 600, 'original600s review/observed clock')
    operator.need(profile['preflight_started_s'] == started and profile['base_revision'] == base
        and profile['execution_decision'] == {'path': str(p / 'execution-decision.json'),
            'bytes': len(decision_raw), 'sha256': operator.digest(decision_raw)}, 'prospective decision identity')
    operator.need(not os.path.lexists(p / 'execution-decision.json')
        and not os.path.lexists(p / 'outer-dispatch.json'), 'once-only decision/dispatch consumed')
    return profile, decision, started


def cleanup(operator: Any, process: subprocess.Popen[bytes] | None) -> dict[str, Any]:
    groups: set[int] = set()
    errors: list[str] = []
    if process is not None:
        raw = subprocess.check_output(['/bin/ps', '-Ao', 'pid=,ppid=,pgid='], timeout=5)
        operator.need(len(raw) <= 65536, 'process snapshot cap')
        rows = [tuple(map(int, line.split())) for line in raw.splitlines()]
        descendants = {process.pid}
        while True:
            expanded = descendants | {pid for pid, parent, _ in rows if parent in descendants}
            if expanded == descendants:
                break
            descendants = expanded
        groups = {group for pid, _, group in rows if pid in descendants} | {process.pid}
    for name in ('parent.pgid', 'supervisor.pgid'):
        path = operator.P / 'execution' / name
        if path.exists():
            raw = operator.read(path, 32).strip()
            operator.need(raw.isdigit(), 'invalid recorded PGID')
            groups.add(int(raw))
    for group in groups:
        operator.need(group > 1 and group not in {os.getpid(), os.getpgrp()}, 'unsafe process group')
        try:
            os.killpg(group, signal.SIGKILL)
        except ProcessLookupError:
            pass
        except PermissionError as exc:
            errors.append(f'killpg({group}) refused: {exc}')
    if process is not None:
        process.wait(timeout=5)
    remaining: list[int] = []
    for group in groups:
        try:
            os.killpg(group, 0)
        except ProcessLookupError:
            continue
        except PermissionError as exc:
            errors.append(f'group({group}) inactivity unknown: {exc}')
        remaining.append(group)
    return {'status': 'PASS' if not remaining and not errors else 'FAILED',
            'groups': sorted(groups), 'remaining_groups': remaining, 'errors': errors, 'postpacket': True}


def invoke(base: str) -> dict[str, Any]:
    operator = _prepare()
    p = operator.P
    post = OPERATOR.parent / 'postpacket'
    process: subprocess.Popen[bytes] | None = None
    profile: dict[str, Any] | None = None
    packet: dict[str, Any] = {'status': 'failed', 'reason': 'not dispatched'}
    failures: list[str] = []
    post.mkdir(exist_ok=False)
    operator.sync_dir(post.parent)
    try:
        profile, decision, started = reviewed_decision(operator, base)
        operator.put(p / 'execution-decision.json', decision)
        operator.need(0 <= time.monotonic() - started < 600, 'original preflight expired before dispatch')
        argv = [profile['outer_python']['path'], '-I', '-B', str(p / 'dispatch-once.py'), str(p / 'profile.json')]
        process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, start_new_session=True, cwd=operator.REPO)
        operator.put(p / 'outer-dispatch.json', {'schema': 'ariadna.f18.completed-outer-dispatch.v1',
            'pid': process.pid, 'pgid': process.pid, 'command': argv, 'preflight_started_s': started,
            'failure_only_deadline_s': started + 600 + 65})
        timed_out = False
        try:
            output, errors = process.communicate(timeout=max(0.001, started + 600 + 65 - time.monotonic()))
        except subprocess.TimeoutExpired:
            timed_out = True
            operator.put(post / 'timeout-cleanup.json', cleanup(operator, process))
            output, errors = process.communicate(timeout=5)
        operator.need(len(output) + len(errors) <= 65536, 'combined outer command64KiB cap')
        operator.put(p / 'collector-actual-stdout.log', output, raw=True)
        operator.put(p / 'collector-actual-stderr.log', errors, raw=True)
        episode = p / 'episode-start.json'
        native_started = operator.object_value(operator.read(episode))['started_s'] if episode.exists() else None
        try:
            actual = operator.object_value(output)
        except (ValueError, UnicodeDecodeError, RuntimeError):
            actual = {}
        after_capture = time.monotonic() - native_started if native_started is not None else None
        candidate = (process.returncode == 0 and not errors and not timed_out
            and actual.get('status') == 'passed' and actual.get('finalization') == 'checked-after-fsync'
            and after_capture is not None and 0 <= after_capture < 60)
        retained = {'schema': 'ariadna.f18.completed-actual-tool-return.v1',
            'status': 'PENDING_FINAL_DURABILITY_CHECK' if candidate else 'failed',
            'returncode': process.returncode, 'timed_out': timed_out, 'collector_actual': actual,
            'original_native_started_s': native_started, 'observed_after_capture_fsync_s': after_capture}
        operator.put(p / 'collector-actual-return.json', retained)
        operator.put(p / 'collector-actual-observed.json', {'status': 'PENDING_FINAL_DURABILITY_CHECK',
            'return_sha256': operator.digest(operator.encoded(retained))})
        total = operator.aggregate(p)
        for directory in sorted([p, *(q for q in p.rglob('*') if q.is_dir())],
                                key=lambda q: len(q.parts), reverse=True):
            operator.sync_dir(directory)
            if native_started is not None:
                operator.need(time.monotonic() < native_started + 60, 'original60s durability clock')
        elapsed = time.monotonic() - native_started if native_started is not None else None
        packet = {'status': 'passed' if candidate and elapsed is not None and 0 <= elapsed < 60 else 'failed',
            'returncode': process.returncode, 'observed_after_own_final_directory_fsync_s': elapsed,
            'aggregate_packet_bytes': total, 'finalization': 'checked-after-fsync',
            'physical_admission': False, 'native_attempt_consumed': (p / 'execution/consumed.json').exists()}
        operator.put(post / 'native-packet-return.json', dict(packet, postpacket=True,
            note='Receipt after native packet observation; does not extend the original60s clock'))
    except BaseException as exc:
        failures.append(type(exc).__name__ + ': ' + str(exc)[:2048])
    finally:
        try:
            result = cleanup(operator, process)
            operator.put(post / 'group-cleanup.json', result)
            if result['status'] != 'PASS':
                failures.append('process-group cleanup failed or inactivity unknown')
        except BaseException as exc:
            failures.append('cleanup: ' + type(exc).__name__ + ': ' + str(exc)[:2048])
        if profile is not None:
            try:
                admission = operator.load_module('_completed_actual_postcheck', p / 'admission.py')
                post_started = time.monotonic()
                def post_tick() -> float:
                    elapsed = time.monotonic() - post_started
                    operator.need(0 <= elapsed < 90, 'bounded postpacket readback')
                    return elapsed
                counts: dict[str, int] = {}
                for group in ('source_pins', 'native_pins', 'ledger_pins', 'control_pins'):
                    for name, pin in profile[group].items():
                        admission._pin(Path(name), pin, post_tick)
                    counts[group] = len(profile[group])
                operator.check_resources(profile['resource_pins'], Path(profile['resource_directory']), admission, post_tick)
                for group in ('outer_python', 'outer_gate', 'contract', 'history_archive'):
                    row = profile[group]
                    admission._pin(Path(row['path']), {k: row[k] for k in ('bytes', 'sha256')}, post_tick)
                ro = admission._live_observation(operator.MOUNT, operator.IMAGE)
                operator.need(ro['read_only'] is True, 'postpacket readonly observation')
                operator.operator_manifest()
                operator.put(post / 'post-native-pins.json', {'status': 'PASS', 'counts': counts,
                    'resources': 11, 'read_only': ro, 'postpacket': True})
            except BaseException as exc:
                failures.append('postpins: ' + type(exc).__name__ + ': ' + str(exc)[:2048])
        try:
            if os.path.ismount(operator.MOUNT):
                operator.command(['/usr/bin/hdiutil', 'detach', str(operator.MOUNT)], timeout=30)
            operator.need(not os.path.ismount(operator.MOUNT), 'image remains mounted')
            operator.put(post / 'detach.json', {'status': 'PASS', 'unmounted': True, 'postpacket': True})
        except BaseException as exc:
            failures.append('detach: ' + type(exc).__name__ + ': ' + str(exc)[:2048])
        try:
            operator.command([str(operator.OUTER), '-I', '-B', str(p / 'check-preservation.py'), 'after'], timeout=90)
            operational = p / 'operational-after.json'
            with operational.open('rb') as stream:
                os.fsync(stream.fileno())
            operator.sync_dir(p)
            receipt = operator.object_value(operator.read(operational))
            operator.need(receipt['status'] == 'passed' and receipt['manifest_equal'] is True
                and receipt['differences'] == [], 'postpacket preservation differs')
            # The qualified checker writes here; move its durably retained result outside packet accounting.
            os.rename(operational, post / 'operational-after.json')
            operator.sync_dir(p)
            operator.sync_dir(post)
        except BaseException as exc:
            failures.append('preservation: ' + type(exc).__name__ + ': ' + str(exc)[:2048])
    total = operator.aggregate(p) + operator.aggregate(post)
    operator.need(total <= operator.LIMIT, 'all actual evidence2MiB cap')
    terminal = {'schema': 'ariadna.f18.completed-operator-terminal.v1',
        'status': 'passed' if packet['status'] == 'passed' and not failures else 'failed',
        'native_packet_observation': packet, 'failures': failures, 'actual_evidence_bytes_before_terminal': total,
        'postpacket': True, 'retry_authorized': False, 'physical_admission': False}
    operator.put(post / 'operator-terminal.json', terminal)
    operator.need(operator.aggregate(p) + operator.aggregate(post) <= operator.LIMIT, 'terminal aggregate cap')
    return terminal


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', required=True)
    args = parser.parse_args()
    result = invoke(args.base)
    print(json.dumps(result, sort_keys=True), flush=True)
    raise SystemExit(0 if result['status'] == 'passed' else 2)


if __name__ == '__main__':
    main()
