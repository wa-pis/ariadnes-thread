"""Prepare one completed-owner episode; no admission, acquisition or native call."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
from typing import Any, Callable
import zipfile

REPO = Path('/Users/agrudin/dev/my/ariadna')
P = Path('/private/tmp/ariadna-f18-forward-completed-v1')
MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
IMAGE = MOUNT.parent / 'scratch.sparseimage'
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
OPERATOR = Path('/private/tmp/ariadna-f18-0285/operator')
CHOICE = 'docs/adr/experiments/0285-completed-owner-user-choice.json'
CONTRACT_SHA = '20397decfe63f978648cfb220778e962410f3a26cab7690449183aae33e52dd8'
ARCHIVES = {
    '0283-completed-control-mapping-evidence.zip': '67bce8cf47c25d2f2c933f6ec37b243d22955c902ca43a3865c87ad42f29374b',
    '0284-completed-control-qualification-evidence.zip': 'ce42d3dee1f176fa0f7efe62ba4b7f9a836e7487ae0bda356a2813abbfc7ff1b',
    '0280-supplemented-setup-evidence.zip': '12bcc6f1c2ce60d2eeff69f466d7d5e0213b28325fb1b19493923661090af242',
}
CONTROL_NAMES = ('call-once.py', 'launch-once.py', 'native.sandbox',
                 'check-preservation.py', 'run-once.py', 'native-entry.py',
                 'supervisor-adapter.py', 'admission.py')
OPERATOR_NAMES = {'prepare-actual.py', 'invoke-once.py', 'review-actual.py', 'test-operator-wiring.py'}
LIMIT = 2097152


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read(path: Path, cap: int = 65536) -> bytes:
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory ancestor')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'regular bounded file required')
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        need(len(raw) == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns,
             'short/changed proof')
        return raw
    finally:
        os.close(fd)


def object_value(raw: bytes) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in items:
            need(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite JSON value: ' + value)
    result = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    need(type(result) is dict, 'JSON object required')
    return result


def sync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def put(path: Path, value: object, *, raw: bool = False) -> None:
    data = value if raw else encoded(value)
    need(type(data) is bytes and len(data) <= 65536, 'record64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(data):
            count = os.write(fd, data[offset:])
            need(0 < count <= len(data) - offset, 'record short write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    sync_dir(path.parent)


def aggregate(root: Path) -> int:
    total = logs = 0
    for path in root.rglob('*'):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        need(stat.S_ISREG(info.st_mode), 'nonregular evidence')
        total += info.st_size
        if path.suffix == '.log':
            logs += info.st_size
        need(total <= LIMIT and logs <= 65536, '2MiB total/64KiB logs cap')
    return total


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'module loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def command(argv: list[str], *, timeout: float = 30) -> bytes:
    result = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=timeout, check=False)
    need(len(result.stdout) + len(result.stderr) <= 65536, 'combined command64KiB log cap')
    need(result.returncode == 0, f'command refused: {argv[0]} exit{result.returncode}')
    return result.stdout


def git_base(base: str) -> None:
    need(re.fullmatch('[0-9a-f]{40}', base) is not None, 'explicit full base SHA required')
    need(command(['git', 'rev-parse', 'HEAD']).decode().strip() == base, 'HEAD differs from explicit base')
    need(command(['git', 'branch', '--show-current']).strip() == b'dev', 'dev required')
    need(not command(['git', 'status', '--porcelain']).strip(), 'clean checkout required')
    need(read(REPO / CHOICE) == command(['git', 'show', base + ':' + CHOICE]), 'committed authorization drift')


def operator_manifest() -> tuple[bytes, dict[str, Any]]:
    raw = read(OPERATOR / 'operator-pins.json')
    result = object_value(raw)
    need(result['schema'] == 'ariadna.f18.completed-operator-pins.v1'
         and set(result['files']) == {str(OPERATOR / name) for name in OPERATOR_NAMES}, 'exact4 operator pins')
    for name, row in result['files'].items():
        data = read(Path(name))
        need(row == {'bytes': len(data), 'sha256': digest(data)}, 'operator source drift: ' + name)
    return raw, result


def material() -> tuple[bytes, dict[str, Any], dict[str, bytes], dict[str, Any]]:
    packets: dict[str, zipfile.ZipFile] = {}
    for name, expected in ARCHIVES.items():
        raw = read(REPO / 'docs/adr/experiments' / name, LIMIT)
        need(digest(raw) == expected, 'qualified archive drift')
        packets[name[:4]] = zipfile.ZipFile(io.BytesIO(raw))
    try:
        contract_raw = packets['0283'].read('mapping-v2.json')
        need(digest(contract_raw) == CONTRACT_SHA, 'exact mapping-v2 bytes required')
        c = object_value(contract_raw)
        manifest = object_value(packets['0284'].read('qualified-cleanup-oracle-sources.json'))
        controls: dict[str, bytes] = {}
        for name in (*CONTROL_NAMES, 'dispatch-once.py'):
            raw = packets['0284'].read('controls/' + name)
            expected = manifest['files']['/private/tmp/ariadna-f18-0284/controls/' + name]
            need(expected == {'bytes': len(raw), 'sha256': digest(raw)}, 'qualified control drift')
            controls[name] = raw
        historical = packets['0280']
        need(len(historical.namelist()) == len(set(historical.namelist())) == 86
             and set(historical.namelist()) == set(c['historical_0280_member_pins']), 'exact86 history')
        for name, expected in c['historical_0280_member_pins'].items():
            raw = historical.read(name)
            need(expected == {'bytes': len(raw), 'sha256': digest(raw)}, 'historical member drift')
        reference = object_value(historical.read('profile.json'))
        return contract_raw, c, controls, reference
    finally:
        for packet in packets.values():
            packet.close()


def check_resources(rows: list[dict[str, Any]], resources: Path, admission: Any,
                    tick: Callable[[], float]) -> None:
    names: set[str] = set()
    for root, directories, files in os.walk(resources, followlinks=False):
        tick()
        for name in directories + files:
            need(not (Path(root) / name).is_symlink(), 'resource symlink')
        names.update(str((Path(root) / name).relative_to(resources)) for name in files)
    need(len(rows) == 11 and names == {row['name'] for row in rows}, 'exact11 resource inventory')
    for row in rows:
        admission._pin(resources / row['name'], {k: row[k] for k in ('bytes', 'sha256')}, tick)


def prepare(base: str) -> dict[str, Any]:
    git_base(base)
    need(not os.path.lexists(P) and not os.path.ismount(MOUNT), 'occupied namespace or mount')
    manifest_raw, _ = operator_manifest()
    contract_raw, c, controls, reference = material()
    started = time.monotonic()  # Before the first new namespace write or mount.
    need(type(started) in (float, int) and math.isfinite(started), 'finite initial clock')
    P.mkdir()
    sync_dir(P.parent)
    mounted = False
    last = started

    def tick() -> float:
        nonlocal last
        now = time.monotonic()
        need(last <= now and 0 <= now - started < 600, 'original600s preflight exhausted')
        last = now
        return now - started

    def run(argv: list[str], limit: float = 30) -> bytes:
        result = command(argv, timeout=min(limit, 600 - tick()))
        tick()
        return result

    try:
        put(P / 'preflight-start.json', {'schema': 'ariadna.f18.completed-preflight-start.v1',
            'started_s': started, 'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'base_revision': base, 'retry_authorized': False})
        for name, raw in controls.items():
            put(P / name, raw, raw=True)
        put(P / 'mapping-v2.json', contract_raw, raw=True)
        admission = load_module('_completed_actual_admission', P / 'admission.py')
        run([str(OUTER), '-I', '-B', str(P / 'check-preservation.py'), 'before'], 90)
        with (P / 'operational-before.json').open('rb') as stream:
            os.fsync(stream.fileno())
        sync_dir(P)
        operational_raw = read(P / 'operational-before.json')
        operational = object_value(operational_raw)
        need(operational['status'] == 'passed' and operational['manifest_equal'] is True
             and operational['differences'] == [] and operational['phase'] == 'before'
             and operational['baseline_file_sha256'] == '4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56',
             'operational preservation baseline differs')
        sources = admission._canonical_group(c['old_source_pins'], REPO)
        appended = admission._canonical_group(c['appended_source_pins'], REPO)
        need(not set(sources) & set(appended), 'duplicate source identity')
        sources.update(appended)
        need(len(sources) == 53 and len(c['native_pins']) == 10 and len(c['historical_ledger_pins']) == 25,
             'fixed53/10/25 pin counts')
        groups = {'source_pins': sources, 'native_pins': c['native_pins'],
                  'ledger_pins': c['historical_ledger_pins'],
                  'control_pins': {str(P / name): {'bytes': len(controls[name]), 'sha256': digest(controls[name])}
                                   for name in CONTROL_NAMES}}
        for group in ('source_pins', 'ledger_pins', 'control_pins'):
            for name, row in groups[group].items():
                admission._pin(Path(name), row, tick)
        run(['/usr/bin/hdiutil', 'attach', str(IMAGE), '-nobrowse', '-noautoopen',
             '-mountpoint', str(MOUNT), '-readonly'])
        mounted = True
        observation = admission._live_observation(MOUNT, IMAGE)
        need(observation['read_only'] is True and 0 < observation['capacity_bytes'] <= 8589934592,
             'retained mount must be read-only within8GiB')
        resources = MOUNT / 'home/.tudat/resource'
        rows = c['retained_resources']
        check_resources(rows, resources, admission, tick)
        for name, row in groups['native_pins'].items():
            admission._pin(Path(name), row, tick)
        history = {'path': str(REPO / c['reference_archive']['path']),
                   **{k: c['reference_archive'][k] for k in ('bytes', 'sha256')}}
        contract = {'path': str(P / 'mapping-v2.json'), 'bytes': len(contract_raw), 'sha256': CONTRACT_SHA}
        gate = {'path': str(P / 'dispatch-once.py'), 'bytes': len(controls['dispatch-once.py']),
                'sha256': digest(controls['dispatch-once.py'])}
        outer_path = OUTER.resolve()
        outer_data = read(outer_path, 16 * 1024 * 1024)
        outer = {'path': str(outer_path), 'bytes': len(outer_data), 'sha256': digest(outer_data)}
        expected = dict(groups, resource_pins=rows, history_member_pins=c['historical_0280_member_pins'],
                        history_archive=history, contract=contract)
        decision = {'schema': 'ariadna.f18.completed-execution-decision.v1', 'stage': 'F18.16',
            'mode': 'native', 'status': 'ADMITTED_ONCE', 'base_revision': base, 'contract_sha256': CONTRACT_SHA,
            'expected_pins': expected, 'outer_gate_pin': gate, 'outer_python_pin': outer}
        put(P / 'execution-decision-draft.json', dict(decision, status='PENDING_INDEPENDENT_REVIEW'))
        probe = {'schema': 'ariadna-owner-completed-input-v1', 'scope': 'single-forward-completed-owner-only',
            'mode': 'native', 'kernel_path': reference['probe_input']['kernel_path'],
            'kernel_sha256': reference['kernel_sha256']}
        for field, name in {'probe_sha256': '_owner_completed_probe.py',
            'owner_fixture_sha256': '_owner_endpoint_fixture.py', 'owner_auditor_sha256': '_owner_endpoint_audit.py',
            'trajectory_sha256': 'trajectory.py', 'completed_auditor_sha256': '_owner_completed_audit.py'}.items():
            probe[field] = sources[str(REPO / 'src/space_nav' / name)]['sha256']
        profile = {'schema': 'ariadna.f18.completed-control-profile.v1',
            'scope': 'single-forward-completed-owner-only', 'mode': 'native', 'repo': str(REPO),
            'base_revision': base, 'root': str(P), 'work_directory': str(P / 'execution'),
            'preflight_started_s': started, 'outer_python': outer, 'private_python': reference['private_python'],
            'environment': reference['environment'], 'sandbox_profile': str(P / 'native.sandbox'), **groups,
            'resource_pins': rows, 'resource_directory': str(resources), 'image': str(IMAGE), 'mount': str(MOUNT),
            'history_archive': history, 'history_member_pins': c['historical_0280_member_pins'],
            'outer_gate': gate, 'contract': contract, 'kernel_sha256': reference['kernel_sha256'], 'probe_input': probe,
            'prelaunch_admission': str(P / 'launch-admission.json'),
            'execution_decision': {'path': str(P / 'execution-decision.json'),
                                   'bytes': len(encoded(decision)), 'sha256': digest(encoded(decision))}}
        for field, name in {'entry_sha256': 'native-entry.py', 'launch_sha256': 'launch-once.py',
            'caller_sha256': 'call-once.py', 'adapter_sha256': 'supervisor-adapter.py',
            'sandbox_sha256': 'native.sandbox'}.items():
            profile[field] = groups['control_pins'][str(P / name)]['sha256']
        need(set(profile) == admission.PROFILE_KEYS and set(probe) == admission.PROBE_KEYS, 'exact completed wire shape')
        put(P / 'profile.json', profile)
        operator_manifest()
        ready = {'schema': 'ariadna.f18.completed-operator-preflight.v1',
            'status': 'READY_FOR_INDEPENDENT_REVIEW', 'started_s': started, 'elapsed_s': tick(),
            'base_revision': base, 'profile_sha256': digest(encoded(profile)),
            'execution_decision_sha256': digest(encoded(decision)), 'operator_manifest_sha256': digest(manifest_raw),
            'auth_choice_sha256': digest(read(REPO / CHOICE)), 'operational_sha256': digest(operational_raw),
            'group_counts': {**{k: len(v) for k, v in groups.items()},
                'resource_pins': len(rows), 'history_member_pins': len(c['historical_0280_member_pins'])}, 'resources': len(rows),
            'resource_bytes': sum(row['bytes'] for row in rows), 'live_observation': observation}
        put(P / 'operator-preflight.json', ready)
        aggregate(P)
        elapsed = tick()
        return {'status': ready['status'], 'elapsed_s_after_ready_fsync': elapsed,
                'remaining_preflight_s': 600 - elapsed, 'namespace': str(P)}
    except BaseException as exc:
        try:
            put(P / 'operator-preflight-failure.json', {'status': 'FAILED_NO_RETRY',
                'error_type': type(exc).__name__, 'message': str(exc)[:2048], 'started_s': started,
                'elapsed_s': time.monotonic() - started})
        finally:
            if mounted or os.path.ismount(MOUNT):
                result = subprocess.run(['/usr/bin/hdiutil', 'detach', str(MOUNT)],
                                        capture_output=True, timeout=30, check=False)
                put(P / 'failed-preflight-detach.json', {'returncode': result.returncode,
                    'unmounted': not os.path.ismount(MOUNT), 'postpacket': True})
        raise


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.base), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
