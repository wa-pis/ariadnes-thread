"""Record the actual completed reviewer tool return once on its original clock."""
from pathlib import Path
import json,math,os,sys,time
p=Path('/private/tmp/ariadna-f18-forward-completed-v1')
observed=time.monotonic()
assert len(sys.argv)==2 and len(sys.argv[1].encode())<=65536
capture=json.loads(sys.argv[1]);assert set(capture)=={'exit_code','output'}and type(capture['exit_code'])is int and capture['exit_code']==0 and type(capture['output'])is str
returned=json.loads(capture['output']);assert returned['status']=='PASS_INDEPENDENT_REVIEW'and returned['mode']=='native'and returned['native_calls']==0 and returned['live_decision_written']is False
start=json.loads((p/'preflight-start.json').read_bytes())['started_s'];assert type(start)in(int,float)and math.isfinite(start)
assert 0<=returned['elapsed_s_after_review_fsync']<=observed-start<600
x={'schema':'ariadna.f18.completed-review-observation.v1','returncode':capture['exit_code'],'reviewer_return':returned,'observed_s':observed}
raw=(json.dumps(x,sort_keys=True,allow_nan=False)+'\n').encode();assert len(raw)<=65536
fd=os.open(p/'independent-review-observation.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
try:
 offset=0
 while offset<len(raw):
  n=os.write(fd,raw[offset:]);assert n>0;offset+=n
 os.fsync(fd)
finally:os.close(fd)
fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:os.fsync(fd)
finally:os.close(fd)
assert 0<=time.monotonic()-start<600
print(json.dumps({'status':'REVIEW_TOOL_RETURN_RECORDED','elapsed_s_after_observation_fsync':time.monotonic()-start,'native_admission':False}),flush=True)
