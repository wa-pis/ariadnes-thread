"""One bounded artificial qualification invocation; no mount or native command."""
from __future__ import annotations

from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
from types import SimpleNamespace
from typing import Any
import unittest
from unittest.mock import patch
import zipfile

HERE = Path('/private/tmp/ariadna-f18-0285/operator')
ARTIFICIAL = Path('/private/tmp/ariadna-f18-0284/artificial')
REPO = Path('/Users/agrudin/dev/my/ariadna')
BASE = 'c9b8b565eb39281a6228d28112932398c31edf5d'


def load(name: str) -> Any:
    spec = importlib.util.spec_from_file_location('operator_test_' + name.replace('-', '_'), HERE / name)
    if spec is None or spec.loader is None:
        raise RuntimeError('source loader absent')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class Wiring(unittest.TestCase):
    def setUp(self) -> None:
        ARTIFICIAL.mkdir(exist_ok=True)
        self.case = Path(tempfile.mkdtemp(prefix='case-', dir=ARTIFICIAL))
        self.p = self.case / 'episode'
        self.fixture = self.case / 'fixtures'
        self.repo = self.fixture / 'repo'
        self.repo.mkdir(parents=True)
        self.operator = self.fixture / 'operator'
        self.operator.mkdir()
        self.prep = load('prepare-actual.py')
        self.inv = load('invoke-once.py')
        self.rev = load('review-actual.py')
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        self.addCleanup(shutil.rmtree, self.case)
        self.mounted = False
        self.commands: list[list[str]] = []
        self.controls: dict[str, bytes] = {}
        self.pin = lambda raw: {'bytes': len(raw), 'sha256': self.prep.digest(raw)}
        with zipfile.ZipFile(REPO / 'docs/adr/experiments/0284-completed-control-qualification-evidence.zip') as z:
            for name in (*self.prep.CONTROL_NAMES, 'dispatch-once.py'):
                self.controls[name] = z.read('controls/' + name)
        def write(path: Path, data: bytes) -> dict[str, Any]:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            return self.pin(data)
        sources: dict[str, Any] = {}
        names = ['src/space_nav/_owner_endpoint_fixture.py', 'src/space_nav/_owner_endpoint_audit.py',
                 'src/space_nav/trajectory.py'] + [f'src/old-{i}.py' for i in range(46)]
        names += ['src/space_nav/_owner_completed_probe.py', 'src/space_nav/_owner_completed_audit.py',
                  'tests/test_owner_completed_probe.py', 'tests/test_owner_completed_audit.py']
        for index, name in enumerate(names):
            path = self.repo / name
            sources[str(path) if index < 49 else name] = write(path, f'# fabricated source{index}\n'.encode())
        native = {str(self.fixture / f'native/{i}.bin'): write(self.fixture / f'native/{i}.bin', f'non-executable{i}'.encode())
                  for i in range(10)}
        ledgers = {str(self.fixture / f'ledger/{i}.json'): write(self.fixture / f'ledger/{i}.json', b'{}\n') for i in range(25)}
        self.mount = self.fixture / 'volume'
        self.resources = self.mount / 'home/.tudat/resource'
        with zipfile.ZipFile(REPO / 'docs/adr/experiments/0283-completed-control-mapping-evidence.zip') as z:
            real = json.loads(z.read('mapping-v2.json'))
        rows = [{'name': row['name'], **write(self.resources / row['name'], bytes([65 + i]) * row['bytes'])}
                for i, row in enumerate(real['retained_resources'])]
        kernel = next(iter(native))
        self.reference = {'environment': {'LANG': 'C'}, 'private_python': str(self.prep.OUTER.resolve()),
            'kernel_sha256': native[kernel]['sha256'], 'probe_input': {'kernel_path': kernel}}
        archive = self.fixture / 'history.zip'
        members = {}
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
            for index, name in enumerate(real['historical_0280_member_pins']):
                data = self.prep.encoded(self.reference) if name == 'profile.json' else f'fakehistory{index}'.encode()
                z.writestr(name, data)
                members[name] = self.pin(data)
        self.c = {'schema': 'ariadna.f18.completed-control-mapping.v1', 'qualification': 'ARTIFICIAL',
            'old_source_pins': dict(list(sources.items())[:49]), 'appended_source_pins': dict(list(sources.items())[49:]),
            'native_pins': native, 'historical_ledger_pins': ledgers, 'retained_resources': rows,
            'historical_0280_member_pins': members, 'environment_unchanged': self.reference['environment'],
            'reference_archive': {'path': str(archive), **self.pin(archive.read_bytes())}}
        self.contract_raw = self.prep.encoded(self.c)
        for name in self.prep.OPERATOR_NAMES:
            write(self.operator / name, (HERE / name).read_bytes())
        manifest = {'schema': 'ariadna.f18.completed-operator-pins.v1',
                    'files': {str(self.operator / name): self.pin((self.operator / name).read_bytes())
                              for name in self.prep.OPERATOR_NAMES}}
        write(self.operator / 'operator-pins.json', self.prep.encoded(manifest))
        choice = (REPO / self.prep.CHOICE).read_bytes()
        write(self.repo / self.prep.CHOICE, choice)
        shutil.copyfile(REPO / 'docs/adr/experiments/0284-completed-control-qualification-evidence.zip',
                        self.repo / 'docs/adr/experiments/0284-completed-control-qualification-evidence.zip')
        self.stack.enter_context(patch.multiple(self.prep, P=self.p, REPO=self.repo, OPERATOR=self.operator,
            MOUNT=self.mount, IMAGE=self.fixture / 'image', CONTRACT_SHA=self.prep.digest(self.contract_raw)))
        self.stack.enter_context(patch.object(self.prep, 'git_base', lambda base: self.assertEqual(base, BASE)))
        self.stack.enter_context(patch.object(self.prep, 'material', lambda: (self.contract_raw, self.c, self.controls, self.reference)))
        self.stack.enter_context(patch.object(self.prep, 'command', self.command))
        self.stack.enter_context(patch.object(self.prep.os.path, 'ismount', lambda path: self.mounted))
        loader = self.prep.load_module
        def fake_loader(name: str, path: Path) -> Any:
            result = loader(name, path)
            result._live_observation = lambda mount, image: self.observer(image, mount)
            return result
        self.stack.enter_context(patch.object(self.prep, 'load_module', fake_loader))
        self.stack.enter_context(patch.multiple(self.rev, ROOT=self.p, PREP=self.operator, REPO=self.repo))
        self.stack.enter_context(patch.object(self.rev, '_clean_git', lambda base, tick: tick()))
        self.stack.enter_context(patch.object(self.rev, '_committed_authority', lambda base, helper, tick: self.prep.digest(choice)))
        self.stack.enter_context(patch.multiple(self.inv, OPERATOR=self.operator))
        self.stack.enter_context(patch.object(self.inv, '_prepare', lambda: self.prep))

    def observer(self, image: Path, mount: Path) -> dict[str, Any]:
        return {'image': str(image), 'mount': str(mount), 'read_only': True, 'capacity_bytes': 8589934592}

    def command(self, argv: list[str], *, timeout: float = 30) -> bytes:
        self.commands.append(argv)
        self.assertGreater(timeout, 0)
        if argv[0] == '/usr/bin/hdiutil':
            if argv[1] == 'attach':
                self.assertIn('-readonly', argv)
                self.assertNotIn('-readwrite', argv)
                self.mounted = True
            else:
                self.mounted = False
        elif argv[-1] in {'before', 'after'}:
            phase = argv[-1]
            self.prep.put(self.p / f'operational-{phase}.json', {
                'schema': 'ariadna.f18.operational-preservation.v1', 'status': 'passed', 'phase': phase,
                'manifest_equal': True, 'differences': [],
                'baseline_file_sha256': '4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56'})
        return b''

    def prepared_artificial(self) -> None:
        result = self.prep.prepare(BASE)
        self.assertEqual(result['status'], 'READY_FOR_INDEPENDENT_REVIEW')
        self.assertFalse((self.p / 'execution-decision.json').exists())
        profile = json.loads((self.p / 'profile.json').read_bytes())
        profile['mode'] = 'artificial'
        profile['probe_input']['mode'] = 'injected'
        draft = json.loads((self.p / 'execution-decision-draft.json').read_bytes())
        draft['mode'] = 'artificial'
        decision_raw = self.prep.encoded(dict(draft, status='ADMITTED_ONCE'))
        profile['execution_decision'].update(bytes=len(decision_raw), sha256=self.prep.digest(decision_raw))
        for name, obj in [('profile.json', profile), ('execution-decision-draft.json', draft)]:
            (self.p / name).write_bytes(self.prep.encoded(obj))
        ready = json.loads((self.p / 'operator-preflight.json').read_bytes())
        ready.update(profile_sha256=self.prep.digest(self.prep.encoded(profile)),
                     execution_decision_sha256=self.prep.digest(decision_raw))
        (self.p / 'operator-preflight.json').write_bytes(self.prep.encoded(ready))

    def reviewed(self) -> dict[str, Any]:
        self.prepared_artificial()
        result = self.rev.review(BASE, artificial_observer=self.observer)
        self.prep.put(self.p / 'independent-review-observation.json', {
            'schema': 'ariadna.f18.completed-review-observation.v1', 'returncode': 0,
            'reviewer_return': result, 'observed_s': time.monotonic()})
        return result

    def test_connected_prepare_review_dispatch_and_terminal_order(self) -> None:
        self.reviewed()
        cleanup_calls: list[bool] = []
        class HarmlessProcess:
            pid = 99999999
            returncode = 0
            def __init__(inner, argv: list[str], **kwargs: Any) -> None:
                self.assertTrue((self.p / 'execution-decision.json').exists())
                self.assertEqual(argv, [str(self.prep.OUTER.resolve()), '-I', '-B',
                    str(self.p / 'dispatch-once.py'), str(self.p / 'profile.json')])
                self.prep.put(self.p / 'episode-start.json', {'started_s': time.monotonic()})
            def communicate(inner, timeout: float) -> tuple[bytes, bytes]:
                return self.prep.encoded({'status': 'passed', 'finalization': 'checked-after-fsync'}), b''
        def clean(operator: Any, process: Any) -> dict[str, Any]:
            cleanup_calls.append(True)
            return {'status': 'PASS', 'postpacket': True}
        with patch.object(self.inv.subprocess, 'Popen', HarmlessProcess), patch.object(self.inv, 'cleanup', clean):
            result = self.inv.invoke(BASE)
        self.assertEqual(result['status'], 'passed', result)
        self.assertFalse(self.mounted)
        self.assertEqual(len(cleanup_calls), 1)
        self.assertEqual(len([cmd for cmd in self.commands if cmd[:2] == ['/usr/bin/hdiutil', 'attach']]), 1)
        self.assertEqual(len(json.loads((self.p / 'profile.json').read_bytes())['source_pins']), 53)
        self.assertTrue(all(Path(name).is_absolute() for name in json.loads((self.p / 'profile.json').read_bytes())['source_pins']))
        self.assertEqual(result['native_packet_observation']['finalization'], 'checked-after-fsync')
        self.assertLess(self.prep.aggregate(self.p) + self.prep.aggregate(self.operator.parent / 'postpacket'), 2097152)

    def test_pending_disk_review_is_not_observed_completion(self) -> None:
        self.prepared_artificial()
        self.rev.review(BASE, artificial_observer=self.observer)
        with self.assertRaises(FileNotFoundError):
            self.inv.reviewed_decision(self.prep, BASE)
        self.assertFalse((self.p / 'execution-decision.json').exists())

    def test_failed_review_or_changed_profile_refuses_before_decision(self) -> None:
        self.reviewed()
        path = self.p / 'independent-review-observation.json'
        value = json.loads(path.read_bytes())
        value['returncode'] = 2
        path.write_bytes(self.prep.encoded(value))
        with self.assertRaisesRegex(RuntimeError, 'successful external'):
            self.inv.reviewed_decision(self.prep, BASE)
        value['returncode'] = 0
        path.write_bytes(self.prep.encoded(value))
        with (self.p / 'profile.json').open('ab') as stream:
            stream.write(b' ')
        with self.assertRaisesRegex(RuntimeError, 'review binding drift'):
            self.inv.reviewed_decision(self.prep, BASE)
        self.assertFalse((self.p / 'execution-decision.json').exists())

    def test_original_review_clock_cannot_restart(self) -> None:
        self.reviewed()
        started = json.loads((self.p / 'preflight-start.json').read_bytes())['started_s']
        with patch.object(self.inv.time, 'monotonic', return_value=started + 600):
            with self.assertRaisesRegex(RuntimeError, 'original600s'):
                self.inv.reviewed_decision(self.prep, BASE)
        self.assertFalse((self.p / 'execution-decision.json').exists())

    def test_occupied_namespace_never_mounts_or_overwrites(self) -> None:
        self.p.mkdir()
        sentinel = self.p / 'user-owned'
        sentinel.write_bytes(b'preserve')
        with self.assertRaisesRegex(RuntimeError, 'occupied'):
            self.prep.prepare(BASE)
        self.assertEqual(sentinel.read_bytes(), b'preserve')
        self.assertFalse(self.commands)

    def test_no_writeable_mount_and_drift_refusal_detaches_even_failed_receipt(self) -> None:
        original_load = self.prep.load_module
        def loader(name: str, path: Path) -> Any:
            module = original_load(name, path)
            module._live_observation = lambda mount, image: {'read_only': False, 'capacity_bytes': 1}
            return module
        original_put = self.prep.put
        def put(path: Path, value: object, *, raw: bool = False) -> None:
            if path.name == 'operator-preflight-failure.json':
                raise OSError('fabricated fsync failure')
            original_put(path, value, raw=raw)
        with patch.object(self.prep, 'load_module', loader), patch.object(self.prep, 'put', put), \
             patch.object(self.prep.subprocess, 'run', return_value=SimpleNamespace(returncode=0)) as detach:
            with self.assertRaisesRegex(OSError, 'fsync failure'):
                self.prep.prepare(BASE)
        self.assertEqual(detach.call_args.args[0][:2], ['/usr/bin/hdiutil', 'detach'])
        self.assertFalse((self.p / 'profile.json').exists())

    def test_payload_pin_drift_refuses_before_mount(self) -> None:
        first = Path(next(iter(self.c['old_source_pins'])))
        first.write_bytes(b'changed source bytes')
        with self.assertRaises(RuntimeError):
            self.prep.prepare(BASE)
        self.assertFalse(self.commands and any(cmd[0] == '/usr/bin/hdiutil' for cmd in self.commands))
        self.assertFalse((self.p / 'profile.json').exists())

    def test_record_exclusive_fsync_and_aggregate_caps(self) -> None:
        self.p.mkdir()
        target = self.p / 'sealed.json'
        with patch.object(self.prep.os, 'fsync', wraps=os.fsync) as sync:
            self.prep.put(target, {'pending': True})
        self.assertGreaterEqual(sync.call_count, 2)
        with self.assertRaises(FileExistsError):
            self.prep.put(target, {})
        with self.assertRaisesRegex(RuntimeError, '64KiB'):
            self.prep.put(self.p / 'oversized', b'x' * 65537, raw=True)
        (self.p / 'huge').write_bytes(b'x' * 2097152)
        with self.assertRaisesRegex(RuntimeError, '2MiB'):
            self.prep.aggregate(self.p)


if __name__ == '__main__':
    before = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Wiring)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if time.monotonic() - before >= 120:
        raise SystemExit('artificial campaign original120s exhausted')
    raise SystemExit(0 if result.wasSuccessful() else 2)
