from pathlib import Path
import hashlib,json,os,time
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0287')
anchors={
'docs/adr/0267-design-actual-owner-endpoint-qualification.md':[(46,123)],
'docs/adr/0268-qualify-artificial-owner-runner.md':[(29,55)],
'docs/adr/0286-verify-single-completed-owner.md':[(1,110)],
'src/space_nav/_owner_endpoint_fixture.py':[(121,173),(310,347)],
'src/space_nav/_owner_completed_probe.py':[(158,205)],
'src/space_nav/_native_arc_conformance.py':[(192,232),(338,378)],
'src/space_nav/_coupled_bridge.py':[(445,470)],
'src/space_nav/trajectory.py':[(1821,1890)],
'src/space_nav/research_propagation.py':[(302,317),(328,375)],
'docs/adr/0247-formulate-coupled-moon-mars-problem.md':[(1,75)],
}
sources={}
for name,ranges in anchors.items():
 raw=(r/name).read_bytes();lines=raw.decode().splitlines()
 sources[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'anchors':[{'first':a,'last':b,'text':'\n'.join(lines[a-1:b])}for a,b in ranges]}
res={'schema':'ariadna.f18.owner-carry-readiness-note.v1','stage':'F18.17','base_revision':'13f53fb663c7614b9d662beeddb7799d9d076ef3','fixed':'Original0267 fixture and0247F0 boundaries/sixcontrols unchanged','free_scientific_variables':[],
'finding':'0286 establishes one fixed forward owner endpoint only.0267 deliberately uses independent forward and reverse literals; it has no interarc carry premise. Missing0267carry is not a defect to fix.',
'existing':'0268 artificial fullowner runner and0251 artificial bridge replaycarry are already qualified; do not repeat unchanged tests or connect0267reverse to forward output.',
'precise_missing_prerequisite':'A source-backed contract associates the original-key primitive endpoint and processed seven-state metadata/completion with the existing production state/mass handoff, preserving requested versus observed time and failing closed without exported history maps. No such qualified production adapter follows from0286.',
'next_source_question':'F18.18: map original-key endpoint to the existing handoff; enumerate each required already-proven premise and exact missing prerequisite before adopting any adapter.',
'conditional_gates':{'copy':'All seven binary64 state/mass words and source-endpoint association exactly preserved; no tolerance for substitution. This is a proposed interface gate, not evidence of arbitrary-time validity.','time':'Requested/represented/observed epochs remain distinct. Existing exact-event requirement and <=1e-6s label/residual checks cannot be inferred from integer1000s or approximate equality.','numerical':'If a later analytic fixture is separately admitted, use its independent own-start Fraction(binary64) oracle, Euclidean position<=0.001m, velocity<=1e-6m/s, scalar mass<=1e-9kg, without resetting mass or changing reverse initial literal. No oracle evaluated now.'},
'work_performed':'Source/metadata reading and independent source review only; no test/import/native/SPICE/integration/mount/acquisition/scientific-oracle-command-trajectory evaluation',
'native_authority':'ADR0285 consumed; no new native episode or replay authorized',
'qualification':'SOURCE_READINESS_ONLY; full0267, nativecarry, arbitraryTime, ABI/FP, physicalF0/M3/99percent remain OPEN',
'source_pins':sources}
with(p/'root-source-note.json').open('x')as f:json.dump(res,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'source_files':len(sources),'source_note_bytes':(p/'root-source-note.json').stat().st_size,'elapsed_s':time.monotonic()-json.loads((p/'scope.json').read_text())['started_s']}))
