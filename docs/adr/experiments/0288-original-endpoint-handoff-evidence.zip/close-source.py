from pathlib import Path
import json,hashlib,os,time,subprocess
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0288');s=json.loads((p/'scope.json').read_text())
review=json.loads((p/'reviewer.json').read_text());table=json.loads((p/'table-review.json').read_text());note=json.loads((p/'root-interface-map.json').read_text())
assert review['status']==table['status']=='PASS'and not review['findings']and not table['findings']
assert review['started_s']==s['started_s']
for n,record in note['source_pins'].items():
 raw=(r/n).read_bytes();assert len(raw)==record['bytes']and hashlib.sha256(raw).hexdigest()==record['sha256'],n
for n,record in review['reviewed_files'].items():
 raw=subprocess.check_output(['git','show',s['base_revision']+':'+n],cwd=r)
 assert len(raw)==record['bytes']and hashlib.sha256(raw).hexdigest()==record['sha256'],n
for n in('scope.json','reviewer.json','table-review.json','root-interface-map.json','0267-owner-source-excerpts.txt'):
 with(p/n).open('rb')as f:os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
x={'schema':'ariadna.f18.handoff-map-source-closure.v1','observed_after_source_files_directory_fsync_s':time.monotonic()-s['started_s'],'source_limit_s':600,'source_evidence_bytes':sum((p/n).stat().st_size for n in('scope.json','reviewer.json','table-review.json','root-interface-map.json','0267-owner-source-excerpts.txt')),'independent_source_and_table_review':'PASS','scientific_native_execution':False,'documentary_publication_follows_separately':True}
assert x['observed_after_source_files_directory_fsync_s']<600 and x['source_evidence_bytes']<2097152
with(p/'source-closure.json').open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'closure':x,'observed_after_closure_receipt_directory_fsync_s':time.monotonic()-s['started_s']}))
