from pathlib import Path
import hashlib,json,os,time,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0288')
anchors={
'src/space_nav/_owner_endpoint_fixture.py':[(121,173),(176,236)],
'src/space_nav/_owner_completed_probe.py':[(169,205)],
'src/space_nav/_native_arc_conformance.py':[(192,232)],
'src/space_nav/_coupled_bridge.py':[(92,114),(155,213),(445,470)],
'src/space_nav/trajectory.py':[(1821,1890)],
'src/space_nav/research_propagation.py':[(302,317),(328,366),(395,420)],
'src/space_nav/_realized_clock_packet.py':[(88,104),(248,277),(329,345)],
'docs/adr/0254-record-native-event-transport-limits.md':[(25,41),(59,85)],
'docs/adr/0255-design-realized-clock-packet.md':[(35,85)],
'docs/adr/0257-design-conditional-split-time-enclosure.md':[(34,66)],
'docs/adr/0267-design-actual-owner-endpoint-qualification.md':[(47,110)],
'docs/adr/0286-verify-single-completed-owner.md':[(1,95)],
'docs/adr/0247-formulate-coupled-moon-mars-problem.md':[(1,70)]}
sources={}
for n,ranges in anchors.items():
 raw=(r/n).read_bytes();lines=raw.decode().splitlines()
 sources[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'anchors':[{'first':a,'last':b,'text':'\n'.join(lines[a-1:b])}for a,b in ranges]}
a=r/'docs/adr/experiments/0267-owner-readback-design-evidence.zip';raw=a.read_bytes()
with zipfile.ZipFile(a)as z:member=z.read('owner-source-excerpts.txt')
assert member==(p/'0267-owner-source-excerpts.txt').read_bytes()
table=[
{'item':'Original row/key and selector','established':'Retained binding58–77 selects one const map iterator with chronological first/last, reads original normalized finite long-double remainder and copies seven finite double words before Python allocation. Exact int hour plus narrowed double remainder and same-row words are returned.','unavailable':'Narrowed remainder is not exact stored remainder or a requested-event comparison. Selector is chronology, not propagation direction. One1000s observation is not arbitrary event identity.'},
{'item':'Conversion/domain route','established':'Binding54/66 explicitly checks selected ORIGINAL remainder finite and0<=r<3600; binding72 explicitly static_cast<double>,76 py::float_(double). This is a different route from the old generic long-double Python caster lookup.','unavailable':'Source-level conditional0257enclosure is not yet a qualified selected linked-binary/domain/FP readback basis. No exact-key/roundtrip/residual observation is supplied by this triplet; rounded3600 and signed zero must be retained.'},
{'item':'State/mass and metadata','established':'Native state scalar is double; one row of seven finite doubles is copied. Fixture_metadata checks processed/propagated IDs, seven-state length and successful exact-condition completion; native factory checks actual type/settings/initial words and frame.0286 observes this one fixed fixture.','unavailable':'Caller schema alone gives no physical frame/state meaning. Exact receiving words in another native arc and arbitrary physical settings are not qualified by one owner. Existing research numeric equality is not a new bitwise-preservation proof.'},
{'item':'Completion and safety','established':'Visitor requires performed/not-cleared, while fixture separately checks successful exact termination. Existing research caller handles failure and detected safety event before completed readback.','unavailable':'Performed marker is not success or synchronization. Primitive endpoint cannot confer safety, whole-path guards or force fidelity. Do not synthesize complete/safe from row presence.'},
{'item':'Ownership and handoff','established':'Retained binding137–143 takes shared owner and returns owned primitive tuples; no borrowed row escapes. Bridge replay carries priorresponse state/mass; research caller supplies state/mass and checks initial saved row.','unavailable':'Serial/no concurrent native mutation remains a premise; full0267retained-method/clear lifecycle is not actual-qualified by0286. Production readback still uses exported histories; original-key reader is not wired/adopted.'},
{'item':'Exact artificial response versus physical realized clock','established':'Artificial ArcResponse exact-event association is distinct from1e-6s label/residual.0254/0255 preserve a separate physical realized-clock allowance under0205, immutable commands and both mass ledgers.','unavailable':'Do not force arbitrary physical events into ExactEvent identity or infer F0 infeasibility. Existing_realized_clock_packet native-observation shape requires comparison/roundtrip/provenance not returned by the triplet; unobserved is not false or zero.'},
{'item':'Bounds and admission','established':'Existing checker_bound88–104 accepts intervals only for exact fabricated basis;269–270 requires fabricated route+roundtrip, and final admission stays unavailable.','unavailable':'No actual native conversion enclosure, signed realized-clock chain, full-force clock/mass transport, physical endpoint bounds or mission admission supplied. Do not retag fabricated evidence or a provenance flag as a native certificate.'}
]
x={'schema':'ariadna.f18.original-endpoint-handoff-map.v1','stage':'F18.18','base_revision':'03798360a5a217231bce507dda56a6d5cdf1e27e','fixed_inputs':'Original0267independent literal directions and0247F0boundaries/sixcontrols unchanged','free_scientific_variables':[],'table':table,
'precise_next_prerequisite':'Before adopting a real observation adapter, determine which0257conversion/domain premises are supported by the explicit pre-narrow-checked static_cast<double> route and retained selected extension build receipts. Do not inherit the old generic caster gap mechanically. If a premise cannot be supported, name it unavailable. Full realized-clock chain/lifecycle/physical bounds remain separate.',
'next_scope_proposal':'A single bounded retained-source/build-metadata premise check only:600s inclusive independent review/2MiB, no new source acquisition/mount/import/test/native/build/formula/trajectory work; no claim of complete core ABI/FP proof. No native-interface change/build is presently shown necessary.',
'new_adapter_implementation_or_native_authority':False,'source_pins':sources,
'retained_native_source':{'archive':str(a.relative_to(r)),'archive_bytes':len(raw),'archive_sha256':hashlib.sha256(raw).hexdigest(),'member':'owner-source-excerpts.txt','member_bytes':len(member),'member_sha256':hashlib.sha256(member).hexdigest(),'native_file_identity':'Retained binding excerpt declares SHA4fe1f7e99468430461eb2add1170e4a4d4f0206f0f1b68378f777df1a94eefec; full unmounted source/binary not re-read now'},
'qualification':'SOURCE_MAPPING_ONLY; no numerical/oracle/scientific/physical qualification','work_performed':'Pinned source/excerpt/metadata reading; no runtime/scientific evaluation or native operation'}
with(p/'root-interface-map.json').open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'source_files':len(sources),'map_bytes':(p/'root-interface-map.json').stat().st_size,'elapsed_s':time.monotonic()-json.loads((p/'scope.json').read_text())['started_s']}))
