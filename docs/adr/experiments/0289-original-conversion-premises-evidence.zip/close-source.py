from pathlib import Path
import json,hashlib,time,os,zipfile
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0289');s=json.loads((p/'scope.json').read_text());note=json.loads((p/'root-premise-ledger.json').read_text());review=json.loads((p/'reviewer.json').read_text());nextreview=json.loads((p/'next-scope-review.json').read_text())
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
assert review['status']==nextreview['status']=='PASS'and not review['findings']and not nextreview['findings']
assert review['started_s']==nextreview['started_s']==s['started_s']
for n,v in note['source_pins'].items():assert pin((r/n).read_bytes())=={k:v[k]for k in('bytes','sha256')},n
for n,v in review['file_pins'].items():assert pin((r/n).read_bytes())==v,n
for n,v in review['member_pins'].items():
 a,member=n.split('!',1)
 with zipfile.ZipFile(r/a)as z:assert pin(z.read(member))==v,n
files=[q for q in p.iterdir()if q.is_file()and q.name!='close-source.py']
for q in files:
 with q.open('rb')as f:os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
x={'schema':'ariadna.f18.conversion-premise-source-closure.v1','observed_after_source_files_directory_fsync_s':time.monotonic()-s['started_s'],'source_limit_s':600,'evidence_bytes':sum(q.stat().st_size for q in files),'independent_source_and_next_scope_reviews':'PASS','scientific_native_execution':False,'documentary_publication_follows_separately':True}
assert x['observed_after_source_files_directory_fsync_s']<600 and x['evidence_bytes']<2097152
with(p/'source-closure.json').open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({'closure':x,'observed_after_closure_receipt_directory_fsync_s':time.monotonic()-s['started_s']}))
