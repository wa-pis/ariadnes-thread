from pathlib import Path
import json,hashlib,zipfile,os,time
r=Path('/Users/agrudin/dev/my/ariadna');p=Path('/private/tmp/ariadna-f18-0289')
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
archives={};retained={}
selections={
'0263-build-evidence.zip':['volume/build/compile_commands.json','volume/build/CMakeCache.txt','volume/build/CMakeFiles/kernel.dir/link.txt','episode/generated-command-audit.json','episode/final-source-command-review.json','episode/native-build-result.json','episode/private-variant-install.json','volume/logs/compiler-identity-1795589186362962000.log','volume/header-manifest.json'],
'0267-owner-readback-design-evidence.zip':['owner-source-excerpts.txt'],
'0286-single-completed-owner-evidence.zip':['episode/profile.json','episode/execution/native-packet/producer.json']}
selected={}
for a,names in selections.items():
 q=r/'docs/adr/experiments'/a;archives[a]=pin(q.read_bytes());retained[a]={}
 with zipfile.ZipFile(q)as z:
  for n in names:
   raw=z.read(n);retained[a][n]=pin(raw);selected[(a,n)]=raw
b='0263-build-evidence.zip';s='0267-owner-readback-design-evidence.zip';v='0286-single-completed-owner-evidence.zip'
commands=json.loads(selected[(b,'volume/build/compile_commands.json')]);match=[x for x in commands if x['file'].endswith('/expose_simulator.cpp')];assert len(match)==1
command=match[0];install=json.loads(selected[(b,'episode/private-variant-install.json')]);profile=json.loads(selected[(v,'episode/profile.json')]);producer=json.loads(selected[(v,'episode/execution/native-packet/producer.json')])
assert install['artifact_sha256']==install['isolated_installed_sha256']==profile['kernel_sha256']==producer['kernel_sha256']
assert all(f in command['command'].split()for f in('-std=c++14','-arch','arm64','-O1','-fno-fast-math','-ffp-contract=off','-fno-lto'))
headers=json.loads(selected[(b,'volume/header-manifest.json')]);headerpins={n:h for n,h in headers.items()if any(n.endswith(t)for t in('/pybind11/cast.h','/pybind11/pytypes.h','/python3.12/floatobject.h','/python3.12/cpython/floatobject.h','/python3.12/internal/pycore_floatobject.h'))}
assert len(headerpins)==5
sources={}
for name,ranges in {
'docs/adr/0257-design-conditional-split-time-enclosure.md':[(34,66)],
'docs/adr/0288-map-original-endpoint-handoff.md':[(24,88)],
'docs/adr/0267-design-actual-owner-endpoint-qualification.md':[(47,123)],
'docs/adr/0268-qualify-artificial-owner-runner.md':[(27,78)],
'docs/adr/0286-verify-single-completed-owner.md':[(1,90)],
'docs/adr/0247-formulate-coupled-moon-mars-problem.md':[(1,70)]}.items():
 raw=(r/name).read_bytes();lines=raw.decode().splitlines();sources[name]={**pin(raw),'anchors':[{'first':a,'last':b,'text':'\n'.join(lines[a-1:b])}for a,b in ranges]}
ledger=[
{'premise':'Original finite/range check and same-row association','status':'SUPPORTED_SELECTED_SOURCE','evidence':'0267binding54,63–77: selected original remainder finite/[0,3600) before narrowing; original key and seven finite double words from one iterator. Not proof of requested/actualidentity or all prior arithmetic.'},
{'premise':'Explicit native conversion selection','status':'SUPPORTED_SELECTED_SOURCE','evidence':'Binding72 static_cast<double>(long-double remainder),77 py::make_tuple narrowed double. Explicit py::float_(double)76 applies to seven state words, not directly the remainder. Neither route is the old generic long-double caster.'},
{'premise':'Selected generated FP/compiler command','status':'SUPPORTED_RETAINED_BUILD_RECEIPTS','evidence':'Exactly one expose_simulator.cpp command: clang18.1.8 arm64,C++14,-O1,-fno-fast-math,-ffp-contract=off,-fno-lto; CMakeRelease -DNDEBUG. Native buildreceipt return0/422.086s. Generated commands/buildsuccess are retained observations, not new execution/disassembly or fullcoreABIproof.'},
{'premise':'Retained artifact identity and one observed context','status':'SUPPORTED_SAVED_INSTANCE_ONLY','evidence':'0263artifact/privateinstall and0286profile/producer kernel hashes match;0286 context53/53/8 is observed for its one fixed owner. It does not establish every format/domain/conversion/storage premise for arbitrary rows.'},
{'premise':'Double-to-Python exporter/storage value preservation','status':'UNAVAILABLE_FROM_NAMED_RECEIPTS','evidence':'Header manifest pins selected pybind11/cast.h andpytypes.h plus3Python float headers; named archives retain hash identities, not the relevant constructor/caster/storage bodies. No current native or newheaderbody lookup made. This is a DOUBLE export premise, not the old long-double caster gap.'},
{'premise':'Conditional adjacent-neighbour enclosure','status':'CONDITIONAL_SOURCE_ARGUMENT_ONLY','evidence':'Existing0257C++conversion argument permits either adjacent result; no new nearest-rounding/FP-mode premise is invented. It encloses stored native value only under its premises, not requestedexactevent/prior arithmetic/fullforceerror. No numerical envelope or interval is evaluated now.'},
{'premise':'Physical realized-clock and mission admission','status':'UNAVAILABLE_SEPARATE_OBLIGATIONS','evidence':'Requested/realized event-chain, actual mass/carry/lifecycle and clock/mass/full-force/endpoint bounds remain separate. Exact artificialF5identity is not a new universal physicalF0requirement. No build/interface change or nativeauthority inferred.'}
]
x={'schema':'ariadna.f18.original-conversion-premise-ledger.v1','stage':'F18.19','base_revision':'bbab11a296cbf9c758b22110e3817476c7ba5e9f','fixed_inputs':'0267independent literals/settings/schema and0247F0boundaries/sixcontrols unchanged','free_scientific_variables':[],'premise_ledger':ledger,'selected_generated_command':command,'observed_kernel_sha256':producer['kernel_sha256'],'saved_native_context':producer['native_context'],'selected_header_manifest_pins':headerpins,'retained_archive_pins':archives,'retained_member_pins':retained,'source_pins':sources,
'precise_missing_prerequisite':'Relevant selected DOUBLE caster/constructor and Python-float storage value-preservation basis plus applicable format/domain relation are not reconstructed from the named receipts. Do not broaden this phase or call conditional enclosure an actual physical certificate.',
'next_scope_recommendation':'SOURCE-only600s/2MiB finite mapping of existing0268fullowner runner onto0286outer controls for original0267fixed0/1000synthetic/lifecycle contract. This missing general export basis does not block that fixedfixture or require chasing all headers first; do not duplicate0268artificialqualification. No profile/implementation/native attempt adopted. Any actualnewnativeepisode needs distinct explicit choice and freshadmission;0285consumed.',
'new_native_or_scientific_work':False,'qualification':'RETAINED_SOURCE_BUILD_PREMISE_LEDGER_ONLY; no nativebasis/physicalqualification','new_adapter_profile_or_native_authority':False}
with(p/'root-premise-ledger.json').open('x')as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({'ledger_bytes':(p/'root-premise-ledger.json').stat().st_size,'elapsed_s':time.monotonic()-json.loads((p/'scope.json').read_text())['started_s'],'kernel_sha256':producer['kernel_sha256'],'context':producer['native_context']}))
