"""Artificial-only full-owner entry; no native profile or override is accepted."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from typing import Any

ROOT = Path('/private/tmp/ariadna-f18-0291/qualification')


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def run(slice_path: Path, started_s: float) -> dict[str, object]:
    """Validate one artificial descriptor, create one entry group record and delegate."""
    # Native and override paths are refused before any file/resource read.
    need(slice_path.is_absolute() and '..' not in slice_path.parts and '\0' not in str(slice_path)
         and slice_path.is_relative_to(ROOT) and slice_path.name == 'slice.json', 'artificial slice path only')
    need(type(started_s) in (int, float) and math.isfinite(started_s)
         and 0 <= time.monotonic() - started_s < 60, 'finite inherited original clock required')
    for parent in [*reversed(slice_path.parent.parents), slice_path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'unsafe artificial descriptor ancestor')
    fd = os.open(slice_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        need(stat.S_ISREG(os.fstat(fd).st_mode), 'regular descriptor required')
        raw = os.read(fd, 65537)
        need(len(raw) <= 65536, 'descriptor64KiB cap')
    finally:
        os.close(fd)
    def pairs(rows: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in rows:
            need(key not in value, 'duplicate descriptor key')
            value[key] = item
        return value
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite descriptor: ' + value)
    descriptor = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    need(type(descriptor) is dict and descriptor.get('mode') == 'artificial'
         and descriptor.get('schema') == 'ariadna.f18.full-owner-artificial-slice.v1', 'native descriptor not adopted')
    expected = descriptor.get('adapter_pin')
    adapter_path = Path(__file__).with_name('supervisor-adapter.py')
    need(type(expected) is dict and set(expected) == {'path', 'bytes', 'sha256'}
         and expected['path'] == str(adapter_path), 'fixed adapter pin shape/path')
    adapter_raw = adapter_path.read_bytes()
    need(type(expected['bytes']) is int and len(adapter_raw) == expected['bytes'] <= 65536
         and hashlib.sha256(adapter_raw).hexdigest() == expected['sha256'], 'adapter source drift')
    spec = importlib.util.spec_from_file_location('full_owner_artificial_adapter', adapter_path)
    need(spec is not None and spec.loader is not None, 'artificial adapter unavailable')
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    work, _ = adapter.validate(descriptor)
    need(descriptor['original_started_s'] == started_s, 'original descriptor/start binding changed')
    need(slice_path.parent == Path(descriptor['root']), 'descriptor must belong to its artificial case')
    need(os.getpid() == os.getpgrp() == os.getsid(0), 'entry requires one isolated session/group')
    adapter.check_clock(started_s, 45)
    work.mkdir(parents=False, exist_ok=False)
    group = (str(os.getpgrp()) + '\n').encode('ascii')
    need(len(group) <= 32, 'bounded PGID required')
    with (work / 'supervisor.pgid').open('xb') as stream:
        need(stream.write(group) == len(group), 'short PGID write')
        stream.flush()
        os.fsync(stream.fileno())
    descriptor_fd = os.open(work, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor_fd)
    finally:
        os.close(descriptor_fd)
    adapter.check_clock(started_s, 45)
    result = adapter.collect(descriptor, work / 'native-packet', started_s)
    need(len(adapter.encoded(result)) <= 2048, 'entry result2048B cap')
    return result


def main() -> int:
    # There is deliberately no native or configurable executor parser.
    need(len(sys.argv) == 4 and sys.argv[1] == '--artificial-slice', 'only --artificial-slice PATH ORIGINAL_START is accepted')
    try:
        result = run(Path(sys.argv[2]), float(sys.argv[3]))
    except (RuntimeError, OSError, ValueError, TypeError, KeyError) as exc:
        result = {'schema': 'ariadna.f18.full-owner-artificial-slice-result.v1', 'mode': 'artificial',
                  'status': 'failed', 'failure': f'{type(exc).__name__}: {exc}'[:1024],
                  'physical_admission': 'unavailable', 'completion_requires_outer_finalization': True,
                  'finalization': 'unavailable', 'actual_partial_counts': 'UNKNOWN'}
    sys.stdout.write(json.dumps(result, sort_keys=True, allow_nan=False) + '\n')
    sys.stdout.flush()
    return 0 if result.get('status') == 'passed' and result.get('finalization') == 'checked-after-fsync' else 2


if __name__ == '__main__':
    raise SystemExit(main())
