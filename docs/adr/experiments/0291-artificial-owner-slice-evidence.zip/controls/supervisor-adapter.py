"""Artificial full-owner seam: unchanged runner, producer-only saved-packet hook."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from typing import Any

ROOT = Path('/private/tmp/ariadna-f18-0291/qualification')
REPO = Path('/Users/agrudin/dev/my/ariadna')
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
SCOPE = 'synthetic-owner-conformance-only'
INPUT = {'schema': 'ariadna-owner-fixture-input-v1', 'scope': SCOPE}
KEYS = set('schema scope mode root work_directory outer_python entry_pin adapter_pin source_pins fixture_input packet original_started_s'.split())
SOURCE_PINS = {
    str(REPO / 'src/space_nav/_owner_endpoint_run.py'): {'bytes': 17901, 'sha256': 'ba41c64e880b369ffc83844a3185fce40f2020d4a55e671b768cfd32f96988d4'},
    str(REPO / 'src/space_nav/_owner_endpoint_fixture.py'): {'bytes': 17390, 'sha256': '48c33d3388d9d780312da25666fae9726c53576d46eefd285ef97d20232c5ee0'},
    str(REPO / 'src/space_nav/_owner_endpoint_audit.py'): {'bytes': 14638, 'sha256': '409c629c27efabccd96a6f0da85942b51f0a8bd79d2c943f5da09d9138f94eba'},
}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def safe(path: Path) -> None:
    need(path.is_absolute() and '..' not in path.parts and '\0' not in str(path), 'absolute artificial path required')
    need(path.is_relative_to(ROOT) and path != ROOT, 'outside fixed artificial prefix')
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory ancestor')
    if os.path.lexists(path):
        need(not stat.S_ISLNK(path.lstat().st_mode), 'artificial symlink forbidden')


def read(path: Path, cap: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= cap, 'regular bounded file required')
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        need(len(raw) == before.st_size == after.st_size and not os.read(fd, 1)
             and before.st_mtime_ns == after.st_mtime_ns, 'short/changed read')
        return raw
    finally:
        os.close(fd)


def object_value(raw: bytes) -> dict[str, Any]:
    def pairs(rows: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite JSON: ' + value)
    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    need(type(value) is dict, 'JSON object required')
    return value


def pin(value: object, *, cap: int, expected_path: Path | None = None) -> bytes:
    need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}, 'exact path pin required')
    need(type(value['path']) is str and type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str and len(value['sha256']) == 64
         and all(c in '0123456789abcdef' for c in value['sha256']), 'invalid bounded pin')
    path = Path(value['path'])
    need(path.is_absolute() and '..' not in path.parts, 'absolute normalized pin path')
    if expected_path is not None:
        need(path == expected_path, 'fixed pin path mismatch')
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'pin symlink ancestor')
    raw = read(path, cap)
    need(len(raw) == value['bytes'] and hashlib.sha256(raw).hexdigest() == value['sha256'], 'pinned source/packet drift')
    return raw


def check_clock(started_s: float, seconds: float = 60) -> float:
    now = time.monotonic()
    need(type(started_s) in (int, float) and math.isfinite(started_s)
         and math.isfinite(now) and 0 <= now - started_s < seconds, 'original packet clock exhausted or reset')
    return now


def validate(descriptor: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    """Refuse native mode before paths or package imports; bind only artificial inputs."""
    need(type(descriptor) is dict and descriptor.get('mode') == 'artificial', 'native/override mode not adopted')
    need(set(descriptor) == KEYS and descriptor['schema'] == 'ariadna.f18.full-owner-artificial-slice.v1'
         and descriptor['scope'] == SCOPE, 'exact artificial slice descriptor')
    need(type(descriptor['original_started_s']) in (int, float)
         and math.isfinite(descriptor['original_started_s']), 'finite original descriptor clock required')
    need(type(descriptor['root']) is str and type(descriptor['work_directory']) is str, 'string artificial paths')
    root, work = Path(descriptor['root']), Path(descriptor['work_directory'])
    safe(root)
    safe(work)
    need(work == root / 'execution', 'fixed artificial work path')
    need(descriptor['fixture_input'] == INPUT and type(descriptor['fixture_input']) is dict, 'unchanged two-key fixture input')
    need(descriptor['source_pins'] == SOURCE_PINS, 'fixed original three-source pins')
    for name, row in SOURCE_PINS.items():
        pin({'path': name, **row}, cap=65536)
    executable = OUTER.resolve()
    need(Path(sys.executable).resolve() == executable, 'fixed outer interpreter required')
    pin(descriptor['outer_python'], cap=16777216, expected_path=executable)
    controls = Path(__file__).parent
    pin(descriptor['entry_pin'], cap=65536, expected_path=controls / 'native-entry.py')
    pin(descriptor['adapter_pin'], cap=65536, expected_path=Path(__file__))
    need(type(descriptor['packet']) is dict and type(descriptor['packet'].get('path')) is str, 'packet pin required')
    packet_path = Path(descriptor['packet']['path'])
    safe(packet_path)
    need(packet_path.is_relative_to(root) and not packet_path.is_relative_to(work), 'packet must be outside execution tree in same case')
    packet = object_value(pin(descriptor['packet'], cap=1048576))
    need(packet.get('schema') == 'ariadna-owner-fixture-v1' and packet.get('scope') == SCOPE
         and packet.get('mode') == 'injected', 'original injected fixture schema/mode required')
    return work, packet


def write(path: Path, value: object) -> bytes:
    raw = encoded(value)
    need(len(raw) <= 65536, 'outer receipt64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(fd, raw[offset:])
            need(count > 0, 'short receipt write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    return raw


def collect(descriptor: dict[str, Any], directory: Path, started_s: float) -> dict[str, object]:
    """Delegate once; only the producer command changes, never the independent audit."""
    work, packet = validate(descriptor)
    need(descriptor['original_started_s'] == started_s, 'original descriptor/start binding changed')
    need(directory == work / 'native-packet', 'fixed packet directory')
    need(os.getpid() == os.getpgrp() == os.getsid(0), 'inherited isolated entry group required')
    check_clock(started_s, 45)
    sys.path.insert(0, str(REPO / 'src'))
    from space_nav import _owner_endpoint_run as runner
    need(Path(runner.__file__).resolve() == REPO / 'src/space_nav/_owner_endpoint_run.py', 'original runner module required')
    original_command = runner._worker_command
    witness: list[dict[str, object]] = []
    result: dict[str, Any] | None = None
    failure: str | None = None
    finalization = 'unavailable'
    audit: dict[str, Any] = {}

    def command(kind: str, source: Path, worker_started: float, deadline_s: float) -> list[str]:
        need(kind in {'produce', 'audit'}, 'unexpected worker role')
        expected_source = directory / ('input.json' if kind == 'produce' else 'producer.json')
        need(source == expected_source and worker_started == started_s, 'original worker source/start changed')
        need(math.isfinite(deadline_s) and (deadline_s == started_s + 45 if kind == 'produce'
             else started_s < deadline_s <= started_s + 55), 'original worker deadline changed')
        expected = [sys.executable, '-m', 'space_nav._owner_endpoint_run', '--worker',
                    kind, str(source), repr(worker_started), repr(deadline_s)]
        actual = original_command(kind, source, worker_started, deadline_s)
        need(actual == expected, 'original worker argv changed')
        if kind == 'produce':
            need(object_value(read(source, 65536)) == INPUT, 'original worker input bytes changed')
        need([row['kind'] for row in witness] == ([] if kind == 'produce' else ['produce']), 'duplicate/out-of-order worker')
        if kind == 'produce':
            # Byte-identical default pipeline from the existing connected test helper.
            raw = json.dumps(packet)
            replacement = [sys.executable, '-c', f'import sys;sys.stdout.write({raw!r});sys.exit(0)']
            row = {'kind': kind, 'original_argv': actual, 'replacement_argv': replacement,
                'replacement_argv_sha256': hashlib.sha256(encoded(replacement)).hexdigest(),
                'replacement_argv_bytes': len(encoded(replacement)), 'packet_pin': descriptor['packet'],
                'original_started_s': started_s, 'deadline_s': deadline_s}
            chosen = replacement
        else:
            row = {'kind': kind, 'original_argv': actual, 'audit_argv_unchanged': True,
                   'original_started_s': started_s, 'deadline_s': deadline_s}
            chosen = actual
        check_clock(started_s, deadline_s - started_s)
        write(work / (kind + '-command-before-dispatch.json'), row)
        descriptor_fd = os.open(work, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor_fd)
        finally:
            os.close(descriptor_fd)
        need(read(work / (kind + '-command-before-dispatch.json'), 65536) == encoded(row),
             'pre-dispatch witness changed after file/directory fsync')
        check_clock(started_s, deadline_s - started_s)
        # The summary stays small; the exact producer command is retained above.
        witness.append({key: value for key, value in row.items() if key != 'replacement_argv'})
        return chosen

    runner._worker_command = command
    try:
        result = runner.run(encoded(INPUT), directory, started_s=started_s, inherited_group=True)
        failure = result.get('failure')
        finalization = result.get('finalization', 'unavailable')
        if result.get('status') == 'passed':
            need(result.get('schema') == 'ariadna-owner-run-v1' and result.get('producer_mode') == 'injected'
                 and result.get('physical_admission') == 'unavailable'
                 and finalization == 'checked-after-fsync'
                 and [row['kind'] for row in witness] == ['produce', 'audit'], 'original run result mismatch')
            audit = object_value(read(directory / 'audit.json', 524288))
            need(audit.get('schema') == 'ariadna-owner-audit-v1' and audit.get('status') == 'passed'
                 and audit.get('mode') == 'injected' and audit.get('physical_admission') == 'unavailable'
                 and type(audit.get('calls_checked')) is int and audit['calls_checked'] == 8
                 and type(audit.get('analytic_arcs_checked')) is int and audit['analytic_arcs_checked'] == 2,
                 'original independent audit did not establish eight calls/two arcs')
    except (RuntimeError, OSError, ValueError, TypeError, KeyError) as exc:
        failure = failure or f'{type(exc).__name__}: {exc}'[:1024]
    finally:
        runner._worker_command = original_command
    wrapper: dict[str, object] = {'schema': 'ariadna.f18.full-owner-artificial-slice-result.v1',
        'scope': SCOPE, 'mode': 'artificial', 'status': 'failed', 'failure': failure,
        'producer_mode': 'injected', 'physical_admission': 'unavailable',
        'completion_requires_outer_finalization': True, 'finalization': finalization,
        'actual_partial_counts': 'UNKNOWN unless original successful producer and audit establish completion'}
    try:
        write(work / 'worker-command-witness.json', {'workers': witness, 'audit_replaced': False})
        raw_result = write(work / 'runner-result.json', result if result is not None else {'status': 'failed', 'failure': failure})
        wrapper['runner_report'] = {'path': str(work / 'runner-result.json'), 'bytes': len(raw_result),
                                    'sha256': hashlib.sha256(raw_result).hexdigest()}
        check_clock(started_s)
    except (RuntimeError, OSError, ValueError) as exc:
        wrapper['failure'] = failure or f'{type(exc).__name__}: {exc}'[:1024]
    else:
        if result is not None and result.get('status') == 'passed' and failure is None:
            wrapper.update(status='passed', calls_checked=8, analytic_arcs_checked=2,
                           actual_partial_counts='validated original producer/audit completion')
    need(len(encoded(wrapper)) <= 2048, 'outer output2048B reservation')
    return wrapper
