"""One bounded injected-only F18.21 wiring qualification; no native authority."""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib.abc
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
from types import SimpleNamespace
from typing import Any
import unittest

REPO = Path('/Users/agrudin/dev/my/ariadna')
ROOT = Path('/private/tmp/ariadna-f18-0291')
CASES = ROOT / 'qualification'
SOURCE_REVIEW = ROOT / 'source-seam-review.json'
CANDIDATE = ROOT / 'candidate-source-pins.json'
ENTRY = ROOT / 'controls/native-entry.py'
ADAPTER = ROOT / 'controls/supervisor-adapter.py'
RETAINED = Path('/private/tmp/ariadna-f18-0290/retained-0286/episode')
FIXTURE_TEST = REPO / 'tests/test_owner_endpoint_fixture.py'
INPUT = {'schema': 'ariadna-owner-fixture-input-v1', 'scope': 'synthetic-owner-conformance-only'}
PROJECT_NAMES = ('_owner_endpoint_fixture.py', '_owner_endpoint_run.py', '_owner_endpoint_audit.py')
FORBIDDEN = ('tudatpy', 'numpy', 'scipy', 'spiceypy')
STATE: dict[str, Any] = {}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def read(path: Path, cap: int = 2097152) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and 0 <= info.st_size <= cap, 'bounded regular artificial/source file')
        data = os.read(fd, cap + 1)
        need(len(data) == info.st_size and not os.read(fd, 1), 'source/evidence short read')
        return data
    finally:
        os.close(fd)


def pin(path: Path) -> dict[str, object]:
    raw = read(path)
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def path_pin(path: Path) -> dict[str, object]:
    return {'path': str(path), **pin(path)}


def put(path: Path, value: object, *, raw: bool = False, cap: int = 65536) -> None:
    data = value if raw else encoded(value)
    need(type(data) is bytes and len(data) <= cap, 'bounded retained artificial evidence')
    with path.open('xb') as stream:
        need(stream.write(data) == len(data), 'short artificial record write')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'artificial module loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def select(path: Path, names: set[str], namespace: dict[str, Any]) -> dict[str, Any]:
    tree = ast.parse(read(path), filename=str(path))
    nodes = []
    found: set[str] = set()
    for node in tree.body:
        selected = ({node.name} if isinstance(node, (ast.ClassDef, ast.FunctionDef)) else
                    {target.id for target in node.targets if isinstance(target, ast.Name)}
                    if isinstance(node, ast.Assign) else set())
        if selected & names:
            need(selected <= names, 'AST extraction included unnamed binding')
            nodes.append(node)
            found.update(selected)
    need(found == names, 'exact original AST extraction names')
    module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), *nodes],
                        type_ignores=[])
    exec(compile(ast.fix_missing_locations(module), str(path), 'exec'), namespace)
    return namespace


def tick() -> None:
    need(STATE['started_s'] <= time.monotonic() < STATE['started_s'] + 115,
         'original focused invocation clock/reserve exhausted')


def prepare() -> None:
    """Verify the externally frozen recipe before importing any project/control code."""
    tick()
    raw = read(CANDIDATE, 65536)
    candidate = json.loads(raw)
    need(set(candidate) == {'schema', 'files', 'source_review_pin', 'recipes_only_before_first_invocation'}
         and candidate['schema'] == 'ariadna.f18.artificial-slice-candidate-pins.v1'
         and candidate['recipes_only_before_first_invocation'] is True
         and set(candidate['files']) == {str(ENTRY), str(ADAPTER), str(Path(__file__))}, 'frozen three-source recipe')
    for name, expected in candidate['files'].items():
        need(pin(Path(name)) == expected, 'candidate source changed: ' + name)
    need(candidate['source_review_pin'] == path_pin(SOURCE_REVIEW), 'closed source-review pin')
    review = json.loads(read(SOURCE_REVIEW))
    need(review['status'] == 'PASS' and review['base_revision'] == '9d55df2ad416a916c55bb3a26e6b17b2c02d7b12',
         'accepted source seam/base')
    for name, expected in review['file_pins'].items():
        need(pin(Path(name)) == expected, 'original source changed: ' + name)
    need(not CASES.exists(), 'one focused qualification namespace only')
    CASES.mkdir()

    class NoScientificRuntime(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname: str, path: object = None, target: object = None) -> None:
            if any(fullname == name or fullname.startswith(name + '.') for name in FORBIDDEN):
                raise ImportError('injected slice forbids scientific runtime: ' + fullname)

    need(not any(name == forbidden or name.startswith(forbidden + '.')
                 for name in sys.modules for forbidden in FORBIDDEN), 'scientific runtime already loaded')
    sys.meta_path.insert(0, NoScientificRuntime())
    from space_nav import _owner_endpoint_fixture as producer
    need(Path(producer.__file__).resolve() == REPO / 'src/space_nav/_owner_endpoint_fixture.py'
         and pin(Path(producer.__file__)) == review['file_pins'][str(Path(producer.__file__).resolve())],
         'loaded fixture must be the frozen original source')
    STATE['producer'] = producer
    STATE['fixture'] = select(FIXTURE_TEST,
        {'_INITIAL', '_END', '_METADATA', '_PROPAGATED', 'Results', 'Owner', '_factory'},
        {'producer': producer, 'SimpleNamespace': SimpleNamespace})
    STATE['outer'] = load_module('_f1821_retained_call', RETAINED / 'call-once.py')
    STATE['durability'] = select(RETAINED / 'run-once.py', {'check_aggregate', 'sync_directories'},
                                 {'Path': Path, 'os': os, 'stat': stat, 'time': time})
    STATE['candidate_pin'] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    STATE['case_returns'] = []
    STATE['source_pins'] = {str(REPO / 'src/space_nav' / name): review['file_pins'][str(REPO / 'src/space_nav' / name)]
                            for name in PROJECT_NAMES}
    put(CASES / 'recipe-readback.json', {'candidate': STATE['candidate_pin'],
        'source_review': candidate['source_review_pin'], 'source_pins': STATE['source_pins'],
        'fixture_extraction': ['_INITIAL', '_END', '_METADATA', '_PROPAGATED', 'Results', 'Owner', '_factory'],
        'run_once_extraction': ['check_aggregate', 'sync_directories'],
        'producer_recipe': "json.dumps(packet); [sys.executable,'-c',f'import sys;sys.stdout.write({raw!r});sys.exit(0)']",
        'clock': 'Each case starts before its original fixture generation; no logical Clock(0) replacement',
        'scope': 'injected-only; unchanged guarded independent audit; no native authority'})
    tick()


def make_case(name: str, *, failed_factory: bool = False) -> tuple[Path, dict[str, Any], float]:
    tick()
    started = time.monotonic()  # Original packet clock precedes fixture generation and all case writes.
    case = CASES / name
    case.mkdir()
    put(case / 'original-clock-start.json', {'started_s': started,
        'scope': 'Original real packet clock, durably retained before fixture generation'})
    factory = STATE['fixture']['_factory']
    if failed_factory:
        original = factory
        def factory(arc_id: str, simulate: bool, budget: Any) -> object:
            if simulate:
                raise RuntimeError('first injected factory defect')
            return original(arc_id, simulate, budget)
    packet = STATE['producer'].produce(factory=factory, budget=STATE['producer'].Budget(started))
    need(packet['mode'] == 'injected', 'genuine fixture must remain injected')
    packet_path = case / 'injected-packet.json'
    put(packet_path, packet)
    descriptor = {'schema': 'ariadna.f18.full-owner-artificial-slice.v1',
        'scope': INPUT['scope'], 'mode': 'artificial', 'root': str(case), 'work_directory': str(case / 'execution'),
        'original_started_s': started,
        'outer_python': path_pin(Path(sys.executable).resolve()), 'entry_pin': path_pin(ENTRY),
        'adapter_pin': path_pin(ADAPTER), 'source_pins': STATE['source_pins'], 'fixture_input': INPUT.copy(),
        'packet': path_pin(packet_path)}
    put(case / 'original-clock.json', {'started_s': started, 'fixture_finished_s': time.monotonic(),
        'mode': 'injected', 'factory_failure_injected': failed_factory, 'packet_pin': descriptor['packet']})
    return case, descriptor, started


def rewrite_packet(descriptor: dict[str, Any], change: Any) -> None:
    path = Path(descriptor['packet']['path'])
    packet = json.loads(read(path))
    change(packet)
    changed = path.with_name('mutated-injected-packet.json')
    put(changed, packet)
    descriptor['packet'] = path_pin(changed)


def launch(case: Path, descriptor: dict[str, Any], started: float, *, entry_started: float | None = None,
           oversized: bool = False) -> tuple[dict[str, Any], dict[str, Any]]:
    need(descriptor['original_started_s'] == started
         == json.loads(read(case / 'original-clock-start.json'))['started_s'], 'durable original case start drift')
    source = case / 'slice.json'
    raw = encoded(descriptor)
    if oversized:
        raw += b' ' * (65537 - len(raw))
    put(source, raw, raw=True, cap=65537)
    argv = [sys.executable, '-I', '-B', str(ENTRY), '--artificial-slice', str(source),
            repr(started if entry_started is None else entry_started)]
    put(case / 'entry-command.json', {'argv': argv, 'original_watchdog_started_s': started,
        'injected_invalid_entry_start': entry_started, 'scope': 'artificial-only'})
    report, output = STATE['outer'].supervise(argv, case / 'execution', started, seconds=60)
    need(len(output) <= 2048, 'original outer2048B reservation')
    put(case / 'entry.stdout.json', output, raw=True)
    put(case / 'retained-caller-return.json', report)
    returned = json.loads(output) if output else {}
    return report, returned


def seal_case(case: Path, started: float, *, accepted: bool) -> None:
    deadline = started + (60 if accepted else 65)  # 65 is refusal cleanup, never successful packet time.
    STATE['durability']['check_aggregate'](case, deadline)
    STATE['durability']['sync_directories'](case, deadline)
    elapsed = time.monotonic() - started
    need(0 <= elapsed < (60 if accepted else 65), 'terminal enclosing original-clock observation')
    put(case / 'harness-observation.json', {'status': 'PENDING_CASE_DURABILITY_READBACK',
        'intended_injected_pass': accepted, 'elapsed_before_observation_write_s': elapsed, 'original_started_s': started,
        'successful_packet_limit_s': 60, 'failure_only_limit_s': 65, 'native_authority': False})
    STATE['durability']['check_aggregate'](case, deadline)
    STATE['durability']['sync_directories'](case, deadline)
    elapsed = time.monotonic() - started
    need(0 <= elapsed < (60 if accepted else 65), 'actual post-observation original-clock check')
    STATE['case_returns'].append({'case': str(case),
        'status': 'observed-injected-pass' if accepted else 'observed-refusal-only',
        'original_started_s': started, 'elapsed_after_observation_directory_fsync_s': elapsed})
    tick()


class SliceTests(unittest.TestCase):
    def refusal(self, name: str, change: Any, reason: str, *, entry_offset: float | None = None,
                oversized: bool = False) -> tuple[Path, dict[str, Any]]:
        case, descriptor, started = make_case(name)
        change(descriptor)
        caller, result = launch(case, descriptor, started,
            entry_started=(time.monotonic() + entry_offset if entry_offset is not None else None), oversized=oversized)
        self.assertTrue(caller['returncode'] != 0 or result.get('status') != 'passed', 'invalid slice admitted')
        self.assertIn(reason, result.get('failure', ''), 'wrong first refusal')
        self.assertFalse((case / 'execution/native-packet/audit.json').exists(), 'early refusal launched independent audit')
        seal_case(case, started, accepted=False)
        return case, result

    def test_01_genuine_full_fixture_unchanged_audit_and_duplicate_entry(self) -> None:
        case, descriptor, started = make_case('positive')
        caller, result = launch(case, descriptor, started)
        self.assertIsNone(caller['failure'])
        self.assertEqual(caller['returncode'], 0)
        self.assertEqual(result.get('status'), 'passed')
        self.assertEqual(result.get('producer_mode'), 'injected')
        self.assertEqual(result.get('physical_admission'), 'unavailable')
        self.assertIs(result.get('completion_requires_outer_finalization'), True)
        audit = json.loads(read(case / 'execution/native-packet/audit.json'))
        self.assertEqual((audit['schema'], audit['mode'], audit['calls_checked'], audit['analytic_arcs_checked']),
                         ('ariadna-owner-audit-v1', 'injected', 8, 2))
        witness = json.loads(read(case / 'execution/worker-command-witness.json'))
        self.assertIs(witness['audit_replaced'], False)
        self.assertEqual([row['kind'] for row in witness['workers']], ['produce', 'audit'])
        produce = json.loads(read(case / 'execution/produce-command-before-dispatch.json'))
        audited = json.loads(read(case / 'execution/audit-command-before-dispatch.json'))
        packet_directory = case / 'execution/native-packet'
        for row, role, source in ((produce, 'produce', packet_directory / 'input.json'),
                                  (audited, 'audit', packet_directory / 'producer.json')):
            self.assertEqual(row['kind'], role)
            self.assertEqual(row['original_started_s'], started)
            self.assertEqual(row['original_argv'], [sys.executable, '-m', 'space_nav._owner_endpoint_run',
                '--worker', role, str(source), repr(started), repr(row['deadline_s'])])
        self.assertEqual(produce['deadline_s'], started + 45)
        self.assertTrue(started < audited['deadline_s'] <= started + 55)
        self.assertIs(audited['audit_argv_unchanged'], True)
        generated = [sys.executable, '-c',
            f"import sys;sys.stdout.write({json.dumps(json.loads(read(Path(descriptor['packet']['path']))))!r});sys.exit(0)"]
        self.assertEqual(produce['replacement_argv'], generated)
        self.assertEqual(produce['replacement_argv_bytes'], len(encoded(generated)))
        self.assertEqual(produce['replacement_argv_sha256'], hashlib.sha256(encoded(generated)).hexdigest())
        self.assertEqual(produce['packet_pin'], descriptor['packet'])
        put(case / 'harness-seam-witness.json', {'raw_witness_pin': path_pin(case / 'execution/worker-command-witness.json'),
            'actual_audit_result_pin': path_pin(case / 'execution/native-packet/audit.json'),
            'witness': witness, 'not_a_fabricated_auditor': True})
        before = {str(p.relative_to(case / 'execution')): pin(p) for p in (case / 'execution').rglob('*') if p.is_file()}
        repeated, second = STATE['outer'].supervise(
            [sys.executable, '-I', '-B', str(ENTRY), '--artificial-slice', str(case / 'slice.json'), repr(started)],
            case / 'execution', started, seconds=60)
        self.assertNotEqual(repeated['returncode'], 0)
        self.assertEqual(before, {str(p.relative_to(case / 'execution')): pin(p)
                                 for p in (case / 'execution').rglob('*') if p.is_file()})
        put(case / 'duplicate-entry-refusal.json', {'caller': repeated, 'stdout': second.decode(), 'old_work_unchanged': True})
        seal_case(case, started, accepted=True)

    def test_02_wrong_mode_and_schema_refuse_before_workers(self) -> None:
        self.refusal('wrong-mode', lambda d: d.update(mode='native'), 'native descriptor not adopted')
        self.refusal('wrong-input-schema', lambda d: d.update(fixture_input={'schema': 'wrong', 'scope': INPUT['scope']}),
                     'two-key fixture input')
        self.refusal('wrong-descriptor-schema', lambda d: d.update(schema='wrong'), 'native descriptor not adopted')

    def test_03_wrong_source_and_interpreter_refuse_before_workers(self) -> None:
        def wrong_source(d: dict[str, Any]) -> None:
            d['source_pins'] = copy.deepcopy(d['source_pins'])
            d['source_pins'][str(REPO / 'src/space_nav/_owner_endpoint_run.py')]['sha256'] = '0' * 64
        self.refusal('wrong-source', wrong_source, 'three-source pins')
        self.refusal('wrong-interpreter', lambda d: d.update(outer_python=dict(d['outer_python'], path='/usr/bin/python3')),
                     'fixed pin path mismatch')

    def test_04_future_expired_and_reset_clocks_cannot_create_packet(self) -> None:
        self.refusal('future-clock', lambda d: None, 'inherited original clock', entry_offset=5)
        self.refusal('expired-clock', lambda d: None, 'inherited original clock', entry_offset=-61)
        self.refusal('reset-clock-binding', lambda d: None, 'original descriptor/start binding changed', entry_offset=0)

    def test_05_descriptor_byte_overrun_refuses_before_workers(self) -> None:
        self.refusal('oversized-descriptor', lambda d: None, 'descriptor64KiB cap', oversized=True)

    def test_06_unisolated_group_refuses_without_consumption(self) -> None:
        case, descriptor, started = make_case('wrong-group')
        put(case / 'slice.json', descriptor)
        child = subprocess.run([sys.executable, '-I', '-B', str(ENTRY), '--artificial-slice',
            str(case / 'slice.json'), repr(started)], capture_output=True, timeout=min(5, started + 60 - time.monotonic()),
            check=False)  # Deliberately inherit this process's group for this refusal only.
        self.assertNotEqual(child.returncode, 0)
        self.assertFalse(child.stderr)
        self.assertLessEqual(len(child.stdout), 2048)
        refusal = json.loads(child.stdout)
        self.assertIn('isolated session/group', refusal['failure'])
        put(case / 'unisolated-entry-refusal.json', refusal)
        self.assertFalse((case / 'execution').exists())
        seal_case(case, started, accepted=False)

    def test_07_wrong_count_reaches_actual_auditor_and_refuses(self) -> None:
        case, descriptor, started = make_case('wrong-count')
        rewrite_packet(descriptor, lambda p: p['counts'].update(visitor_calls=9))
        _, result = launch(case, descriptor, started)
        self.assertNotEqual(result.get('status'), 'passed')
        self.assertEqual(read(case / 'execution/native-packet/audit.json'), b'')
        errors = read(case / 'execution/native-packet/audit.stderr.log', 63488)
        self.assertIn(b'counts.visitor_calls', errors)
        report = json.loads(read(case / 'execution/runner-result.json'))
        self.assertEqual(report['workers'][-1]['kind'], 'audit')
        self.assertEqual(report['workers'][-1]['exit_code'], 2)
        seal_case(case, started, accepted=False)

    def test_08_producer_schema_refuses_without_audit(self) -> None:
        case, descriptor, started = make_case('wrong-producer-schema')
        rewrite_packet(descriptor, lambda p: p.update(schema='wrong'))
        _, result = launch(case, descriptor, started)
        self.assertNotEqual(result.get('status'), 'passed')
        self.assertFalse((case / 'execution/native-packet/audit.json').exists())
        self.assertFalse((case / 'execution').exists(), 'invalid producer schema consumed work')
        self.assertIn('original injected fixture schema/mode', result['failure'])
        self.assertEqual(path_pin(Path(descriptor['packet']['path'])), descriptor['packet'])
        seal_case(case, started, accepted=False)

    def test_09_first_failed_fixture_partial_is_retained_without_audit(self) -> None:
        case, descriptor, started = make_case('first-failure', failed_factory=True)
        _, result = launch(case, descriptor, started)
        partial = json.loads(read(case / 'execution/native-packet/producer.json'))
        self.assertEqual(partial['status'], 'failed')
        self.assertIn('first injected factory defect', partial['failure'])
        self.assertEqual(len(partial['calls']), 1)
        self.assertEqual(partial['counts']['integration_attempts'], 1)
        self.assertNotEqual(result.get('status'), 'passed')
        self.assertFalse((case / 'execution/native-packet/audit.json').exists())
        seal_case(case, started, accepted=False)

    def test_10_directory_fsync_delay_and_error_are_not_success(self) -> None:
        case = CASES / 'directory-failure'
        case.mkdir()
        clock = SimpleNamespace(value=0.0)
        proxy = SimpleNamespace(open=os.open, close=os.close, O_RDONLY=os.O_RDONLY,
                                O_DIRECTORY=os.O_DIRECTORY, O_NOFOLLOW=os.O_NOFOLLOW)
        def delayed(fd: int) -> None:
            os.fsync(fd)
            clock.value = 1.0
        proxy.fsync = delayed
        ns = select(RETAINED / 'run-once.py', {'check_aggregate', 'sync_directories'},
                    {'Path': Path, 'os': proxy, 'stat': stat, 'time': SimpleNamespace(monotonic=lambda: clock.value)})
        with self.assertRaisesRegex(RuntimeError, 'after directory fsync'):
            ns['sync_directories'](case, 1.0)
        def refused(fd: int) -> None:
            raise OSError('injected directory fsync refusal')
        clock.value = 0.0
        proxy.fsync = refused
        with self.assertRaisesRegex(OSError, 'injected directory fsync refusal'):
            ns['sync_directories'](case, 1.0)
        put(case / 'failure-observations.json', {'actual_fsync_then_expired': True, 'fsync_error_propagated': True,
            'clock_scope': 'synthetic helper clock only; genuine packet uses original real monotonic time'})

    def test_11_aggregate_helpers_refuse_limits_without_large_payload(self) -> None:
        class FakePath:
            name = 'bounded.json'
            def lstat(self) -> object:
                return SimpleNamespace(st_mode=stat.S_IFREG, st_size=2097153)
        fake = SimpleNamespace(rglob=lambda pattern: [FakePath()])
        with self.assertRaisesRegex(RuntimeError, 'aggregate outer-inner'):
            STATE['durability']['check_aggregate'](fake, time.monotonic() + 1)
        with self.assertRaisesRegex(RuntimeError, 'deadline'):
            STATE['durability']['check_aggregate'](fake, time.monotonic() - 1)

    def test_12_retained_supervisor_kills_descendant_after_leader_exit(self) -> None:
        case = CASES / 'whole-group-cleanup'
        case.mkdir()
        work = case / 'work'
        work.mkdir()
        child_record = case / 'child.json'
        code = ('import json,os,pathlib,subprocess,sys\n'
                "p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'])\n"
                f"pathlib.Path({str(child_record)!r}).write_text(json.dumps({{'pid':p.pid,'pgid':os.getpgrp(),'sid':os.getsid(0)}}))\n"
                "sys.stdout.write('partial-before-leader-exit');sys.stdout.flush()\n")
        started = time.monotonic()
        caller, output = STATE['outer'].supervise([sys.executable, '-I', '-B', '-c', code], work, started, seconds=0.5)
        self.assertEqual(caller['failure'], 'caller absolute deadline exhausted')
        child = json.loads(read(child_record, 1024))
        observation = subprocess.run(['/bin/ps', '-p', str(child['pid']), '-o', 'pid=,pgid=,stat='],
                                     capture_output=True, timeout=1, check=False)
        self.assertLessEqual(len(observation.stdout) + len(observation.stderr), 2048)
        rows = observation.stdout.splitlines()
        self.assertFalse(observation.stderr, 'process witness itself failed')
        if observation.returncode == 1:
            self.assertEqual(rows, [], 'ps rc1 with nonempty output is not absence')
        else:
            self.assertEqual(observation.returncode, 0, 'unexpected ps error is not inactivity')
            self.assertEqual(len(rows), 1, 'exact known child process row required')
            pid, group, state = rows[0].split()
            self.assertEqual((int(pid), int(group)), (child['pid'], child['pgid']))
            self.assertTrue(state.startswith(b'Z'), 'known artificial descendant remains running')
        put(case / 'cleanup-observation.json', {'caller': caller, 'retained_stdout': output.decode(), 'child': child,
            'ps_returncode': observation.returncode, 'ps_stdout': observation.stdout.decode(),
            'scope': 'Known harmless descendant inactive after retained group kill; no native/reaping claim'})
        seal_case(case, started, accepted=False)


def inventory(root: Path) -> dict[str, int]:
    structured = logs = files = 0
    for path in root.rglob('*'):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        need(stat.S_ISREG(info.st_mode), 'nonregular qualification evidence')
        files += 1
        if path.name.endswith('.log'):
            logs += info.st_size
        else:
            structured += info.st_size
    need(structured <= 2097152 and logs <= 65536, 'whole qualification2MiB/64KiB caps')
    return {'structured_bytes': structured, 'log_bytes': logs, 'files': files}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--started-s', required=True, type=float)
    args = parser.parse_args()
    need(math.isfinite(args.started_s) and 0 <= time.monotonic() - args.started_s < 115,
         'original root pre-cold-import clock required')
    STATE['started_s'] = args.started_s
    prepare()
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(SliceTests)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    log = stream.getvalue().encode()
    need(len(log) <= 32768, 'bounded readable harness log')
    put(CASES / 'unittest.log', log, raw=True)
    tick()
    sizes = inventory(CASES)
    need(not any(name == forbidden or name.startswith(forbidden + '.')
                 for name in sys.modules for forbidden in FORBIDDEN), 'scientific runtime imported')
    record = {'schema': 'ariadna.f18.full-owner-artificial-slice-qualification.v1',
        'status': 'PENDING_DURABLE_READBACK', 'tests_run': result.testsRun,
        'failures': len(result.failures), 'errors': len(result.errors), 'test_success_observed': result.wasSuccessful(),
        'candidate_pin': STATE['candidate_pin'], 'source_pins': STATE['source_pins'],
        'case_observed_returns': STATE['case_returns'],
        'started_s': args.started_s, 'elapsed_before_report_s': time.monotonic() - args.started_s,
        'byte_counters_before_report': sizes, 'native_authority': False, 'physical_admission': 'unavailable',
        'scope': 'Fabricated/injected only; unchanged independent auditor; no native/scientific execution',
        'completion_requires_root_observed_return': True, 'exitcode': 0 if result.wasSuccessful() else 2}
    output = ROOT / 'qualification-result.json'
    put(output, record)
    STATE['durability']['check_aggregate'](CASES, args.started_s + 115)
    STATE['durability']['sync_directories'](CASES, args.started_s + 115)
    need(read(output) == encoded(record), 'qualification report changed after fsync')
    report_pin = path_pin(output)
    sizes = inventory(ROOT)
    tick()
    print(json.dumps({'status': 'PASS_INJECTED_QUALIFICATION' if result.wasSuccessful() else 'FAILED_INJECTED_QUALIFICATION',
        'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'elapsed_after_report_readback_s': time.monotonic() - args.started_s, 'report_pin': report_pin,
        'byte_counters': sizes, 'native_authority': False}, sort_keys=True), flush=True)
    return 0 if result.wasSuccessful() else 2


if __name__ == '__main__':
    raise SystemExit(main())
