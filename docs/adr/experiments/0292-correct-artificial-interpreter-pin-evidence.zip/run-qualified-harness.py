"""One external budget observation for the artificial test invocation, not a mission control."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
p=Path('/private/tmp/ariadna-f18-0292');exe='/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python'
# Candidate bytes must already have independent review and an exclusive freeze.
review=json.loads((p/'candidate-code-review.json').read_text());freeze=json.loads((p/'candidate-source-pins.json').read_text())
assert review['status']=='PASS' and not review['findings']
assert review['file_pins']==freeze['files']
for name,record in freeze['files'].items():
 raw=Path(name).read_bytes();assert {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}==record,name
assert not(p/'qualification').exists() and not(p/'qualification-result.json').exists()
started=time.monotonic();command=[exe,'-I','-B',str(p/'test-slice.py'),'--started-s',repr(started)]
child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
failure=None;cleanup={'owned_process_rows':[],'recorded_groups':[],'errors':[]}
try:
 out,err=child.communicate(timeout=max(0.001,started+115-time.monotonic()))
except subprocess.TimeoutExpired as exc:
 failure='original115s harness/reserve exhausted; no successful qualification'
 out,err=exc.output or b'',exc.stderr or b''
finally:
 # The harness's retained caller creates separate sessions. Observe owned
 # descendants before killing their ancestor; never infer EPERM as inactivity.
 groups={child.pid}
 try:
  table=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid='],capture_output=True,timeout=1,check=False)
  assert table.returncode==0 and not table.stderr and len(table.stdout)<=65536,'bounded process witness unavailable'
  rows=[tuple(map(int,line.split())) for line in table.stdout.splitlines()]
  owned={child.pid}
  for _ in rows:
   more={pid for pid,parent,group in rows if parent in owned}
   if more<=owned:break
   owned|=more
  cleanup['owned_process_rows']=[{'pid':pid,'ppid':parent,'pgid':group}for pid,parent,group in rows if pid in owned]
  groups|={group for pid,parent,group in rows if pid in owned}
 except (AssertionError,OSError,ValueError,subprocess.TimeoutExpired)as exc:
  cleanup['errors'].append(type(exc).__name__+': '+str(exc)[:256])
 # Fixed prefix was freshly created by this invocation. These records belong
 # to its frozen artificial entries/known harmless descendant test only.
 records=list((p/'qualification').glob('*/execution/supervisor.pgid'))
 for path in records:
  try:
   with path.open('rb')as f:raw=f.read(33)
   assert len(raw)<=32 and raw.strip().isdigit(),'invalid owned group record'
   group=int(raw);groups.add(group);cleanup['recorded_groups'].append({'path':str(path),'pgid':group})
  except (AssertionError,OSError,ValueError)as exc:cleanup['errors'].append(type(exc).__name__+': '+str(exc)[:256])
 known=p/'qualification/whole-group-cleanup/child.json'
 if known.exists():
  try:
   with known.open('rb')as f:raw=f.read(1025)
   assert len(raw)<=1024,'oversize known artificial child witness'
   item=json.loads(raw);assert type(item['pgid'])is int;groups.add(item['pgid'])
  except (AssertionError,OSError,ValueError,KeyError,TypeError)as exc:cleanup['errors'].append(type(exc).__name__+': '+str(exc)[:256])
 for group in sorted(groups):
  try:
   assert group>1 and group not in {os.getpid(),os.getpgrp()},'unsafe cleanup group'
   os.killpg(group,signal.SIGKILL)
  except ProcessLookupError:pass
  except (AssertionError,OSError)as exc:cleanup['errors'].append(type(exc).__name__+': '+str(exc)[:256])
 child.wait(timeout=max(0.001,min(1,started+120-time.monotonic())))
 if cleanup['errors']:failure=failure or 'external artificial group cleanup/witness failed'
assert len(out)<=65536 and len(err)<=65536
for name,raw in [('harness.stdout.json',out),('harness.stderr.log',err)]:
 with(p/name).open('xb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
try:packet=json.loads(out)
except (ValueError,UnicodeError):packet=None;failure=failure or 'harness return unavailable/malformed'
observed=time.monotonic()-started
record={'schema':'ariadna.f18.artificial-slice-external-invocation.v1','command':command,'started_s':started,'limit_s':120,'harness_reserve_s':5,'elapsed_after_stdout_stderr_fsync_s':observed,'exit_code':child.returncode,'failure':failure,'stdout':packet,'stderr_bytes':len(err),'cleanup':cleanup,'candidate_manifest_sha256':hashlib.sha256((p/'candidate-source-pins.json').read_bytes()).hexdigest(),'structured_scientific_or_native_work':False,'status':'PENDING_EXTERNAL_OBSERVATION_FSYNC'}
with(p/'external-invocation.json').open('x')as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
actual=time.monotonic()-started
ok=(failure is None and child.returncode==0 and not err and type(packet)is dict and packet.get('status')=='PASS_INJECTED_QUALIFICATION' and actual<120)
print(json.dumps({'status':'PASS'if ok else'FAILED','observed_after_external_receipt_fsync_s':actual,'external_record':'external-invocation.json','exit_code':child.returncode,'stdout':packet,'failure':failure}))
raise SystemExit(0 if ok else 2)
