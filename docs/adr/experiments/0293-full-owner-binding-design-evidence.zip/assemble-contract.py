from pathlib import Path
import hashlib, json, time
p=Path('/private/tmp/ariadna-f18-0293')
scope=json.loads((p/'scope.json').read_text())
assert time.monotonic()<scope['started_s']+600
old=json.loads((p/'retained-control-pins.json').read_text())
inputs=json.loads((p/'input-pins.json').read_text())['files']
rows=[]
def row(names, classification, anchors, changes, checks):
    rows.append({'pieces':names,'classification':classification,'sources':{n:old[n] for n in names},
                 'anchors':anchors,'exact_change_recipe':changes,'required_checks':checks})
row(['episode/call-once.py','episode/launch-once.py'],'byte-identical reuse candidates',
    'call main/supervise; launch main lines30-128',
    ['Keep whole bytes unchanged; profile is dynamically supplied.',
     'The launcher command remains /usr/bin/sandbox-exec -f profile.sandbox_profile profile.private_python -B native-entry.py PROFILE repr(original_start).',
     'Keep caller outerPython -I -B launch-once.py PROFILE repr(original_start), cold source/native/resource pins, exclusive consumed marker, isolated session, unchanged environment and original-clock inheritance.'],
    ['Byte comparison against retained pins; role argv contains exact profile/privatePython/source identity and original start.',
     'Focused injected end-to-end return, repeat-consumption refusal and owned-group cleanup; no actual native CLI execution.'])
row(['episode/run-once.py','episode/native.sandbox','episode/check-preservation.py'],'namespace/label only',
    'run lines4-39,41-80; sandbox entirefile; preservation fixedroot and observation schema',
    ['Replace only fixed /private/tmp/ariadna-f18-forward-completed-v1 by /private/tmp/ariadna-f18-full-owner-v1 and completed factual observation labels by full-owner labels.',
     'Sandbox writes only newroot/execution and /dev/null, denies network and reads of operational Conda prefix; preserve all other bytes.',
     'run-once module remains non-import-safe: never import/execute its consumed-root top level during artificial tests; reuse exact selected check_aggregate/sync_directories definitions.',
     'Preservation baseline path/SHA and compared operational prefix stay unchanged.'],
    ['Exact byte transformation proof; sandbox literal comparison; no live operational-prefix scan during artificial qualification.',
     'Preserve bottom-up directory fsync, all-root2MiB/64KiB and actual originalclock after last observation fsync;65s failure-only outer failsafe.'])
row(['episode/native-entry.py'],'logic changed, minimal inherited native entry',
    'entry _KEYS/_read_profile/run/main lines16-22,40-68,78-161; qualified0292 entry original-start/group/source checks',
    ['Use fixed future root and full-owner profile schema/scope, rename probe_input to fixture_input as specified by admission field map; all other runtime profile keys remain exact.',
     'Native CLI stays exactly PROFILE ORIGINAL_START with no artificial/worker/executor overrides. Reject such overrides before profile/resource access.',
     'Keep private interpreter identity, exact own/adapter pins, original episode-start binding, PID=PGID=SID, bounded supervisor.pgid durable creation and one collector import.',
     'Use the profile original two-key fixture_input and unchanged full runner instead of completed probe identity; do not execute or relabel qualified0292 artificial-only entry as native.',
     'An artificial-only API/namespace may exercise harmless injected commands; native mode always rejects substitutions.'],
    ['Native CLI extra args/artificial overrides refuse before resource read; wrong schema/scope/root/interpreter/source/group/reset/future/expired clock refuse.',
     'Artificial positive inherited entry uses unchanged guarded audit; duplicate consumption and first-failure partials are preserved.'])
row(['episode/supervisor-adapter.py'],'logic changed, thin delegation',
    'retained collect149-260; qualified0292 collect/validate and original run172-253,_worker_command162-164',
    ['Replace completed producer/audit/ten-marker controller with thin call to original run(raw, packetdir, started_s=original, inherited_group=True); do not mkdir packetdir before original run owns its exclusive creation.',
     'Encode only fixture_input={schema:ariadna-owner-fixture-input-v1,scope:synthetic-owner-conformance-only}.',
     'Native mode leaves original _worker_command untouched and requires actual producer_mode=native; injected mode belongs only to explicit artificial profile/API and may intercept produce only, never audit.',
     'Keep result as bounded full-owner collector envelope with passed only after original run status=passed, finalization=checked-after-fsync and actual full audit schema/mode/calls8/arcs2; completion still requires enclosing outer finalization.',
     'Remove completed ten-marker/probe telemetry assumptions entirely, not by retagging their values. Preserve first failure and any raw partials; unresolved actual native counts remain UNKNOWN.'],
    ['Native command identity source proof, plus nonexecuting argv validation; no native-labelled fabricated success.',
     'Artificial eight-outcome/two-arc packet passes unchanged auditor; wrong producer mode/schema/counts and actual audit refusal fail; first failed factory preserves partials without audit.',
     'Original-source pins stay unchanged; no new controller/run_isolated recursion.'])
contract={
 'schema':'ariadna.f18.full-owner-binding-design.v1','stage':'F18.23','status':'DESIGN_ONLY_NOT_ADMITTED',
 'base_revision':scope['base_revision'],'future_native_root':'/private/tmp/ariadna-f18-full-owner-v1',
 'future_native_namespace_created':False,'runtime_profile_schema':'ariadna.f18.full-owner-control-profile.v1',
 'runtime_decision_schema':'ariadna.f18.full-owner-execution-decision.v1',
 'scope':'synthetic-owner-conformance-only','scientific_free_variables':[],
 'fixed_input':{'schema':'ariadna-owner-fixture-input-v1','scope':'synthetic-owner-conformance-only'},
 'original_source_pins':{n:rec for n,rec in inputs.items() if n.startswith('original-source/')},
 'qualified_artificial_sources':{n:rec for n,rec in inputs.items() if n.startswith('qualified-0292/controls/')},
 'source_count_policy':'Retain53existing source identities; verify original full fixture/run/audit already belong before implementation. Missing source requires an explicit cohort/count design revision, never silent addition.',
 'active_controls':['call-once.py','launch-once.py','run-once.py','native.sandbox','check-preservation.py','native-entry.py','supervisor-adapter.py','admission.py'],
 'external_gate':'dispatch-once.py is separately pinned, outside eight active controls; three operators/profile/decision are separate bindings',
 'control_changes':rows,
 'admission_profile_gate_field_map':'field-bindings-admission.json',
 'profile_template':'profile-template.json','decision_template':'decision-template.json',
 'native_worker_argv':{'recipe':['profile.private_python','-m','space_nav._owner_endpoint_run','--worker','produce|audit','source','repr(original_start)','repr(cutoff)'],
   'source_for_produce':'packetdir/input.json','source_for_audit':'packetdir/producer.json',
   'produce_cutoff':'original_start+45','audit_cutoff':'min(producer_completion+10, original_start+55)',
   'actual_executable':'sys.executable inside fixed private entry; no command replacement/native monkeypatch',
   'origin':'unchanged original _worker_command lines162-164'},
 'fixed_contract':{'outcomes_order':['never-run refusal','forward start','forward end','wrong-schema refusal','retained-bound equal terminal','cleared refusal','independent reverse end','reverse start'],
   'arcs':2,'factory_attempts_max':3,'analytic_integration_attempts_max':2,'visitor_calls_max':8,'precharged_acceleration_callbacks_max':100000,
   'native_function_counts':'Separate telemetry; never substitute for callback entries',
   'epochs_s':[0,1000],'reverse_initialization':'Independent original literal, not carried forward endpoint',
   'gates':{'euclidean_position_m':0.001,'euclidean_velocity_m_s':0.000001,'absolute_mass_kg':0.000000001},
   'oracle':'Unchanged original independent own-start binary64 literal/Fraction analytic oracle and exact schema/settings/metadata',
   'physical_admission':'unavailable'},
 'budgets':{'design_s':600,'design_structured_bytes':2097152,'design_log_bytes':65536,
   'future_minimal_implementation_and_static_review_s':1800,
   'future_one_focused_artificial_invocation_s':120,'artificial_cold_and_durable_finalization_inclusive':True,
   'packet_s':60,'producer_finish_s':45,'audit_s':10,'audit_finish_s':55,'finalization_reserve_s':5,'failure_only_cleanup_s':65,
   'input_bytes':65536,'producer_bytes':1048576,'audit_bytes':524288,'receipt_bytes':65536,'aggregate_structured_bytes':2097152,
   'aggregate_log_bytes':65536,'inner_log_bytes':63488,'outer_log_bytes':2048,
   'known_interpreter_identity_input_bytes':16777216,'generic_artifact_read_bytes':2097152,
   'repository_executable_test_dependency_change_requires':'Focused tests plus frozen make test portable+live<=1800s, Ruff and strict; no checkout mutations while suite runs'},
 'focused_artificial_qualification':[
   'Freeze exact changed sources/templates/argv recipes and independent connected review before one<=120s artificial invocation; retain original clock from before generation/cold imports.',
   'One complete eight-outcome/two-arc injected positive through unchanged original guarded auditor and changed outer profile/entry/admission/gate/operator bindings, explicitly non-native.',
   'Refuse old completed schemas/ten-keyinput/ten-markercounts; wrong mode/root/source/native/resource/control/gate/profile/decision identities; injected override on native CLI; missing or reused once markers.',
   'Refuse reset/future/expired original preflight/packet clocks; unisolated group and duplicate entry; exact-bound/over-bound inputs/logs/producer/audit/receipt/aggregate and failed finalization.',
   'Missing actual-admission/explicit-choice fields refuse before native namespace/resource access; synthetic admission stays synthetic and cannot write actual PASS/admitted-once.',
   'Actual wrong-count auditor refusal, first-failure partial preservation, enclosing all-root directory-fsync/clock and owned-group cleanup; use existing qualified helpers, no unchanged194case/3helper rerun.',
   'All artificial work below fresh diagnostic namespace, no actual native root/mount/resourcepayloads/operational-prefix scan; independent saved-only audit and exact pin/history checks after return.'
 ],
 'implementation_completion':['Exact8controls+externalgate/operators/profile/decision candidate pins, honest changed/reuse proof and original runtime source identity',
   'All targeted artificial checks pass with actual terminal<=120s and independent code/saved-evidence review',
   'Protected history, archive identities, links, CURRENT<60lines, diff/strict and conditional required repository runtime checks pass; separate commit/push'],
 'actual_native_prerequisites':['Distinct future explicit user choice for one full0267owner episode;0285authority remains consumed',
   'Fixed non-placeholder new candidate/profile/decision/source/native/resource/history identities; physical gates unchanged',
   'Fresh actual independent<=600s admission including read-only11resource observation and coldruntime flags, before native namespace/mount; retained receipts are not fresh admission',
   'Preserve53source/10native/11resources/25ledger/86history and existing image/environment, exclusive once markers and60s/65failure packet/byte/cleanup/preservation/detach duties'],
 'deferred':['Native episode itself','native full lifecycle/carry/concurrency/arbitraryTime/prior arithmetic/core ABI-FP','physical realized-clock/full-force/endpoint bounds','physicalF0/strictM3/task3.9','admissible command pair/99percent/safety','M4-M6/ML/UI/newsearch/optimizer changes'],
 'new_native_authority':False,'tests_or_scientific_work_in_this_design':False,
 'unresolved_future_values':'Future execution stage/explicit choice, candidate SHA/base/preflight and actual admission are deliberately absent in NOT_ADMITTED templates; cannot be accepted by runtime. No scientific free variable is released.'
}
with(p/'binding-contract.json').open('x')as f:json.dump(contract,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'contract_bytes':(p/'binding-contract.json').stat().st_size,'elapsed_s':time.monotonic()-scope['started_s']}))
