from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path('/private/tmp/ariadna-f18-0293');r=Path('/Users/agrudin/dev/my/ariadna')
scope=json.loads((p/'scope.json').read_text());started=scope['started_s']
def tick(): assert 0<=time.monotonic()-started<600,'Original source/design budget exhausted'
def pin(f):
 raw=f.read_bytes();return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
tick();review=json.loads((p/'reviewer.json').read_text())
assert review['status']=='PASS' and not review['findings']
assert not Path('/private/tmp/ariadna-f18-full-owner-v1').exists(),'Future native namespace was created'
for name,expected in review['reviewed_files'].items():
 q=Path(name) if Path(name).is_absolute() else p/name
 assert pin(q)==expected,name
names=['binding-contract.json','field-bindings-admission.json','profile-template.json','decision-template.json']
frozen={name:pin(p/name)for name in names}
mapping=json.loads((p/'field-bindings-admission.json').read_text())
assert json.loads((p/'profile-template.json').read_text())==mapping['profile_template']
assert json.loads((p/'decision-template.json').read_text())==mapping['decision_template']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==scope['base_revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r)
with(p/'contract-pins.json').open('x')as f:json.dump({'schema':'ariadna.f18.full-owner-binding-design-pins.v1','files':frozen,'review_pin':pin(p/'reviewer.json')},f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
files=[f for f in p.rglob('*')if f.is_file()]
structured=sum(f.stat().st_size for f in files if not f.name.endswith('.log'))
logs=sum(f.stat().st_size for f in files if f.name.endswith('.log'))
assert structured+4096<=2097152 and logs<=65536
for f in files:
 with f.open('rb')as stream:os.fsync(stream.fileno())
for d in sorted([p]+[q for q in p.rglob('*')if q.is_dir()],key=lambda q:len(q.parts),reverse=True):
 fd=os.open(d,os.O_RDONLY);os.fsync(fd);os.close(fd);tick()
before=time.monotonic()-started
record={'schema':'ariadna.f18.native-binding-design-closure.v1','stage':'F18.23','base_revision':scope['base_revision'],'status':'DESIGN_ONLY_NOT_ADMITTED','source_phase_passed':True,'started_s':started,'source_limit_s':600,'elapsed_after_source_fsync_s':before,'evidence_bytes_before_receipt':structured,'log_bytes':logs,'evidence_limit_bytes':2097152,'contract_pins':frozen,'independent_review_pin':pin(p/'reviewer.json'),'tests_native_spice_integration_or_mount_executed':False,'actual_native_namespace_created':False,'new_native_authority':False,'documentary_publication':'Separate after source phase'}
with(p/'source-closure.json').open('x')as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd);tick()
print(json.dumps({'closure':record,'observed_after_closure_fsync_s':time.monotonic()-started}))
