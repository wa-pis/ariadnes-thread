"""Fixed full-owner entry; native CLI has no replacement command options."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from typing import Any

_ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0294/artificial')
_NATIVE_ROOT = Path('/private/tmp/ariadna-f18-full-owner-v1')
NATIVE_EXECUTION_STAGE = None  # A distinct future native choice is still missing.
_KEYS = set('schema scope mode repo base_revision root work_directory preflight_started_s '
            'outer_python private_python environment sandbox_profile source_pins native_pins '
            'resource_pins resource_directory image mount ledger_pins history_archive '
            'history_member_pins control_pins outer_gate contract kernel_sha256 fixture_input '
            'entry_sha256 launch_sha256 caller_sha256 adapter_sha256 sandbox_sha256 '
            'prelaunch_admission execution_decision'.split())


def _safe_artificial(path: Path) -> None:
    if not path.is_absolute() or '..' in path.parts or '\0' in str(path):
        raise RuntimeError('absolute safe artificial path required')
    if not path.is_relative_to(_ARTIFICIAL_ROOT) or path == _ARTIFICIAL_ROOT:
        raise RuntimeError('replacement packets forbidden outside artificial prefix')
    for parent in [*reversed(path.parent.parents), path.parent]:
        if not stat.S_ISDIR(parent.lstat().st_mode):
            raise RuntimeError('unsafe artificial profile ancestor')
    if stat.S_ISLNK(path.lstat().st_mode):
        raise RuntimeError('artificial profile symlink forbidden')


def _read(path: Path) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or not 0 <= info.st_size <= 65536:
            raise RuntimeError('regular entry artifact64KiB cap')
        raw = os.read(fd, 65537)
        after = os.fstat(fd)
        if (len(raw) != info.st_size or os.read(fd, 1) or after.st_size != info.st_size
                or after.st_mtime_ns != info.st_mtime_ns):
            raise RuntimeError('short/changed entry artifact read')
        return raw
    finally:
        os.close(fd)


def _read_profile(path: Path) -> dict[str, Any]:
    def unique(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise RuntimeError('duplicate profile field')
            result[key] = value
        return result
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite profile value: ' + value)
    profile = json.loads(_read(path), object_pairs_hook=unique, parse_constant=invalid)
    if (type(profile) is not dict or set(profile) != _KEYS
            or profile['schema'] != 'ariadna.f18.full-owner-control-profile.v1'
            or profile['scope'] != 'synthetic-owner-conformance-only'):
        raise RuntimeError('fixed full-owner entry profile required')
    return profile


def run(profile_path: Path, started_s: float, *,
        artificial_commands: object = None) -> dict[str, object]:
    """Enter one existing session and collector without another supervisor."""
    # CLI replacements and outside artificial paths refuse before profile reads.
    if artificial_commands is not None:
        _safe_artificial(profile_path)
    elif profile_path != _NATIVE_ROOT / 'profile.json':
        raise RuntimeError('native entry requires fixed native profile path')
    elif NATIVE_EXECUTION_STAGE is None:
        raise RuntimeError('distinct full-owner native user choice is not available')
    if (type(started_s) not in (int, float) or not math.isfinite(started_s)
            or not 0 <= time.monotonic() - started_s < 60):
        raise RuntimeError('finite inherited original entry clock required')
    profile = _read_profile(profile_path)
    if profile['mode'] == 'native':
        if artificial_commands is not None:
            raise RuntimeError('native forbids command replacements')
        if profile['root'] != str(_NATIVE_ROOT) or profile_path.parent != _NATIVE_ROOT:
            raise RuntimeError('fixed native namespace required')
    elif profile['mode'] == 'artificial':
        if artificial_commands is None:
            raise RuntimeError('artificial entry requires explicit harmless packet')
        _safe_artificial(Path(profile['root']))
    else:
        raise RuntimeError('fixed native/artificial entry mode required')
    if os.getpid() != os.getpgrp() or os.getpid() != os.getsid(0):
        raise RuntimeError('entry requires one isolated session')
    if profile_path.parent != Path(profile['root']):
        raise RuntimeError('profile must belong to its entry root')
    own_raw = _read(Path(__file__))
    adapter_path = Path(__file__).with_name('supervisor-adapter.py')
    adapter_raw = _read(adapter_path)
    if len(own_raw) > 65536 or hashlib.sha256(own_raw).hexdigest() != profile['entry_sha256']:
        raise RuntimeError('entry source pin mismatch')
    if len(adapter_raw) > 65536 or hashlib.sha256(adapter_raw).hexdigest() != profile['adapter_sha256']:
        raise RuntimeError('full-owner collector source pin mismatch')
    spec = importlib.util.spec_from_file_location('full_owner_packet_collector', adapter_path)
    if spec is None or spec.loader is None:
        raise RuntimeError('fixed full-owner collector unavailable')
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    work, _ = adapter.validate(profile, started_s, artificial_commands=artificial_commands)
    adapter.check_clock(started_s, 45)
    group = (str(os.getpgrp()) + '\n').encode('ascii')
    if len(group) > 32:
        raise RuntimeError('entry PGID exceeds fixed32B cap')
    with (work / 'supervisor.pgid').open('xb') as stream:
        if stream.write(group) != len(group):
            raise RuntimeError('short PGID write')
        stream.flush()
        os.fsync(stream.fileno())
    adapter.directory_sync(work)
    adapter.check_clock(started_s, 45)
    result = adapter.collect(profile, work / 'native-packet', started_s,
                             artificial_commands=artificial_commands)
    if len(adapter.encoded(result)) > 2048:
        raise RuntimeError('entry result2048B cap')
    return result


def main() -> int:
    """Native-only CLI; artificial API is never an argv option."""
    if len(sys.argv) != 3:
        raise RuntimeError('fixed native entry requires profile and original clock only')
    result = run(Path(sys.argv[1]), float(sys.argv[2]))
    sys.stdout.write(json.dumps(result, sort_keys=True, allow_nan=False) + '\n')
    sys.stdout.flush()
    return 0 if (result.get('status') == 'passed'
                 and result.get('finalization') == 'checked-after-fsync') else 2


if __name__ == '__main__':
    raise SystemExit(main())
