"""Fixed full-owner binding: unchanged runner and independent guarded auditor."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys
import time
from typing import Any

_ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0294/artificial')
_NATIVE_ROOT = Path('/private/tmp/ariadna-f18-full-owner-v1')
_REPO = Path('/Users/agrudin/dev/my/ariadna')
_OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
_SCOPE = 'synthetic-owner-conformance-only'
_INPUT = {'schema': 'ariadna-owner-fixture-input-v1', 'scope': _SCOPE}
_KEYS = set('schema scope mode repo base_revision root work_directory preflight_started_s '
            'outer_python private_python environment sandbox_profile source_pins native_pins '
            'resource_pins resource_directory image mount ledger_pins history_archive '
            'history_member_pins control_pins outer_gate contract kernel_sha256 fixture_input '
            'entry_sha256 launch_sha256 caller_sha256 adapter_sha256 sandbox_sha256 '
            'prelaunch_admission execution_decision'.split())
_SOURCE_PINS = {
    str(_REPO / 'src/space_nav/_owner_endpoint_run.py'): {'bytes': 17901, 'sha256': 'ba41c64e880b369ffc83844a3185fce40f2020d4a55e671b768cfd32f96988d4'},
    str(_REPO / 'src/space_nav/_owner_endpoint_fixture.py'): {'bytes': 17390, 'sha256': '48c33d3388d9d780312da25666fae9726c53576d46eefd285ef97d20232c5ee0'},
    str(_REPO / 'src/space_nav/_owner_endpoint_audit.py'): {'bytes': 14638, 'sha256': '409c629c27efabccd96a6f0da85942b51f0a8bd79d2c943f5da09d9138f94eba'},
}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def safe(path: Path) -> None:
    """Allow only the explicit artificial tree, without symlink ancestors."""
    need(path.is_absolute() and '..' not in path.parts and '\0' not in str(path), 'absolute artificial path required')
    need(path.is_relative_to(_ARTIFICIAL_ROOT) and path != _ARTIFICIAL_ROOT, 'outside fixed artificial prefix')
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory ancestor')
    if os.path.lexists(path):
        need(not stat.S_ISLNK(path.lstat().st_mode), 'artificial symlink forbidden')


def read(path: Path, cap: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= cap, 'regular bounded file required')
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        need(len(raw) == before.st_size == after.st_size and not os.read(fd, 1)
             and before.st_mtime_ns == after.st_mtime_ns, 'short/changed read')
        return raw
    finally:
        os.close(fd)


def object_value(raw: bytes) -> dict[str, Any]:
    def pairs(rows: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite JSON: ' + value)
    value = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    need(type(value) is dict, 'JSON object required')
    return value


def pin(value: object, *, cap: int, expected_path: Path | None = None) -> bytes:
    need(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}, 'exact path pin required')
    need(type(value['path']) is str and type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str and len(value['sha256']) == 64
         and all(c in '0123456789abcdef' for c in value['sha256']), 'invalid bounded pin')
    path = Path(value['path'])
    need(path.is_absolute() and '..' not in path.parts and '\0' not in str(path), 'absolute normalized pin path')
    if expected_path is not None:
        need(path == expected_path, 'fixed pin path mismatch')
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'pin symlink ancestor')
    raw = read(path, cap)
    need(len(raw) == value['bytes'] and hashlib.sha256(raw).hexdigest() == value['sha256'], 'pinned source/packet drift')
    return raw


def check_clock(started_s: float, seconds: float = 60) -> float:
    now = time.monotonic()
    need(type(started_s) in (int, float) and math.isfinite(started_s)
         and math.isfinite(now) and 0 <= now - started_s < seconds, 'original packet clock exhausted or reset')
    return now


def directory_sync(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write(path: Path, value: object) -> bytes:
    raw = encoded(value)
    need(len(raw) <= 65536, 'outer receipt64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(fd, raw[offset:])
            need(count > 0, 'short receipt write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    return raw


def validate(profile: dict[str, Any], started_s: float, *,
             artificial_commands: object = None) -> tuple[Path, dict[str, Any] | None]:
    """Bind native identities or an explicitly artificial packet before package import."""
    need(type(profile) is dict, 'exact full-owner profile required')
    mode = profile.get('mode')
    # These refusals precede namespace, resource and package access.
    if mode == 'native':
        need(artificial_commands is None, 'native forbids command replacements before live reads')
        need(profile.get('root') == str(_NATIVE_ROOT), 'fixed native namespace required')
    elif mode == 'artificial':
        need(type(artificial_commands) is dict and set(artificial_commands) == {'packet'}, 'explicit artificial packet pin required')
        need(type(profile.get('root')) is str, 'string artificial root required')
        safe(Path(profile['root']))
    else:
        raise RuntimeError('fixed native/artificial mode required')
    need(set(profile) == _KEYS and profile['schema'] == 'ariadna.f18.full-owner-control-profile.v1'
         and profile['scope'] == _SCOPE and type(profile['repo']) is str, 'exact full-owner profile schema/scope/repo required')
    if mode == 'native':
        need(profile['repo'] == str(_REPO), 'fixed native repository required')
    else:
        # This is fabricated cohort metadata, never the executing package source.
        safe(Path(profile['repo']))
    now = check_clock(started_s)
    preflight = profile['preflight_started_s']
    need(type(preflight) in (int, float) and math.isfinite(preflight)
         and preflight <= started_s and 0 <= now - preflight < 600, 'original preflight clock exhausted or reset')
    need(type(profile['work_directory']) is str, 'string work path required')
    root, work = Path(profile['root']), Path(profile['work_directory'])
    need(work == root / 'execution' and not (work / 'parent.pgid').exists(), 'fixed inherited work path without recursive parent')
    if mode == 'artificial':
        safe(work)
    need(stat.S_ISDIR(work.lstat().st_mode), 'launcher-owned work directory required')
    profile_raw = read(root / 'profile.json', 65536)
    need(object_value(profile_raw) == profile, 'profile file/value binding mismatch')
    episode = object_value(read(root / 'episode-start.json', 65536))
    need(set(episode) == set('schema started_s started_utc preflight_elapsed_s deadline_s profile_sha256 retry_authorized'.split())
         and episode['schema'] == 'ariadna.f18.native-start.v1'
         and type(episode['started_s']) in (int, float) and episode['started_s'] == started_s
         and type(episode['deadline_s']) in (int, float) and episode['deadline_s'] == started_s + 60
         and type(episode['preflight_elapsed_s']) in (int, float)
         and episode['preflight_elapsed_s'] == started_s - preflight
         and episode['profile_sha256'] == hashlib.sha256(profile_raw).hexdigest()
         and episode['retry_authorized'] is False, 'original episode/start/profile binding changed')
    need(type(profile['fixture_input']) is dict and profile['fixture_input'] == _INPUT, 'unchanged two-key fixture input required')
    expected_interpreter = profile['private_python'] if mode == 'native' else profile['outer_python']['path']
    need(type(expected_interpreter) is str and Path(sys.executable).resolve() == Path(expected_interpreter).resolve(), 'entry interpreter identity mismatch')
    if mode == 'artificial':
        pin(profile['outer_python'], cap=16777216, expected_path=_OUTER.resolve())
    need(type(profile['source_pins']) is dict and len(profile['source_pins']) == 53, 'retained53 source cohort required')
    if mode == 'native':
        sources: dict[str, Any] = {}
        for name, row in profile['source_pins'].items():
            need(type(name) is str, 'source path required')
            path = Path(name)
            path = path if path.is_absolute() else _REPO / path
            need(path.is_relative_to(_REPO) and '..' not in path.parts and str(path) not in sources, 'source cohort path alias')
            sources[str(path)] = row
        for name, row in _SOURCE_PINS.items():
            need(sources.get(name) == row, 'native original source cohort identity mismatch')
    # Artificial cohort rows are synthetic admission inputs, not native identities.
    # Actual imported package sources are independently pinned in either mode.
    for name, row in _SOURCE_PINS.items():
        pin({'path': name, **row}, cap=65536)
    controls = Path(__file__).parent
    for name, field in [('native-entry.py', 'entry_sha256'), ('supervisor-adapter.py', 'adapter_sha256')]:
        need(hashlib.sha256(read(controls / name, 65536)).hexdigest() == profile[field], 'entry/adapter source pin mismatch')
    packet = None
    if mode == 'artificial':
        packet_pin = artificial_commands['packet']
        need(type(packet_pin) is dict and type(packet_pin.get('path')) is str, 'artificial packet path pin required')
        packet_path = Path(packet_pin['path'])
        safe(packet_path)
        need(packet_path.is_relative_to(root) and not packet_path.is_relative_to(work), 'artificial packet must be outside work in same case')
        packet = object_value(pin(packet_pin, cap=1048576))
        need(packet.get('schema') == 'ariadna-owner-fixture-v1' and packet.get('scope') == _SCOPE
             and packet.get('mode') == 'injected', 'original injected fixture schema/mode required')
    return work, packet


def collect(profile: dict[str, Any], directory: Path, started_s: float, *,
            artificial_commands: object = None) -> dict[str, object]:
    """Delegate one unchanged full-owner runner; native worker commands stay untouched."""
    work, packet = validate(profile, started_s, artificial_commands=artificial_commands)
    need(directory == work / 'native-packet', 'fixed packet directory')
    need(os.getpid() == os.getpgrp() == os.getsid(0), 'inherited isolated entry group required')
    check_clock(started_s, 45)
    sys.path.insert(0, str(_REPO / 'src'))
    from space_nav import _owner_endpoint_run as runner
    need(Path(runner.__file__).resolve() == _REPO / 'src/space_nav/_owner_endpoint_run.py', 'original runner module required')
    original_command = runner._worker_command
    if profile['mode'] == 'native':
        # Pure command construction only; no interception on the native branch.
        for kind, source, cutoff in [('produce', directory / 'input.json', started_s + 45),
                                     ('audit', directory / 'producer.json', started_s + 55)]:
            need(original_command(kind, source, started_s, cutoff)
                 == [sys.executable, '-m', 'space_nav._owner_endpoint_run', '--worker',
                     kind, str(source), repr(started_s), repr(cutoff)], 'original native worker argv changed')
    witness: list[dict[str, object]] = []
    result: dict[str, Any] | None = None
    failure: str | None = None
    finalization = 'unavailable'
    expected_mode = 'native' if profile['mode'] == 'native' else 'injected'

    def command(kind: str, source: Path, worker_started: float, deadline_s: float) -> list[str]:
        need(kind in {'produce', 'audit'}, 'unexpected worker role')
        expected_source = directory / ('input.json' if kind == 'produce' else 'producer.json')
        need(source == expected_source and worker_started == started_s, 'original worker source/start changed')
        need(math.isfinite(deadline_s) and (deadline_s == started_s + 45 if kind == 'produce'
             else started_s < deadline_s <= started_s + 55), 'original worker deadline changed')
        expected = [sys.executable, '-m', 'space_nav._owner_endpoint_run', '--worker',
                    kind, str(source), repr(worker_started), repr(deadline_s)]
        actual = original_command(kind, source, worker_started, deadline_s)
        need(actual == expected, 'original worker argv changed')
        if kind == 'produce':
            need(object_value(read(source, 65536)) == _INPUT, 'original worker input bytes changed')
        need([row['kind'] for row in witness] == ([] if kind == 'produce' else ['produce']), 'duplicate/out-of-order worker')
        if kind == 'produce':
            raw = json.dumps(packet)
            chosen = [sys.executable, '-c', f'import sys;sys.stdout.write({raw!r});sys.exit(0)']
            row = {'kind': kind, 'original_argv': actual, 'replacement_argv': chosen,
                   'replacement_argv_sha256': hashlib.sha256(encoded(chosen)).hexdigest(),
                   'replacement_argv_bytes': len(encoded(chosen)), 'packet_pin': artificial_commands['packet'],
                   'original_started_s': started_s, 'deadline_s': deadline_s}
        else:
            row = {'kind': kind, 'original_argv': actual, 'audit_argv_unchanged': True,
                   'original_started_s': started_s, 'deadline_s': deadline_s}
            chosen = actual
        check_clock(started_s, deadline_s - started_s)
        path = work / (kind + '-command-before-dispatch.json')
        write(path, row)
        directory_sync(work)
        need(read(path, 65536) == encoded(row), 'pre-dispatch witness changed after file/directory fsync')
        check_clock(started_s, deadline_s - started_s)
        witness.append({key: value for key, value in row.items() if key != 'replacement_argv'})
        return chosen

    # This is the only substitution and only the explicit artificial branch uses it.
    if profile['mode'] == 'artificial':
        runner._worker_command = command
    try:
        result = runner.run(encoded(_INPUT), directory, started_s=started_s, inherited_group=True)
        failure = result.get('failure')
        finalization = result.get('finalization', 'unavailable')
        if result.get('status') == 'passed':
            need(result.get('schema') == 'ariadna-owner-run-v1' and result.get('producer_mode') == expected_mode
                 and result.get('physical_admission') == 'unavailable'
                 and finalization == 'checked-after-fsync', 'original run result mode/finalization mismatch')
            if profile['mode'] == 'artificial':
                need([row['kind'] for row in witness] == ['produce', 'audit'], 'full artificial producer/audit sequence required')
            audit = object_value(read(directory / 'audit.json', 524288))
            need(audit.get('schema') == 'ariadna-owner-audit-v1' and audit.get('status') == 'passed'
                 and audit.get('mode') == expected_mode and audit.get('physical_admission') == 'unavailable'
                 and type(audit.get('calls_checked')) is int and audit['calls_checked'] == 8
                 and type(audit.get('analytic_arcs_checked')) is int and audit['analytic_arcs_checked'] == 2,
                 'original independent audit did not establish eight calls/two arcs')
    except (RuntimeError, OSError, ValueError, TypeError, KeyError) as exc:
        failure = failure or f'{type(exc).__name__}: {exc}'[:1024]
    finally:
        if profile['mode'] == 'artificial':
            runner._worker_command = original_command
    wrapper: dict[str, object] = {'schema': 'ariadna.f18.full-owner-collector.v1',
        'scope': _SCOPE, 'mode': profile['mode'], 'status': 'failed', 'failure': failure,
        'producer_mode': expected_mode, 'physical_admission': 'unavailable',
        'completion_requires_outer_finalization': True, 'finalization': finalization,
        'actual_partial_counts': 'UNKNOWN unless original successful producer and audit establish completion'}
    try:
        if profile['mode'] == 'artificial':
            write(work / 'worker-command-witness.json', {'workers': witness, 'audit_replaced': False})
        raw_result = write(work / 'runner-result.json', result if result is not None else {'status': 'failed', 'failure': failure})
        wrapper['runner_report'] = {'path': str(work / 'runner-result.json'), 'bytes': len(raw_result),
                                    'sha256': hashlib.sha256(raw_result).hexdigest()}
        directory_sync(directory)
        directory_sync(work)
        check_clock(started_s)
    except (RuntimeError, OSError, ValueError) as exc:
        wrapper['failure'] = failure or f'{type(exc).__name__}: {exc}'[:1024]
        wrapper['finalization'] = 'failed-after-fsync'
    else:
        if result is not None and result.get('status') == 'passed' and failure is None:
            wrapper.update(status='passed', calls_checked=8, analytic_arcs_checked=2,
                           actual_partial_counts='validated original producer/audit completion')
    need(len(encoded(wrapper)) <= 2048, 'outer output2048B reservation')
    return wrapper
