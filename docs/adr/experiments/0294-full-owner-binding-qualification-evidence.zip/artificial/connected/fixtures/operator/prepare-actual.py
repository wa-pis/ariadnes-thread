"""Prepare one full-owner episode; no admission, acquisition or native call."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
from typing import Any, Callable
import zipfile

REPO = Path('/Users/agrudin/dev/my/ariadna')
P = Path('/private/tmp/ariadna-f18-full-owner-v1')
MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
IMAGE = MOUNT.parent / 'scratch.sparseimage'
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
OPERATOR = Path('/private/tmp/ariadna-f18-0294/candidates/operators')
CHOICE: str | None = None
NATIVE_EXECUTION_STAGE: str | None = None
ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0294/artificial')
ARTIFICIAL_EXECUTION_STAGE = 'F18.24_ARTIFICIAL_ONLY'
QUALIFICATION_ARCHIVE_PIN: dict[str, object] | None = None
CONTRACT_SHA = '843a5a76f6c0ad4f01759960e4e2d8db8d14876367613fa38758c4c364cc9505'

CONTROL_NAMES = ('call-once.py', 'launch-once.py', 'native.sandbox',
                 'check-preservation.py', 'run-once.py', 'native-entry.py',
                 'supervisor-adapter.py', 'admission.py')
OPERATOR_NAMES = {'prepare-actual.py', 'invoke-once.py', 'review-actual.py', 'test-operator-wiring.py'}
LIMIT = 2097152


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read(path: Path, cap: int = 65536) -> bytes:
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory ancestor')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'regular bounded file required')
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        need(len(raw) == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns,
             'short/changed proof')
        return raw
    finally:
        os.close(fd)


def object_value(raw: bytes) -> dict[str, Any]:
    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in items:
            need(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    def invalid(value: str) -> None:
        raise RuntimeError('nonfinite JSON value: ' + value)
    result = json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    need(type(result) is dict, 'JSON object required')
    return result


def sync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def put(path: Path, value: object, *, raw: bool = False) -> None:
    data = value if raw else encoded(value)
    need(type(data) is bytes and len(data) <= 65536, 'record64KiB cap')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        offset = 0
        while offset < len(data):
            count = os.write(fd, data[offset:])
            need(0 < count <= len(data) - offset, 'record short write')
            offset += count
        os.fsync(fd)
    finally:
        os.close(fd)
    sync_dir(path.parent)


def aggregate(root: Path) -> int:
    total = logs = 0
    for path in root.rglob('*'):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        need(stat.S_ISREG(info.st_mode), 'nonregular evidence')
        total += info.st_size
        if path.suffix == '.log':
            logs += info.st_size
        need(total <= LIMIT and logs <= 65536, '2MiB total/64KiB logs cap')
    return total


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'module loader unavailable')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def command(argv: list[str], *, timeout: float = 30) -> bytes:
    result = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=timeout, check=False)
    need(len(result.stdout) + len(result.stderr) <= 65536, 'combined command64KiB log cap')
    need(result.returncode == 0, f'command refused: {argv[0]} exit{result.returncode}')
    return result.stdout


def git_base(base: str) -> None:
    need(re.fullmatch('[0-9a-f]{40}', base) is not None, 'explicit full base SHA required')
    need(command(['git', 'rev-parse', 'HEAD']).decode().strip() == base, 'HEAD differs from explicit base')
    need(command(['git', 'branch', '--show-current']).strip() == b'dev', 'dev required')
    need(not command(['git', 'status', '--porcelain']).strip(), 'clean checkout required')
    need(read(REPO / CHOICE) == command(['git', 'show', base + ':' + CHOICE]), 'committed authorization drift')


def operator_manifest(directory: Path | None = None) -> tuple[bytes, dict[str, Any]]:
    directory = OPERATOR if directory is None else directory
    raw = read(directory / 'operator-pins.json')
    result = object_value(raw)
    need(result['schema'] == 'ariadna.f18.full-owner-operator-pins.v1'
         and set(result['files']) == {str(directory / name) for name in OPERATOR_NAMES}, 'exact4 operator pins')
    for name, row in result['files'].items():
        data = read(Path(name))
        need(row == {'bytes': len(data), 'sha256': digest(data)}, 'operator source drift: ' + name)
    return raw, result


def require_native_choice() -> None:
    need(NATIVE_EXECUTION_STAGE is not None and CHOICE is not None
         and QUALIFICATION_ARCHIVE_PIN is not None,
         'distinct native user choice and frozen qualification proof are not available')


def material() -> tuple[bytes, dict[str, Any], dict[str, bytes], dict[str, Any]]:
    require_native_choice()
    raise RuntimeError('native qualification archive binding requires the separately reviewed future choice')


def check_resources(rows: list[dict[str, Any]], resources: Path, admission: Any,
                    tick: Callable[[], float]) -> None:
    names: set[str] = set()
    for root, directories, files in os.walk(resources, followlinks=False):
        tick()
        for name in directories + files:
            need(not (Path(root) / name).is_symlink(), 'resource symlink')
        names.update(str((Path(root) / name).relative_to(resources)) for name in files)
    need(len(rows) == 11 and names == {row['name'] for row in rows}, 'exact11 resource inventory')
    for row in rows:
        admission._pin(resources / row['name'], {k: row[k] for k in ('bytes', 'sha256')}, tick)


def _prepare_native(base: str) -> dict[str, Any]:
    require_native_choice()
    git_base(base)
    need(not os.path.lexists(P) and not os.path.ismount(MOUNT), 'occupied namespace or mount')
    manifest_raw, _ = operator_manifest()
    contract_raw, c, controls, reference = material()
    started = time.monotonic()  # Before the first new namespace write or mount.
    need(type(started) in (float, int) and math.isfinite(started), 'finite initial clock')
    P.mkdir()
    sync_dir(P.parent)
    mounted = False
    last = started

    def tick() -> float:
        nonlocal last
        now = time.monotonic()
        need(last <= now and 0 <= now - started < 600, 'original600s preflight exhausted')
        last = now
        return now - started

    def run(argv: list[str], limit: float = 30) -> bytes:
        result = command(argv, timeout=min(limit, 600 - tick()))
        tick()
        return result

    try:
        put(P / 'preflight-start.json', {'schema': 'ariadna.f18.full-owner-preflight-start.v1',
            'started_s': started, 'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'base_revision': base, 'retry_authorized': False})
        for name, raw in controls.items():
            put(P / name, raw, raw=True)
        put(P / 'binding-contract.json', contract_raw, raw=True)
        admission = load_module('_completed_actual_admission', P / 'admission.py')
        run([str(OUTER), '-I', '-B', str(P / 'check-preservation.py'), 'before'], 90)
        with (P / 'operational-before.json').open('rb') as stream:
            os.fsync(stream.fileno())
        sync_dir(P)
        operational_raw = read(P / 'operational-before.json')
        operational = object_value(operational_raw)
        need(operational['status'] == 'passed' and operational['manifest_equal'] is True
             and operational['differences'] == [] and operational['phase'] == 'before'
             and operational['baseline_file_sha256'] == '4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56',
             'operational preservation baseline differs')
        sources = admission._canonical_group(c['old_source_pins'], REPO)
        appended = admission._canonical_group(c['appended_source_pins'], REPO)
        need(not set(sources) & set(appended), 'duplicate source identity')
        sources.update(appended)
        need(len(sources) == 53 and len(c['native_pins']) == 10 and len(c['historical_ledger_pins']) == 25,
             'fixed53/10/25 pin counts')
        groups = {'source_pins': sources, 'native_pins': c['native_pins'],
                  'ledger_pins': c['historical_ledger_pins'],
                  'control_pins': {str(P / name): {'bytes': len(controls[name]), 'sha256': digest(controls[name])}
                                   for name in CONTROL_NAMES}}
        for group in ('source_pins', 'ledger_pins', 'control_pins'):
            for name, row in groups[group].items():
                admission._pin(Path(name), row, tick)
        run(['/usr/bin/hdiutil', 'attach', str(IMAGE), '-nobrowse', '-noautoopen',
             '-mountpoint', str(MOUNT), '-readonly'])
        mounted = True
        observation = admission._live_observation(MOUNT, IMAGE)
        need(observation['read_only'] is True and 0 < observation['capacity_bytes'] <= 8589934592,
             'retained mount must be read-only within8GiB')
        resources = MOUNT / 'home/.tudat/resource'
        rows = c['retained_resources']
        check_resources(rows, resources, admission, tick)
        for name, row in groups['native_pins'].items():
            admission._pin(Path(name), row, tick)
        history = {'path': str(REPO / c['reference_archive']['path']),
                   **{k: c['reference_archive'][k] for k in ('bytes', 'sha256')}}
        contract = {'path': str(P / 'binding-contract.json'), 'bytes': len(contract_raw), 'sha256': CONTRACT_SHA}
        gate = {'path': str(P / 'dispatch-once.py'), 'bytes': len(controls['dispatch-once.py']),
                'sha256': digest(controls['dispatch-once.py'])}
        outer_path = OUTER.resolve()
        outer_data = read(outer_path, 16 * 1024 * 1024)
        outer = {'path': str(outer_path), 'bytes': len(outer_data), 'sha256': digest(outer_data)}
        expected = dict(groups, resource_pins=rows, history_member_pins=c['historical_0280_member_pins'],
                        history_archive=history, contract=contract)
        decision = {'schema': 'ariadna.f18.full-owner-execution-decision.v1', 'stage': NATIVE_EXECUTION_STAGE,
            'mode': 'native', 'status': 'ADMITTED_ONCE', 'base_revision': base, 'contract_sha256': CONTRACT_SHA,
            'expected_pins': expected, 'outer_gate_pin': gate, 'outer_python_pin': outer}
        put(P / 'execution-decision-draft.json', dict(decision, status='PENDING_INDEPENDENT_REVIEW'))
        fixture_input = {'schema': 'ariadna-owner-fixture-input-v1', 'scope': 'synthetic-owner-conformance-only'}
        profile = {'schema': 'ariadna.f18.full-owner-control-profile.v1',
            'scope': 'synthetic-owner-conformance-only', 'mode': 'native', 'repo': str(REPO),
            'base_revision': base, 'root': str(P), 'work_directory': str(P / 'execution'),
            'preflight_started_s': started, 'outer_python': outer, 'private_python': reference['private_python'],
            'environment': reference['environment'], 'sandbox_profile': str(P / 'native.sandbox'), **groups,
            'resource_pins': rows, 'resource_directory': str(resources), 'image': str(IMAGE), 'mount': str(MOUNT),
            'history_archive': history, 'history_member_pins': c['historical_0280_member_pins'],
            'outer_gate': gate, 'contract': contract, 'kernel_sha256': reference['kernel_sha256'], 'fixture_input': fixture_input,
            'prelaunch_admission': str(P / 'launch-admission.json'),
            'execution_decision': {'path': str(P / 'execution-decision.json'),
                                   'bytes': len(encoded(decision)), 'sha256': digest(encoded(decision))}}
        for field, name in {'entry_sha256': 'native-entry.py', 'launch_sha256': 'launch-once.py',
            'caller_sha256': 'call-once.py', 'adapter_sha256': 'supervisor-adapter.py',
            'sandbox_sha256': 'native.sandbox'}.items():
            profile[field] = groups['control_pins'][str(P / name)]['sha256']
        need(set(profile) == admission.PROFILE_KEYS and fixture_input == admission.FIXTURE_INPUT, 'exact completed wire shape')
        put(P / 'profile.json', profile)
        operator_manifest()
        ready = {'schema': 'ariadna.f18.full-owner-operator-preflight.v1',
            'status': 'READY_FOR_INDEPENDENT_REVIEW', 'started_s': started, 'elapsed_s': tick(),
            'base_revision': base, 'profile_sha256': digest(encoded(profile)),
            'execution_decision_sha256': digest(encoded(decision)), 'operator_manifest_sha256': digest(manifest_raw),
            'auth_choice_sha256': digest(read(REPO / CHOICE)), 'operational_sha256': digest(operational_raw),
            'group_counts': {**{k: len(v) for k, v in groups.items()},
                'resource_pins': len(rows), 'history_member_pins': len(c['historical_0280_member_pins'])}, 'resources': len(rows),
            'resource_bytes': sum(row['bytes'] for row in rows), 'live_observation': observation}
        put(P / 'operator-preflight.json', ready)
        aggregate(P)
        elapsed = tick()
        return {'status': ready['status'], 'elapsed_s_after_ready_fsync': elapsed,
                'remaining_preflight_s': 600 - elapsed, 'namespace': str(P)}
    except BaseException as exc:
        try:
            put(P / 'operator-preflight-failure.json', {'status': 'FAILED_NO_RETRY',
                'error_type': type(exc).__name__, 'message': str(exc)[:2048], 'started_s': started,
                'elapsed_s': time.monotonic() - started})
        finally:
            if mounted or os.path.ismount(MOUNT):
                result = subprocess.run(['/usr/bin/hdiutil', 'detach', str(MOUNT)],
                                        capture_output=True, timeout=30, check=False)
                put(P / 'failed-preflight-detach.json', {'returncode': result.returncode,
                    'unmounted': not os.path.ismount(MOUNT), 'postpacket': True})
        raise


def artificial_path(path: Path) -> None:
    need(path.is_absolute() and '..' not in path.parts and path.is_relative_to(ARTIFICIAL_ROOT)
         and path != ARTIFICIAL_ROOT, 'fixed artificial prefix required')
    for parent in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(parent.lstat().st_mode), 'artificial symlink/non-directory ancestor')
    if os.path.lexists(path):
        need(not path.is_symlink(), 'artificial symlink forbidden')


def prepare(base: str, *, artificial_root: Path | None = None,
            artificial_material: tuple[bytes, dict[str, Any], dict[str, bytes], dict[str, Any]] | None = None,
            artificial_observer: Callable[[Path, Path], dict[str, object]] | None = None,
            artificial_command: Callable[..., bytes] | None = None) -> dict[str, Any]:
    """Prepare native only with future choice, or an explicitly harmless fake episode."""
    if artificial_root is None:
        need(artificial_material is None and artificial_observer is None and artificial_command is None,
             'native artificial overrides forbidden before live reads')
        return _prepare_native(base)
    need(artificial_material is not None and callable(artificial_observer) and callable(artificial_command),
         'all explicit harmless preparation inputs required')
    need(type(base) is str and re.fullmatch('[0-9a-f]{40}', base) is not None, 'full artificial base label required')
    root = artificial_root
    artificial_path(root)
    need(not os.path.lexists(root), 'occupied artificial episode')
    contract_raw, c, controls, reference = artificial_material
    need(type(contract_raw) is bytes and len(contract_raw) <= 65536 and object_value(contract_raw) == c
         and c['schema'] == 'ariadna.f18.full-owner-control-mapping.v1'
         and c.get('qualification') == 'ARTIFICIAL', 'bounded fabricated mapping required')
    need(set(controls) == set(CONTROL_NAMES) | {'dispatch-once.py'}, 'exact eight controls plus external gate')
    repo, mount, image, resources = (Path(reference[name]) for name in ('repo', 'mount', 'image', 'resource_directory'))
    for path in (repo, mount, image, resources):
        artificial_path(path)
    operator_directory = Path(reference['operator_directory'])
    artificial_path(operator_directory)
    need(Path(reference['manifest_path']) == operator_directory / 'operator-pins.json', 'fixed operator manifest path')
    manifest_raw, _ = operator_manifest(operator_directory)
    started = time.monotonic()  # Before first episode write; no real mount is attempted.
    root.mkdir()
    sync_dir(root.parent)
    last = started
    def tick() -> float:
        nonlocal last
        now = time.monotonic()
        need(last <= now and 0 <= now - started < 600, 'original600s artificial preflight exhausted')
        last = now
        return now - started
    put(root / 'preflight-start.json', {'schema': 'ariadna.f18.full-owner-preflight-start.v1',
        'started_s': started, 'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'base_revision': base, 'retry_authorized': False})
    for name, raw in controls.items():
        put(root / name, raw, raw=True)
    put(root / 'binding-contract.json', contract_raw, raw=True)
    admission = load_module('_full_owner_artificial_admission_prepare', root / 'admission.py')
    sources = admission._canonical_group(c['old_source_pins'], repo)
    appended = admission._canonical_group(c['appended_source_pins'], repo)
    need(not set(sources) & set(appended) and len(sources) == 49 and len(appended) == 4, 'fixed disjoint49+4 cohort')
    sources.update(appended)
    groups = {'source_pins': sources, 'native_pins': c['native_pins'], 'ledger_pins': c['historical_ledger_pins'],
        'control_pins': {str(root / name): {'bytes': len(controls[name]), 'sha256': digest(controls[name])}
                         for name in CONTROL_NAMES}}
    need(len(sources) == 53 and len(groups['native_pins']) == 10 and len(groups['ledger_pins']) == 25,
         'fixed artificial53/10/25 metadata counts')
    for group in ('source_pins', 'native_pins', 'ledger_pins'):
        for name, row in groups[group].items():
            artificial_path(Path(name))
            admission._pin(Path(name), row, tick)
    check_resources(c['retained_resources'], resources, admission, tick)
    outer = reference['outer_python']
    outer_path, outer_pin = admission._path_pin(outer)
    need(outer_path == OUTER.resolve(), 'actual pinned outer interpreter required')
    admission._pin(outer_path, outer_pin, tick)
    need(reference['private_python'] == str(outer_path), 'harmless artificial interpreter required')
    history = c['reference_archive']
    history = {'path': str(Path(history['path']) if Path(history['path']).is_absolute() else repo / history['path']),
               **{k: history[k] for k in ('bytes', 'sha256')}}
    artificial_path(Path(history['path']))
    contract = {'path': str(root / 'binding-contract.json'), 'bytes': len(contract_raw), 'sha256': digest(contract_raw)}
    gate = {'path': str(root / 'dispatch-once.py'), 'bytes': len(controls['dispatch-once.py']), 'sha256': digest(controls['dispatch-once.py'])}
    expected = dict(groups, resource_pins=c['retained_resources'], history_member_pins=c['historical_0280_member_pins'],
                    history_archive=history, contract=contract)
    decision = {'schema': 'ariadna.f18.full-owner-execution-decision.v1', 'stage': ARTIFICIAL_EXECUTION_STAGE,
        'mode': 'artificial', 'status': 'ARTIFICIAL_EXECUTION_DECISION', 'base_revision': base,
        'contract_sha256': contract['sha256'], 'expected_pins': expected, 'outer_gate_pin': gate, 'outer_python_pin': outer}
    put(root / 'execution-decision-draft.json', dict(decision, status='PENDING_INDEPENDENT_REVIEW'))
    profile = {'schema': 'ariadna.f18.full-owner-control-profile.v1', 'scope': 'synthetic-owner-conformance-only',
        'mode': 'artificial', 'repo': str(repo), 'base_revision': base, 'root': str(root),
        'work_directory': str(root / 'execution'), 'preflight_started_s': started,
        'outer_python': outer, 'private_python': reference['private_python'], 'environment': reference['environment'],
        'sandbox_profile': str(root / 'native.sandbox'), **groups, 'resource_pins': c['retained_resources'],
        'resource_directory': str(resources), 'image': str(image), 'mount': str(mount),
        'history_archive': history, 'history_member_pins': c['historical_0280_member_pins'], 'outer_gate': gate,
        'contract': contract, 'kernel_sha256': reference['kernel_sha256'], 'fixture_input': admission.FIXTURE_INPUT,
        'prelaunch_admission': str(root / 'launch-admission.json'),
        'execution_decision': {'path': str(root / 'execution-decision.json'), 'bytes': len(encoded(decision)), 'sha256': digest(encoded(decision))}}
    for field, name in {'entry_sha256': 'native-entry.py', 'launch_sha256': 'launch-once.py',
        'caller_sha256': 'call-once.py', 'adapter_sha256': 'supervisor-adapter.py', 'sandbox_sha256': 'native.sandbox'}.items():
        profile[field] = groups['control_pins'][str(root / name)]['sha256']
    need(set(profile) == admission.PROFILE_KEYS, 'exact full-owner profile shape')
    put(root / 'profile.json', profile)
    admission._history(profile, c, tick)
    output = artificial_command([outer['path'], '-I', '-B', str(root / 'check-preservation.py'), 'before'], timeout=min(90, 600 - tick()))
    need(type(output) is bytes and len(output) <= 65536, 'bounded artificial command output')
    with (root / 'operational-before.json').open('rb') as stream:
        os.fsync(stream.fileno())
    sync_dir(root)
    operational_raw = read(root / 'operational-before.json')
    operational = object_value(operational_raw)
    need(operational.get('schema') == 'ariadna.f18.operational-preservation.v1'
         and operational.get('status') == 'ARTIFICIAL_READY' and operational.get('phase') == 'before'
         and operational.get('native_authority') is False and operational.get('manifest_equal') is True
         and operational.get('differences') == [], 'honest artificial operational metadata required')
    observation = artificial_observer(image, mount)
    need(type(observation) is dict and set(observation) == {'image', 'mount', 'read_only', 'capacity_bytes'}
         and observation['image'] == str(image) and observation['mount'] == str(mount)
         and observation['read_only'] is True and type(observation['capacity_bytes']) is int
         and 0 < observation['capacity_bytes'] <= 8589934592, 'explicit harmless readonly observation')
    ready = {'schema': 'ariadna.f18.full-owner-operator-preflight.v1',
        'status': 'ARTIFICIAL_READY_FOR_INDEPENDENT_REVIEW', 'started_s': started, 'elapsed_s': tick(),
        'base_revision': base, 'profile_sha256': digest(encoded(profile)), 'execution_decision_sha256': digest(encoded(decision)),
        'operator_manifest_sha256': digest(manifest_raw), 'auth_choice_sha256': None,
        'operational_sha256': digest(operational_raw), 'group_counts': {**{k: len(v) for k, v in groups.items()},
            'resource_pins': len(c['retained_resources']), 'history_member_pins': len(c['historical_0280_member_pins'])},
        'resources': 11, 'resource_bytes': sum(row['bytes'] for row in c['retained_resources']), 'live_observation': observation}
    put(root / 'operator-preflight.json', ready)
    aggregate(root)
    elapsed = tick()
    return {'status': ready['status'], 'namespace': str(root), 'elapsed_s_after_ready_fsync': elapsed,
            'remaining_preflight_s': 600 - elapsed, 'native_authority': False}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.base), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
