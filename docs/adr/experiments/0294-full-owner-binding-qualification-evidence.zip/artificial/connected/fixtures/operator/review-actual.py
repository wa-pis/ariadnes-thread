"""Independent F18.24 artificial readback; never admit, seal a decision, or launch a child."""
from __future__ import annotations

import argparse
from collections.abc import Callable
import datetime
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
from types import ModuleType
import zipfile

REPO = Path('/Users/agrudin/dev/my/ariadna')
LIVE_ROOT = Path('/private/tmp/ariadna-f18-full-owner-v1')
ROOT = LIVE_ROOT
PREP = Path('/private/tmp/ariadna-f18-0294/candidates/operators')
ARTIFICIAL_ROOT = Path('/private/tmp/ariadna-f18-0294/artificial')
MOUNT = Path('/private/tmp/ariadna-f17-0263/volume')
IMAGE = Path('/private/tmp/ariadna-f17-0263/scratch.sparseimage')
OUTER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python')
CONTRACT_SHA = '843a5a76f6c0ad4f01759960e4e2d8db8d14876367613fa38758c4c364cc9505'
ADMISSION_PIN = {'bytes': 19777, 'sha256': '8d725e32e15edc277c50b6b18b5bfea114f01c658e326635121259c5ac195e57'}
QUALIFIED_PIN = None  # Future native qualification is explicitly deferred.
CHOICE: Path | None = None
NATIVE_EXECUTION_STAGE: str | None = None
AUTHORITY: Path | None = None
CHOICE_SHA = None  # Consumed prior choices are not full-owner authority.
BASELINE_SHA = '4325cbeddd8d05604fc95b46520520f0a001c3a7af716bec2b58897bcc94cc56'
KERNEL_SHA = '04f7af4c8429c09aec9a21f50888e7e4a979e69184e8abc530e17e88e4cb4941'
OPERATORS = {'prepare-actual.py', 'invoke-once.py', 'review-actual.py', 'test-operator-wiring.py'}
DECISION_KEYS = set('schema stage mode status base_revision contract_sha256 expected_pins outer_gate_pin outer_python_pin'.split())
GROUP_KEYS = set('source_pins native_pins resource_pins ledger_pins history_member_pins control_pins history_archive contract'.split())


class ReviewError(RuntimeError):
    """A prerequisite is missing, changed, unqualified, or outside its clock."""


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ReviewError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _bootstrap_read(path: Path, cap: int = 65536) -> bytes:
    for directory in [*reversed(path.parent.parents), path.parent]:
        need(stat.S_ISDIR(directory.lstat().st_mode), 'bootstrap symlink/non-directory')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= cap, 'bootstrap size/type')
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        need(len(raw) == before.st_size and not os.read(fd, 1)
             and before.st_mtime_ns == after.st_mtime_ns and before.st_size == after.st_size,
             'bootstrap changed/short proof')
        return raw
    finally:
        os.close(fd)


def _clean_git(base: str, tick: Callable[[], float]) -> None:
    for args, expected in ((['rev-parse', 'HEAD'], base), (['branch', '--show-current'], 'dev'),
                           (['status', '--porcelain'], '')):
        output = subprocess.check_output(['git', *args], cwd=REPO,
                                         timeout=min(10, 600 - tick()))
        need(len(output) <= 65536 and output.decode().strip() == expected, 'clean committed dev/base')
        tick()


def _committed_authority(base: str, helper: ModuleType, tick: Callable[[], float]) -> str:
    for relative in (CHOICE, AUTHORITY):
        current = helper._read(REPO / relative)
        committed = subprocess.check_output(['git', 'show', base + ':' + str(relative)], cwd=REPO,
                                            timeout=min(10, 600 - tick()))
        need(len(committed) <= 65536 and committed == current, 'committed distinct choice/ADR')
        tick()
    choice_raw = helper._read(REPO / CHOICE)
    choice = helper._object(choice_raw)
    need(sha(choice_raw) == CHOICE_SHA
         and choice['schema'] == 'ariadna.f18.full-owner-owner-user-choice.v1'
         and choice['stage'] == NATIVE_EXECUTION_STAGE and choice['decision'] == 'AUTHORIZE_ONE_CONDITIONAL_EPISODE'
         and choice['user_reply'] == 'разрешаю' and choice['automatic_retry_authorized'] is False
         and choice['execution_status'] == 'NOT_STARTED'
         and choice['qualification_archive'] == dict(QUALIFIED_PIN,
                 path='docs/adr/experiments/0284-completed-control-qualification-evidence.zip'),
         'exact distinct user choice')
    return sha(choice_raw)


def review(base: str, *, artificial_root: Path | None = None,
           artificial_reference: dict[str, object] | None = None,
           artificial_observer: Callable[[Path, Path], dict[str, object]] | None = None) -> dict[str, object]:
    """Independently read back an explicitly artificial episode; native is deferred."""
    if artificial_root is None:
        need(artificial_reference is None and artificial_observer is None,
             'native artificial overrides forbidden before live reads')
        raise ReviewError('distinct native choice and full-owner qualification are deferred')
    need(type(base) is str and re.fullmatch('[0-9a-f]{40}', base) is not None, 'full artificial base label')
    need(type(artificial_reference) is dict and callable(artificial_observer), 'explicit harmless reviewer inputs')
    artificial = True
    ROOT = artificial_root
    need(ROOT.is_absolute() and '..' not in ROOT.parts and ROOT.is_relative_to(ARTIFICIAL_ROOT)
         and ROOT != ARTIFICIAL_ROOT, 'fixed artificial reviewer namespace')
    REPO = Path(artificial_reference['repo'])
    PREP = Path(artificial_reference['operator_directory'])
    need(all(path.is_absolute() and path.is_relative_to(ARTIFICIAL_ROOT) and '..' not in path.parts
             for path in (REPO, PREP)), 'fixed harmless reference paths')
    output = ROOT / 'independent-preflight-review.json'
    need(not os.path.lexists(output), 'independent review already consumed')
    start_raw = _bootstrap_read(ROOT / 'preflight-start.json')
    provisional = json.loads(start_raw)
    started = provisional['started_s']
    need(type(started) in (int, float) and math.isfinite(started), 'finite original preflight clock')
    last = started

    def tick() -> float:
        nonlocal last
        current = time.monotonic()
        need(last <= current and 0 <= current - started < 600, 'original strict600s clock')
        last = current
        return current - started

    tick()
    raw = _bootstrap_read(ROOT / 'admission.py')
    need({'bytes': len(raw), 'sha256': sha(raw)} == ADMISSION_PIN, 'qualified admission helper bytes')
    helper = ModuleType('_completed_independent_readback_primitives')
    helper.__file__ = str(ROOT / 'admission.py')
    exec(compile(raw, helper.__file__, 'exec'), helper.__dict__)
    tick()
    start = helper._object(start_raw)
    need(set(start) == {'schema', 'started_s', 'checked_utc', 'base_revision', 'retry_authorized'}
         and start['schema'] == 'ariadna.f18.full-owner-preflight-start.v1'
         and start['base_revision'] == base and start['retry_authorized'] is False,
         'exact fresh original preflight record')
    choice_sha = None  # Honest artificial provenance, never a user/native authority.
    candidates = Path('/private/tmp/ariadna-f18-0294/candidates')
    controls_raw = {name: helper._read(candidates / 'controls' / name)
                    for name in helper.CONTROL_NAMES}
    controls_raw['dispatch-once.py'] = helper._read(candidates / 'dispatch-once.py')
    controls = {str(ROOT / name): {'bytes': len(data), 'sha256': sha(data)}
                for name, data in controls_raw.items() if name != 'dispatch-once.py'}
    profile_raw = helper._read(ROOT / 'profile.json')
    profile = helper._object(profile_raw)
    need(set(profile) == helper.PROFILE_KEYS
         and profile['schema'] == 'ariadna.f18.full-owner-control-profile.v1'
         and profile['scope'] == 'synthetic-owner-conformance-only'
         and profile['mode'] == ('artificial' if artificial else 'native'), 'exact completed profile/mode')
    need(profile['root'] == str(ROOT) and profile['repo'] == str(REPO)
         and profile['base_revision'] == base and profile['preflight_started_s'] == started
         and profile['work_directory'] == str(ROOT / 'execution')
         and profile['sandbox_profile'] == str(ROOT / 'native.sandbox')
         and profile['prelaunch_admission'] == str(ROOT / 'launch-admission.json'), 'fixed profile namespaces/base/clock')
    contract_path, contract_pin = helper._path_pin(profile['contract'])
    need(contract_path == ROOT / 'binding-contract.json', 'fixed copied mapping path')
    helper._pin(contract_path, contract_pin, tick)
    contract_raw = helper._read(contract_path)
    contract = helper._object(contract_raw)
    need(contract['schema'] == 'ariadna.f18.full-owner-control-mapping.v1', 'mapping-v2 schema')
    if artificial:
        need(contract.get('qualification') == 'ARTIFICIAL', 'fabricated mapping label required')
    else:
        need(contract_pin['sha256'] == CONTRACT_SHA and contract.get('qualification') is None
             and profile['mount'] == str(MOUNT) and profile['image'] == str(IMAGE)
             and profile['resource_directory'] == str(MOUNT / 'home/.tudat/resource'), 'immutable actual mapping/retained paths')
        need(contract['limits']['new_acquisition_bytes'] == 0
             and contract['limits']['historical_carried_acquisition_bytes'] == 500624382
             and contract['limits']['acquisition_ceiling_bytes'] == 2147483648,
             'unchanged retained acquisition accounting')
    draft_raw = helper._read(ROOT / 'execution-decision-draft.json')
    draft = helper._object(draft_raw)
    need(set(draft) == DECISION_KEYS and draft['schema'] == 'ariadna.f18.full-owner-execution-decision.v1'
         and draft['stage'] == 'F18.24_ARTIFICIAL_ONLY' and draft['mode'] == profile['mode']
         and draft['status'] == 'PENDING_INDEPENDENT_REVIEW' and draft['base_revision'] == base
         and draft['contract_sha256'] == contract_pin['sha256'], 'exact pending decision')
    prospective_raw = encoded(dict(draft, status='ARTIFICIAL_EXECUTION_DECISION'))
    decision_sha = sha(prospective_raw)
    need(profile['execution_decision'] == {'path': str(ROOT / 'execution-decision.json'),
                                         'bytes': len(prospective_raw), 'sha256': decision_sha},
         'prospective final decision pin; never write decision here')
    for name in ('execution-decision.json', 'independent-review-observation.json', 'operator-seal.json', 'outer-dispatch.json',
                 'gate-start.json', 'admission-check.json', 'launch-admission.json', 'episode-start.json', 'execution'):
        need(not os.path.lexists(ROOT / name), 'premature/consumed record: ' + name)
    groups = draft['expected_pins']
    need(type(groups) is dict and set(groups) == GROUP_KEYS, 'exact eight decision groups')
    need(all(encoded(groups[name]) == encoded(profile[name]) for name in GROUP_KEYS), 'decision/profile group bindings')
    expected_source = helper._canonical_group(contract['old_source_pins'] | contract['appended_source_pins'], REPO)
    need(len(contract['old_source_pins']) == 49 and len(contract['appended_source_pins']) == 4
         and len(expected_source) == 53, 'exact49+4 source mapping')
    for field, expected, count in (('source_pins', expected_source, 53),
                                    ('native_pins', contract['native_pins'], 10),
                                    ('ledger_pins', contract['historical_ledger_pins'], 25)):
        pins = helper._canonical_group(profile[field], REPO)
        need(len(pins) == count and encoded(pins) == encoded(helper._canonical_group(expected, REPO)),
             'exact pinned group: ' + field)
        for path, pin in pins.items():
            if artificial:
                need(Path(path).is_relative_to(ARTIFICIAL_ROOT), 'fake pin escaped fake prefix')
            helper._pin(Path(path), pin, tick)
    history_path, history_pin = helper._path_pin(profile['history_archive'])
    need(history_pin == {k: contract['reference_archive'][k] for k in ('bytes', 'sha256')},
         'original historical archive identity')
    need(history_path.is_relative_to(ARTIFICIAL_ROOT) if artificial
         else history_path == REPO / contract['reference_archive']['path'], 'historical archive path')
    helper._pin(history_path, history_pin, tick)
    history_raw = helper._read(history_path, 2097152)
    members = profile['history_member_pins']
    need(type(members) is dict and len(members) == 86
         and encoded(members) == encoded(contract['historical_0280_member_pins']), 'exact86 historical member pins')
    with zipfile.ZipFile(io.BytesIO(history_raw)) as packet:
        names = packet.namelist()
        need(len(names) == len(set(names)) == 86 and set(names) == set(members), 'independent exact86 archive inventory')
        expanded = 0
        for name, pin in members.items():
            need(type(name) is str and not Path(name).is_absolute() and '..' not in Path(name).parts,
                 'relative historical member name')
            helper._pin_shape(pin)
            expanded += pin['bytes']
            need(expanded <= 2097152 and packet.getinfo(name).file_size == pin['bytes'], 'historical expanded cap')
            data = packet.read(name)
            need({'bytes': len(data), 'sha256': sha(data)} == pin, 'independent history member drift: ' + name)
            tick()
        history = helper._object(packet.read('profile.json')) if not artificial else {}
    if artificial:
        need(profile['environment'] == contract['environment_unchanged']
             and profile['private_python'] == profile['outer_python']['path'], 'explicit harmless fake environment')
    else:
        need(profile['environment'] == history['environment'] and profile['private_python'] == history['private_python']
             and profile['private_python'] == str(MOUNT / 'env/bin/python')
             and profile['kernel_sha256'] == history['kernel_sha256'] == KERNEL_SHA,
             'retained environment/private interpreter/kernel')
        need(contract['reference_profile_pin'] == contract['historical_0280_member_pins']['profile.json'],
             'retained historical profile pin')
    need(encoded(profile['control_pins']) == encoded(controls) and len(controls) == 8, 'qualified eight active controls')
    for name, pin in controls.items():
        helper._pin(Path(name), pin, tick)
    for field, name in (('entry_sha256', 'native-entry.py'), ('adapter_sha256', 'supervisor-adapter.py'),
                        ('launch_sha256', 'launch-once.py'), ('caller_sha256', 'call-once.py'),
                        ('sandbox_sha256', 'native.sandbox')):
        need(profile[field] == controls[str(ROOT / name)]['sha256'], 'qualified control binding: ' + field)
    gate = controls_raw['dispatch-once.py']
    gate_pin = {'path': str(ROOT / 'dispatch-once.py'), 'bytes': len(gate), 'sha256': sha(gate)}
    need(profile['outer_gate'] == draft['outer_gate_pin'] == gate_pin, 'separate qualified external gate')
    helper._pin(ROOT / 'dispatch-once.py', {k: gate_pin[k] for k in ('bytes', 'sha256')}, tick)
    outer_path, outer_pin = helper._path_pin(profile['outer_python'])
    need(profile['outer_python'] == draft['outer_python_pin']
         and outer_path == OUTER.resolve() == Path(sys.executable).resolve(), 'pinned actual outer interpreter')
    helper._pin(outer_path, outer_pin, tick)
    manifest_raw = helper._read(PREP / 'operator-pins.json')
    manifest = helper._object(manifest_raw)
    need(set(manifest) == {'schema', 'files'} and manifest['schema'] == 'ariadna.f18.full-owner-operator-pins.v1'
         and type(manifest['files']) is dict
         and set(manifest['files']) == {str(PREP / name) for name in OPERATORS}, 'qualified four operator manifest')
    for path, pin in manifest['files'].items():
        helper._pin(Path(path), pin, tick)
    need(sha(helper._read(Path(__file__))) == manifest['files'][str(PREP / 'review-actual.py')]['sha256'],
         'loaded reviewer bound to qualified operator source')
    resources = Path(profile['resource_directory'])
    rows = profile['resource_pins']
    need(type(rows) is list and len(rows) == 11 and encoded(rows) == encoded(contract['retained_resources']), 'exact11 retained resource rows')
    if artificial:
        need(all(Path(profile[field]).is_relative_to(ARTIFICIAL_ROOT)
                 for field in ('resource_directory', 'mount', 'image')), 'fake retained paths escaped fake tree')
    helper._directory(resources)
    names: set[str] = set()
    for row in rows:
        need(type(row) is dict and set(row) == {'name', 'bytes', 'sha256'} and type(row['name']) is str,
             'exact resource pin row')
        name = Path(row['name'])
        need(not name.is_absolute() and '..' not in name.parts and str(name) not in names, 'relative unique resource')
        names.add(str(name))
        helper._pin(resources / name, {k: row[k] for k in ('bytes', 'sha256')}, tick)
    actual: set[str] = set()
    for directory, dirs, files in os.walk(resources, followlinks=False):
        need(all(not (Path(directory) / name).is_symlink() for name in dirs), 'resource directory symlink')
        actual.update(str((Path(directory) / name).relative_to(resources)) for name in files)
        tick()
    need(actual == names, 'exact retained resource inventory')
    need(profile['fixture_input'] == {'schema': 'ariadna-owner-fixture-input-v1',
                                      'scope': 'synthetic-owner-conformance-only'}, 'original two-key fixture input')
    kernel_path = contract['artificial_kernel_path']
    need(kernel_path in profile['native_pins']
         and profile['native_pins'][kernel_path]['sha256'] == profile['kernel_sha256'], 'pinned retained kernel')
    observation = (artificial_observer(Path(profile['image']), Path(profile['mount'])) if artificial_observer is not None
                   else helper._live_observation(MOUNT, IMAGE))
    need(type(observation) is dict and set(observation) == {'image', 'mount', 'read_only', 'capacity_bytes'}
         and observation['image'] == profile['image'] and observation['mount'] == profile['mount']
         and observation['read_only'] is True and type(observation['capacity_bytes']) is int
         and 0 < observation['capacity_bytes'] <= 8589934592, 'fresh independent readonly observation')
    operational_raw = helper._read(ROOT / 'operational-before.json')
    operational = helper._object(operational_raw)
    need(operational['schema'] == 'ariadna.f18.operational-preservation.v1' and operational['phase'] == 'before'
         and operational['status'] == 'ARTIFICIAL_READY' and operational.get('native_authority') is False and operational['manifest_equal'] is True
         and operational['differences'] == [],
         'durable unchanged operational-before record')
    ready_raw = helper._read(ROOT / 'operator-preflight.json')
    ready = helper._object(ready_raw)
    need(set(ready) == set('schema status started_s elapsed_s base_revision profile_sha256 execution_decision_sha256 operator_manifest_sha256 auth_choice_sha256 operational_sha256 group_counts resources resource_bytes live_observation'.split())
         and ready['schema'] == 'ariadna.f18.full-owner-operator-preflight.v1'
         and ready['status'] == 'ARTIFICIAL_READY_FOR_INDEPENDENT_REVIEW' and ready['started_s'] == started
         and ready['base_revision'] == base and ready['profile_sha256'] == sha(profile_raw)
         and ready['execution_decision_sha256'] == decision_sha
         and ready['operator_manifest_sha256'] == sha(manifest_raw) and ready['auth_choice_sha256'] == choice_sha
         and ready['operational_sha256'] == sha(operational_raw) and encoded(ready['live_observation']) == encoded(observation)
         and ready['resources'] == 11 and ready['resource_bytes'] == sum(row['bytes'] for row in rows),
         'fresh prepare READY binding')
    need(type(ready['elapsed_s']) in (int, float) and math.isfinite(ready['elapsed_s'])
         and 0 <= ready['elapsed_s'] <= tick(), 'original READY elapsed clock')
    for path, data in ((ROOT / 'profile.json', profile_raw), (ROOT / 'execution-decision-draft.json', draft_raw),
                       (ROOT / 'preflight-start.json', start_raw), (contract_path, contract_raw),
                       (ROOT / 'operator-preflight.json', ready_raw), (ROOT / 'operational-before.json', operational_raw),
                       (PREP / 'operator-pins.json', manifest_raw)):
        need(helper._read(path) == data, 'readback changed during review: ' + path.name)
        tick()
    aggregate = 0
    for directory, dirs, files in os.walk(ROOT, followlinks=False):
        need(all(not (Path(directory) / name).is_symlink() for name in dirs), 'episode symlink directory')
        for name in files:
            info = (Path(directory) / name).lstat()
            need(stat.S_ISREG(info.st_mode), 'episode nonregular evidence')
            aggregate += info.st_size
        tick()
    need(aggregate < 2097152 - 16384, 'aggregate reserve before review')
    counts = {'source_pins': 53, 'native_pins': 10, 'resource_pins': 11, 'ledger_pins': 25,
              'history_member_pins': 86, 'control_pins': 8}
    need(encoded(ready['group_counts']) == encoded(counts), 'READY exact pin counts')
    record: dict[str, object] = {'schema': 'ariadna.f18.full-owner-independent-preflight-review.v1',
        'status': 'PENDING_DURABLE_REVIEW', 'started_s': started, 'elapsed_s': tick(), 'base_revision': base,
        'profile_sha256': sha(profile_raw), 'execution_decision_sha256': decision_sha,
        'operator_manifest_sha256': sha(manifest_raw), 'auth_choice_sha256': choice_sha,
        'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'group_counts': counts,
        'resources': 11, 'resource_bytes': sum(row['bytes'] for row in rows), 'read_only_observation': observation,
        'aggregate_bytes_before_review': aggregate, 'native_calls': 0, 'live_decision_written': False,
        'profile_modified': False, 'completion_requires_successful_reviewer_return': True,
        'physical_admission': 'unavailable', 'mode': profile['mode'], 'native_authority': False}
    record_raw = helper._write(output, record)
    need(helper._read(output) == record_raw, 'pending review changed after file/directory fsync')
    elapsed = tick()
    return {'status': 'PASS_INDEPENDENT_REVIEW', 'started_s': started, 'elapsed_s_after_review_fsync': elapsed,
            'remaining_preflight_s': 600 - elapsed, 'base_revision': base, 'review_sha256': sha(record_raw),
            'profile_sha256': sha(profile_raw), 'execution_decision_sha256': decision_sha,
            'operator_manifest_sha256': sha(manifest_raw), 'auth_choice_sha256': choice_sha,
            'mode': profile['mode'], 'native_calls': 0, 'live_decision_written': False, 'native_authority': False}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', required=True)
    args = parser.parse_args()
    try:
        result = review(args.base)
    except (RuntimeError, OSError, ValueError, TypeError, KeyError, OverflowError,
            subprocess.SubprocessError, zipfile.BadZipFile) as exc:
        print(json.dumps({'status': 'REFUSED_INDEPENDENT_REVIEW', 'reason': str(exc),
                          'live_decision_written': False}), flush=True)
        return 2
    print(json.dumps(result, sort_keys=True, allow_nan=False), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
