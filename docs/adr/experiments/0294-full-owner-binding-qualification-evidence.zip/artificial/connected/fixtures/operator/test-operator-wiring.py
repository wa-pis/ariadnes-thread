"""F18.24 one bounded artificial qualification of the fixed full-owner bindings."""
from __future__ import annotations

import argparse
import ast
import copy
import datetime
import hashlib
import importlib.abc
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
from types import SimpleNamespace
from typing import Any
import unittest

ROOT = Path('/private/tmp/ariadna-f18-0294')
CANDIDATES = ROOT / 'candidates'
ARTIFICIAL = ROOT / 'artificial'
REPO = Path('/Users/agrudin/dev/my/ariadna')
BASE = 'd2f37e724b4a36751c39cd62fc9931dca38e651f'
KNOWN_INTERPRETER = Path('/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python3.12')
KNOWN_INTERPRETER_BYTES = 6829984
KNOWN_INTERPRETER_SHA = '795d8316b7dabff1c64e56d5f5787caf0fe1b1e18580d34fc3a4956d501475c2'
INPUT = {'schema': 'ariadna-owner-fixture-input-v1', 'scope': 'synthetic-owner-conformance-only'}
FORBIDDEN = ('tudatpy', 'numpy', 'scipy', 'spiceypy')
STATE: dict[str, Any] = {}


def need(ok: bool, message: str) -> None:
    if not ok:
        raise RuntimeError(message)


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def read(path: Path, cap: int = 2097152) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        need(stat.S_ISREG(info.st_mode) and 0 <= info.st_size <= cap, 'bounded regular evidence/source file')
        raw = os.read(fd, cap + 1)
        need(len(raw) == info.st_size and not os.read(fd, 1), 'short evidence read')
        return raw
    finally:
        os.close(fd)


def pin(path: Path) -> dict[str, object]:
    raw = read(path)
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def path_pin(path: Path) -> dict[str, object]:
    return {'path': str(path), **pin(path)}


def put(path: Path, value: object, *, raw: bool = False, cap: int = 65536) -> None:
    data = value if raw else encoded(value)
    need(type(data) is bytes and len(data) <= cap, 'bounded artificial evidence')
    with path.open('xb') as stream:
        need(stream.write(data) == len(data), 'short artificial write')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def load(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, 'fixed module loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def select(path: Path, names: set[str], namespace: dict[str, Any]) -> dict[str, Any]:
    nodes = []
    found: set[str] = set()
    for node in ast.parse(read(path), filename=str(path)).body:
        selected = ({node.name} if isinstance(node, (ast.ClassDef, ast.FunctionDef)) else
                    {target.id for target in node.targets if isinstance(target, ast.Name)}
                    if isinstance(node, ast.Assign) else set())
        if selected & names:
            need(selected <= names, 'AST extraction included unnamed binding')
            nodes.append(node)
            found.update(selected)
    need(found == names, 'exact original AST extraction names')
    tree = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), *nodes], type_ignores=[])
    exec(compile(ast.fix_missing_locations(tree), str(path), 'exec'), namespace)
    return namespace


def tick() -> None:
    need(STATE['started_s'] <= time.monotonic() < STATE['started_s'] + 115, 'original120s qualification reserve exhausted')


def observer(image: Path, mount: Path) -> dict[str, object]:
    return {'image': str(image), 'mount': str(mount), 'read_only': True, 'capacity_bytes': 8589934592}


def inventory() -> dict[str, int]:
    structured = logs = files = 0
    for path in ROOT.rglob('*'):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        need(stat.S_ISREG(info.st_mode), 'nonregular qualification evidence')
        files += 1
        if path.name.endswith('.log'):
            logs += info.st_size
        else:
            structured += info.st_size
    need(structured + logs <= 2097152 and logs <= 65536, 'whole0294root2MiB/64KiB cap')
    return {'structured_bytes': structured, 'log_bytes': logs, 'total_bytes': structured + logs, 'files': files}


def setup() -> None:
    tick()
    scope = json.loads(read(ROOT / 'scope.json', 65536))
    need(scope['stage'] == 'F18.24' and scope['base_revision'] == BASE and scope['focused_artificial_invocations_max'] == 1, 'fixed current scope')
    manifest_path = ROOT / 'candidate-source-pins.json'
    candidate = json.loads(read(manifest_path, 65536))
    need(candidate['schema'] == 'ariadna.f18.full-owner-binding-candidate-pins.v1'
         and candidate['recipes_only_before_first_invocation'] is True, 'frozen recipe-only candidate manifest')
    actual = {str(path) for path in CANDIDATES.rglob('*') if path.is_file()}
    need(set(candidate['files']) == actual and str(Path(__file__)) in actual, 'exact candidate cohort')
    for name, expected in candidate['files'].items():
        need(pin(Path(name)) == expected, 'candidate source drift: ' + name)
    review_pin = candidate['source_review_pin']
    need(path_pin(Path(review_pin['path'])) == review_pin, 'independent static review pin')
    review = json.loads(read(Path(review_pin['path'])))
    need(review['status'] == 'PASS' and not review.get('findings'), 'independent candidate review required')
    need(not ARTIFICIAL.exists(), 'qualification namespace is once only')
    ARTIFICIAL.mkdir()

    class NoScientificRuntime(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname: str, path: object = None, target: object = None) -> None:
            if any(fullname == item or fullname.startswith(item + '.') for item in FORBIDDEN):
                raise ImportError('artificial qualification forbids scientific runtime: ' + fullname)
    need(not any(name == item or name.startswith(item + '.') for name in sys.modules for item in FORBIDDEN), 'scientific runtime already loaded')
    sys.meta_path.insert(0, NoScientificRuntime())
    sys.path.insert(0, str(REPO / 'src'))
    from space_nav import _owner_endpoint_fixture as producer
    need(Path(producer.__file__).resolve() == REPO / 'src/space_nav/_owner_endpoint_fixture.py', 'original fixture module path')
    adapter = load('f1824_adapter_reference', CANDIDATES / 'controls/supervisor-adapter.py')
    for name, expected in adapter._SOURCE_PINS.items():
        need(pin(Path(name)) == expected, 'original project source pin')
    STATE['producer'] = producer
    retained = json.loads(read(CANDIDATES / 'runtime-contract.json', 65536))
    fixture_test = REPO / 'tests/test_owner_endpoint_fixture.py'
    expected_sources = retained['old_source_pins'] | retained['appended_source_pins']
    need(pin(fixture_test) == expected_sources[str(fixture_test)], 'original fixture-test extraction source pin')
    os.environ['PYTHONPATH'] = str(REPO / 'src')
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    STATE['fixture'] = select(REPO / 'tests/test_owner_endpoint_fixture.py',
        {'_INITIAL', '_END', '_METADATA', '_PROPAGATED', 'Results', 'Owner', '_factory'},
        {'producer': producer, 'SimpleNamespace': SimpleNamespace})
    STATE['caller'] = load('f1824_retained_caller', CANDIDATES / 'controls/call-once.py')
    STATE['durability'] = select(CANDIDATES / 'controls/run-once.py', {'check_aggregate', 'sync_directories'},
        {'Path': Path, 'os': os, 'stat': stat, 'time': time})
    for name in ('prepare-actual.py', 'review-actual.py', 'invoke-once.py'):
        STATE[name] = load('f1824_' + name.replace('-', '_'), CANDIDATES / 'operators' / name)
    STATE['admission'] = load('f1824_admission', CANDIDATES / 'controls/admission.py')
    STATE['gate'] = load('f1824_gate', CANDIDATES / 'dispatch-once.py')
    STATE['fixtures'] = load('f1824_material', CANDIDATES / 'harness-fixtures.py')
    STATE['candidate_pin'] = path_pin(manifest_path)
    STATE['case_returns'] = []
    STATE['candidate_files'] = candidate['files']
    tick()


REVIEW_CHILD = r'''
import importlib.util,json,pathlib,sys,time
path=pathlib.Path(sys.argv[1]);reference=json.loads(pathlib.Path(sys.argv[3]).read_bytes())
spec=importlib.util.spec_from_file_location('actual_independent_artificial_review',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def observer(image,mount):return {'image':str(image),'mount':str(mount),'read_only':True,'capacity_bytes':8589934592}
x=m.review(sys.argv[2],artificial_root=pathlib.Path(sys.argv[4]),artificial_reference=reference,artificial_observer=observer)
print(json.dumps(x,sort_keys=True,allow_nan=False),flush=True)
'''
ENTRY_CHILD = r'''
import importlib.abc,importlib.util,json,pathlib,sys
class Guard(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if any(fullname==x or fullname.startswith(x+'.') for x in ('tudatpy','numpy','scipy','spiceypy')):raise ImportError('artificial child forbids scientific runtime')
sys.meta_path.insert(0,Guard());path=pathlib.Path(sys.argv[1]);profile_path=pathlib.Path(sys.argv[2]);started=float(sys.argv[3]);commands=json.loads(pathlib.Path(sys.argv[4]).read_bytes());fault=sys.argv[5]
spec=importlib.util.spec_from_file_location('actual_full_owner_entry' if fault!='adapter-finalization' else 'actual_full_owner_adapter',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
try:
 if fault=='adapter-finalization':
  original=m.directory_sync
  def failed(directory):
   if directory.name=='native-packet':raise OSError('injected changed-adapter finalization failure')
   return original(directory)
  m.directory_sync=failed
  p=json.loads(profile_path.read_bytes());x=m.collect(p,pathlib.Path(p['work_directory'])/'native-packet',started,artificial_commands=commands)
 else:x=m.run(profile_path,started,artificial_commands=commands)
except (RuntimeError,OSError,ValueError,TypeError,KeyError) as e:x={'status':'failed','mode':'artificial','failure':type(e).__name__+': '+str(e)[:1024],'finalization':'unavailable','native_authority':False}
print(json.dumps(x,sort_keys=True,allow_nan=False),flush=True)
raise SystemExit(0 if x.get('status')=='passed' and x.get('finalization')=='checked-after-fsync' else 2)
'''


def seal(case: Path, started: float, *, accepted: bool) -> float:
    limit = 60 if accepted else 65
    deadline = started + limit
    STATE['durability']['check_aggregate'](case, deadline)
    STATE['durability']['sync_directories'](case, deadline)
    put(case / 'harness-observation.json', {'status': 'PENDING_DURABLE_READBACK', 'original_started_s': started,
        'elapsed_before_write_s': time.monotonic() - started, 'injected_success_intended': accepted, 'native_authority': False})
    STATE['durability']['check_aggregate'](case, deadline)
    STATE['durability']['sync_directories'](case, deadline)
    elapsed = time.monotonic() - started
    need(0 <= elapsed < limit, 'actual post-file/directory-fsync packet clock exhausted')
    STATE['case_returns'].append({'case': str(case), 'accepted_injected': accepted, 'elapsed_after_final_fsync_s': elapsed})
    inventory()
    tick()
    return elapsed


def genuine_packet(started: float, *, partial: bool = False) -> dict[str, Any]:
    factory = STATE['fixture']['_factory']
    if partial:
        original = factory
        def factory(arc_id: str, simulate: bool, budget: Any) -> object:
            if simulate:
                raise RuntimeError('first injected factory defect')
            return original(arc_id, simulate, budget)
    packet = STATE['producer'].produce(factory=factory, budget=STATE['producer'].Budget(started))
    need(packet['mode'] == 'injected', 'genuine artificial fixture mode')
    return packet


def episode(case: Path, profile: dict[str, Any], *, packet: dict[str, Any] | None = None,
            partial: bool = False) -> tuple[float, Path]:
    started = time.monotonic()
    # Durable original start precedes genuine generation, cold entry, and all work.
    put(case / 'episode-start.json', {'schema': 'ariadna.f18.native-start.v1', 'started_s': started,
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'preflight_elapsed_s': started - profile['preflight_started_s'],
        'deadline_s': started + 60, 'profile_sha256': pin(case / 'profile.json')['sha256'], 'retry_authorized': False})
    Path(profile['work_directory']).mkdir()
    value = genuine_packet(started, partial=partial) if packet is None else packet
    packet_path = case / 'injected-packet.json'
    put(packet_path, value, cap=1048576)
    put(case / 'artificial-commands.json', {'packet': path_pin(packet_path)})
    return started, packet_path


def entry(case: Path, profile: dict[str, Any], started: float, *, supplied_start: float | None = None,
          fault: str = '', isolated: bool = True, label: str = 'entry') -> tuple[dict[str, Any], dict[str, Any]]:
    source = CANDIDATES / 'controls' / ('supervisor-adapter.py' if fault else 'native-entry.py')
    argv = [sys.executable, '-I', '-B', '-c', ENTRY_CHILD, str(source), str(case / 'profile.json'),
            repr(started if supplied_start is None else supplied_start), str(case / 'artificial-commands.json'), fault]
    put(case / (label + '-command.json'), {'argv': argv, 'original_watchdog_started_s': started, 'mode': 'artificial'})
    if isolated:
        report, output = STATE['caller'].supervise(argv, Path(profile['work_directory']), started, seconds=60)
    else:
        child = subprocess.run(argv, capture_output=True, timeout=min(5, started + 60 - time.monotonic()), check=False)
        need(not child.stderr, 'unisolated refusal itself failed')
        report, output = {'returncode': child.returncode, 'failure': None, 'groups': {}}, child.stdout
    need(len(output) <= 2048, 'entry output2048B reservation')
    put(case / (label + '.stdout.json'), output, raw=True)
    put(case / (label + '-caller-return.json'), report)
    actual = json.loads(output) if output else {}
    return report, actual


def clone_entry_case(name: str, mutate: Any = None, *, partial: bool = False,
                     packet_mutate: Any = None) -> tuple[Path, dict[str, Any], float]:
    case = ARTIFICIAL / name
    case.mkdir()
    profile = copy.deepcopy(STATE['positive_profile'])
    profile.update(root=str(case), work_directory=str(case / 'execution'))
    # Entry-only artificial role fixtures are deliberately not admission proofs.
    # The full connected positive and eight-group admission tests keep real fake-
    # cohort bytes; these unused fields need no repeated 30KiB metadata copies.
    profile['source_pins'] = {str(case / ('fabricated-source-' + str(i))):
                              {'qualification': 'ARTIFICIAL_ENTRY_ONLY'} for i in range(53)}
    for field in ('native_pins', 'ledger_pins', 'history_member_pins', 'control_pins',
                  'history_archive', 'contract', 'execution_decision'):
        profile[field] = {}
    profile['resource_pins'] = []
    put(case / 'entry-only-scope.json', {'qualification': 'ARTIFICIAL_ENTRY_ONLY', 'admission_claim': False,
        'fabricated_source_metadata_rows': 53, 'executing_original3_identity': 'separate actual source pins',
        'full_connected_and_eight_group_admission_fixtures_changed': False})
    if mutate is not None:
        mutate(profile)
    put(case / 'profile.json', profile)
    packet = copy.deepcopy(STATE['positive_packet']) if not partial else None
    if packet_mutate is not None:
        packet_mutate(packet)
    started, _ = episode(case, profile, packet=packet, partial=partial)
    return case, profile, started


class Wiring(unittest.TestCase):
    def test_01_real_prepare_review_invoke_gate_entry_and_original_audit(self) -> None:
        case = ARTIFICIAL / 'connected'
        material, reference = STATE['fixtures'].create_material(case, CANDIDATES)
        self.assertEqual(material[3], reference)
        root = Path(reference.get('root', str(case / 'episode')))
        def command(argv: list[str], *, timeout: float = 30) -> bytes:
            self.assertGreater(timeout, 0)
            self.assertEqual(argv, [reference['outer_python']['path'], '-I', '-B', str(root / 'check-preservation.py'), 'before'])
            put(root / 'operational-before.json', {'schema': 'ariadna.f18.operational-preservation.v1', 'status': 'ARTIFICIAL_READY',
                'phase': 'before', 'manifest_equal': True, 'differences': [], 'native_authority': False})
            return b''
        prep = STATE['prepare-actual.py']
        ready = prep.prepare(BASE, artificial_root=root, artificial_material=material,
                             artificial_observer=observer, artificial_command=command)
        self.assertEqual(ready['status'], 'ARTIFICIAL_READY_FOR_INDEPENDENT_REVIEW')
        self.assertFalse((root / 'execution-decision.json').exists())
        put(case / 'review-reference.json', reference)
        argv = [sys.executable, '-I', '-B', '-c', REVIEW_CHILD,
                str(Path(reference['operator_directory']) / 'review-actual.py'), BASE,
                str(case / 'review-reference.json'), str(root)]
        preflight_started = json.loads(read(root / 'preflight-start.json'))['started_s']
        put(case / 'review-command.json', {'argv': argv, 'preflight_original_started_s': preflight_started})
        child = subprocess.run(argv, capture_output=True, timeout=min(15, STATE['started_s'] + 115 - time.monotonic()), check=False)
        self.assertEqual(child.returncode, 0, child.stderr[:2048])
        self.assertFalse(child.stderr)
        self.assertLessEqual(len(child.stdout), 32768)
        actual_review = json.loads(child.stdout)
        self.assertEqual(actual_review['status'], 'PASS_INDEPENDENT_REVIEW')
        self.assertEqual(actual_review['mode'], 'artificial')
        self.assertIs(actual_review['native_authority'], False)
        put(root / 'independent-review-tool.stdout.json', child.stdout, raw=True)
        put(root / 'independent-review-tool-return.json', {'returncode': child.returncode, 'stderr_bytes': len(child.stderr)})
        inv = STATE['invoke-once.py']
        with self.assertRaises((RuntimeError, OSError, ValueError, KeyError)):
            inv.invoke(BASE, artificial_root=root, artificial_reference=reference, artificial_observer=observer, artificial_dispatch=lambda: self.fail('pending disk review dispatched'))
        self.assertFalse((root / 'execution-decision.json').exists())
        put(root / 'independent-review-observation.json', {'schema': 'ariadna.f18.full-owner-review-observation.v1',
            'returncode': child.returncode, 'reviewer_return': actual_review, 'observed_s': time.monotonic()})
        # These are deliberately mutable artificial proof inputs, before once-only
        # consumption. Preserve every tested bad version, then restore exact bytes;
        # the real cold review/observation is never fabricated or rebound.
        def refuse_changed(name: str, path: Path, change: Any, reason: str) -> None:
            original = read(path, 65536)
            changed = change(original)
            put(case / (name + '.input.json'), changed, raw=True)
            def replace(raw: bytes) -> None:
                with path.open('wb') as stream:
                    self.assertEqual(stream.write(raw), len(raw)); stream.flush(); os.fsync(stream.fileno())
                STATE['durability']['sync_directories'](root, STATE['started_s'] + 115)
            try:
                replace(changed)
                with self.assertRaisesRegex(RuntimeError, reason) as failure:
                    inv.invoke(BASE, artificial_root=root, artificial_reference=reference,
                        artificial_observer=observer, artificial_dispatch=lambda: self.fail('bad proof dispatched'))
                self.assertFalse((root / 'execution-decision.json').exists())
                put(case / (name + '.refusal.json'), {'original_pin': {'bytes': len(original), 'sha256': hashlib.sha256(original).hexdigest()},
                    'tested_input_pin': path_pin(case / (name + '.input.json')), 'failure': str(failure.exception),
                    'native_authority': False, 'actual_review_unchanged': True})
            finally:
                replace(original)
            self.assertEqual(read(path), original)
        def altered(raw: bytes, **changes: Any) -> bytes:
            return encoded(dict(json.loads(raw), **changes))
        for name, value, reason in [('future-preflight', time.monotonic() + 5, 'original strict600s'),
                                    ('expired-preflight', time.monotonic() - 601, 'original strict600s'),
                                    ('reset-preflight', time.monotonic(), 'explicit pending artificial decision')]:
            refuse_changed(name, root / 'preflight-start.json', lambda raw, value=value: altered(raw, started_s=value), reason)
        refuse_changed('profile-identity', root / 'profile.json', lambda raw: raw + b'\n', 'review binding drift: profile_sha256')
        refuse_changed('decision-identity', root / 'execution-decision-draft.json',
            lambda raw: altered(raw, base_revision='0' * 40), 'review binding drift: execution_decision_sha256')
        refuse_changed('gate-identity', root / 'dispatch-once.py', lambda raw: raw + b'\n', 'outer gate source drift')
        profile = json.loads(read(root / 'profile.json'))
        STATE['positive_profile'] = profile
        dispatches = []
        def dispatch() -> dict[str, Any]:
            dispatches.append(True)
            started, packet_path = episode(root, profile)
            STATE['positive_packet'] = json.loads(read(packet_path))
            caller, result = entry(root, profile, started)
            passed = caller['returncode'] == 0 and caller['failure'] is None and result.get('status') == 'passed'
            elapsed = seal(root, started, accepted=passed)
            return {'status': 'passed' if passed else 'failed', 'returncode': caller['returncode'], 'stdout': result,
                    'finalization': 'checked-after-fsync' if passed else 'failed-after-fsync', 'elapsed_s': elapsed, 'native_authority': False}
        terminal = inv.invoke(BASE, artificial_root=root, artificial_reference=reference, artificial_observer=observer, artificial_dispatch=dispatch)
        self.assertEqual(len(dispatches), 1)
        self.assertEqual(terminal.get('status'), 'passed')
        self.assertEqual(terminal.get('finalization'), 'checked-after-fsync')
        self.assertIs(terminal.get('native_authority'), False)
        audit = json.loads(read(root / 'execution/native-packet/audit.json'))
        self.assertEqual((audit['schema'], audit['mode'], audit['calls_checked'], audit['analytic_arcs_checked']), ('ariadna-owner-audit-v1', 'injected', 8, 2))
        self.assertEqual(json.loads(read(root / 'execution/runner-result.json'))['producer_mode'], 'injected')
        self.assertEqual(json.loads(read(root / 'execution-decision.json'))['status'], 'ARTIFICIAL_EXECUTION_DECISION')
        self.assertNotEqual(json.loads(read(root / 'admission-check.json'))['status'], 'PASS_NATIVE_ADMISSION_ONLY')
        produce = json.loads(read(root / 'execution/produce-command-before-dispatch.json'))
        audited = json.loads(read(root / 'execution/audit-command-before-dispatch.json'))
        self.assertEqual(produce['packet_pin'], path_pin(root / 'injected-packet.json'))
        self.assertIs(audited['audit_argv_unchanged'], True)
        self.assertEqual(audited['original_argv'][:5], [sys.executable, '-m', 'space_nav._owner_endpoint_run', '--worker', 'audit'])
        with self.assertRaises((RuntimeError, OSError, ValueError, KeyError)):
            inv.invoke(BASE, artificial_root=root, artificial_reference=reference, artificial_observer=observer, artificial_dispatch=lambda: self.fail('duplicate dispatch'))
        STATE['positive_root'] = root
        STATE['reference'] = reference
        STATE['terminal'] = terminal

    def test_02_missing_native_choice_and_cli_override_refuse_before_access(self) -> None:
        for name in ('prepare-actual.py', 'review-actual.py', 'invoke-once.py'):
            function = getattr(STATE[name], {'prepare-actual.py': 'prepare', 'review-actual.py': 'review', 'invoke-once.py': 'invoke'}[name])
            with self.assertRaisesRegex(RuntimeError, 'choice|authority|available'):
                function(BASE)
        native_read_calls = []
        for module, function in [(STATE['admission'], STATE['admission'].admit),
                                 (STATE['gate'], STATE['gate'].dispatch)]:
            original_read = module._read
            def forbidden_read(*args: Any, **kwargs: Any) -> bytes:
                native_read_calls.append(str(args[0]))
                self.fail('missing-choice path reached a file reader')
            module._read = forbidden_read
            try:
                with self.assertRaisesRegex(RuntimeError, 'choice|available'):
                    function(Path('/private/tmp/ariadna-f18-full-owner-v1/profile.json'))
            finally:
                module._read = original_read
        native_entry = load('f1824_native_choice_entry', CANDIDATES / 'controls/native-entry.py')
        original_profile_reader = native_entry._read_profile
        native_entry._read_profile = forbidden_read
        try:
            with self.assertRaisesRegex(RuntimeError, 'choice|available'):
                native_entry.run(Path('/private/tmp/ariadna-f18-full-owner-v1/profile.json'), time.monotonic())
        finally:
            native_entry._read_profile = original_profile_reader
        self.assertEqual(native_read_calls, [])
        argv = [sys.executable, '-I', '-B', str(CANDIDATES / 'controls/native-entry.py'), '--artificial', 'missing', 'extra']
        child = subprocess.run(argv, capture_output=True, timeout=5, check=False)
        self.assertNotEqual(child.returncode, 0)
        self.assertIn(b'profile and original clock only', child.stderr)
        self.assertLessEqual(len(child.stderr), 2048)
        put(ARTIFICIAL / 'native-refusals.json', {'operators_missing_choice_refused': True, 'admission_missing_choice_refused': True,
            'native_cli_returncode': child.returncode, 'native_cli_stderr': child.stderr.decode(), 'guarded_native_reader_calls': native_read_calls})

    def test_03_entry_schema_mode_interpreter_and_source_pin_refusals(self) -> None:
        variants = [('entry-schema', lambda p: p.update(schema='completed-old'), 'full-owner entry profile'),
                    ('entry-mode', lambda p: p.update(mode='native'), 'native forbids'),
                    ('entry-pin', lambda p: p.update(entry_sha256='0' * 64), 'entry source pin'),
                    ('entry-interpreter', lambda p: p['outer_python'].update(path='/usr/bin/python3'), 'interpreter identity'),
                    ('old-ten-key-input', lambda p: p.update(fixture_input={str(i): 'old' for i in range(10)}), 'two-key fixture input'),
                    ('entry-wrong-root', lambda p: p.update(root='/private/tmp/ariadna-f18-full-owner-v1'), 'artificial prefix')]
        for name, mutation, reason in variants:
            with self.subTest(name=name):
                case, profile, started = clone_entry_case(name, mutation)
                caller, result = entry(case, profile, started)
                self.assertNotEqual(caller['returncode'], 0)
                self.assertIn(reason, result.get('failure', ''))
                self.assertFalse((case / 'execution/native-packet').exists())
                seal(case, started, accepted=False)

    def test_04_real_original_future_expired_and_reset_clock_refusals(self) -> None:
        for name, offset in [('future-clock', 5), ('expired-clock', -61), ('reset-clock', 0)]:
            case, profile, started = clone_entry_case(name)
            supplied = time.monotonic() + offset
            caller, result = entry(case, profile, started, supplied_start=supplied)
            self.assertNotEqual(caller['returncode'], 0)
            self.assertIn('clock' if offset else 'episode/start/profile binding', result.get('failure', ''))
            self.assertFalse((case / 'execution/native-packet').exists())
            seal(case, started, accepted=False)

    def test_05_group_and_duplicate_entry_refuse(self) -> None:
        case, profile, started = clone_entry_case('unisolated')
        _, result = entry(case, profile, started, isolated=False)
        self.assertIn('isolated session', result.get('failure', ''))
        self.assertFalse((case / 'execution/supervisor.pgid').exists())
        seal(case, started, accepted=False)
        root = STATE['positive_root']; profile = STATE['positive_profile']
        started = json.loads(read(root / 'episode-start.json'))['started_s']
        before = {str(p.relative_to(root / 'execution')): pin(p) for p in (root / 'execution').rglob('*') if p.is_file()}
        caller, result = entry(root, profile, started, label='duplicate-entry')
        self.assertNotEqual(caller['returncode'], 0)
        self.assertEqual(before, {str(p.relative_to(root / 'execution')): pin(p) for p in (root / 'execution').rglob('*') if p.is_file()})

    def test_06_wrong_count_uses_real_independent_auditor(self) -> None:
        case, profile, started = clone_entry_case('wrong-count', packet_mutate=lambda p: p['counts'].update(visitor_calls=10))
        _, result = entry(case, profile, started)
        self.assertNotEqual(result.get('status'), 'passed')
        self.assertEqual(read(case / 'execution/native-packet/audit.json'), b'')
        self.assertIn(b'counts.visitor_calls', read(case / 'execution/native-packet/audit.stderr.log', 63488))
        self.assertEqual(json.loads(read(case / 'execution/runner-result.json'))['workers'][-1]['kind'], 'audit')
        seal(case, started, accepted=False)

    def test_07_first_failed_fixture_retains_partial_without_audit(self) -> None:
        case, profile, started = clone_entry_case('first-partial', partial=True)
        _, result = entry(case, profile, started)
        partial = json.loads(read(case / 'execution/native-packet/producer.json'))
        self.assertIn('first injected factory defect', partial['failure'])
        self.assertEqual((len(partial['calls']), partial['counts']['integration_attempts']), (1, 1))
        self.assertNotEqual(result.get('status'), 'passed')
        self.assertFalse((case / 'execution/native-packet/audit.json').exists())
        seal(case, started, accepted=False)

    def test_08_adapter_finalization_failure_never_passes(self) -> None:
        case, profile, started = clone_entry_case('adapter-finalization')
        _, result = entry(case, profile, started, fault='adapter-finalization')
        self.assertEqual(result.get('status'), 'failed')
        self.assertEqual(result.get('finalization'), 'failed-after-fsync')
        self.assertIn('changed-adapter finalization failure', result.get('failure', ''))
        self.assertEqual(json.loads(read(case / 'execution/native-packet/audit.json'))['status'], 'passed')
        seal(case, started, accepted=False)

    def test_09_schema_and_byte_limits_refuse_without_worker(self) -> None:
        case, profile, started = clone_entry_case('wrong-producer-schema', packet_mutate=lambda p: p.update(schema='wrong'))
        _, result = entry(case, profile, started)
        self.assertIn('injected fixture schema/mode', result.get('failure', ''))
        self.assertFalse((case / 'execution/native-packet').exists())
        seal(case, started, accepted=False)
        case, profile, started = clone_entry_case('profile-overbound')
        path = case / 'profile.json'; old = read(path)
        put(case / 'profile-before-overbound.json', old, raw=True)
        with path.open('ab') as stream:
            stream.write(b' ' * (65537 - len(old))); stream.flush(); os.fsync(stream.fileno())
        _, result = entry(case, profile, started)
        self.assertIn('64KiB cap', result.get('failure', ''))
        self.assertFalse((case / 'execution/native-packet').exists())
        seal(case, started, accepted=False)


    def test_10_all_eight_admission_pin_groups_and_readonly_are_checked(self) -> None:
        root = ARTIFICIAL / 'admission-refusals'
        root.mkdir()
        profile = copy.deepcopy(STATE['positive_profile'])
        profile.update(root=str(root), work_directory=str(root / 'execution'),
                       sandbox_profile=str(root / 'native.sandbox'), prelaunch_admission=str(root / 'launch-admission.json'))
        old_controls = profile['control_pins']
        profile['control_pins'] = {}
        for old_path, expected in old_controls.items():
            name = Path(old_path).name
            put(root / name, read(CANDIDATES / 'controls' / name, 65536), raw=True)
            profile['control_pins'][str(root / name)] = expected
        put(root / 'dispatch-once.py', read(CANDIDATES / 'dispatch-once.py', 65536), raw=True)
        profile['outer_gate'] = path_pin(root / 'dispatch-once.py')
        groups = ('source_pins', 'native_pins', 'resource_pins', 'ledger_pins',
                  'history_member_pins', 'control_pins', 'history_archive', 'contract')
        for field in groups:
            with self.subTest(field=field):
                changed = copy.deepcopy(profile)
                if field in ('history_archive', 'contract'):
                    changed[field]['sha256'] = '0' * 64
                elif field == 'resource_pins':
                    changed[field] = changed[field][:-1]
                else:
                    changed[field].pop(next(iter(changed[field])))
                path = root / (field + '.json')
                put(path, changed)
                with self.assertRaises((RuntimeError, OSError, ValueError, KeyError)):
                    STATE['admission'].admit(path, artificial_observer=observer)
                self.assertFalse((root / 'admission-check.json').exists())
        path = root / 'readonly.json'
        put(path, profile)
        def writable(image: Path, mount: Path) -> dict[str, object]:
            return dict(observer(image, mount), read_only=False)
        with self.assertRaisesRegex(RuntimeError, 'readonly'):
            STATE['admission'].admit(path, artificial_observer=writable)
        self.assertFalse((root / 'admission-check.json').exists())
        put(root / 'refusal-summary.json', {'eight_groups_checked': list(groups), 'readonly_false_refused': True,
            'native_authority': False, 'shared_fake_metadata_only': True})
        inventory(); tick()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--started-s', required=True, type=float)
    args = parser.parse_args()
    need(math.isfinite(args.started_s) and 0 <= time.monotonic() - args.started_s < 115, 'original pre-cold-import root clock')
    STATE['started_s'] = args.started_s
    setup()
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Wiring))
    log = stream.getvalue().encode()
    need(len(log) <= 32768, 'bounded readable qualification log')
    put(ARTIFICIAL / 'unittest.log', log, raw=True)
    tick()
    sizes = inventory()
    need(not any(name == item or name.startswith(item + '.') for name in sys.modules for item in FORBIDDEN), 'scientific runtime imported')
    record = {'schema': 'ariadna.f18.full-owner-binding-qualification.v1', 'stage': 'F18.24', 'base_revision': BASE,
        'status': 'PENDING_DURABLE_READBACK', 'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'test_success_observed': result.wasSuccessful(), 'candidate_pin': STATE['candidate_pin'],
        'case_observed_returns': STATE['case_returns'], 'started_s': args.started_s,
        'elapsed_before_report_s': time.monotonic() - args.started_s, 'byte_counters_before_report': sizes,
        'previous194case_and3helper_tests_repeated': False, 'native_authority': False, 'physical_admission': 'unavailable',
        'scope': 'Artificial metadata/observer + genuine injected fixture only; actual unchanged guarded auditor, no native execution',
        'completion_requires_root_observed_return': True, 'exitcode': 0 if result.wasSuccessful() else 2}
    put(ROOT / 'qualification-result.json', record)
    STATE['durability']['check_aggregate'](ROOT, args.started_s + 115)
    STATE['durability']['sync_directories'](ROOT, args.started_s + 115)
    need(json.loads(read(ROOT / 'qualification-result.json')) == record, 'final report readback mismatch')
    sizes = inventory(); tick()
    print(json.dumps({'status': 'PASS_INJECTED_QUALIFICATION' if result.wasSuccessful() else 'FAILED_INJECTED_QUALIFICATION',
        'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'elapsed_after_report_directory_fsync_s': time.monotonic() - args.started_s,
        'report_pin': path_pin(ROOT / 'qualification-result.json'), 'byte_counters': sizes, 'native_authority': False}, sort_keys=True), flush=True)
    return 0 if result.wasSuccessful() else 2


if __name__ == '__main__':
    raise SystemExit(main())
