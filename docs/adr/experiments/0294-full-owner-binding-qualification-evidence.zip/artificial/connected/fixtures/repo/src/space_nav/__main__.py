# ARTIFICIAL-NONEXECUTABLE-SOURCE 1 src/space_nav/__main__.py
