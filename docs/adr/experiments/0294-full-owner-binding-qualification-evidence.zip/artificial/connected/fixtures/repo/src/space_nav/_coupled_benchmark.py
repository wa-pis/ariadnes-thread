# ARTIFICIAL-NONEXECUTABLE-SOURCE 2 src/space_nav/_coupled_benchmark.py
