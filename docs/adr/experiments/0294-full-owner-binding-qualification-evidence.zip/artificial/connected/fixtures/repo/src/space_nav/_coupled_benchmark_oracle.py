# ARTIFICIAL-NONEXECUTABLE-SOURCE 3 src/space_nav/_coupled_benchmark_oracle.py
