# ARTIFICIAL-NONEXECUTABLE-SOURCE 4 src/space_nav/_coupled_benchmark_run.py
