# ARTIFICIAL-NONEXECUTABLE-SOURCE 5 src/space_nav/_coupled_bridge.py
