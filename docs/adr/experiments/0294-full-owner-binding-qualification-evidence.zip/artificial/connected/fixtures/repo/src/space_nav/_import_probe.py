# ARTIFICIAL-NONEXECUTABLE-SOURCE 6 src/space_nav/_import_probe.py
