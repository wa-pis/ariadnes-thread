# ARTIFICIAL-NONEXECUTABLE-SOURCE 7 src/space_nav/_import_probe_audit.py
