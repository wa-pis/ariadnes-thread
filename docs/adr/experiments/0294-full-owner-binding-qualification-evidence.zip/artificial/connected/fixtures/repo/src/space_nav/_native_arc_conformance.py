# ARTIFICIAL-NONEXECUTABLE-SOURCE 8 src/space_nav/_native_arc_conformance.py
