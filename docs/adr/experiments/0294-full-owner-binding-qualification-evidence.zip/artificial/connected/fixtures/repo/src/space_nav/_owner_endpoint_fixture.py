# ARTIFICIAL-NONEXECUTABLE-SOURCE 12 src/space_nav/_owner_endpoint_fixture.py
