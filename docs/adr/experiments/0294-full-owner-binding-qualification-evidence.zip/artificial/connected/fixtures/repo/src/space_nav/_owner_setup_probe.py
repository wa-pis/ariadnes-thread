# ARTIFICIAL-NONEXECUTABLE-SOURCE 15 src/space_nav/_owner_setup_probe.py
