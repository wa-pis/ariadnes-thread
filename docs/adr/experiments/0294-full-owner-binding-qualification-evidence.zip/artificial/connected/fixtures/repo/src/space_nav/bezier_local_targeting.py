# ARTIFICIAL-NONEXECUTABLE-SOURCE 18 src/space_nav/bezier_local_targeting.py
