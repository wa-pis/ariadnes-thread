# ARTIFICIAL-NONEXECUTABLE-SOURCE 26 src/space_nav/explorer_ui.py
