# ARTIFICIAL-NONEXECUTABLE-SOURCE 27 src/space_nav/local_burn.py
