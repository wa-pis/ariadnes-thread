# ARTIFICIAL-NONEXECUTABLE-SOURCE 42 tests/test_import_probe.py
