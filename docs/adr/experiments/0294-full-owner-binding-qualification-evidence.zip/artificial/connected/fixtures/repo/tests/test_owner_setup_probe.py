# ARTIFICIAL-NONEXECUTABLE-SOURCE 48 tests/test_owner_setup_probe.py
