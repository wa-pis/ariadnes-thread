"""Tiny explicit artificial metadata; never retained native resources or authority."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
import sys
from typing import Any
import zipfile

ROOT = Path('/private/tmp/ariadna-f18-0294')
ARTIFICIAL = ROOT / 'artificial'
REPO = Path('/Users/agrudin/dev/my/ariadna')
OPERATORS = ('prepare-actual.py', 'review-actual.py', 'invoke-once.py', 'test-operator-wiring.py')
CONTROLS = ('call-once.py', 'launch-once.py', 'native.sandbox', 'check-preservation.py',
            'run-once.py', 'native-entry.py', 'supervisor-adapter.py', 'admission.py')


def encoded(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, allow_nan=False) + '\n').encode()


def pin(raw: bytes) -> dict[str, Any]:
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def put(path: Path, raw: bytes) -> dict[str, Any]:
    assert path.is_relative_to(ARTIFICIAL) and '..' not in path.parts
    assert len(raw) <= 65536
    path.parent.mkdir(parents=True, exist_ok=True)
    for parent in [*reversed(path.parent.parents), path.parent]:
        assert parent.is_dir() and not parent.is_symlink()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, 'wb', closefd=False) as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(fd)
    finally:
        os.close(fd)
    assert path.read_bytes() == raw
    return pin(raw)


def create_material(case: Path, candidate_dir: Path) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """Build one tiny fake53/10/11/25/86 cohort, with actual frozen control bytes."""
    assert case.is_absolute() and case.is_relative_to(ARTIFICIAL) and case != ARTIFICIAL
    assert candidate_dir == ROOT / 'candidates' and not case.exists()
    case.mkdir(parents=True)
    original = json.loads((candidate_dir / 'runtime-contract.json').read_bytes())
    repo = case / 'fixtures/repo'
    mount = case / 'fixtures/mount'
    resources = mount / 'home/.tudat/resource'
    image = case / 'fixtures/fake.sparseimage'
    operator_dir = case / 'fixtures/operator'
    for directory in (repo, resources, operator_dir):
        directory.mkdir(parents=True)
    put(image, b'ARTIFICIAL-NOT-A-DISK-IMAGE\n')

    def sources(group: dict[str, Any]) -> dict[str, Any]:
        rows: dict[str, Any] = {}
        for index, name in enumerate(sorted(group)):
            relative = Path(name).relative_to(REPO)
            path = repo / relative
            # Metadata is visibly fabricated; genuine executing original3 source
            # identities are verified separately by the unmodified candidate adapter.
            rows[str(path)] = put(path, f'# ARTIFICIAL-NONEXECUTABLE-SOURCE {index} {relative}\n'.encode())
        return rows

    old = sources(original['old_source_pins'])
    appended = sources(original['appended_source_pins'])
    native: dict[str, Any] = {}
    for index in range(10):
        path = case / 'fixtures/native' / f'artificial-{index}.bin'
        native[str(path)] = put(path, f'ARTIFICIAL-NONEXECUTABLE-{index}\n'.encode())
    kernel_path = next(iter(native))
    ledgers: dict[str, Any] = {}
    for index in range(25):
        path = case / 'fixtures/ledgers' / f'ledger-{index}.json'
        ledgers[str(path)] = put(path, encoded({'qualification': 'ARTIFICIAL', 'index': index}))
    resource_rows: list[dict[str, Any]] = []
    for index, row in enumerate(original['retained_resources']):
        raw = f'ARTIFICIAL-NONRESOURCE-{index}\n'.encode()
        resource_rows.append({'name': row['name'], **put(resources / row['name'], raw)})
    executable = Path(sys.executable).resolve()
    assert str(executable) == '/opt/homebrew/Caskroom/miniforge/base/envs/space-nav/bin/python3.12'
    # Dedicated known-executable identity reader; never the2MiB evidence reader.
    fd = os.open(executable, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_size == 6829984 and before.st_size <= 16777216
        digest = hashlib.sha256()
        remaining = before.st_size
        while remaining:
            data = os.read(fd, min(1048576, remaining))
            assert data
            digest.update(data)
            remaining -= len(data)
        after = os.fstat(fd)
        assert not os.read(fd, 1)
        assert before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns
        interpreter_pin = {'path': str(executable), 'bytes': before.st_size, 'sha256': digest.hexdigest()}
    finally:
        os.close(fd)
    assert interpreter_pin['bytes'] == 6829984
    assert interpreter_pin['sha256'] == '795d8316b7dabff1c64e56d5f5787caf0fe1b1e18580d34fc3a4956d501475c2'
    environment = {'LANG': 'C', 'LC_ALL': 'C', 'PYTHONDONTWRITEBYTECODE': '1',
                   'PYTHONNOUSERSITE': '1', 'PYTHONSAFEPATH': '1',
                   'PYTHONPATH': str(REPO / 'src'), 'PATH': '/usr/bin:/bin'}
    reference: dict[str, Any] = {'repo': str(repo), 'mount': str(mount), 'image': str(image),
        'resource_directory': str(resources), 'outer_python': interpreter_pin,
        'private_python': str(executable), 'environment': environment,
        'kernel_sha256': native[kernel_path]['sha256'], 'probe_input': {'kernel_path': kernel_path},
        'operator_directory': str(operator_dir), 'manifest_path': str(operator_dir / 'operator-pins.json')}
    members: dict[str, bytes] = {}
    for index, name in enumerate(sorted(original['historical_0280_member_pins'])):
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        members[name] = encoded(reference) if name == 'profile.json' else f'ARTIFICIAL-HISTORY-{index}\n'.encode()
    archive_path = case / 'fixtures/history.zip'
    # Zip construction occurs only inside the frozen artificial invocation.
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in members.items():
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
    with archive_path.open('rb') as stream:
        os.fsync(stream.fileno())
    archive_raw = archive_path.read_bytes()
    assert len(archive_raw) <= 65536 and sum(map(len, members.values())) <= 2097152
    contract = {'schema': original['schema'], 'qualification': 'ARTIFICIAL',
        'old_source_pins': old, 'appended_source_pins': appended, 'native_pins': native,
        'historical_ledger_pins': ledgers, 'historical_0280_member_pins': {name: pin(raw) for name, raw in members.items()},
        'retained_resources': resource_rows, 'environment_unchanged': environment,
        'reference_archive': {'path': str(archive_path), **pin(archive_raw)},
        'reference_profile_pin': pin(members['profile.json']), 'retained_resource_directory': str(resources),
        'fixture_input': original['fixture_input'], 'fixed_contract': original['fixed_contract'],
        'limits': original['limits'], 'artificial_kernel_path': kernel_path}
    controls = {name: (candidate_dir / 'controls' / name).read_bytes() for name in CONTROLS}
    controls['dispatch-once.py'] = (candidate_dir / 'dispatch-once.py').read_bytes()
    operator_pins = {str(operator_dir / name): put(operator_dir / name, (candidate_dir / 'operators' / name).read_bytes())
                     for name in OPERATORS}
    put(operator_dir / 'operator-pins.json', encoded({'schema': 'ariadna.f18.full-owner-operator-pins.v1', 'files': operator_pins}))
    assert len(old) == 49 and len(appended) == 4 and len(native) == 10
    assert len(ledgers) == 25 and len(members) == 86 and len(resource_rows) == 11
    raw = encoded(contract)
    assert len(raw) <= 65536
    put(case / 'fixture-recipe.json', encoded({'schema': 'ariadna.f18.artificial-metadata-recipe.v1',
        'qualification': 'ARTIFICIAL', 'native_authority': False, 'reference': reference,
        'groups': [49, 4, 10, 11, 25, 86], 'executed_original_source_cohort': 'separately verified by adapter',
        'fake_native_payload_total_bytes': sum(row['bytes'] for row in native.values()),
        'fake_resource_total_bytes': sum(row['bytes'] for row in resource_rows)}))
    return (raw, contract, controls, reference), reference
