"""Saved-result/links/protected-history checks only; no runtime or test execution."""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import os
import re
import subprocess
import zipfile

R=Path('/Users/agrudin/dev/my/ariadna');P=Path('/private/tmp/ariadna-f18-0294')
BASE='d2f37e724b4a36751c39cd62fc9931dca38e651f';NAME='0294-full-owner-binding-qualification'
changed={'CURRENT_STATE.md','docs/adr/README.md','openspec/ROADMAP.md','openspec/changes/refine-physical-trajectory/tasks.md','openspec/changes/refine-physical-trajectory/design.md','openspec/changes/refine-physical-trajectory/specs/research-trajectory-experiment/spec.md'}
new={'docs/adr/0294-qualify-full-owner-bindings.md','docs/adr/experiments/'+NAME+'.json','docs/adr/experiments/'+NAME+'-evidence.zip'}
proof='docs/adr/experiments/0294-doc-verification.json'
def pin(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def git(*argv):return subprocess.check_output(['git',*argv],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==BASE and git('branch','--show-current')=='dev'
assert not git('diff','--cached','--name-only')
assert set(git('diff','--name-only').splitlines())==changed
assert set(git('ls-files','--others','--exclude-standard').splitlines())==new
protected=0
for row in subprocess.check_output(['git','ls-tree','-rz','--full-tree',BASE],cwd=R).split(b'\0'):
 if not row:continue
 metadata,name=row.split(b'\t',1);name=name.decode()
 if name in changed:continue
 raw=(R/name).read_bytes()
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==metadata.decode().split()[2],name
 protected+=1
result=json.loads((R/'docs/adr/experiments'/ (NAME+'.json')).read_bytes());archive=R/'docs/adr/experiments'/result['archive']['name']
assert pin(archive.read_bytes())=={k:result['archive'][k] for k in ('bytes','sha256')}
with zipfile.ZipFile(archive) as z:
 names=z.namelist();assert len(names)==len(set(names))==result['archive']['members'] and z.testzip() is None
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
 expanded=sum(i.file_size for i in z.infolist());assert expanded==result['archive']['expanded_bytes']<=2097152
 d={}
 for n in names:
  raw=z.read(n)
  if not n.endswith('.json') or not raw:continue
  try:d[n]=json.loads(raw)
  except ValueError:
   assert n=='artificial/connected/gate-identity.input.json',n
   assert raw==z.read('candidates/dispatch-once.py')+b'\n'

 scope,freeze,review,post=(d[n] for n in ('scope.json','candidate-source-pins.json','candidate-code-review-final.json','post-run-evidence-review.json'))
 assert scope['stage']=='F18.24' and scope['base_revision']==BASE and scope['scientific_free_variables']==[]
 assert review['status']==post['status']=='PASS' and not review['findings'] and not post['findings']
 assert len(freeze['files'])==18 and review['file_pins']==freeze['files']
 for path,expected in freeze['files'].items():assert pin(z.read(str(Path(path).relative_to(P))))==expected,path
 assert set(freeze['files'])=={str(P/n) for n in names if n.startswith('candidates/')}
 assert pin(z.read('candidate-code-review-final.json'))=={k:freeze['source_review_pin'][k] for k in ('bytes','sha256')}
 assert pin(z.read('run-qualified-harness.py'))=={k:freeze['external_wrapper_pin'][k] for k in ('bytes','sha256')}
 assert pin(z.read('candidates/runtime-contract.json'))==result['runtime_mapping_pin']
 transforms=d['control-transformations.json'];old='inputs/retained-0286/episode/'
 for name in ('call-once.py','launch-once.py','run-once.py','native.sandbox','check-preservation.py'):
  before=z.read(old+name);after=z.read('candidates/controls/'+name)
  assert pin(before)==transforms[name]['old'] and pin(after)==transforms[name]['new']
  if name in ('call-once.py','launch-once.py'):assert after==before
  else:
   expected=before.replace(b'/private/tmp/ariadna-f18-forward-completed-v1',b'/private/tmp/ariadna-f18-full-owner-v1')
   if name=='run-once.py':expected=expected.replace(b'ariadna.f18.completed-caller-tool-observation.v1',b'ariadna.f18.full-owner-caller-tool-observation.v1')
   assert after==expected,name
 runtime=d['candidates/runtime-contract.json'];assert runtime['schema']=='ariadna.f18.full-owner-control-mapping.v1'
 assert [len(runtime[k]) for k in ('old_source_pins','appended_source_pins','native_pins','retained_resources','historical_ledger_pins','historical_0280_member_pins')]==[49,4,10,11,25,86]
 assert runtime['fixture_input']=={'schema':'ariadna-owner-fixture-input-v1','scope':'synthetic-owner-conformance-only'}
 for name in ('_owner_endpoint_run.py','_owner_endpoint_fixture.py','_owner_endpoint_audit.py'):
  expected=runtime['old_source_pins'][str(R/'src/space_nav'/name)]
  assert pin(z.read('inputs/original-source/'+name))==expected
  assert pin((R/'src/space_nav'/name).read_bytes())==expected
 tool=d['tool-result.json'];obs=json.loads(tool['output']);ext=d['external-invocation.json'];q=d['qualification-result.json']
 assert result['actual_tool_return']==tool and tool['exit_code']==ext['exit_code']==0
 assert obs['status']=='PASS' and obs['observed_after_external_receipt_fsync_s']==1.079061333090067<120
 assert ext['failure'] is None and ext['stderr_bytes']==0 and not ext['cleanup']['errors']
 assert ext['status']=='PENDING_EXTERNAL_OBSERVATION_FSYNC' and q['status']=='PENDING_DURABLE_READBACK'
 assert obs['stdout']['tests_run']==q['tests_run']==10 and obs['stdout']['failures']==q['failures']==0 and obs['stdout']['errors']==q['errors']==0
 assert q['test_success_observed'] is True and q['previous194case_and3helper_tests_repeated'] is False
 assert pin(z.read('qualification-result.json'))=={k:obs['stdout']['report_pin'][k] for k in ('bytes','sha256')}
 assert obs['whole_root']=={'files':419,'structured_bytes':1958289,'log_bytes':1560}
 assert len(q['case_observed_returns'])==16
 assert all(0<=row['elapsed_after_final_fsync_s']<(60 if row['accepted_injected'] else 65) for row in q['case_observed_returns'])
 log=z.read('artificial/unittest.log');assert log.count(b'... ok')==10 and b'Ran 10 tests' in log and b'\nOK\n' in log
 a=d['artificial/connected/episode/execution/native-packet/audit.json']
 assert (a['status'],a['mode'],a['calls_checked'],a['analytic_arcs_checked'],a['physical_admission'])==('passed','injected',8,2,'unavailable')
 terminal=d['artificial/connected/episode/artificial-operator-terminal.json']
 assert terminal['status']=='PENDING_DURABLE_ARTIFICIAL_FINALIZATION' and terminal['finalization']=='pending-outer-readback'
 assert terminal['gate_return']['native_launch_authorized'] is False
 assert result['temporary_artificial_bindings_qualified'] is True and result['new_native_authority'] is False
 assert result['physical_admission']=='unavailable' and not result['runtime_tests_ci_dependencies_changed']
 assert d['static-closure-observed-return.json']['elapsed_after_closure_fsync_s']==1413.7336331247352<1800
links=anchors=0
for name in sorted(changed|{n for n in new if n.endswith('.md')}):
 for dest in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(R/name).read_text()):
  dest=dest.strip('<>')
  if '://' in dest or dest.startswith(('mailto:','data:')):continue
  file,_,frag=dest.partition('#');target=((R/name).parent/unquote(file)).resolve() if file else R/name
  if not target.exists():assert target==R/proof,(name,dest)
  links+=1
  if frag and target.suffix=='.md':
   titles=re.findall(r'^#{1,6}\s+(.+?)\s*$',target.read_text(),re.M)
   slugs={re.sub(r'[^\w\- ]','',t.strip().lower().replace('`','')).replace(' ','-') for t in titles}
   assert unquote(frag) in slugs,(name,dest);anchors+=1
assert len((R/'CURRENT_STATE.md').read_text().splitlines())<60
assert '- [x] F18.24 ' in (R/'openspec/changes/refine-physical-trajectory/tasks.md').read_text()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
v=subprocess.run(['openspec','validate','refine-physical-trajectory','--strict'],cwd=R,capture_output=True,text=True,timeout=60)
assert v.returncode==0,v.stdout+v.stderr
out={'schema':'ariadna.f18.full-owner-binding-documentary-check.v1','status':'PASS','base_revision':BASE,
 'protected_prior_blobs':protected,'local_links':links,'anchors':anchors,'archive_members':len(names),'archive_expanded_bytes':expanded,
 'strict_openspec':{'exit_code':v.returncode,'stdout':v.stdout,'stderr':v.stderr},
 'checked_files':{name:pin((R/name).read_bytes()) for name in sorted(changed|new)},
 'unchanged_full_suite_repeated':False,'new_scientific_native_work':False,'native_admission':'DEFERRED; artificial qualification only'}
with(P/'doc-checks.json').open('x') as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps({k:v for k,v in out.items() if k!='checked_files'}))
