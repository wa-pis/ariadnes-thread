from pathlib import Path
p=Path('/private/tmp/ariadna-f18-0294/candidates/operators/review-actual.py')
s=p.read_text()
s=s.replace("QUALIFIED_PIN = {'bytes': 392115, 'sha256': 'ce42d3dee1f176fa0f7efe62ba4b7f9a836e7487ae0bda356a2813abbfc7ff1b'}", "QUALIFIED_PIN = None  # Future native qualification is explicitly deferred.")
s=s.replace("CHOICE_SHA = 'dc308cb3beb4cfabca1eecf89b9156938c062b1399b18bb92a02f84b85251ef9'", "CHOICE_SHA = None  # Consumed prior choices are not full-owner authority.")
a=s.index('def _review_native(')
b=s.index("    output = ROOT / 'independent-preflight-review.json'",a)
s=s[:a]+'''def review(base: str, *, artificial_root: Path | None = None,
           artificial_reference: dict[str, object] | None = None,
           artificial_observer: Callable[[Path, Path], dict[str, object]] | None = None) -> dict[str, object]:
    """Independently read back an explicitly artificial episode; native is deferred."""
    if artificial_root is None:
        need(artificial_reference is None and artificial_observer is None,
             'native artificial overrides forbidden before live reads')
        raise ReviewError('distinct native choice and full-owner qualification are deferred')
    need(type(base) is str and re.fullmatch('[0-9a-f]{40}', base) is not None, 'full artificial base label')
    need(type(artificial_reference) is dict and callable(artificial_observer), 'explicit harmless reviewer inputs')
    artificial = True
    ROOT = artificial_root
    need(ROOT.is_absolute() and '..' not in ROOT.parts and ROOT.is_relative_to(ARTIFICIAL_ROOT)
         and ROOT != ARTIFICIAL_ROOT, 'fixed artificial reviewer namespace')
    REPO = Path(artificial_reference['repo'])
    PREP = Path(artificial_reference['operator_directory'])
    need(all(path.is_absolute() and path.is_relative_to(ARTIFICIAL_ROOT) and '..' not in path.parts
             for path in (REPO, PREP)), 'fixed harmless reference paths')
''' + s[b:]
s=s.replace("    _clean_git(base, tick)\n    choice_sha = _committed_authority(base, helper, tick)\n    qualified_path = REPO / 'docs/adr/experiments/0284-completed-control-qualification-evidence.zip'\n    helper._pin(qualified_path, QUALIFIED_PIN, tick)\n    qualified_raw = helper._read(qualified_path, 2097152)\n    with zipfile.ZipFile(io.BytesIO(qualified_raw)) as packet:\n        controls_raw = {name: packet.read('controls/' + name) for name in helper.CONTROL_NAMES | {'dispatch-once.py'}}", "    choice_sha = None  # Honest artificial provenance, never a user/native authority.\n    candidates = Path('/private/tmp/ariadna-f18-0294/candidates')\n    controls_raw = {name: helper._read(candidates / 'controls' / name)\n                    for name in helper.CONTROL_NAMES}\n    controls_raw['dispatch-once.py'] = helper._read(candidates / 'dispatch-once.py')")
s=s.replace("contract_path == ROOT / 'mapping-v2.json'", "contract_path == ROOT / 'binding-contract.json'")
s=s.replace("draft['stage'] == NATIVE_EXECUTION_STAGE", "draft['stage'] == 'F18.24_ARTIFICIAL_ONLY'")
s=s.replace("prospective_raw = encoded(dict(draft, status='ADMITTED_ONCE'))", "prospective_raw = encoded(dict(draft, status='ARTIFICIAL_EXECUTION_DECISION'))")
s=s.replace("and sum(row['bytes'] for row in rows) == 3710549, 'exact11 retained resource rows'", ", 'exact11 retained resource rows'")
s=s.replace("    for name in ('_owner_endpoint_run.py', '_owner_endpoint_fixture.py', '_owner_endpoint_audit.py'):\n        need(str(REPO / 'src/space_nav' / name) in expected_source, 'full-owner source absent')\n    kernel_path = history['probe_input']['kernel_path']", "    kernel_path = contract['artificial_kernel_path']")
s=s.replace("and operational['status'] == 'passed'", "and operational['status'] == 'ARTIFICIAL_READY' and operational.get('native_authority') is False")
s=s.replace("and operational['differences'] == [] and operational['baseline_file_sha256'] == BASELINE_SHA", "and operational['differences'] == []")
s=s.replace("ready['status'] == 'READY_FOR_INDEPENDENT_REVIEW'", "ready['status'] == 'ARTIFICIAL_READY_FOR_INDEPENDENT_REVIEW'")
s=s.replace("ready['resource_bytes'] == 3710549", "ready['resource_bytes'] == sum(row['bytes'] for row in rows)")
s=s.replace("    _clean_git(base, tick)\n", "")
s=s.replace("'resources': 11, 'resource_bytes': 3710549, 'read_only_observation'", "'resources': 11, 'resource_bytes': sum(row['bytes'] for row in rows), 'read_only_observation'")
s=s.replace("'physical_admission': 'unavailable', 'mode': profile['mode']}", "'physical_admission': 'unavailable', 'mode': profile['mode'], 'native_authority': False}")
s=s.replace("'mode': profile['mode'], 'native_calls': 0, 'live_decision_written': False}", "'mode': profile['mode'], 'native_calls': 0, 'live_decision_written': False, 'native_authority': False}")
p.write_text(s)
